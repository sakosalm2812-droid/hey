# Workstream 30 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_30_Personal_Life_Systems_Health_Finance_Travel_Home_Relationships_Life_Ad.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 30 Personal Life Systems Health Finance Travel Home Relationships Life Ad

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Home / dashboard, Health / legal / science informational support.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0669: Active project overview
- BIBLE-0670: Current mission
- BIBLE-0671: Tasks
- BIBLE-0672: Calendar
- BIBLE-0673: Weather
- BIBLE-0674: Prayer information
- BIBLE-0675: Usage
- BIBLE-0676: System health
- BIBLE-0677: Reminders
- BIBLE-0678: Quick actions
- BIBLE-0679: Recent files/artifacts
- BIBLE-0680: Recommendations
- BIBLE-0681: Add Widget
- BIBLE-0682: Personalized layout
- BIBLE-1442: Health information
- BIBLE-1443: Medical research support
- BIBLE-1444: Legal information support
- BIBLE-1445: Science research
- BIBLE-1446: Engineering support
- BIBLE-1447: Data analysis
- BIBLE-1448: Statistics
- BIBLE-1449: Visualization
- BIBLE-1450: Documentation/compliance support

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
