# Workstream 37 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_37_Security_Hardening_AI_Firewall_Secrets_Software_Supply_Chain.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 37 Security Hardening AI Firewall Secrets Software Supply Chain

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Security and Trust Center.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1277: Fail-closed permission model
- BIBLE-1278: Authentication security
- BIBLE-1279: Authorization security
- BIBLE-1280: Supabase RLS
- BIBLE-1281: Least privilege
- BIBLE-1282: Explicit high-risk confirmations
- BIBLE-1283: Audit logs
- BIBLE-1284: Secret isolation
- BIBLE-1285: Prompt-injection resistance
- BIBLE-1286: Minimum-context sharing
- BIBLE-1287: Agent self-authorization prevention
- BIBLE-1288: Trust Center
- BIBLE-1289: Mic-status control
- BIBLE-1290: Camera-status control

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
