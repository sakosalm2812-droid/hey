# Workstream 11 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_11_Computer_Use_Browser_GUI_Filesystem_OS_Control.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 11 Computer Use Browser GUI Filesystem OS Control

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Computer control, Browser control.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0562: Pointer movement
- BIBLE-0563: Click
- BIBLE-0564: Double-click
- BIBLE-0565: Right-click
- BIBLE-0566: Drag
- BIBLE-0567: Scroll
- BIBLE-0568: Keyboard typing
- BIBLE-0569: Keyboard shortcuts
- BIBLE-0570: App launching
- BIBLE-0571: Window management
- BIBLE-0572: Multi-monitor control
- BIBLE-0573: Process control
- BIBLE-0574: File operations
- BIBLE-0575: Clipboard actions
- BIBLE-0591: Open websites
- BIBLE-0592: Search web
- BIBLE-0593: Navigate pages
- BIBLE-0594: Tab control
- BIBLE-0595: Click web controls
- BIBLE-0596: Type into forms
- BIBLE-0597: Select menu items
- BIBLE-0598: Scroll pages
- BIBLE-0599: Upload files
- BIBLE-0600: Download files
- BIBLE-0601: Extract data
- BIBLE-0602: Summarize pages
- BIBLE-0603: Compare pages
- BIBLE-0604: Research from pages

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
