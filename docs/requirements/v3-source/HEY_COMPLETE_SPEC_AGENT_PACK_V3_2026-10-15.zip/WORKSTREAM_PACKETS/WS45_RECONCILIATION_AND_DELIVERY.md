# Workstream 45 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_45_Domain_Expert_Packs_High_Stakes_Specialization_Knowledge_Certification.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 45 Domain Expert Packs High Stakes Specialization Knowledge Certification

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Knowledge transformation.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0448: Source → summary
- BIBLE-0449: Source → notes
- BIBLE-0450: Source → presentation
- BIBLE-0451: Source → worksheet
- BIBLE-0452: Source → flashcards
- BIBLE-0453: Source → quiz
- BIBLE-0454: Source → audio explanation
- BIBLE-0455: Source → visual explainer
- BIBLE-0456: Source → mind map
- BIBLE-0457: Source → teacher edition
- BIBLE-0458: Source → student edition
- BIBLE-0459: Source → exam
- BIBLE-0460: Source → answer key
- BIBLE-0461: Universal “Turn this into…” workflow

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
