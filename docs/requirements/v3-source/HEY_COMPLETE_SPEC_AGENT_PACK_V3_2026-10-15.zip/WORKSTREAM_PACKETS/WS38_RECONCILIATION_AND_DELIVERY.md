# Workstream 38 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_38_Observability_Telemetry_Diagnostics_Owner_Console.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 38 Observability Telemetry Diagnostics Owner Console

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Observability and quality, Diagnostics and reliability.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1382: Structured error logging
- BIBLE-1383: Provider health visibility
- BIBLE-1384: API failure visibility
- BIBLE-1385: Cost visibility
- BIBLE-1386: Abuse visibility
- BIBLE-1387: Mission tracing
- BIBLE-1388: Tool tracing
- BIBLE-1389: Correlation IDs
- BIBLE-1390: Action receipts
- BIBLE-1391: Regression tests
- BIBLE-1392: Integration tests
- BIBLE-1393: Contract tests
- BIBLE-1394: E2E tests
- BIBLE-1395: Visual regression
- BIBLE-1353: HEY Health
- BIBLE-1354: Provider diagnostics
- BIBLE-1355: Database diagnostics
- BIBLE-1356: Supabase diagnostics
- BIBLE-1357: Auth diagnostics
- BIBLE-1358: Cosmos diagnostics
- BIBLE-1359: Microphone diagnostics
- BIBLE-1360: Speaker diagnostics
- BIBLE-1361: Camera diagnostics
- BIBLE-1362: Wake-word diagnostics
- BIBLE-1363: Notification diagnostics
- BIBLE-1364: Tauri/native diagnostics
- BIBLE-1365: OS diagnostics
- BIBLE-1366: Browser diagnostics

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
