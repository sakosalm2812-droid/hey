# Workstream 42 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_42_Platform_Native_Adapters_PWA_Android_iOS_Windows_macOS_Linux_Wearables.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 42 Platform Native Adapters PWA Android iOS Windows macOS Linux Wearables

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** PWA and install.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1317: Install HEY PWA
- BIBLE-1318: Web App Manifest
- BIBLE-1319: Service worker
- BIBLE-1320: Offline shell
- BIBLE-1321: Standalone PWA experience
- BIBLE-1322: PWA icons
- BIBLE-1323: Maskable icons
- BIBLE-1324: beforeinstallprompt flow where supported
- BIBLE-1325: Manual-install guidance where needed
- BIBLE-1326: Deep linking
- BIBLE-1327: App shortcuts
- BIBLE-1328: Safe update flow
- BIBLE-1329: Update notifications
- BIBLE-1330: Download page

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
