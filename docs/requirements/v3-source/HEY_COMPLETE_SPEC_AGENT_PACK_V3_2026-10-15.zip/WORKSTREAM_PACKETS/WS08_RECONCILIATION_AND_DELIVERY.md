# Workstream 08 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_08_HEY_Prompt_08_Tool_Action_Fabric_Universal_Command_Protocol_and_Verification.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 08 HEY Prompt 08 Tool Action Fabric Universal Command Protocol and Verification

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Cross-device and Device Fabric.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1072: Windows support
- BIBLE-1073: macOS support
- BIBLE-1074: Linux support
- BIBLE-1075: Android support
- BIBLE-1076: iOS support using legitimate APIs
- BIBLE-1077: Tablet support
- BIBLE-1078: TV/projector support
- BIBLE-1079: Wearable support where integrated
- BIBLE-1080: Vehicle support where integrated
- BIBLE-1081: Smart-home integrations
- BIBLE-1082: Device discovery
- BIBLE-1083: Device pairing
- BIBLE-1084: Device trust
- BIBLE-1085: Device roles

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
