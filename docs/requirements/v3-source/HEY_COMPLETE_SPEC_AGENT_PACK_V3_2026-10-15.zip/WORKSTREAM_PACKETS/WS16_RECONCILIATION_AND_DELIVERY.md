# Workstream 16 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_16_Voice_Live_Multimodal_Wake_Word_Real_Time_Interaction.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 16 Voice Live Multimodal Wake Word Real Time Interaction

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Voice system, HEY Live, Core HEY identity and interaction.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0490: Wake word “HEY”
- BIBLE-0491: Voice activity detection
- BIBLE-0492: Speech interruption / barge-in
- BIBLE-0493: Listening state
- BIBLE-0494: Thinking state
- BIBLE-0495: Speaking state
- BIBLE-0496: Deep British male voice direction
- BIBLE-0497: Voice-language detection
- BIBLE-0498: Voice translation
- BIBLE-0499: Voice summarization
- BIBLE-0500: Voice personality adaptation
- BIBLE-0501: Voice command execution
- BIBLE-0502: Background wake-word support where platform allows
- BIBLE-0503: Mute/unmute
- BIBLE-0463: Live voice session
- BIBLE-0464: Live screen understanding
- BIBLE-0465: Live camera understanding
- BIBLE-0466: Screen + camera simultaneously
- BIBLE-0467: Active-window understanding
- BIBLE-0468: Selected-monitor understanding
- BIBLE-0469: Selected-region understanding
- BIBLE-0470: File/project context during Live
- BIBLE-0471: Pointer context
- BIBLE-0472: Live source switching
- BIBLE-0473: Multiple-monitor support
- BIBLE-0474: Live pointer overlay
- BIBLE-0475: Highlight targets
- BIBLE-0476: Outline targets
- BIBLE-0001: Text chat with HEY
- BIBLE-0002: Voice conversations with HEY
- BIBLE-0003: Switching between Chat and Voice without losing context
- BIBLE-0004: Continuous conversation history
- BIBLE-0005: Project-aware conversations
- BIBLE-0006: File-aware conversations
- BIBLE-0007: Screen-aware conversations
- BIBLE-0008: Camera-aware conversations
- BIBLE-0009: Browser-aware conversations
- BIBLE-0010: Context-aware answers
- BIBLE-0011: Memory-aware answers
- BIBLE-0012: Device-aware answers
- BIBLE-0013: Mode-aware answers
- BIBLE-0014: Time-aware answers

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
