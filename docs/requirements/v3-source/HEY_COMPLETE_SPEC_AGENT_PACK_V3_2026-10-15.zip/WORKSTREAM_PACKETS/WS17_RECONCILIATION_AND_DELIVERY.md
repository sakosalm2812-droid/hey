# Workstream 17 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_17_Zero_UI_HEY_FlowOS_Dynamic_Island_Global_Invocation_Capture.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 17 Zero UI HEY FlowOS Dynamic Island Global Invocation Capture

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Dynamic Island.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0508: Persistent native Dynamic Island
- BIBLE-0509: Works outside main HEY window where supported
- BIBLE-0510: Idle mode
- BIBLE-0511: Listening mode
- BIBLE-0512: Thinking mode
- BIBLE-0513: Speaking mode
- BIBLE-0514: Voice-call mode
- BIBLE-0515: Music/media mode
- BIBLE-0516: Generation mode
- BIBLE-0517: Research mode
- BIBLE-0518: Mission mode
- BIBLE-0519: Timer mode
- BIBLE-0520: Reminder mode
- BIBLE-0521: Upload mode

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
