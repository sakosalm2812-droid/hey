# Workstream 05 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_05_HEY_Prompt_05_HEY_Brain_Orchestration_Intent_to_Reality_Graph.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 05 HEY Prompt 05 HEY Brain Orchestration Intent to Reality Graph

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Cosmos / memory / second brain.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0085: Persistent long-term memory
- BIBLE-0086: Preference memory
- BIBLE-0087: Project memory
- BIBLE-0088: Goal memory
- BIBLE-0089: Decision memory
- BIBLE-0090: Task memory
- BIBLE-0091: People memory
- BIBLE-0092: Device memory
- BIBLE-0093: File memory
- BIBLE-0094: Artifact memory
- BIBLE-0095: Conversation memory
- BIBLE-0096: Place memory
- BIBLE-0097: Routine memory
- BIBLE-0098: Command memory

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
