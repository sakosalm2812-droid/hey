# Workstream 15 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_15_Chat_Core_Answer_Engine_Modes_Personality_Hey_Brother.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 15 Chat Core Answer Engine Modes Personality Hey Brother

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** HEY Answer Engine, Modes, Core HEY identity and interaction.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0051: Answer-first response structure
- BIBLE-0052: Dynamic response length
- BIBLE-0053: Evidence-backed answers
- BIBLE-0054: Citations where appropriate
- BIBLE-0055: Source-quality ranking
- BIBLE-0056: Freshness checking
- BIBLE-0057: Conflicting-source handling
- BIBLE-0058: Fact verification
- BIBLE-0059: Research synthesis
- BIBLE-0060: Hallucination reduction
- BIBLE-0061: Uncertainty detection
- BIBLE-0062: Output quality gate
- BIBLE-0063: Anti-sycophancy
- BIBLE-0064: Anti-filler behavior
- BIBLE-1194: Study Mode
- BIBLE-1195: Creator Mode
- BIBLE-1196: Coding Mode
- BIBLE-1197: Research Mode
- BIBLE-1198: Business Mode
- BIBLE-1199: Focus Mode
- BIBLE-1200: Meeting Mode
- BIBLE-1201: Presentation Mode
- BIBLE-1202: Travel Mode
- BIBLE-1203: Morning Mode
- BIBLE-1204: Late Night Mode
- BIBLE-1205: Accessibility Mode
- BIBLE-1206: Private Mode
- BIBLE-1207: Offline Mode
- BIBLE-0001: Text chat with HEY
- BIBLE-0002: Voice conversations with HEY
- BIBLE-0003: Switching between Chat and Voice without losing context
- BIBLE-0004: Continuous conversation history
- BIBLE-0005: Project-aware conversations
- BIBLE-0006: File-aware conversations
- BIBLE-0007: Screen-aware conversations
- BIBLE-0008: Camera-aware conversations
- BIBLE-0009: Browser-aware conversations
- BIBLE-0010: Context-aware answers
- BIBLE-0011: Memory-aware answers
- BIBLE-0012: Device-aware answers
- BIBLE-0013: Mode-aware answers
- BIBLE-0014: Time-aware answers

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
