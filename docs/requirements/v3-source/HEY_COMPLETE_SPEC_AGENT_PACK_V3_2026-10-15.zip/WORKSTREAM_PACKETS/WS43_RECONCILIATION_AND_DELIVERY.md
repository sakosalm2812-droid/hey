# Workstream 43 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_43_Accessibility_Localization_Internationalization_Inclusive_Interaction.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 43 Accessibility Localization Internationalization Inclusive Interaction

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Localization, Core HEY identity and interaction, Accessibility.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1238: Kurdish Sorani support
- BIBLE-1239: Kurdish Kurmanji support where implemented
- BIBLE-1240: Arabic support
- BIBLE-1241: English support
- BIBLE-1242: RTL layout
- BIBLE-1243: Locale-aware formatting
- BIBLE-1244: Pronunciation adaptation
- BIBLE-1245: Translation
- BIBLE-1246: Multilingual voice
- BIBLE-1247: Multilingual tutorials
- BIBLE-0001: Text chat with HEY
- BIBLE-0002: Voice conversations with HEY
- BIBLE-0003: Switching between Chat and Voice without losing context
- BIBLE-0004: Continuous conversation history
- BIBLE-0005: Project-aware conversations
- BIBLE-0006: File-aware conversations
- BIBLE-0007: Screen-aware conversations
- BIBLE-0008: Camera-aware conversations
- BIBLE-0009: Browser-aware conversations
- BIBLE-0010: Context-aware answers
- BIBLE-0011: Memory-aware answers
- BIBLE-0012: Device-aware answers
- BIBLE-0013: Mode-aware answers
- BIBLE-0014: Time-aware answers
- BIBLE-1226: Keyboard navigation
- BIBLE-1227: Screen-reader support
- BIBLE-1228: Focus states
- BIBLE-1229: High contrast
- BIBLE-1230: Reduced motion
- BIBLE-1231: Text scaling
- BIBLE-1232: Accessible color choices
- BIBLE-1233: Captioning
- BIBLE-1234: Voice alternatives
- BIBLE-1235: Accessibility profiles
- BIBLE-1236: Device-specific accessibility
- BIBLE-1237: RTL accessibility

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
