# Workstream 23 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_23_Documents_Spreadsheets_Presentations_Structured_Office_Artifacts.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 23 Documents Spreadsheets Presentations Structured Office Artifacts

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Presentations, Documents and books.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0405: PPTX creation
- BIBLE-0406: Presentation outlining
- BIBLE-0407: Slide narrative planning
- BIBLE-0408: Slide writing
- BIBLE-0409: Slide design
- BIBLE-0410: Visual generation
- BIBLE-0411: Diagram creation
- BIBLE-0412: Chart creation
- BIBLE-0413: Speaker notes
- BIBLE-0414: Citations
- BIBLE-0415: Theme system
- BIBLE-0416: Typography system
- BIBLE-0417: Animation/transitions
- BIBLE-0418: Presentation QA
- BIBLE-0424: DOCX creation
- BIBLE-0425: PDF creation
- BIBLE-0426: Markdown documents
- BIBLE-0427: Long-form writing
- BIBLE-0428: Book-page generation
- BIBLE-0429: Document redesign
- BIBLE-0430: Document consistency
- BIBLE-0431: Citation support
- BIBLE-0432: Structured reports
- BIBLE-0433: Manuals
- BIBLE-0434: Guides
- BIBLE-0435: Worksheets
- BIBLE-0436: Teacher editions
- BIBLE-0437: Student editions

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
