# Workstream 44 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_44_Product_Design_Premium_UX_Onboarding_Discoverability_Psychology.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 44 Product Design Premium UX Onboarding Discoverability Psychology

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Navigation and discoverability.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0685: Conversation Surface as default sign-in destination
- BIBLE-0686: Chat/Voice switcher
- BIBLE-0687: Primary navigation
- BIBLE-0688: Create hub
- BIBLE-0689: Projects
- BIBLE-0690: Cosmos
- BIBLE-0691: Research
- BIBLE-0692: Files
- BIBLE-0693: Tasks/Missions
- BIBLE-0694: Automations
- BIBLE-0695: Widgets
- BIBLE-0696: Explore More
- BIBLE-0697: Add capability
- BIBLE-0698: Pin capability

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
