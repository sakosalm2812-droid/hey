# Workstream 24 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_24_Visual_Design_Image_Creation_Canvas_Semantic_Point_Editing.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 24 Visual Design Image Creation Canvas Semantic Point Editing

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Image editing, Video generation and editing, Image generation.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0267: Brightness adjustment
- BIBLE-0268: Exposure adjustment
- BIBLE-0269: Contrast adjustment
- BIBLE-0270: Saturation adjustment
- BIBLE-0271: Hue adjustment
- BIBLE-0272: Temperature adjustment
- BIBLE-0273: Tint adjustment
- BIBLE-0274: Highlights adjustment
- BIBLE-0275: Shadows adjustment
- BIBLE-0276: Sharpening
- BIBLE-0277: Blur
- BIBLE-0278: Denoising
- BIBLE-0279: Crop
- BIBLE-0280: Rotate
- BIBLE-0334: Text-to-video
- BIBLE-0335: Image-to-video
- BIBLE-0336: Frame-to-video
- BIBLE-0337: First/last-frame video generation
- BIBLE-0338: Storyboard-to-video
- BIBLE-0339: Video continuation
- BIBLE-0340: B-roll generation
- BIBLE-0341: Product video generation
- BIBLE-0342: UI-demo video generation
- BIBLE-0343: Educational video generation
- BIBLE-0344: Cinematic video generation
- BIBLE-0345: Marketing video generation
- BIBLE-0346: Shot extension
- BIBLE-0347: Camera control
- BIBLE-0232: Text-to-image
- BIBLE-0233: Image-to-image
- BIBLE-0234: Voice-to-image
- BIBLE-0235: Multiple reference images
- BIBLE-0236: Image variations
- BIBLE-0237: Transparent-background images
- BIBLE-0238: Vector-like outputs where supported
- BIBLE-0239: Icon generation
- BIBLE-0240: Logo generation
- BIBLE-0241: Poster generation
- BIBLE-0242: Diagram generation
- BIBLE-0243: UI mockup generation
- BIBLE-0244: Product visual generation
- BIBLE-0245: Educational illustration generation

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
