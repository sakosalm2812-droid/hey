# Workstream 41 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_41_Local_First_Offline_Sync_LAN_Self_Hosted_Private_Compute.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 41 Local First Offline Sync LAN Self Hosted Private Compute

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Offline and local.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1102: Local Mode
- BIBLE-1103: Local wake word
- BIBLE-1104: Local reminders
- BIBLE-1105: Local file search
- BIBLE-1106: Selected local models
- BIBLE-1107: Local computer control
- BIBLE-1108: Cached memory
- BIBLE-1109: LAN-only operation
- BIBLE-1110: Offline degradation
- BIBLE-1111: Cloud-action queueing
- BIBLE-1112: Local/cloud indicator
- BIBLE-1113: Local-only project policy
- BIBLE-1114: Privacy-based routing
- BIBLE-1115: Hardware-adaptive routing

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
