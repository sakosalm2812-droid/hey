# Workstream 21 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_21_Evolution_Engine_Continuous_R_D_Benchmarking_Safe_Self_Improvement.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 21 Evolution Engine Continuous R D Benchmarking Safe Self Improvement

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** HEY Answer Engine.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-0051: Answer-first response structure
- BIBLE-0052: Dynamic response length
- BIBLE-0053: Evidence-backed answers
- BIBLE-0054: Citations where appropriate
- BIBLE-0055: Source-quality ranking
- BIBLE-0056: Freshness checking
- BIBLE-0057: Conflicting-source handling
- BIBLE-0058: Fact verification
- BIBLE-0059: Research synthesis
- BIBLE-0060: Hallucination reduction
- BIBLE-0061: Uncertainty detection
- BIBLE-0062: Output quality gate
- BIBLE-0063: Anti-sycophancy
- BIBLE-0064: Anti-filler behavior

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
