# Workstream 02 — complete-source integration contract

**Original full engineering task:** `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_02_02_Identity_Accounts_Device_Trust.md`. You must read the full original file, not only this packet. The authoritative new source material lives in `SOURCE_SPLIT/HEY_FINAL/` and the newer refinements.

**Current working title:** HEY WORKSTREAM 02 02 Identity Accounts Device Trust

**Required shared read:** `00_V3_START_HERE.md`, `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`, `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md`, `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, original workstream prompt, specific matching original detailed source sections, and relevant model/security/frontend files.

**Source-linked historical groups to reconcile (lexical suggestions only, verify yourself):** Security and Trust Center, Cross-device and Device Fabric, Core HEY identity and interaction, Accounts and authentication.

**Example historical requirement IDs to retrieve (non-exhaustive):**
- BIBLE-1277: Fail-closed permission model
- BIBLE-1278: Authentication security
- BIBLE-1279: Authorization security
- BIBLE-1280: Supabase RLS
- BIBLE-1281: Least privilege
- BIBLE-1282: Explicit high-risk confirmations
- BIBLE-1283: Audit logs
- BIBLE-1284: Secret isolation
- BIBLE-1285: Prompt-injection resistance
- BIBLE-1286: Minimum-context sharing
- BIBLE-1287: Agent self-authorization prevention
- BIBLE-1288: Trust Center
- BIBLE-1289: Mic-status control
- BIBLE-1290: Camera-status control
- BIBLE-1072: Windows support
- BIBLE-1073: macOS support
- BIBLE-1074: Linux support
- BIBLE-1075: Android support
- BIBLE-1076: iOS support using legitimate APIs
- BIBLE-1077: Tablet support
- BIBLE-1078: TV/projector support
- BIBLE-1079: Wearable support where integrated
- BIBLE-1080: Vehicle support where integrated
- BIBLE-1081: Smart-home integrations
- BIBLE-1082: Device discovery
- BIBLE-1083: Device pairing
- BIBLE-1084: Device trust
- BIBLE-1085: Device roles
- BIBLE-0001: Text chat with HEY
- BIBLE-0002: Voice conversations with HEY
- BIBLE-0003: Switching between Chat and Voice without losing context
- BIBLE-0004: Continuous conversation history
- BIBLE-0005: Project-aware conversations
- BIBLE-0006: File-aware conversations
- BIBLE-0007: Screen-aware conversations
- BIBLE-0008: Camera-aware conversations
- BIBLE-0009: Browser-aware conversations
- BIBLE-0010: Context-aware answers
- BIBLE-0011: Memory-aware answers
- BIBLE-0012: Device-aware answers
- BIBLE-0013: Mode-aware answers
- BIBLE-0014: Time-aware answers
- BIBLE-1248: Sign up
- BIBLE-1249: Sign in
- BIBLE-1250: Email verification
- BIBLE-1251: Password reset
- BIBLE-1252: Session refresh
- BIBLE-1253: Logout
- BIBLE-1254: Returning-user resume
- BIBLE-1255: Account deletion
- BIBLE-1256: Data export
- BIBLE-1257: Server-side plan enforcement
- BIBLE-1258: Server-side entitlements
- BIBLE-1259: Founder/cofounder role without bypassing security
- BIBLE-1260: Admin-granted plans
- BIBLE-1261: Session security

**Current repository investigation:** enumerate actual code paths, feature flags, public routes, API schemas, server policies, DB tables/migrations, OS/device dependencies, runtime owners, tests, mocks/stubs, duplication and the latest verified SHA.

**Implementation goal:** finish the full original prompt plus every newer relevant amendment as a real vertical user/ops capability. For overlapping code, preserve unique strengths, safely migrate and remove redundant implementations only after independent verification.

**Evidence required:** accessible entrypoint, actual UI and backend, real provider/DB/OS when applicable, permission denial tests, cancellation/recovery, zero fake success, accessible localized UX, CI test logs, independent E2E observations, owner approval on material changes and integration branch commit.

**Do not call this task complete** until the full required scope is operational and independently tested; if external hardware/credentials are unavailable, continue independently solvable code and record precise blocked validation.
