# 05 — HEY MODEL ACQUISITION, ADAPTATION, EVALUATION & DEPLOYMENT BLUEPRINT

**Edition:** 2026-10-15 continuation. **Status:** Detailed engineering recommendation and source-verified candidate list, not a claim that the models were downloaded, trained, licensed for a particular business, or deployed. This extends `02_MODEL_FLEET_AND_TRAINING.md` and all 75 roles in `MODEL_ROLE_MATRIX.csv`. Final technical choices require measured testing and owner approval when they substantially alter product requirements or expenditures.

## 1. Vocabulary and non-negotiable separation

1. **HEY One — intelligence identity and model program:** stable HEY behavior, shared session/context, standardized input/output contracts and identity, with one or more licensed foundation checkpoints, proprietary hosted providers where authorized, tools, adapters and memory. Do not claim S&A owns a model's weights because it built an orchestration wrapper.
2. **Foundation checkpoint:** a complete downloadable set of model weights/tokenizer/config, with publisher, version, hash, license and supported inference runtime.
3. **Specialist role:** Coder, Debugger, Teacher, Editor, Visual Designer and so on — a typed task capability. A role may share a checkpoint with other roles.
4. **Fine-tuned adapter:** separately versioned learned parameters, e.g. LoRA, applied to one compatible foundation. Own adapter work does not transfer ownership of base weights.
5. **Deterministic tool:** compiler, browser, file executor, SQL engine, slide renderer, optimizer, grammar checker, mathematical library, policy engine. Models propose and interpret; verified tools perform objective work.
6. **Modality engine:** ASR, TTS, image generator, segmentation, OCR, video generator, embedding model, reranker. These often have separate model architectures and cannot all be served as a generic chat LLM.
7. **Knowledge and context:** user memory / project DNA / documents / school resources in consented RAG indexes and databases, NOT silently incorporated into training weights.

**HEY should not download or fine-tune every candidate.** The economic implementation starts with a small shared fleet and scales specialist checkpoints only after tests prove a measurable gain.

## 2. Exact candidate acquisition catalogue

**Acquisition process:** start from an original publisher model repository; examine its README/model card, license text, acceptable use, dependencies, architecture, tokenizer/chat template, storage size, supported language, precision, and inference compatibility. Record immutable revision and SHA-256/manifest. Use an isolated scanning environment for any custom Python loader. These links are *candidate publisher sources* verified as publicly listed on 2026-10-15, not production endorsements or universal rights clearance.

| Artifact / official publisher link | Task candidates | Operational notes and restrictions to validate before use |
|---|---|---|
| [Qwen3-8B](https://huggingface.co/Qwen/Qwen3-8B) | HEY One small Brain, instructor, editor, multilingual assistant, summarizer | Good shared baseline; test Sorani dialect, Arabic, English and tool calling; license and tokenizer must be checked at pinned revision |
| [Qwen3-Coder-30B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct) | Coder, code editor, debugger, tests, API, DevOps, SQL | Official card marks Apache-2.0; ~61 GB source repository, unsuitable for weak laptop full-precision inference |
| [gpt-oss-20b](https://huggingface.co/openai/gpt-oss-20b) | Reasoning, alternate HEY One checkpoint, planner, verifier | Official card marks Apache-2.0; verify exact policy/use terms and serving capability |
| [gpt-oss-120b](https://huggingface.co/openai/gpt-oss-120b) | Hosted heavyweight reasoning/evaluators | Not an 8 GB RAM laptop workload; usage-cost and provider quality gates required |
| [Qwen3-Omni-30B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-Omni-30B-A3B-Instruct) | Experimental unified multimodal language/speech/audio | Official card lists Apache-2.0; ~70 GB repository. Evaluate dedicated voice pipeline versus all-in-one model |
| [Qwen3-Embedding-0.6B](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B) | Cosmos semantic retrieval, tool retrieval, document similarity | Independently check retrieval on Sorani, Arabic, English and Romanized Kurdish; handle embedding model upgrades via reindexing |
| [BAAI/bge-m3](https://huggingface.co/BAAI/bge-m3) | Multilingual dense/hybrid memory retrieval alternative | Test query/document chunking and semantic vs lexical recall before selecting |
| [Whisper-large-v3-turbo](https://huggingface.co/openai/whisper-large-v3-turbo) | Cloud/on-device ASR as device permits, HEY Flow baseline | Measure noise, interruptions, Kurdish dialect, code-switching, specialized school terms, punctuation |
| [Kokoro-82M](https://huggingface.co/hexgrad/Kokoro-82M) | Fast economical English TTS | Test male British voice availability, voice consent, pronunciation and licensing of voices/assets separately |
| [ResembleAI/chatterbox](https://huggingface.co/ResembleAI/chatterbox) | Alternate expressive multilingual TTS | Official card lists MIT; voice-cloning capability requires authorization, consent and misuse protections |
| [pyannote/speaker-diarization-community-1](https://huggingface.co/pyannote/speaker-diarization-community-1) | Speaker turns for imported recordings when lawful | Publisher card lists CC-BY-4.0; gated agreement/contact details and attribution obligations; not needed for simple voice commands |
| [FLUX.1-schnell](https://huggingface.co/black-forest-labs/FLUX.1-schnell) | Image generation and visual asset drafting | Official model card says Apache-2.0 and commercial use allowed; large GPU needs. Do not assume dev/pro variants share this license |
| [SAM2.1 Hiera Tiny](https://huggingface.co/facebook/sam2.1-hiera-tiny) | Video/object masks, visual tracking, surgical edit support | Verify asset licenses, mask stability across frames and latency; not a complete image editor alone |
| [PaddleOCR-VL-1.5](https://huggingface.co/PaddlePaddle/PaddleOCR-VL-1.5) | Scanned worksheet/document/table/formula reading | Official card lists Apache-2.0; audit `trust_remote_code` and dependencies; verify Sorani/Arabic and math-layout accuracy |
| [Wan2.2-T2V-A14B](https://huggingface.co/Wan-AI/Wan2.2-T2V-A14B) | Experimental text-to-video and shot creation | Official card lists Apache-2.0; ~126 GB repository and parts using `.pth` pickle format, high compute and loader risk; not affordable on $50/month baseline |

Do not label unverified Qwen3-TTS, Qwen3-VL, updated Llama/Gemma/Mistral releases, video/audio/music checkpoints as approved solely by name. Create separate sourcing tickets, verify original publishers and current license at the exact revision, run tests, THEN add to approved registry. Commercial deployment must comply with both model and training-data rights; gating alone does not prove commercial rights.

### Reference acquisition commands — do not run without approved compute/storage/credentials

```bash
python -m venv .venv
# Activate .venv using your host OS's documented activation command.
python -m pip install --upgrade huggingface_hub safetensors
hf --help
# First get a lightweight original manifest/card rather than tens of gigabytes of weights.
hf download Qwen/Qwen3-8B README.md --local-dir ./model_cands/qwen3-8b-card
# Once approved, pass the pinned exact revision as --revision <COMMIT_SHA>.
hf download Qwen/Qwen3-8B --revision <VERIFIED_COMMIT_SHA> --local-dir ./model_cands/qwen3-8b-verified
```

- Replace `<VERIFIED_COMMIT_SHA>` with the actual current publisher commit obtained from the Hub; never invent a hash.
- Use the official `hf auth login` flow for explicitly gated models. Keep tokens in secret storage; never commit them to the repository or evidence logs.
- Weights and inference caches belong outside version control; retain hashes, provenance and artifact pointers.
- Reject suspicious executable model code, unexpected deserializers, symlinks or undocumented remote downloads until an independent security review.

## 3. Which model types HEY needs and how each should work

The 75-row role matrix enumerates the full logical fleet. This table groups those roles into implementation families with their canonical base architecture and training trigger.

| Family | Representative HEY roles | Initial realization | Fine-tuning/retraining threshold | Ground-truth verification |
|---|---|---|---|---|
| General Brain/reasoner | Conversation, planner, orchestrator, analyst, creative ideation, coach | Licensed Qwen3 general or hosted model + structured tools | Repeated failures on measured HEY missions that retrieval/tools cannot solve | Task completion, calibrated uncertainty, evidence/source grounding |
| Code developer | Architect, coder, code editor, debugger, test writer, security reviewer, SQL/API/DevOps | Code-specialist model + repository index, AST and compiler/test tools | Exact patch rate on untouched repositories improves under blinded benchmarks | Minimal diff, compile, tests actually executed, no unauthorized side effects |
| Text and document editor | Writing editor, proofreader, translator, summarizer, legal/academic style | General model + grammar/format/semantic-diff validators | Human-edited before/after corpus shows better scope fidelity after adaptation | Meaning preservation, changed regions, citations, format/RTL |
| Learning and teachers | Tutor, curriculum planner, worksheet/quiz generator, grading assistant | General model + approved curriculum retrieval + deterministic export | Consented, educationally reviewed examples improve learning quality beyond baseline | Correct answer key, rubric, grade/subject fit, no pupil-data leakage |
| Business/product | Strategy, finance, operations, market research, missing-requirement hunter | General model + calculator, evidence board, spreadsheet and decision graph | Specific style/workflow improvements validated on business cases | Actual numeric correctness, risk coverage, cited assumptions, source lineage |
| Retrieval + memory | Embedding, reranker, entity/decision extraction, temporal contradiction resolution | Multilingual embedding + lexical search + structured graph | Relevant-query recall unsatisfactory on representative multilingual eval | Recall@k, MRR/nDCG, privacy boundary, deletion, freshness |
| Vision/document | VLM, screen understanding, OCR, object detector, mask segmentation | OCR-specific model and licensed VLM; SAM for masks | Fine-tune narrow screenshots/handwritten content after data permissions | Bounding box overlap, document fields, table/formula parse, no false clicks |
| Image/design | Prompt designer, image generator, inpaint/restore/upscale, UI designer | Licensed image diffusion/flow API + masks, renderers, style data | Approved brand consistency dataset justifies LoRA or trained edit adapter | Mask/outside-mask preservation, identity consistency, usability and cost |
| Video/motion | Storyboard, shot scheduler, video generator, motion/title/caption editor | Structured scenes + externally priced video renderer + codecs | Licensing and budget-backed shot consistency improvement | Actual playable artifact, precise shot-locks, correct duration/export |
| Speech | VAD, wake word, ASR, voice activity, TTS, diarization | Device-efficient detector/ASR + separate expressive TTS | Noise/accent/code-switching tests expose improvement possible with data rights | WER/CER, latency, barge-in, pause, consent, language coverage |
| Native/gestures | Hand landmark detector, custom gesture recognizer, command classifier | Local MediaPipe-type landmarks + tiny temporal classifier/state machine | New custom gesture dataset outperforms thresholds reliably | False triggers per hour, FPS/latency on board, pause/stop, accidental actions |
| Safety/control | Risk detection, prompt injection evaluator, hallucination and permission critic | Deterministic policy/mandate checks plus measured detection models | Detector gap warrants training, not authorization changes | False allow rate, false deny, cross-user isolation, external proof |
| Fusion arbitration | Expert selector, model quality predictor, council synthesis, independent verifier | Deterministic/learned router + available specialist backends | Calibrated outcome labels yield demonstrated lower cost for same quality | Routing regret, cost, latency, independent task-success |

**Explicit sample specialist division:**
- **Coder:** produces new working modules or applications with repo inspection, test harnesses and dependency validation.
- **Editor:** makes minimal specified changes to existing text, documents, images, video or code; supports locks, before/after diff and rollback. Different asset types have different engines.
- **Generator:** creates an image/audio/video/document/presentation artifact with the modality-appropriate foundation and structured editors, not one universal “generator weight.”
- **Tester:** designs hard tests, but a real isolated runner is the authority on whether they passed.
- **Verifier:** independently checks postconditions and provenance; cannot rely solely on the implementer's statement.
- **Researcher:** retrieves current sources and gives traceable support rather than pretending weights store today's facts.
- **Teacher:** uses actual grade/subject/curriculum context, generates and edits lessons, quizzes, rubrics, presentations and exports.
- **Translator:** deliberately handles Sorani Kurdish (script and dialect), Kurmanji, Arabic and English, with native evaluation; never equate general multilingual marketing with real dialect proficiency.
- **Visual designer:** operates HEY brand and structured layout tokens; precise edits preserve approved regions and assets.
- **Native operator:** reads devices and executes actions through an authorized permissioned Edge adapter; no LLM has raw privileged access.

## 4. Repeatable training process — execution contract for each learned specialist

### Phase A — benchmark first

Define exact I/O JSON schema (including user intent, task type, attachments, sensitive-data scope, permitted tools, expected output contract). Select zero-shot baseline, scaffolded baseline, and candidate alternative. Prepare 100+ independent representative evaluation examples **as a recommended minimum for an initial exploratory suite, not a universal statistical guarantee**. Record dialect, device and risk coverage. Blind-test on different projects/users from training. Performance baseline must distinguish model answer quality from actual downstream action success.

### Phase B — data collection and creation

Data must have a permitted source: properly licensed public corpora; S&A-created examples; properly consented approved human edits; synthetic examples only when checked against independent real cases. Exclude school children's identifiable information, secrets, unpublished correspondence, and private records from weights unless separately legally authorized (prefer NEVER for mutable/private user facts). Preserve annotation instructions, split lineage, contamination audit, data subject rights and deletion process.

A supervised tool call is a **plan**, not evidence of execution. Use explicit `tool_proposal` and separately recorded real `tool_result` with provenance; do not train fabricated success messages. Tool results may contain untrusted text, so training examples must identify instruction versus retrieved data.

### Phase C — dataset structure

Example of a fictional (non-sensitive) code editor example:

```json
{"id":"hey-codeedit-demo-001","task_family":"code_editor","input":{"user_instruction":"Change only the label of the Save button to Save Project","repository_snapshot":"sha256:EXAMPLE_ONLY","locked_files":["src/payments.ts"]},"ideal_output":{"type":"unapplied_patch","changed_paths":["src/components/SaveButton.tsx"],"must_preserve_other_files":true},"labels":{"requires_approval":false,"security_scope":"workspace_edit_only"},"rights":{"source":"synthetic_SA_example","commercial_use_approved":true},"split":"train"}
```

Separate `chat_messages` training formulation from downstream app execution. Create task-family loaders that validate JSON schema and train/test isolation. Report rare and hazardous labels, not just aggregate accuracy.

### Phase D — adaptation selection

- **Prompt/format conditioning first:** for common style, task routing and bounded text editing; no expensive GPU training if enough.
- **RAG and tool use:** for current facts, user memory, school lesson material and exact workspace data; weights are the wrong database.
- **LoRA:** train task-specific low-rank layers when evidence shows a repeated skill gap. Recommended exploratory ranks 8–32; actual settings depend on architecture, compute, tokenizer and evaluation.
- **QLoRA:** train adapters over appropriately quantized compatible foundation weights to reduce accelerator memory demand; compatibility with selected MoE/attention architecture must be checked.
- **Distillation:** train smaller narrow models against legally and contractually permitted qualified demonstrations, using independent human/source verification and ensuring teacher/student private data is not leaked.
- **Full fine-tuning:** only for funded hardware/data and when PEFT demonstrably inadequate.
- **From-scratch pretraining:** not part of the $25–50 infrastructure plan; requires separate data, compute, safety and finance program.
- **Vision/media adapters:** use model-specific pipelines and compatible license; image LoRA does not transform into a video or TTS adapter.

### Phase E — practical reference SFT adapter sketch

This is an **illustrative implementation pattern, not an executed training run**; engineers must validate tokenizer, context, `target_modules`, GPU VRAM and current API for their actual pinned foundation.

```python
# requirements: a compatible CUDA training environment, licensed dataset, pinned package versions
# pip install transformers datasets accelerate peft trl bitsandbytes
from datasets import load_dataset
from peft import LoraConfig, TaskType
from transformers import AutoModelForCausalLM, AutoTokenizer
from trl import SFTConfig, SFTTrainer

BASE = "Qwen/Qwen3-8B"  # replace with a verified pinned model revision
REVISION = "REPLACE_WITH_VERIFIED_PUBLISHER_COMMIT"
model = AutoModelForCausalLM.from_pretrained(BASE, revision=REVISION, torch_dtype="auto")
tokenizer = AutoTokenizer.from_pretrained(BASE, revision=REVISION)
# Train file is a consented, deduplicated, prevalidated JSONL dataset of chat-formatted examples.
dataset = load_dataset("json", data_files="data/approved_train.jsonl", split="train")
peft = LoraConfig(task_type=TaskType.CAUSAL_LM, r=16, lora_alpha=32,
                  lora_dropout=0.05, target_modules="all-linear")
config = SFTConfig(output_dir="artifacts/hey_role_adapter",
                   max_length=2048, per_device_train_batch_size=1,
                   gradient_accumulation_steps=8, learning_rate=1e-4,
                   num_train_epochs=1, logging_steps=10, save_strategy="steps",
                   save_steps=100)
trainer = SFTTrainer(model=model, args=config, train_dataset=dataset,
                     processing_class=tokenizer, peft_config=peft)
trainer.train()
trainer.save_model("artifacts/hey_role_adapter")
```

The code must **not** be run as written until `REVISION`, hardware, `target_modules`, dataset format, training privacy, pinned dependencies, and training budget are reviewed. Train/dev/test separation and comparison against the original foundation are mandatory for promotion. No model should learn to execute malicious or unauthorized operations.

### Phase F — evaluation and acceptance

Run one consistent frozen evaluation bundle per task family:
1. Task correctness, real tool use and edit fidelity.
2. Faithful uncertain and negative responses instead of unsupported confident statements.
3. Multilingual English/Sorani/Arabic and appropriate code-switching.
4. Permission denial and prompt-injection challenge cases.
5. Long-context retention, contradictory history and supersession.
6. Latency p50/p95, throughput, cold start, resource draw and quality/cost ratio.
7. Reliability under 429, 500, retries, task cancel, network drop, context overflow, DB unavailability.
8. Out-of-domain and novel cases; report regressions per cohort, not only average.
9. Licensing and provenance integrity; ensure only permitted datasets used.
10. Independent evaluator reproducibility on unshared holdout cases.

Gate condition: observed task-level improvement that matters to HEY, with no material policy regression and with service unit economics staying inside spending controls. Neither a benchmark leaderboard score nor a polished answer proves mission success.

### Phase G — deployment, rollout and governance

`CANDIDATE → LICENSE_REVIEWED → BENCHMARKED → SHADOW → CANARY → APPROVED → ACTIVE → RETIRED/REVOKED`.

For each revision, record source repo+SHA, model weights hash, tokenizer/template, adapter hash, dataset/rights manifest, signed eval report, hardware/runtime, quality distribution, p95 latency, cost/use, safety/permission tests, fallback endpoint, incident contact, rollback instruction and explicit authorized approver. Version endpoints; never change an active model alias without canary + rollback.

#### Serving choice

- `vLLM` / `SGLang` / applicable high-throughput inference server for a funded CUDA GPU/managed dedicated environment; evaluate tool calling, streaming, MoE and batching compatibility.
- `llama.cpp` and `Ollama` for user opted-in local quantized model experiments where device resources are sufficient; they cannot silently monopolize RAM or force downloads.
- Usage-priced third-party inference when modest workloads make dedicated GPU uneconomic, subject to provider privacy/retention and availability review.
- Special media engines may need provider-specific asynchronous job APIs and object storage, not a chat completion endpoint.

## 5. Model registry — canonical typed schema

```json
{
  "model_id": "hey-one-general-candidate",
  "status": "BENCHMARKED",
  "base": {"publisher": "Qwen", "repo_id": "Qwen/Qwen3-8B", "revision": "ACTUAL_SHA_REQUIRED", "weights_sha256": "ACTUAL_HASH_REQUIRED", "license": "REVIEWED_LICENSE_REQUIRED"},
  "adapter": {"type": "none", "artifact_hash": null, "owner": null},
  "runtime": {"kind": "hosted_or_selfhosted", "endpoint_secret_ref": "secret_manager_reference", "supports_streaming": true, "supports_json": "TO_VERIFY", "supports_tools": "TO_VERIFY"},
  "roles": ["general_brain", "summarizer", "teacher_planner"],
  "modalities": ["text"],
  "verified_languages": [],
  "resource_budget": {"max_cost_per_request_usd": 0.01, "max_parallel_calls": 1, "p95_ms": null},
  "privacy": {"allowed_data_scopes": ["public", "user_consented"], "school_data_allowed": false},
  "evaluation": {"suite_version": "PENDING", "task_success_rate": null, "citation_precision": null, "security_false_allow_rate": null},
  "routing": {"fallback_ids": [], "circuit_breaker": true, "quality_tier": "baseline"},
  "rollout": {"approved_by": null, "promoted_at": null, "rollback_to": null}
}
```

**Contract:** Unknown means `null`/unverified, never optimistic defaults. Per-role scorecards map to actual model instance IDs. The server, not an LLM, enforces entitlements, privacy eligibility, call budgets, user authorization, output contracts and action mandates.

## 6. Cost, hardware and training honesty

- HEY's initial cloud operating budget is **$25–50/month**. The earlier provisional allocation was ~$25 Supabase Pro, ~$5 Cloudflare Workers Paid, ~$12 prepaid inference, ~$2 amortized domain and ~$5 contingency. This is a **planning proposal** requiring live vendor eligibility/pricing checks, not a purchased subscription or guaranteed hard cap.
- A several-tens-of-gigabytes model may have a small number of *active* MoE parameters, but the full total weights still require hosting/caching/storage. Active parameters do not eliminate memory, bandwidth, or total cost.
- The 8GB/older laptop needs an optional minimal companion (Edge), not a mandatory HEY One server. Use local tiny classifiers when appropriate and cloud LLM if permissioned/affordable.
- Model research, GPU rentals, training, video rendering and school pilot consumption must be budgeted separately if they exceed the $12 inference allocation. Do not auto-provision GPU servers.
- Any training plan should have an estimated per-run accelerator bill, storage/output cost, retry budget, expected benefit and stop criteria before initiation.
- Make every model route independently disableable on high cost, privacy failure, benchmark regression or provider outage.

## 7. Testable user examples for model-to-model composition

### A. Build a native application
User: “Make a functional desktop app for my school lesson planner.” HEY: identifies platform/resources → architect creates structured design → coder changes scoped repo → compile/test tools run → UI agent performs browser/native inspection → independent verifier checks install/run → document actual outputs. No “compiled” claim without tool receipt, no “deployed” claim without real URL/runtime.

### B. Edit one part of a presentation
User: “Change only the headline on slide 3; preserve every other slide.” HEY: resolves artifact version → editable document graph → model proposes exact semantic diff → deterministic renderer/exporter → compare unchanged slides 1,2,4+ and all non-target elements → produce verified export and rollback snapshot. The editing model is only one piece.

### C. Generate marketing video
User: “Generate fifteen seconds with these three product shots, and keep the approved brand text.” HEY: storyboard → scene constraints/locked assets → priced job proposal → appropriate licensed video/image engine → actual clip result → duration/content/brand verification → accessible media artifact with edit controls. Credit exhaustion checkpoints cleanly; no fake video preview.

### D. Tutoring and teaching
Teacher: “Create a Grade 8 chemistry worksheet and quiz from this approved textbook page.” HEY: parse pages → evidence-grounded lesson planner → age/level alignment → answer key fact check → worksheet/export renderer → Kurdish/English/Arabic layout if requested → teacher review → saved version. No real pupil data needed for a trial.

### E. Sorani and speech
User code-switches Kurdish/English, says “rewrite this paragraph, don't execute a command.” HEY Flow records as dictation, transcribes with confidence, applies requested edits in focused app, never routes dictated words into privileged VoiceOS commands. On lost microphone permission the stream must stop with accurate status.

## 8. Official source checks used for the 2026-10-15 candidate review

- Publisher repos: https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct ; https://huggingface.co/openai/gpt-oss-20b ; https://huggingface.co/Qwen/Qwen3-Omni-30B-A3B-Instruct ; https://huggingface.co/black-forest-labs/FLUX.1-schnell ; https://huggingface.co/Wan-AI/Wan2.2-T2V-A14B ; https://huggingface.co/ResembleAI/chatterbox ; https://huggingface.co/pyannote/speaker-diarization-community-1 ; https://huggingface.co/PaddlePaddle/PaddleOCR-VL-1.5 .
- Hugging Face LoRA/QLoRA workflow: https://huggingface.co/docs/trl/peft_integration ; official Hub model cards: https://huggingface.co/docs/hub/model-cards ; Hub CLI: https://huggingface.co/docs/huggingface_hub/guides/cli .
- Licenses and repositories **must be rechecked at an exact pinned revision at acquisition time**, not treated as immutable because this dated specification says they existed.
