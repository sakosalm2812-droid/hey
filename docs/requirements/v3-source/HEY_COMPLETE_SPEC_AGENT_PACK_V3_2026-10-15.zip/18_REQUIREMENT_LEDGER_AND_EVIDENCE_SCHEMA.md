# REQUIREMENT-TO-CODE EVIDENCE CONTRACT (APPLY TO REPOSITORY)

Implement one canonical machine-readable ledger, merge V3 machine-assisted cards with actual source sections and repo tests. All source counts are inventory counts, never percentage of implementation by themselves.

## Minimum requirement record

```json
{
 "requirement_id":"HEY-EFFECTIVE-...",
 "historical_ids":["BIBLE-0001"],
 "original_sources":[{"path":"...","anchor":"...","content_sha256":"..."}],
 "latest_amendments":[{"source":"...","decision":"approved|rejected|proposal","supersedes":"..."}],
 "effective_description":"Observable requirement explicitly reconciled with source",
 "acceptance": [{"action":"...","expected":"...","negative":"...","test_id":"..."}],
 "affected_code_paths":[],
 "entrypoints":[],
 "runtime_dependencies":[],
 "owner":"unassigned",
 "implementation_state":"SOURCE_ONLY",
 "independent_verification_state":"NOT_EXECUTED",
 "evidence":{"commit_sha":null,"test_run":null,"deployment_url":null,"device":null,"provider":null,"artifact_hash":null,"independent_reviewer":null},
 "external_blockers":[],
 "last_reviewed":"2026-10-15"
}
```

## Allowed state transitions

`SOURCE_ONLY → RECONCILED → IMPLEMENTING → IMPLEMENTED_UNVERIFIED → VERIFIED_WORKING → PRODUCTION_READY`.

A `BLOCKED_EXTERNAL` flag adds missing conditions but does not grant completion. `UNSUPPORTED_BY_PLATFORM` must include real OS evidence and supported fallback. `CONTRADICTED` requires decision revision; don't quietly choose old design. `DEPRECATED` requires source/evidence of explicit supersession.

## Evidence validator

- Do not accept raw `verified=true` fields from a feature agent. Require verifier identity, test artifacts and observed real side effect.
- A missing provider credential can block E2E; implement and test noncredential code using safe fixtures but never call mocked tests live evidence.
- Tests and source refs must resolve on the exact commit; hashes guard against stale docs.
- Developer/tester cannot edit the ledger to inflate completion without independent verification trail.
- Historical 229 agent-role entries must map to actual registered specialist roles/effective agent designs, not individual UIs.
- Cost and supported-platform evidence is per-model and per-device, not global platitude.
