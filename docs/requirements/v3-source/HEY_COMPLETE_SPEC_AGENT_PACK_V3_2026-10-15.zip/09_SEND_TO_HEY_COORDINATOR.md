# SEND THIS TO THE ACTIVE HEY DEVELOPMENT COORDINATOR

Use this exact task with the **complete updated HEY specification and agent-pack ZIP attached**. It is a source-delivery and continuous implementation directive, not a request for a new proposal-only report.

---

## HEY — MANDATORY COMPLETE-SOURCE RESET, WITHOUT RESETTING CODE

The prior problem was insufficient requirement context distributed to specialists. This package supplies the detailed available sources, historical source-preserving archives, newer approved refinements, model acquisition/training blueprint, 75 logical model roles, 57 planned real end-to-end journeys, and all 47 individually retrievable historical workstream prompts.

**Do not discard, roll back, restart or unnecessarily rewrite any verified working HEY code.** Start by verifying the latest actual repo SHA and live execution capabilities. The prior report of 500 unit tests passing is historical evidence only, not end-to-end proof.

### Read order and source verification

1. Read `00_START_HERE.md` completely and record its hash.
2. Read `01_LATEST_APPROVED_REFINEMENTS.md` and `03_PRODUCT_INTEGRITY_AND_EXECUTION.md` completely.
3. Read `05_MODEL_ACQUISITION_ADAPTATION_AND_DEPLOYMENT_BLUEPRINT.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `07_ALL_75_MODEL_ROLE_IMPLEMENTATION_CARDS.md` before delegating any model work.
4. Read `06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and parse `E2E_ACCEPTANCE_CASES.jsonl` into the independent test queue. **All cases start NOT EXECUTED.**
5. Read `08_FULL_47_WORKSTREAM_PROMPT_INDEX.md`. For every workstream, retrieve its original complete file under `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/`, the relevant source sections in `SOURCE_SPLIT/HEY_FINAL/`, and the latest amendments. Do not assume index presence means the agent read the actual file.
6. The 8.4 MB original combined source and the earlier refined engineering documents remain in `ARCHIVES/` as immutable records. Read the exact applicable portions and cross-check hashes. The older `HEY-MASTER-PRODUCT-BIBLE.docx` and indexed historical 1,460 entries preserve a separate early source; superseded behavior must not override later approved decisions.
7. Flag any unavailable source, inaccessible conversation, truncated text or ambiguous contradiction; **never invent historical decisions**.

### Mandatory dispatch and ownership

Before assigning work to an active specialist, create a packet with: actual source text required for its function; latest amendments; actual repository files/interfaces; typed data, permission and provider contracts; design behavior; failure cases; independent acceptance cases and ownership. Present evidence each packet was delivered completely. `AGENT_BRIEFS/` contains the newer 13 scope packets and full relevant included source sections; the full original 47 prompts are separate.

Preserve one integration/release owner, one shared frontend owner, independent QA, and separate branches/worktrees with contract ownership. Existing specialists keep their legitimate responsibilities, but integration must not wait until every isolated component is polished. Implement entire product, real user journeys, and full production gates together.

### Feature-by-feature implementation discipline

For every requirement: source reference → effective current intent → affected code → scoped implementation → actual UI/backend/data/model/device integration → error/security/accessibility states → true independent acceptance evidence. A page rendering or a unit test passing is insufficient.

Use correct AI model categories: logical agent/tool/model role is distinct from downloaded checkpoint, LoRA adapter and paid hosted endpoint. Review model publisher, license, revision, rights, compute cost and held-out evaluation. Do not train 75 checkpoints just because the model-role table lists 75 specialties. Do not claim S&A owns external model weights.

All direct and recurring spend must stay within authorized budgets. Initial HEY cloud operation target is $25–50/month. Do not buy hosted GPUs, establish unsupported merchant accounts, or upload school student records without appropriate permission.

### Mandatory first concrete coordinator response

Produce a compact factual artifact, not a huge generic audit, showing:

- Verified current source SHA and working run command/URL (or why the relevant access is missing).
- Actual source packet receipt table for all active specialist workers, with hashes and missing coverage.
- The first 10 failed/blocked actual user journeys, with exact reproduction and owner, and successful journeys with real evidence.
- Code changes/commits that resolve known missing integration from those journeys.
- External blockers specifying precise missing access/credential/device, with safe setup instructions and no secrets pasted into chat.
- Next assignments covering the remaining approved source requirements, including all newer features rather than only historical program names.

**Do not call HEY finished until the complete approved scope has verified user-facing effects, recovery, security, platform compliance, live integrations and legitimate external approvals. Do not claim that requirement compilation equals implementation. Continue coding and validation after this initial coordinator report.**
