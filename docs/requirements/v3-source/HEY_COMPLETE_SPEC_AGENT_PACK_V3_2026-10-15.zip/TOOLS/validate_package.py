#!/usr/bin/env python3
"""Verify structural completeness of the HEY V3 ZIP. Does NOT verify application implementation."""
import sys,zipfile,csv,io,json,re,hashlib
from pathlib import Path
zpath=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
if zpath.is_dir():
    read=lambda n:(zpath/n).read_bytes()
    names=[str(p.relative_to(zpath)).replace('\\','/') for p in zpath.rglob('*') if p.is_file()]
else:
    z=zipfile.ZipFile(zpath)
    bad=z.testzip(); assert bad is None,f'ZIP CRC failure: {bad}'
    names=z.namelist(); read=z.read
required=['00_V3_START_HERE.md','10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md','11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md','12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md','13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md','14_DETAILED_VERTICAL_JOURNEYS.md','15_MODEL_FLEET_PRODUCTION_PLAYBOOK.md','16_COORDINATOR_PROMPT_V3.md','CAPABILITY_REQUIREMENTS_V3.jsonl','HISTORICAL_1460_CAPABILITIES.csv','MODEL_ROLE_MATRIX.csv','ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md']
missing=[n for n in required if n not in names]
assert not missing, missing
records=[json.loads(l) for l in read('CAPABILITY_REQUIREMENTS_V3.jsonl').decode().splitlines() if l.strip()]
assert len(records)==1460, f'record count {len(records)}'
assert [x['id'] for x in records]==[f'BIBLE-{i:04d}' for i in range(1,1461)]
assert sum(x['record_type']=='historical_agent_role' for x in records)==229
assert len([n for n in names if re.search(r'WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/HEY_WORKSTREAM_\d+_',n)])==47
assert len([n for n in names if re.search(r'WORKSTREAM_PACKETS/WS\d+_',n)])==47
assert len(list(csv.DictReader(io.StringIO(read('MODEL_ROLE_MATRIX.csv').decode('utf-8-sig')))))==75
print('PASS: ZIP, full original source, 1460 item cards, 229 historic roles, 47 prompt files, 47 addenda, 75 model-role records.')
print('WARNING: This is document package integrity only; it proves no real HEY functionality.')
