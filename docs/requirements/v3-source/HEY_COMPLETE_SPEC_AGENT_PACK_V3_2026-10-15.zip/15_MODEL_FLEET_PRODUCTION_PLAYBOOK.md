# HEY — COMPLETE MODEL ACQUISITION, TRAINING AND SERVING PLAYBOOK (V3)

**Status:** Engineering design. No models downloaded, trained or deployed by generating these files. Model-card links, licenses, versions, costs and runtime support must be verified before selection. HEY's product intelligence can exist with one or a few shared models and many dynamic task-specialist agents; it does NOT need 75 separate full parameter checkpoints.

## A. Architecture as seven different types of intelligence

1. **Core LLM:** general chat, reasoning, planning, reflection, high-level coding, research, translation and task explanation. HEY One identity/orchestration can use open weights or hosted endpoints.
2. **Specialist LLM adapters:** Coding/Debugger, Precise Editor, Teacher, Researcher, Creative Writer, Business Analyst, Verification; base may be shared with separate prompts/LoRA/adapters after justified evaluation.
3. **Small classifiers:** Intent/route, safety/risk, document type, language, gesture intent, source relevance, task status. Typically rules/encoders/tiny distilled models rather than large LLMs.
4. **Retrieval/reranking models:** multilingual embeddings, hybrid lexical indexing, reranking and grounded source citation support. Separate from the generator; Cosmos remains a database, not hidden knowledge in LLM weights.
5. **Speech/vision models:** ASR, diarization, TTS, wake-word/VAD, vision-language, camera hand pose, OCR/structured PDF, segmentation/tracking; specialized different architectures.
6. **Creative generative models:** image diffusion/flow, video generation, voice cloning only with permission, audio/music generation and optionally 3D; expensive separate model families with provider quotas.
7. **Deterministic engines:** code compiler/test runner, file editor, slide/document renderer, calculator, SQL/transaction manager, policy authorizer, scheduler, diff/verification. These are often more precise than generating tokens.

## B. First deployed model fleet — financially viable

| Role | First viable implementation | Own training condition |
|---|---|---|
| HEY One general | Single routed hosted economical instruction endpoint; selectable pinned open-weight model candidate | Fine-tune only when held-out tests show repeated distinct weakness that adapters can address |
| Coder/Debugger | Specialized hosted code model + sandboxed coding tools/test runner | LoRA on licensed code and labeled issue→patch→test data if gains exceed cost |
| Precision Editor | Shared LLM + deterministic structured diff/locks/renderers | Adapter on user-approved edit pairs/negative collateral-change cases only after measured deficits |
| Teacher | Shared LLM + authenticated educational retrieval + quality templates | Adapter on permitted deidentified teacher examples/rubrics; never learn private student records without explicit lawful authorization |
| Research/Fact-checker | Shared LLM + search, source fetch, verifier/reranker | Fine-tuning low priority; citations and real retrieval matter more |
| Translator Sorani/Arabic | Multi-language model/ASR plus term memory; corpus-based evaluation | Language adapter if validated on native-speaker held-out set |
| Model Router / Risk classifier | Rules then calibrated small classifier | Train if enough consented labeled outcomes exist; calibrate out-of-distribution abstention |
| Cosmos Retrieval | Multilingual embedding+hybrid index+reranker | Evaluate retrieval benchmark; fine-tune embedding only with lawful labeled relevant/irrelevant pairs |
| Voice Input | ASR endpoint or compatible local engine | Domain vocabulary adaptation if proven necessary; evaluate Sorani, Kurmanji, Arabic, English separately |
| Voice Output | TTS compatible with a consented polished British-male option | Only authorized voices/licensed datasets; don't promise exact accent if provider can't support |
| Image/Video | Hosted image and video generators per-metered request | Training own generators usually financially unjustified in initial $25–50/mo budget |
| Gesture / hand pose | On-device library/model for landmarks + deterministic confidence/hysteresis + profile calibration | Adapt only with consented gesture-specific data and device tests |

## C. Source of model candidates (publisher first)

- `https://huggingface.co/Qwen/Qwen3-8B` general multilingual open-weight candidate.
- `https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct` coding model candidate, large hosted server requirement; official repository currently lists Apache-2.0. Verify card/LICENSE at chosen pinned commit.
- `https://huggingface.co/openai/gpt-oss-20b` reasoning/tool-use candidate; official repository currently lists Apache-2.0. Verify usage policy and runtime-format requirements.
- `https://huggingface.co/Qwen/Qwen3-Embedding-0.6B` embeddings; alternative `https://huggingface.co/BAAI/bge-m3` multilingual retrieval.
- `https://huggingface.co/openai/whisper-large-v3-turbo` ASR; evaluate regional language performance; not assumed flawless Sorani.
- `https://huggingface.co/hexgrad/Kokoro-82M` low-cost TTS candidate; voice accent and voice asset licenses separately evaluated.
- `https://huggingface.co/black-forest-labs/FLUX.1-schnell` image generation candidate; cost/server quota review.
- `https://huggingface.co/facebook/sam2.1-hiera-tiny` segmentation/tracking candidate; test target consistency and inputs.
- `https://huggingface.co/PaddlePaddle/PaddleOCR-VL-1.5` OCR/layout candidate; evaluate text, tables, handwriting and RTL limitations.
- `https://huggingface.co/Wan-AI/Wan2.2-T2V-A14B` large video generation candidate; do not download or host without GPU budget approval.
- MediaPipe Hands/Hand Landmarker official platform artifacts from `https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker` for device pose detection, subject to current runtime/permissions.

These links are candidates, NOT a final exclusive list or blanket commercial license approval. Future state should verify original sources and replace a candidate when benchmarked alternatives are better. Avoid unofficial repacks with unknown provenance.

## D. Exact acquisition checklist

1. Publisher and actual checkpoint repo; dated model card; license and acceptable-use policy; intended redistribution/commercial hosting terms and territorial limits.
2. Immutable revision SHA, tokenizer/config/chat template, weight format, model architecture, dtype/quantization, minimum software versions, required remote-code execution.
3. File hashes and provenance manifest. Reject pickle/executable loader requirements without expert isolation review. Never automatically run model repo scripts as trusted code.
4. Confirm weights vs adapter vs quantization compatibility and tokenizer/version match; don't attempt arbitrary LoRA porting across model architectures.
5. Benchmark cold/warm VRAM/RAM, throughput, latency, batch/sequence length, quality, instruction/tool fidelity, multilingual behavior, privacy and cost.
6. For huge checkpoints (> many GB) on an 8 GB laptop: do **not** download the entire model there. Use cloud endpoint or appropriately sized local quantized model and record realistic disk/memory requirements.
7. Train/fine-tune only after data rights review, dataset cleaning, de-identification, dedup, holdout split by real task/project/person, evaluation rubric and approved GPU cost.
8. Pin inference artifacts, serving configuration, prompt template and adapters; record rollback and safe fallback.

### CLI examples (for an approved machine and version)

```bash
python -m pip install --upgrade huggingface_hub safetensors
# Inspect metadata first (no large checkpoint download):
hf download Qwen/Qwen3-8B README.md --local-dir ./model_cards/qwen3-8b
# Only after recording an actual chosen revision, budget, license and compute plan:
hf download Qwen/Qwen3-8B --revision VERIFIED_SHA_FROM_PUBLISHER --local-dir ./models/qwen3-8b
```

Do not paste tokens into prompts or commit a `.env`; use verified secret handling. Adapt CLI to pinned tool versions rather than assuming commands remain unchanged.

## E. Data program for every specialist

A training example requires task id and clear before/request/constraints/approved output with correctness rubric. Negative labels include hallucinated file edit, scope violation, unsupported provider claims, long no-op agent loops, malformed structured output, insecure computer action, stale citations and style violations. Data ownership must be documented. A user asking for memory does NOT implicitly authorize using the content to train general weights.

Splits: train/dev/test by **project and time**, not merely random rows. Hold out adversarial tasks, Sorani/Arabic dialects, long-session state, permission denial and real provider failure. Compare baseline zero-shot/prompt/RAG and fine-tuned variants under same tasks, generation settings and cost budget. Avoid benchmark training leakage. Store evaluation version, model/adapter hash, dataset provenance and regression confidence intervals.

### Specialist-specific datasets (initial)

| Specialist | Label structure / examples | Metrics / blockers |
|---|---|---|
| Coder | issue + repository snapshot + allowed files → patch + passing tests + safe build; also failing patch examples | Task solve rate, full repo tests, security diff, accidental edits |
| Editor | original artifact + immutable locked regions + requested change → edited artifact + structural/visual diff | Requested change fulfilled, invariant preservation, export openable |
| Teacher | grade/subject/lesson objective and source → lesson/quiz/worksheet and teacher-reviewed rubric | Pedagogical accuracy, format, curriculum fit, privacy |
| Creative Generator | brief/style/asset refs/scene/timing → output and human evaluation | Identity/shot consistency, spec adherence, artifact quality, GPU cost |
| Researcher | query + dated primary sources → grounded claims with linked citations | Citation precision/recall, factual support, freshness abstention |
| Translation | Sorani/Kurmanji/Arabic/English aligned consented sentences + morphology/context | Native reviewer adequacy, terminology, script, dialect, RTL |
| Router | task attributes + observed model results/cost/latency/risk → selected route/abstain | Calibration ECE, normalized regret, spend, SLA |
| Trust | real scope/mandate/event + adversarial mutation → allow/deny/require approval | False allows, target binding, replay prevention; policy engine authoritative |
| ASR | consented audio + transcript/language/noise attributes | WER/CER by language and context; no unsupported claims of universal accuracy |
| TTS | licensed speech/phoneme lexicon + approved voice descriptors | Intelligibility, latency, user consent, accent quality |
| OCR/vision | labeled scans/screenshots/videos with regions/table/hand positions | Layout/reading accuracy, false action triggers, privacy capture |
| Retrieval | query + permitted source fragments with relevance labels | Recall@k, NDCG, leakage risk, source attribution |
| Outcome verifier | requested end state + ground-truth target receipt → success/partial/failure | False-success rate must be rigorously controlled |

## F. How to adapt a model rather than blindly fine-tune

**Phase 0:** Better prompts, structured schemas, retrieval, deterministic tools. Cheapest, usually first.
**Phase 1:** Curate 200–2000 *legally reusable, high-quality* task examples for a small specialist experimental adapter if appropriate (counts are illustrative). Measure base baseline.
**Phase 2:** Train LoRA/QLoRA or supported alternative using `transformers`, `peft`, `trl`, or maintained model-specific framework. Pin versions. Use compatible compute and validate training stability, mixed-precision behavior and context templating. Example PEFT documentation: `https://huggingface.co/docs/peft/quicktour`; supervised fine-tuning docs: `https://huggingface.co/docs/trl/sft_trainer`.
**Phase 3:** Evaluate untrained, prompt/RAG baseline and fine-tuned adapter on same holdout, with blind human review where needed. Block promotion on regressions including authorization, truthfulness, language, cost and hallucinated success.
**Phase 4:** Inference deploy to provider or approved rented GPU using appropriate serving runtime (e.g., vLLM/SGLang if verified compatible). Use versioned rolling/canary release, per-model budget/quotas and fallback.
**Phase 5:** Only train bigger model / multi-adapter family if data, GPU funding and measured superiority justify it. Direct large-model pretraining or weights merges are not automatically required to build HEY One.

## G. Safety/cost adaptation failure rules

Never incorporate school student records, private Cosmos memories, sensitive credentials, private organization data or user attachments into general training sets without lawful explicit permission, access controls and documented retention. Do not train or acquire voice clones without proper voice-owner authorization. Models should propose actions; Trust Kernel alone authorizes them. Model-integrated actions require sandbox/mandates and real outcome verification. Avoid unlimited video generation or always-on dedicated GPU under $25–50 monthly budget. Stop/pause with truthful reason, not fake completion.

## H. Serving and quality telemetry

Every inference request logs protected trace metadata: model/provider/version, route reason, modality, prompt template revision, token/input size, request/cached tokens, time-to-first-token, completion latency, queue time, tool roundtrips, cost estimate/actual, retry/fallback, redacted error, project/tenant scope, evaluation tags and whether any action was truly verified. No raw sensitive prompts in unprotected telemetry. Cross-model A/B requires randomization by meaningful task, guardrails for risk and spend, and independent outcome evaluators.

## I. HEY UltraSparse experimental isolation

Research in-process classifier/expert choice with microbenchmarks under pinned CPU/GPU; report p50/p95/p99, warm/cold, memory, throughput and quality regret. Sub-1ms p95 is only for eligible **routing kernel** with clearly defined input dimensions and batch/hardware, not remote OpenRouter call, full context compilation or text generation. If sparse architecture doesn't outperform ordinary routing under measured constraints, keep it experimental without blocking production.
