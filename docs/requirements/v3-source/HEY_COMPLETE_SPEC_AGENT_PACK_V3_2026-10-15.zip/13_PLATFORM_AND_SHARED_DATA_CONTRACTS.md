# HEY — SHARED TECHNICAL CONTRACTS / REFERENCE STATES

These are **ENGINEERING RECOMMENDATIONS** for enforcing original product requirements. Adapt field names to current repository schema after inspection; do not fork a second parallel state model.

## 1. Canonical identities

- `person`: immutable auth subject ID, session/device trust and age-aware access where required.
- `organization`: tenant, role, school/class policy, invite, key scope and data retention.
- `project`: workspace work context, Project DNA version, artifact/memory scope.
- `space`: customizable UI organization, not implicit permission grant.
- `conversation`: canonical Chat/Voice/Live transcript/thread and related artifacts.
- `mission`: durable parent and child jobs with scoped authority/receipts.
- `capability`: registered feature with modes, platform support, version, permission/price contracts.
- `widget`: instance bound to capability, persisted user/device state, source permissions and freshness.
- `model`: checkpoint/provider/version/runtime; role is an adapter/routing declaration, not another full checkpoint by default.

## 2. Response/Generative UI envelope

```
{
 "schema_version":1,
 "message_id":"uuid",
 "conversation_id":"uuid",
 "text_segments":[{"kind":"text","markdown":"..."}],
 "components":[{"id":"stable","type":"chart|form|table|widget|media|miniapp|...","schema_version":1,
   "props":{},"actions":[{"id":"action_id","capability_id":"...","scope_id":"...","requires_approval":true}],
   "source_provenance":[],"freshness":"known|stale|unknown", "fallback_text":"..."}],
 "mission_refs":[],"generated_at":"RFC3339","trace_id":"opaque"
}
```

Do not interpret this as production code until reviewed against current type schemas. Reject unknown component types or unsupported props. Server retains authorization; client onClick has no special authority. Sandbox generated mini-apps in isolated contexts with explicit RPC and no direct token storage. Keyboard/RTL/screen-reader fallback required. Component must degrade to accessible text if unsupported/offline.

## 3. Action mandate lifecycle

Canonical states: `DRAFT → POLICY_CHECK → NEEDS_APPROVAL|AUTHORIZED → DISPATCHED → EXECUTING → VERIFYING → VERIFIED|PARTIAL|FAILED|CANCELLED|EXPIRED|REVOKED`.

Binding dimensions: authenticated actor, tenant/project, capability, exact target and parameters, exact action class, device/app, time window, max uses, budget and delegation chain. Immutable request hash/event identifiers; atomic non-replay use-count update. Approval for target A must not authorize target B. External untrusted page/document/model text is never an authority source. Irreversible payment/delete/public-send actions require a bounded high-impact consent flow, not thumb gestures alone.

## 4. Persistent mission event envelope

`mission_id, sequence, event_id, parent_id, actor_id, tenant_scope, correlation_id, idempotency_key, state_before, state_after, action_ref, mandate_ref, timestamp, deadline, attempt, payload_hash, receipt_ref, verifier_ref, cost_delta, failure_code`.

Durable event/outbox must be committed alongside transition where required. On restart load last confirmed state, reconcile incomplete external side effect via idempotency/receipt before retrying. Duplicate callbacks and out-of-order events may not double-execute. Cancellation discontinues future work and reports irreversibility of already completed effects.

## 5. Cosmos memory revision contract

`memory_id, author_user_id, tenant_scope, project_scope, source_ref, source_timestamp, created_at, observed_at, effective_interval, normalized_claim, confidence, consent_state, privacy_class, supersedes_id, contradicted_by_ids, provenance_chain, retention_rule, deleted_at, vector_ref, version`.

Memory extraction is a candidate until consent/privacy policy allows commit. User correction creates a newer effective record and retires conflicting old use, while preserving necessary lawful audit metadata. Delete/forget honors capability limits and derived cache purging where technically possible. Never include cross-tenant memory in prompt context. Semantic retrieval alone is insufficient; use provenance, recency and exact filters.

## 6. Capability manifest contract

`id, version, title, category, user_intent_examples, supported_platforms, native_requirements, entrypoints, permissions, risk_class, cost_class, inputs_schema, outputs_schema, action_schemas, widgets, offline_mode, help_tutorial, availability, health, feature_flags, owner, test_ids`.

Only capabilities backed by actual working implementations may appear as **available**; planned capabilities are distinctly represented as not-yet-supported without clickable fake work. Descriptions in simple user terms, full technical metadata in Advanced mode. Availability depends on OS, account role, device permissions and provider health.

## 7. Artifact/Pinpoint version contract

`artifact_id, project_scope, format, base_version, current_version, source_files, dependencies, ProjectDNA_ref, locks, protected_regions, mutation_scope, diff_ref, export_hash, preview_ref, provenance, owner, rollback_ref`.

Edit pipeline: parse object tree / media timeline → resolve target → snapshot input and invariants → generate change plan → apply scoped change → compare protected invariants → render/export → verify format compatibility/content and output → commit new artifact version → return receipt. Reject ambiguous destructive scope until resolved; preserve original even on render crash.

## 8. School organization boundary

Separate `teachers`, `students`, `classes`, `curricula`, `lessons`, `assignments`, `grades`, `attendance`, `artifacts` by `organization_id` plus explicit role/school policy. Do not automatically expose student data across parent/student/teacher roles. Synthetic data in staging; production student records require school agreement and documented controller/processor responsibilities and retention. Public smartboard mode must hide sensitive classes/grades and require re-authentication to show private records.

## 9. Failure modes and errors

Typed errors: `AUTH_REQUIRED, PERMISSION_DENIED, APPROVAL_EXPIRED, SCOPE_CHANGED, UNSUPPORTED_PLATFORM, DEVICE_UNAVAILABLE, CAMERA_REVOKED, NETWORK_OFFLINE, PROVIDER_RATE_LIMIT, PROVIDER_UNAVAILABLE, BUDGET_EXHAUSTED, MISCONFIGURED_SECRET, INVALID_ARTIFACT, TARGET_AMBIGUOUS, VERIFICATION_UNCERTAIN, SOURCE_STALE, TENANT_BOUNDARY_VIOLATION, DUPLICATE_ACTION, RETRY_EXHAUSTED, DATA_CONFLICT, STATE_CORRUPTION, SERVICE_DEGRADED`.

Each error specifies safe user message, debug correlation id, which actions actually occurred, compensation/undo, whether retry is safe and what the user must do. Never translate every error into vague "something went wrong" or fake success. Do not expose raw secrets/PII in UI or logs.

## 10. Minimum acceptance matrix per platform

| Environment | Main verification |
|---|---|
| Web/PWA | installability with supported browser, manifest/service worker, offline shell, login, Widgets, studio, feature-limited browser control; no fake OS access |
| Windows | real Edge native companion; OS file/app/window/keyboard access within permission scope, HEY Flow into external editor, global invoke, crash/restart and low-RAM test |
| macOS | native helper/menu bar, Accessibility/Shortcuts where allowed, privacy prompts, HEY Flow and overlay permissions, proper signing where required |
| Linux | portal/DBus/X11/Wayland behavior accurately distinguished, secure native privilege rules, underpowered machine tests |
| Android | camera gesture and dictation on available device, intents/Accessibility service justification, scoped foreground behavior, smartboard hardware camera verification |
| iOS/iPadOS | App Intents/Shortcuts/share sheet/camera/mic, platform-compliant background limits, no unrestricted system control claims |
| Tablet/smartboard/TV | camera/screen source, orientation, distance typography, public-display privacy, no implied student access |

Test the strongest legitimate user outcome on each supported platform; document unsupported platform details rather than writing a cross-platform theoretical spec as if tested.
