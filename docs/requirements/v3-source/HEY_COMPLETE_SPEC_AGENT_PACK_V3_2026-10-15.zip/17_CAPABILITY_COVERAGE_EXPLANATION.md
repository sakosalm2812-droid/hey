# HISTORICAL CAPABILITY CARD COVERAGE — V3

- Original Bible entries parsed: **1460** (indexed `BIBLE-0001` through `BIBLE-1460`).
- Internal legacy built-in agent entries (numbers 843–1071): **229**. These are internal roles, not separately required user-facing apps or model checkpoints.
- Source groups parsed from the extracted Product Bible: **52**.
- Individual cards split into **52** domain files.
- **All cards default to UNKNOWN / NOT EXECUTED**; no repo inspection, live service, training or testing is claimed.

## Caution on specificity

Each card copies the authentic original capability label, attaches its authentic Product Bible section group, and includes an **explicitly marked engineering acceptance template** inferred from the label and its group. The detailed original HEY Source of Truth and later refinements must be read to flesh out exact UI behavior and every edge case. A name-driven template is not a substitute for an independently sourced final design. This avoids the previous error of inventing approvals and claiming full coverage from mere enumeration.

## Historical grouping counts

- Core HEY identity and interaction: 50
- HEY Answer Engine: 34
- Cosmos / memory / second brain: 48
- Projects and Project DNA: 40
- Pinpoint Precision: 38
- Artifact system and version history: 21
- Image generation: 35
- Image editing: 37
- Storyboard and frame system: 30
- Video generation and editing: 34
- Motion graphics: 14
- Audio and speech: 23
- Presentations: 19
- Documents and books: 24
- Knowledge transformation: 15
- HEY Live: 27
- Voice system: 18
- Dynamic Island: 35
- Background HEY: 19
- Computer control: 29
- Browser control: 18
- Files: 16
- Workspace: 44
- Home / dashboard: 16
- Navigation and discoverability: 22
- Tutorials: 62
- Gestures: 27
- Automations: 20
- Forge: 27
- Built-in agent system: 229
- Cross-device and Device Fabric: 30
- Offline and local: 16
- Provider system: 20
- Proactive HEY: 18
- Productivity: 22
- Search: 16
- Modes: 21
- Religious features: 11
- Accessibility: 12
- Localization: 10
- Accounts and authentication: 14
- Billing and usage: 15
- Security and Trust Center: 40
- PWA and install: 16
- Developer platform: 20
- Diagnostics and reliability: 29
- Observability and quality: 23
- Collaboration: 10
- Business / marketing / productivity intelligence: 14
- Education: 13
- Health / legal / science informational support: 9
- Customization: 10
