# HEY V3 — EXECUTION ENTRYPOINT (READ FIRST)

**Purpose:** Finish the **entire** approved HEY product, not win a documentation contest. This V3 artifact supplements and preserves the entire V2 package; it is NOT a claim that HEY is finished. V3 addresses the main failure modes of previous work: missing requirement context, lost refinements, disconnected parallel branches, mock-only tests, nonoperational UX, costly speculative model training, and unverified declarations of completion.

## Exact reading / authority order

1. Read this file and `10_CURRENT_PRODUCT_CONTRACT_AND_DEFINITION_OF_DONE.md`.
2. Read `11_CONFLICT_RESOLUTION_AND_DECISION_LEDGER.md`, `12_HANDOFF_AND_RELEASE_OPERATING_SYSTEM.md` and `13_PLATFORM_AND_SHARED_DATA_CONTRACTS.md`.
3. Read relevant `01_LATEST_APPROVED_REFINEMENTS.md`, `SOURCE_SPLIT/HEY_FINAL/**`, `ARCHIVES/HEY_REFINED_ENGINEERING_DOCUMENT.md` and full task `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/**`.
4. Read `15_MODEL_FLEET_PRODUCTION_PLAYBOOK.md` before committing to GPU spend or model training.
5. Read all actual matching `CAPABILITY_CARDS/**` and the `CAPABILITY_REQUIREMENTS_V3.jsonl` machine-readable register. Cards are source-anchored *expansion templates* — if a detailed older source provides additional behavior, the detailed source wins.
6. Only then dispatch a self-contained packet. Relevant original and new source text must be delivered **verbatim or via accessible pinned files**, not summarized to a feature name. Record a content hash and retrieval receipt.

## The three distinct truths

- **Product target truth:** approved requirements and subsequent refinements, with source provenance and conflict rules.
- **Code truth:** what the checked-out repository at an exact SHA actually contains.
- **Execution truth:** what a user or independent tester demonstrably accomplished in the real environment.

Never substitute one for another. A source might be fully specified but absent from code. Code might exist but not function. Passing unit tests may leave real integration unverified.

## The no-wasted-work rule

Every assigned work item must specify (a) a real user or operator outcome; (b) its exact feature entry point; (c) actual existing implementation files; (d) what it must integrate with; (e) who owns the shared contracts; (f) an end-to-end test on the target supported platform; (g) failure/recovery; (h) a commit and independent evidence. A task with only architecture or tests as deliverables is allowed only when it unblocks an identified real feature and has an objective completion gate.

## Current evidence limits

The historical report of 500/500 tests passing and 73/73 model/Edge/Fusion tests was **not** equivalent to live E2E certification. Do not extrapolate it forward to new builds. No screenshots, model artifacts, paid accounts, deployments, or hardware sessions are supplied by this specification. The coordinator must discover the current actual repo HEAD. Unavailable old conversations or a historical 4,210-item ledger must be documented as coverage gaps, not invented.

## Hard rule: one HEY

Do not ship 1,460 apps, 229 visible bots, 75 fine-tuned LLMs, or 47 disconnected modules. The historical 1,460 register is a cross-reference including internal agents. The product is one AI operating environment with contextual tools, one canonical identity/memory/trust/mission/artifact stack, and platform-specific adapters.

## Dispatch order

Reconcile source and repository in parallel with implementation. Assign verified end-to-end vertical product outcomes (auth+conversation+model+memory+action; Spaces+Tools; Voice+Flow+Edge; Teacher+smartboard; Creation+editing; background automations). Never stop main engineering solely because the full source history is too large to read in one context. Implement clearly supported requirements, record exact unresolved decisions, and independently verify each finished journey.

Read `16_COORDINATOR_PROMPT_V3.md` for the full operating order, and `TOOLS/validate_package.py` for artifact integrity checking.
