# Repository Implementation Order

The coding agent starts from the current HEY codebase, not from a greenfield rewrite assumption.

1. Inventory routes/components/APIs/edge functions/database/migrations/RLS/auth/providers/agents/tools/workflows/native commands/service worker/config/tests.
2. Search contextually for TODO/FIXME/HACK/TEMP/MOCK/STUB/PLACEHOLDER/coming soon/dummy/localhost/dead flags/duplicate implementations.
3. Build spec↔code map.
4. Fix shared contracts/data/events/auth/security/permissions/rate limits first.
5. Provider/decision/cognitive runtime.
6. Agent registry/verifier/recovery.
7. Cosmos/projects/Pinpoint/artifacts.
8. Chat/Voice/Live/screen-camera guidance/Island/background.
9. Studios/generation.
10. computer/browser/files/device/platform adapters.
11. automations/Forge/capability synthesis/Evolution Engine.
12. plans/billing/API/Education/owner console.
13. discoverability/tutorial/accessibility/localization.
14. whole-system failure/security/performance/production gates.

Every subsystem is audited, improved/replaced, migrated, tested, independently verified and only then marked production-ready.


---

