# Risk Twin + Solution Twin

Every substantial new capability or architecture change is reviewed by two adversarially complementary systems.

**Risk Twin** searches for security, privacy, data-loss, reliability, compatibility, performance, cost, abuse, UX, accessibility, supply-chain, prompt-injection, permission, legal/policy and second-order failure modes.

**Solution Twin** receives every finding and has two responsibilities:
1. eliminate or contain the risk without unnecessarily reducing capability;
2. actively discover additional technologies, architectures or features that make the capability stronger, faster, simpler, cheaper, safer or more reliable.

Then a second Risk Twin pass attacks the revised design. An independent verifier decides whether the residual risk and functionality meet policy.

The default sequence is `maximize capability → enumerate risks → strengthen design + mitigate risks → attack again → verify`, not `see risk → delete feature`.


---

