# Evolution Engine — Continuous Whole-Internet Discovery

HEY continuously learns about the external world so the product does not freeze at today's capabilities.

## Two layers
**Continuous watchers** detect high-value changes immediately.
**Daily Deep Sweep** performs an exhaustive broad-category research cycle every 24 hours.

## Scope
The sweep is not limited to AI. It searches every category that could improve HEY or its users: software, hardware, operating systems, browsers, developer tools, APIs, open source, security, networking, databases, distributed systems, science, mathematics, education, productivity, business, finance, design, accessibility, language, media, communications, consumer apps, enterprise software, robotics, HCI, standards, protocols, legal/platform policy changes, healthcare-information tools, creative tools, automation, devices, new research fields and newly emerging categories not known when this document was written.

## Pipeline
Discovery → primary-source extraction → source/freshness verification → categorization → dedup against discovery history → compare against HEY → benchmark claims where possible → quantify improvement/risk/cost → architecture proposal → Risk Twin → Solution Twin (mitigate + strengthen) → independent critic → concise owner proposal.

Normal internal evolution needs any one of the three owners to approve. Approved work goes through implementation branch, security, tests, shadow deployment/canary, independent verification and rollback-ready promotion.

## Memory
The engine remembers discoveries, benchmarks, adopted/rejected proposals, rejection reasons, failed migrations and superseded systems so it does not waste resources rediscovering the same item. Rejected ideas resurface only when material new evidence changes the decision.


---

