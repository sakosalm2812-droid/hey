# Unlimited Agent Foundry

The old 229-agent catalog is a seed, not a ceiling. HEY starts with every useful known specialist family and can create narrower specialists whenever measured benefit is positive. There is no arbitrary numeric limit.

## Hierarchy
`HEY → domains → agent families → specialists → ultra-specialists → temporary task specialists`.

Only relevant agents are loaded into a mission. A million registered specializations must not mean a million prompts are injected into every context.

## Mandatory specialist families
Core orchestration; memory/Cosmos; research; engineering; security; risk; QA; provider/model; optimization; computer/browser/files; voice; vision; screen/camera guidance; platform-native; product/UX; accessibility/localization; creation; business; education; religious research; devices; automation; Forge; Evolution; governance; billing; observability; recovery; legal/privacy information; data/statistics; support/incident.

## New required specialist examples
Flaw Hunter, Missing Requirement Hunter, Assumption Breaker, Opportunity Hunter, Second-Order Effects, Latency Hunter, Token Efficiency, Prompt Compiler, Spec Retrieval, Duplicate Work Detector, Cost Leak Hunter, Context Quality, Risk Twin, Solution Twin, Data Exfiltration Hunter, Supply Chain Hunter, Sandbox Escape Hunter, Rate-Limit Architect, Public Claims Auditor, User Confusion Hunter, Future Compatibility, Staleness Propagation, Outcome Judge.

## Agent creation lifecycle
Need detected → registry/duplicate search → contract design → simulation → benchmark against existing agent/team → security/permissions review → temporary deployment → measured production shadow → promotion if useful → health monitoring → merge/retire/rollback when superseded.

Every agent declares typed inputs/outputs, tools, permissions, provider policy, privacy, risk, budget, timeout, retry, cancellation, checkpoint behavior, verification, tests, health, version and dependencies. Agents cannot grant themselves permissions or self-certify success.


---

