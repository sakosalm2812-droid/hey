# Decision Fabric — Intelligence Beyond Token Generation

Tokens are only one mechanism used by generative language models. HEY must avoid spending generative-model tokens on work that can be solved faster or more reliably by other mechanisms.

## HEY decision stack
1. Deterministic code/rules/state machines for exact policy and workflow transitions.
2. Caches and memoized validated results.
3. Traditional algorithms for parsing, diffing, scheduling, hashing, graphs, compression, ranking and math.
4. Embeddings/vector retrieval for similarity and memory/search retrieval.
5. Rerankers/classifiers for relevance, spam, risk, intent and candidate ordering.
6. Typed decision models for bounded choices/scores/probabilities.
7. Small/local models for narrow uncertain tasks.
8. Strong generative models for open-ended reasoning/generation.
9. Intelligence Council for high-value/high-uncertainty tasks.

Jev-class systems are useful inspiration: a typed decision model can return probabilities over allowed decisions rather than generating prose token-by-token. HEY should support such engines through adapters for routing, ranking, policy, risk, approvals, relevance and other bounded decisions. They do not replace generative models; they remove unnecessary generative work.

## Speed techniques HEY should use where supported
KV/prefix caching, speculative decoding, batching, parallel tool/model execution, quantization for local models, sparse/MoE inference where provider/runtime supports it, streaming, prefetching, request coalescing, compiled prompts/contracts, context retrieval instead of giant prompts, deterministic fast paths, local heuristics, concurrency controls and latency-aware provider routing.

## Invention mandate
HEY may build its own **MicroDecision Fabric**: task-specific calibrated classifiers and deterministic policies trained/evaluated on HEY's own labelled outcomes. Uncertain cases escalate to stronger intelligence. Every decision engine is calibrated and benchmarked per task.


---

