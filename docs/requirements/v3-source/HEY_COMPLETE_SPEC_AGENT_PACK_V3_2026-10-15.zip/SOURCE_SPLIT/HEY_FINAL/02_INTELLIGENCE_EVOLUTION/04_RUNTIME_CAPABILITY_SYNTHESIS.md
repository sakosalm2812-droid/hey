# Runtime Capability Synthesis

When a user requests an outcome for which HEY has no current capability, HEY should not default to “unavailable.” It should attempt to synthesize the missing capability safely.

## Flow
Request → capability search → gap confirmed → research implementation paths/APIs/libraries/local methods → choose architecture → create smallest capable tool/workflow/agent/adapter/code module → dependency/provenance checks → sandbox → Risk Twin → Solution Twin → adversarial tests → functional tests → execute the original user task → verify outcome.

The synthesized capability is **temporary by default**. The controlling user/owner can choose:
- Save;
- Modify, then Save;
- Delete.

Until saved it is isolated, scoped and disposable. Saved capabilities are versioned, auditable and rollbackable.

## Safety without making the feature weaker
Undo is valuable but cannot reverse exfiltration, an external payment or public disclosure. Therefore generated capabilities use scoped permissions, network/filesystem/tool allowlists, resource budgets, snapshots, sandboxing and action verification before execution. The Solution Twin must find designs that preserve or improve useful capability rather than lazily deleting risky functionality.

## Capability provenance
Record why it was created, models/agents involved, source research, dependencies, permissions, code/config changes, test results, risk findings, mitigations, version, usage and save/delete decision.


---

