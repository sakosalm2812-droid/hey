# Cognitive Fabric & Intelligence Council

HEY does not treat one LLM response as the definition of intelligence. It composes the best topology for the task: one fast model, deterministic engine, cheap→strong cascade, planner/executor/verifier, parallel experts, critic/reviser, tournament, simulation, or a full **Intelligence Council**.

## Meeting-room architecture
For difficult decisions, relevant specialists enter one shared deliberation room. They see the same Evidence Board containing facts, primary sources, constraints, assumptions, calculations, proposals, objections and unresolved questions. They can challenge one another, revise proposals and introduce ideas missed by the original prompt.

Consensus is **evidence-weighted**, not vote-counted. A strong minority objection cannot be erased merely because many agents agree. A Dissent Guardian preserves material disagreement. A Contrarian and Flaw Hunter deliberately attack the emerging consensus. A Deliberation Budgeter stops extra rounds once marginal improvement no longer justifies latency/cost.

## Example topologies
- Simple question: one fast low-cost model.
- Complex factual answer: researcher + source verifier + synthesis + fact checker.
- Coding: architect + implementers + test + security + reviewer + independent verifier.
- Company strategy: product, market, finance, technology, operations, customer, risk, contrarian, opportunity, long-term and synthesis specialists in debate rounds.
- High-assurance security: multiple independent threat models + exploit simulation + mitigation design + verifier.

## Required components
Expert Selector; Council Chair; Evidence Board; Dissent Guardian; Contrarian; Flaw Hunter; Assumption Breaker; Missing-Requirement Hunter; Opportunity Hunter; Second-Order Effects Agent; Consensus Synthesizer; Independent Verifier; Deliberation Budgeter; provenance/cost/latency tracing.

## Goal
Use orchestration, tools, memory, retrieval, specialization, verification and parallelism to outperform the underlying individual model whenever these mechanisms create a real task-level advantage. Measure the result rather than claiming universal superiority.


---

