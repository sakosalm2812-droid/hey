# Master Prompt for Codex / OpenCode / Any Coding Agent

You receive the complete current HEY codebase and the folder `HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH`.

This folder is authoritative and supersedes older HEY planning. Do not reduce it into an MVP or defer useful requirements into a fictional V2.

Work subsystem-by-subsystem in dependency order. For each subsystem:
1. read the newest relevant source files and shared foundation contract;
2. trace the existing implementation end-to-end;
3. preserve anything stronger than the specification;
4. improve or replace weaker/partial implementations rather than stopping because they technically work;
5. when duplicate implementations exist, keep the stronger one and migrate any unique useful behavior from the weaker one before removal;
6. implement every missing layer—UI, backend, data, integrations, permissions, security, recovery, verification, performance, accessibility, localization, tests and help/discovery where applicable;
7. if a low-level technology choice is unspecified, select the best maintained option by comparing quality, reliability, cost, latency, privacy, licensing, platform coverage and maintainability;
8. never weaken authorization/security to make a feature work;
9. independently verify user-visible outcomes and external side effects;
10. run normal, failure-injection, security and regression tests;
11. leave evidence and rollback paths;
12. do not mark the subsystem complete until it is PRODUCTION_READY.

Do not waste tokens re-reading the entire folder for every task. Retrieve only the relevant subsystem documents plus shared contracts. Use the repository as the current-state truth and the specification as the target-state truth.


---

