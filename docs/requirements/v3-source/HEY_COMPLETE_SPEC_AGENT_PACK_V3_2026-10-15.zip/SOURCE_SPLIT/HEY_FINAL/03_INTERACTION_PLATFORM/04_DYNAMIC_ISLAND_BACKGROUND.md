# Dynamic Island & Background HEY

Dynamic Island is a native/persistent HEY surface on supported platforms, not merely a React component inside the main page. It remains when the main HEY window is minimized or closed while the helper/background runtime is enabled.

Modes include idle, listening, thinking, speaking, media, mission, generation, research, upload/download, timer, reminder, approval, cross-device handoff, error/recovery and completed result. Clicking expands context-specific controls rather than a generic Activity screen.

Long-running HEY work is durable state, not one immortal process. Local helpers and server schedulers checkpoint/resume work across crashes, deployments, device restarts and sleep where the platform permits. Owners and authorized users retain stop/revoke controls; an unkillable malfunctioning process is not a feature.

Camera/screen sharing stops when the session ends and normally on main-window close unless an explicit visible background session is active.


---

