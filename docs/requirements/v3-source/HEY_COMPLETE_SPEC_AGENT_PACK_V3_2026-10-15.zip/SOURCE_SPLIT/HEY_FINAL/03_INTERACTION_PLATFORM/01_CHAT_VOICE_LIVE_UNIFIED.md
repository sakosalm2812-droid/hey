# Unified Chat, Voice & Live

Chat and Voice are the same canonical conversation. Voice is not a separate history. A voice turn becomes part of chat history; text and voice share project, files, active artifacts, missions and Cosmos context.

## Different answer styles, same intelligence
Chat can be structured, detailed, source-rich and artifact-heavy. Voice is shorter, more natural, interruption-friendly and spoken in smaller turns. A full transcript/result can still appear in the shared conversation. Raw microphone audio is not retained by default after processing unless the user explicitly saves it. Private Mode can avoid durable transcript/memory according to settings.

Switching `Chat → Voice → Live → Chat` must preserve context.

## Live
HEY Live can combine voice with the user's chosen screen/window/monitor/region, camera, files and project context. Guide mode explains; Assist mode helps with bounded actions; Act mode performs authorized actions and verifies results.


---

