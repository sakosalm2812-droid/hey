# Screen & Camera Guidance / Overlay System

HEY can use the screen or camera (with visible permission) to guide users through digital or physical tasks.

## Screen guidance
HEY understands UI elements, highlights the exact control, draws arrows/outlines/callouts, dims unrelated regions, numbers steps, follows moving UI targets, watches whether the step succeeded and advances only after verification. It can guide settings changes, software workflows, forms, troubleshooting and accessibility tasks.

## Camera guidance
HEY understands the live scene, identifies relevant objects, anchors arrows/labels/step markers to them, tracks them across frames and tells the user what to do next. It can assist with setup, assembly, troubleshooting and other appropriate real-world procedures.

## Spatial Guidance Graph
Both screen and camera guidance share a graph of targets, anchors, instructions, confidence and verification state. Voice can say “the button I mean is here” while the overlay highlights it.

## Privacy/security
Visible sensing indicator, instant pause/stop, selected-source controls, app exclusions, sensitive mode, raw-feed non-retention by default, prompt-injection defense for on-screen text, local vision/pose inference where viable.

## Agents
Screen Understanding, Camera Understanding, Object Detection, Object Tracking, Spatial Anchor, Guidance Planner, Overlay Renderer, Procedure Verification, Accessibility Guide, Prompt-Injection Guard, Safety/Risk.


---

