# Platform Outcome Parity

HEY targets the same **user-level capabilities** across Windows, macOS, Linux, Android, iOS/iPadOS and web/PWA. The internal method can differ because operating systems expose different APIs.

Shared HEY Brain sits above platform Capability Adapters. Each adapter declares what native mechanisms are available, permission state and health. If one device cannot directly perform a step, HEY may compose official OS automation, app intents/shortcuts, accessibility APIs, screen/camera guidance, browser capabilities, a native companion, trusted-device handoff or institution-managed device controls to achieve the same user goal where technically legitimate.

### Examples
Windows: native helper, UI Automation, screen capture, PowerShell/terminal, window/process/filesystem APIs.
macOS: Accessibility API, ScreenCaptureKit, Shortcuts/AppleScript where appropriate, native helper/menu bar.
Linux: Wayland/X11/desktop portals, DBus, shell/native services.
Android: intents, accessibility service when justified/user-enabled, MediaProjection, camera/mic, foreground services, notifications, sideloadable APK before store distribution.
iOS/iPadOS: App Intents, Shortcuts, universal links/URL schemes, ReplayKit/screen broadcast where applicable, camera/mic, Live Activities/Dynamic Island, share extensions, document picker, background tasks within OS limits, and MDM/supervision for eligible institutional deployments.
Web/PWA: manifest/service worker/install, getDisplayMedia/getUserMedia, File System Access where supported, notifications/share/file handlers.

Do not assume an unrestricted iOS terminal exists for ordinary third-party apps. Use the strongest legitimate composition of supported mechanisms instead of building against a false privilege model.

Store publication is not required immediately. Architecture must support PWA, desktop installers and legitimate sideload/institutional distribution paths until App Store/Play Store distribution becomes feasible.


---

