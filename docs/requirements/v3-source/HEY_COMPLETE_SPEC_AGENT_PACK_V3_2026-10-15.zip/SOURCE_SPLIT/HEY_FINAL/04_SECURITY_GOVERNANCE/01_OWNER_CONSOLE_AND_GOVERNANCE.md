# HEY Owner Console & Governance

Exactly three top-level owner identities exist. The Owner Console has a distinct high-security UI and stronger authentication/re-auth policies than normal HEY.

It includes Evolution proposals, discovered vulnerabilities, emergency auto-patches, capability changes, third-party submissions, agent/provider health, global spend, releases, feature flags, rollback, quarantine, incident history and audit trails.

- Normal internal improvement: any one owner approval is sufficient.
- Third-party public extension publication: all three owners approve.
- Proven critical security patch: may auto-deploy under emergency policy, then immediately notify all three owners with what changed, why, evidence, tests, side effects, what should be removed/changed next and rollback.
- No normal admin flow can add a fourth owner.

Owner accounts should use the strongest available account security, including passkeys/MFA/re-auth/device trust where implemented.


---

