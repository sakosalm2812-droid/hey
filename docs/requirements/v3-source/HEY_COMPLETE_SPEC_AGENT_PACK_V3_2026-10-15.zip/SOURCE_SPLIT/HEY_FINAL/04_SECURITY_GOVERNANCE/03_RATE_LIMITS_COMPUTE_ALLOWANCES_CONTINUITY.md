# Rate Limits, Compute Allowances & Atomic Completion

HEY uses distributed server-side rate limiting for expensive/sensitive routes. Limits are endpoint- and cost-aware, not one global frontend counter. Authenticated identity, organization/user ID and appropriate network/device signals are combined; anonymous auth/signup/recovery routes receive separate abuse protection. 429 responses are structured and include retry timing.

## Compute Allowances
User-facing plans should not fundamentally be measured in “hours” or raw tokens. Internal allowance accounting can combine provider spend, input/output tokens, image/video/audio generations, tool/API costs, parallel agents, GPU/compute and long-running background duration. The UI can present a simple understandable capacity meter.

## Atomic Completion / Continuity Reserve
HEY does not randomly stop halfway through a coherent unit when an allowance boundary is reached. It may use a bounded continuity reserve to finish the current file/slide/artifact step/tool transaction, then checkpoint.

It reports: what completed, why it paused, exact saved state, what remains and how to resume. The reserve is capped so a user cannot start an enormous costly job with almost no allowance remaining and force unlimited completion.


---

