# Closed Source Core, APIs, Local Models & Third-Party Extensions

HEY's core codebase remains closed source. Users do not need source access to use local models.

HEY exposes stable API/SDK contracts for models, tools, agents, workflows, widgets and integrations. Local inference options can include Ollama, llama.cpp, LM Studio, vLLM/OpenAI-compatible endpoints, a HEY local runtime and trusted LAN/self-hosted endpoints.

A model profiler records context, tool calling, JSON reliability, modalities, speed, resource use and benchmark quality so the Router can use local models intelligently.

Third-party developers can build extensions through public SDKs/contracts. Before privileged public distribution: automated validation, dependency/supply-chain scan, sandbox, permissions review, security tests, compatibility tests and **all three owners' approval**. Approved packages are signed/versioned and can be revoked/quarantined.


---

