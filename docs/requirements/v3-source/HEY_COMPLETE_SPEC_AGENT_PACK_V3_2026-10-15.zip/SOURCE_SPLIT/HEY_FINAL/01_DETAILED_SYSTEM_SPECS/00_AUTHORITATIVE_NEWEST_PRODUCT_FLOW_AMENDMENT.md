# HEY V1 — AUTHORITATIVE FRONT-END / PRODUCT-FLOW AMENDMENT
## Newest decisions override conflicting older wording

This amendment is authoritative over older navigation/front-end wording wherever conflicts exist.

## A. SIGN-IN DESTINATION

After a successful sign-in, HEY must **not** take the user to a generic dashboard.

Default destination:
**The HEY Conversation Surface** — the primary page where the user can switch directly between **Chat** and **Voice**.

The product should immediately feel like the user has arrived at HEY itself, not at an admin dashboard.

### Required first signed-in view
- HEY wordmark / identity;
- Chat / Voice switcher;
- current project/context indicator when relevant;
- main conversation surface;
- prompt / microphone controls;
- compact access to Live;
- important contextual quick actions;
- Dynamic Island if supported;
- unobtrusive route to Home/Workspace, Projects, Cosmos, Create, etc.

### Returning user behavior
By default:
- return to the most recent Chat/Voice conversation state when safe;
- preserve current project/context;
- if a mission is active, show a compact resumable mission state;
- if user explicitly set a different startup destination, respect it.

### Do not
- dump users onto a generic grid of widgets;
- force users through a dashboard before speaking to HEY;
- make Chat and Voice look like unrelated products.

---

## B. CHAT + VOICE ARE ONE PRIMARY HEY SURFACE

Chat and Voice are two modalities of the same HEY Brain.

They should exist inside one coherent Conversation Surface.

### Desktop layout
Top/center modality selector:
- Chat
- Voice
- optionally Live as a nearby third action, not necessarily equal tab if Live uses immersive layout.

Switching Chat ↔ Voice:
- preserves conversation;
- preserves attachments/context;
- preserves project;
- preserves active artifact/studio;
- preserves mission;
- does not restart HEY.

### Chat mode
- editorial conversation;
- attachments;
- context/project chips;
- artifact cards;
- inline studio surfaces;
- action receipts;
- citations where relevant.

### Voice mode
The current generic voice page is not sufficient.

Required direction:
- use the premium call-like visual language previously designed;
- large HEY living visualizer;
- listening / thinking / speaking states;
- compact transcript;
- mute;
- end;
- captions;
- camera;
- screen;
- device/output;
- optional active task/artifact card;
- same conversation context as Chat.

Voice must feel like a live session with HEY, not a static microphone page.

---

## C. STUDIOS ARE MARRIED TO CHAT + VOICE

Dedicated Studio pages may remain for power users and direct navigation.

But creation must also work naturally **inside Chat and Voice**.

Example:
User in Chat:
“HEY, create me a 15-second video about X.”

Expected flow:
1. HEY understands request.
2. HEY may ask only materially necessary clarification.
3. Creation mission starts.
4. A Video Studio surface opens **inside the current HEY conversation/workspace**.
5. Chat remains available.
6. User can continue issuing edits conversationally.
7. Video Studio receives those edits directly.
8. Pinpoint Precision preserves locked/approved shots.
9. User can expand Studio to full workspace if desired.
10. User can collapse it back into conversation.
11. Dedicated Studio route can open the same artifact/state.

Same principle applies to:
- image;
- storyboard/frame;
- video;
- motion graphics;
- audio;
- presentation;
- document/book;
- code;
- research.

### Voice example
User in Voice:
“HEY, make a presentation about renewable energy.”

Expected:
- HEY verbally acknowledges;
- Presentation Studio appears as an embedded/side/full workspace while Voice remains active;
- user can say “change slide three only”;
- HEY edits slide three;
- conversation and studio remain synchronized.

Studios must never behave like unrelated apps launched from HEY.

---

## D. DYNAMIC ISLAND MUST LIVE OUTSIDE HEY

The Dynamic Island is a native persistent surface on supported platforms.

It must survive:
- unfocus;
- minimize;
- main-window close while helper remains running.

It must not depend on a browser tab or main React/Vite DOM remaining alive.

When clicked, it must show a **contextual control surface**, not merely an Activity list.

Context examples:
- Voice call;
- media;
- generation;
- research;
- mission;
- timer;
- download/upload;
- approval;
- handoff;
- result;
- error/recovery.

---

## E. PWA DOWNLOAD / INSTALL IS MISSING AND REQUIRED

HEY must expose a clear **Install HEY** / **Download HEY** path for the PWA/web-installable version.

### Required surfaces
Public website:
- primary or secondary “Install HEY” CTA where browser/platform supports PWA install;
- Download page with platform choices.

Inside HEY:
- Settings → Apps / Install / Device or equivalent;
- contextual install suggestion after meaningful use, not immediately on first page load;
- Help/Tutorial Center → Install HEY.

### Required PWA implementation
- valid Web App Manifest;
- app name and short_name;
- start_url;
- display mode appropriate for standalone experience;
- theme/background colors;
- icons including maskable icons;
- service worker;
- offline shell;
- installability criteria;
- correct scope;
- screenshots where platform supports richer install UI;
- shortcuts where useful;
- share target/file handling only if truly supported and tested.

### Install UX
If `beforeinstallprompt` is supported:
- capture event;
- show HEY-branded Install button;
- prompt only after user action;
- handle accepted/dismissed outcome;
- do not repeatedly nag after dismissal.

If browser does not expose programmatic prompt:
- show platform-specific manual steps;
- never display a fake “download” button that cannot install.

### Installed PWA behavior
- standalone shell;
- HEY icon;
- startup routes to Conversation Surface, not generic dashboard;
- session persists appropriately;
- deep links work;
- offline/local-capable parts degrade gracefully;
- updates are detected and applied safely;
- user is informed when restart/update is needed.

### Native download distinction
Do not confuse:
- PWA install;
- native Tauri desktop installer;
- mobile platform install.

The Download page should identify what the user is installing.

---

## F. HOME/DASHBOARD STILL EXISTS — BUT IS NOT THE DEFAULT POST-SIGN-IN DESTINATION

Home/Workspace remains useful for:
- widgets;
- tasks;
- calendar;
- active projects;
- missions;
- routines;
- weather;
- prayer where enabled;
- device/system state.

It is accessed from navigation and can be user-selected as startup destination.

But the default “enter HEY” experience is Chat/Voice.

---

## G. ACCEPTANCE TESTS FOR THIS AMENDMENT

1. Fresh sign-in → lands on Chat/Voice Conversation Surface.
2. Switch Chat → Voice → same conversation/context remains.
3. Voice visually matches call-like premium HEY direction.
4. In Chat, ask for video → embedded Studio appears without leaving HEY.
5. In Voice, ask for presentation → Studio appears while session continues.
6. Expand embedded Studio → dedicated/full workspace.
7. Collapse → returns to conversation without state loss.
8. Close main window during active mission → native Dynamic Island remains.
9. Click island during Voice → call controls.
10. Click island during generation → generation controls.
11. Supported browser → Install HEY CTA works.
12. Installed PWA opens standalone and lands on Conversation Surface.
13. Unsupported install browser → correct manual instructions, not fake prompt.



---


---

