# Complete Performance, Battery & Thermal Budgets
## HEY V1 — Full-depth implementation specification

**Mission:** Keep HEY responsive on weak laptops and scalable on stronger hardware.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Startup, input latency, animation FPS, memory, CPU, GPU, bundle size, background usage, network, generation orchestration, battery/thermal adaptation.
- Performance tiers and instrumentation.

# 2. User experience contract
- Typing, scrolling and core navigation remain responsive while background work runs.
- Heavy studios lazy-load.
- Weak hardware automatically reduces nonessential glass/parallax/ambient effects.
- Performance degradation is not confused with feature failure.

# 3. Architecture / runtime contract
- Performance tier detector based on measured capability, not only hardware name.
- Task scheduler budgets background work.
- Virtualize large lists, defer offscreen rendering, cache carefully.
- Native and web telemetry measure actual latency.

# 4. Required state model
- full
- balanced
- lightweight
- battery-saver
- thermal-throttled
- background

# 5. Failure and recovery catalog
- Memory pressure → release caches.
- GPU jank → lower visual tier.
- CPU saturation → throttle background agents.
- Slow network → progressive/streamed UI.

# 6. Security / privacy / trust requirements
- Performance telemetry excludes sensitive content.
- User can disable diagnostics telemetry per policy.

# 7. Data model / persistence
- performance_profiles
- perf_samples
- resource_budgets
- thermal_state
- battery_state

# 8. Events / telemetry contracts
- perf.long_task
- perf.jank
- perf.memory_pressure
- tier.changed
- battery.saver

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Old Toshiba-class weak device smoke test.
- 60Hz/120Hz UI.
- Long chat virtualization.
- Large project.
- Background mission while typing.
- Battery saver.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

