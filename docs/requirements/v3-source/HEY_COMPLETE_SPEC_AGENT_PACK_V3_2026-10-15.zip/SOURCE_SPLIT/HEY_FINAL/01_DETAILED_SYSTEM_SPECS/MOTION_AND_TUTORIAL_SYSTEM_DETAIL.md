# HEY V1 — COMPLETE ANIMATION, MOTION & TUTORIAL SYSTEM SPECIFICATION
## Authoritative OpenCode Motion Source of Truth

**Product:** HEY  
**Scope:** Every animation, transition, microinteraction, state change, tutorial animation, gesture teaching animation, background motion, widget motion, Dynamic Island motion, voice motion, Live motion, generation progress animation, page transition, error/success motion, accessibility motion behavior, and motion-performance rule in HEY V1.

**Brand quote:** **No limits to the sky.**

This document is not a list of “nice animation ideas.” It defines the complete motion language of HEY V1 down to:
- purpose;
- trigger;
- duration;
- easing;
- transform;
- opacity;
- blur;
- scale;
- elevation;
- depth;
- sequencing;
- interruption;
- reduced-motion fallback;
- touch/desktop differences;
- tutorial choreography;
- completion feedback;
- error behavior;
- performance constraints;
- implementation guidance.

The motion system must make HEY feel:
- alive;
- premium;
- calm;
- tactile;
- intelligent;
- fast;
- precise;
- dimensional;
- never gimmicky.

The design signature is:
**old-desktop tactile 3D response + modern liquid-glass depth + cinematic natural-light motion + disciplined modern easing.**

---

# 0. MOTION PRINCIPLES

1. Motion must communicate state, hierarchy, causality, or spatial relationship.
2. Nothing moves simply because “animations look cool.”
3. Motion should be fast enough to feel immediate, slow enough to remain legible.
4. The interface should never feel weightless.
5. Important surfaces have believable mass.
6. Small controls travel less than large cards.
7. Glass should refract/brighten subtly as surfaces move through depth.
8. Dragging should feel physically attached to the pointer/finger.
9. Closing/minimizing should preserve spatial continuity.
10. New content should enter from a direction that explains where it came from.
11. Background ambience must stay extremely subtle.
12. HEY's own presence can breathe gently; the rest of the UI should mostly stay still.
13. Motion must stop immediately when interaction demands it.
14. Every long animation must be interruptible.
15. Never delay a user action purely to finish animation.
16. Reduced-motion mode is a first-class variant, not an afterthought.
17. Weak hardware mode reduces blur/parallax/particles before reducing usability.
18. Animations must not block pointer, keyboard, screen-reader, or automation.
19. Loading motion must never imply fake progress.
20. High-risk confirmations use calmer, slower motion than celebratory interactions.

# 1. GLOBAL MOTION TOKENS

## Durations

- `motion-instant`: 80ms
- `motion-micro`: 120ms
- `motion-fast`: 160ms
- `motion-standard`: 240ms
- `motion-medium`: 300ms
- `motion-large`: 420ms
- `motion-panel`: 500ms
- `motion-cinematic`: 700–1200ms
- `motion-tutorial-step`: 700–1600ms depending on demonstration

## Easings

Primary:
`cubic-bezier(.22,1,.36,1)`

Fast-out:
`cubic-bezier(.16,1,.3,1)`

Press:
`cubic-bezier(.2,.8,.2,1)`

Linear:
only for measurable progress/timeline scrubbers.

Spring:
use physically damped spring for drag release, snapping, widgets, and Dynamic Island morphs.
No bouncy cartoon overshoot.

## Distances

- micro move: 2–4px
- small move: 6–12px
- panel move: 16–24px
- page move: 24–40px
- large spatial transition: 40–80px only when demonstrating hierarchy

## Scale

- hover lift: 1.005–1.015
- press: .985–.995
- modal enter: .975 → 1
- widget pickup: 1 → 1.015
- hero/cinematic: never exceed ~1.08 unless transition specifically requires it

## Blur

- enter blur: max 6–12px for decorative transition only
- never blur text during normal interaction
- use backdrop blur on surfaces, not animated blur filters on every child

# 2. LIQUID-GLASS MOTION LANGUAGE

When a glass surface moves:
- top/left highlight shifts slightly;
- shadow changes with elevation;
- background refraction changes subtly;
- edge specular highlight may travel 4–12px;
- blur amount should remain stable unless moving between depth levels.

Do not:
- animate liquid wobble on every button;
- distort text;
- use exaggerated water ripples;
- make glass bounce.

Approved special liquid morphs:
- Dynamic Island expand/collapse;
- HEY summon;
- mode switch;
- artifact-to-editor transition;
- compact widget → full widget;
- command palette reveal.

Liquid morph duration:
240–420ms.

Shape interpolation must preserve rounded geometry and avoid sudden corner jumps.

# 3. CLASSIC 3D TACTILE CONTROL MOTION

Every tactile button has:

## Hover
- translateY: -1px
- shadow: +10–20% spread/opacity
- top highlight: +8–12%
- duration: 120ms

## Press
- translateY: +1px from rest
- scale: .992
- outer shadow compresses
- inset shadow appears
- duration: 80–100ms

## Release
- return via primary easing
- 120–160ms

## Keyboard activation
Use same pressed visual for 80–100ms.

## Disabled
No hover movement.

## Toggle
Knob moves with spring-like 180–220ms.
Track light shifts after knob begins, not before.

## Segmented control
Selection plate slides under target 180–220ms.
Text/icon color crossfades 120ms.

# 4. PAGE TRANSITIONS

Default page transition:
- outgoing page opacity 1 → .96 over 100ms;
- incoming page opacity 0 → 1;
- incoming translateY 8–12px → 0;
- total 220–280ms.

Sibling pages:
- horizontal 8–16px spatial hint is allowed.

Deep navigation:
- child page moves in from 16–24px right/left depending on direction/RTL.

Back:
- inverse motion.

Do not:
- wipe whole screen;
- use giant zoom;
- spin;
- animate more than 300ms for routine navigation.

Reduced motion:
opacity crossfade 100–160ms only.

# 5. SIDEBAR / NAVIGATION MOTION

Collapsed → expanded:
- width morph: 68px → 244px, 240ms;
- labels fade in after 60ms;
- icons shift 4–8px;
- active pill morphs with container.

Expanded → collapsed:
- label fade first 80ms;
- width closes 220ms.

Active navigation item:
- glass highlight plate slides 160–200ms;
- icon brightens;
- tiny 1px depth lift.

Submenus:
- height expansion 180–220ms;
- child items stagger max 20ms each.

No large accordion bounce.

# 6. TOP BAR / BREADCRUMB MOTION

Title changes:
- old title up 4px + fade out 100ms;
- new title from 4px below + fade in 140ms.

Breadcrumb:
- new segment fades/slides in 120ms.

Context actions:
- appear with 80–120ms opacity;
- never shift page content unexpectedly.

Search field expansion:
- width morph 180–240ms;
- command suggestions fade in after field reaches 60% width.

# 7. MODAL / DRAWER / SHEET MOTION

Modal:
- backdrop 0 → 40–60% opacity, 160ms;
- panel scale .975 → 1;
- translateY 8px → 0;
- 220–280ms.

Close:
- 160–200ms.

Drawer:
- translateX 100% → 0, 260–320ms.
- content inside fades 60ms after drawer begins.

Mobile bottom sheet:
- spring from bottom;
- velocity-sensitive dismissal;
- backdrop crossfade.

High-risk confirmation:
- no bounce;
- calmer 240–320ms.

# 8. TOOLTIP / POPOVER / CONTEXT MENU

Tooltip:
- show delay: ~300ms pointer;
- animation 80–100ms fade + 2px lift;
- disappear 60–80ms.

Popover:
- scale .98 → 1;
- opacity;
- 120–160ms.

Context menu:
- originate visually at pointer;
- scale .97 → 1 around transform origin;
- 100–140ms.

Menu row hover:
- 80ms background/edge response.

# 9. TOAST / NOTIFICATION MOTION

Toast enter:
- desktop: translateX 16px + fade, 220ms;
- mobile: translateY -8px or bottom-sheet style depending placement.

Grouped notifications:
- stack compresses smoothly;
- newest item causes 8–12px stack shift.

Success toast:
- small tactile icon pop 120ms;
- no confetti by default.

Error:
- no aggressive shake.
- use subtle 2px horizontal correction once if needed.

Dismiss:
- opacity + 8px movement 140ms.

# 10. INPUT / PROMPT MOTION

Text field focus:
- border/highlight brightens 120ms;
- subtle inset depth shift;
- no scale jump.

Prompt expansion:
- grows vertically with content 120–180ms;
- toolbar fades in as second line appears.

Attachment:
- chip slides in 160ms;
- upload progress line animates linearly if measurable.

Send:
- icon depresses 80ms;
- message leaves composer with 120–160ms upward movement.

Voice button:
- idle soft pulse every ~2.5s only when voice is available and page context benefits.

# 11. CHAT MOTION

User message:
- enter from 6px below;
- opacity 0 → 1;
- 160ms.

HEY response:
- editorial block fades/settles rather than bubbles in;
- first content appears as soon as available;
- streaming cursor/activity indicator is subtle.

Tool/action status:
- inline chip morphs:
  “Planning” → “Acting” → “Verifying” → “Done”
- state transition 160ms.

Artifact created:
- preview card unfolds from response region;
- 240–320ms;
- clicking it morphs into full artifact viewer/editor.

Do not animate every streamed word independently.

# 12. VOICE VISUALIZER MOTION

Core states:

## Idle
- slow breathing scale 1.0 ↔ 1.015;
- 3.5–5s cycle;
- low brightness.

## Listening
- amplitude reacts to microphone;
- smoothing prevents jitter;
- ring/field expands with voice energy;
- no more than ~8–12% radius excursion.

## Thinking
- motion slows;
- shape becomes more ordered;
- subtle inward/outward energy.

## Speaking
- brighter, more active waveform;
- driven by output audio envelope.

## Interrupted
- visualizer contracts quickly 120–180ms;
- then transitions to listening.

## Muted
- animation dampens;
- indicator becomes clearly muted.

Reduced motion:
- static orb with simple opacity state changes.

# 13. HEY LIVE MOTION

Source switch:
- current source scales to .985 + darkens 120ms;
- new source crossfades 180–240ms;
- source label updates after new source appears.

Pointer guidance:
- outline target in 160ms;
- arrow/path draws over 220ms;
- pulse max 2 times;
- then remains static.

Guide Mode:
- cool neutral highlight.

Assist Mode:
- slightly brighter highlight + prepared action tray.

Act Mode:
- active target receives controlled cyan edge + action cursor.

Screen/camera permission:
- sensing badge slides in 160ms;
- never disappears while active.

Annotations:
- draw in quickly;
- remain until resolved or user clears.

# 14. DYNAMIC ISLAND MOTION

Collapsed idle:
- near-static.

Listening:
- width expands 8–20px;
- waveform appears.

Thinking:
- internal light travels once across surface;
- no continuous spinner if not needed.

Expanded:
- liquid morph from pill to panel;
- 300–420ms spring;
- contents fade in in hierarchy:
  status → primary control → secondary info.

Collapse:
- secondary info fades first;
- shape morphs second.

Progress:
- thin internal progress line.

Success:
- quick check morph;
- return to idle after 1.2–2s.

Error:
- edge shifts to semantic error color;
- no shake.

Cross-monitor move:
- fade from old screen and materialize on target, not animate across physical displays.

# 15. WIDGET MOTION

Create:
- appears at intended spawn location;
- scale .96 → 1;
- opacity 0 → 1;
- 240ms.

Pickup:
- scale 1.015;
- shadow/elevation increases;
- underlying canvas darkens only if necessary.

Drag:
- 1:1 pointer response;
- no easing while directly controlled.

Snap:
- guide appears before drop;
- release spring 180–240ms.

Resize:
- direct response;
- content reflows after threshold;
- avoid jitter by debouncing expensive layout.

Minimize:
- widget collapses toward its dock/taskbar target;
- 220–320ms.

Maximize:
- morph from current bounds to viewport content bounds;
- 300–420ms.

Close:
- opacity + scale .98 over 140–180ms.

Stack:
- cards shift with 160–220ms coordinated motion.

# 16. WORKSPACE MOTION

Workspace mode change:
- do not rearrange everything instantly.
- primary widgets move first;
- secondary widgets settle after;
- total under 500ms.

Auto-layout:
- show ghost positions before move if user initiated.
- user can cancel.

Overview:
- canvas zooms out 4–8%;
- widgets reduce elevation;
- labels appear.

Exit overview:
- restore selected target first.

# 17. PROJECT / CARD / LIST MOTION

Card hover:
- 1px lift;
- subtle thumbnail parallax max 2–3px.

Open project:
- selected card visually becomes header/hero via shared-element transition when performance permits;
- 300–420ms.

List sort:
- FLIP animation;
- 180–260ms.

Filter:
- nonmatching items fade/collapse;
- matching items reposition smoothly.

# 18. COSMOS MOTION

Practical list mode:
- standard list/card transitions only.

Visual Cosmos:
- nodes drift extremely slowly or remain mostly still;
- selected node moves forward in depth;
- connected edges brighten;
- irrelevant nodes dim;
- camera motion is slow and user-controlled.

Zoom:
- inertia small;
- no nausea-inducing acceleration.

New memory:
- subtle node emergence;
- not a dramatic exploding star.

Reduced motion:
- static graph with instant zoom steps.

# 19. IMAGE STUDIO MOTION

Generation:
- placeholder canvas appears immediately;
- status bar stages:
  preparing → generating → QA → complete.
- avoid fake image “painting” unless provider actually streams.

Variant arrival:
- cards fade/scale in 120ms stagger, max 40ms apart.

Selection:
- bounding outline appears 100ms.

Lock:
- lock icon rotates/snaps 90–140ms;
- selected region receives subtle protected outline.

Before/After:
- draggable split with direct response.
- toggle crossfade 120ms.

History branch:
- node expands into tree 220ms.

# 20. STORYBOARD / FRAME MOTION

New shot:
- card inserts in timeline 180ms.

Reorder:
- neighboring cards shift physically out of the way.

Open shot:
- thumbnail morphs to large frame preview.

Continuity warning:
- subtle amber outline/pill;
- no flashing.

Camera parameter changes:
- preview transitions only when actual regenerated/preview data exists.

# 21. VIDEO / MOTION GRAPHICS / AUDIO TIMELINE MOTION

Playhead:
- linear with media time.

Scrubbing:
- immediate direct response.

Clip drag:
- lift + snap lines.

Trim:
- direct edge manipulation.

Generated replacement:
- old clip remains visible until new one verifies;
- then crossfade/replace 180ms.

Waveform:
- do not animate waveform decoratively.

Motion-graphics easing editor:
- curve point movement direct;
- preview can loop only while user requests it.

# 22. PRESENTATION / DOCUMENT MOTION

Slide/page reorder:
- physical card movement.

Slide open:
- thumbnail shared-element transition to canvas.

Presentation playback:
- respect actual chosen transition;
- editor chrome fades away 220ms.

Document page:
- no fake page-turn by default.
- use subtle vertical/page-stack transitions.

Compare revisions:
- diff highlight fades in 120ms.

# 23. RESEARCH MOTION

Source found:
- source card enters 140–180ms.

Evidence status:
- strength badge crossfades.

Research stages:
- plan → searching → reading → synthesizing → verifying.

Do not show hundreds of animated source cards while background research runs.
Use summarized progress.

# 24. FORGE MOTION

Natural-language request:
- prompt collapses into a compact request header.

Forge pipeline:
duplicate check → design → permissions → tests → sandbox → preview → install

Stage transition:
- progress rail advances;
- current panel crossfades/slides 8px;
- completed stage gets tactile check.

Generated capability preview:
- card assembles from sections over 240–320ms.

Install:
- controlled seal/lock-in animation;
- not confetti.

# 25. AUTOMATION MOTION

Node editor:
- connection line draws when linked.
- node drag direct.
- auto-layout uses FLIP transition.

Run:
- current step receives moving 2px edge/rail;
- completed step gets check;
- failed step semantic state.

Paused:
- motion stops.

Test mode:
- simulated values animate through nodes only if readable.

# 26. TASKS / CALENDAR / REMINDERS MOTION

Task complete:
- check depresses;
- title opacity reduces;
- row moves to completed after 180–240ms.

Reorder:
- direct drag.

Calendar event move:
- card follows pointer;
- time indicator tracks.

Reminder snooze:
- card slides to future group.

No celebratory confetti for routine task completion.

# 27. TRUST / PERMISSION MOTION

Grant:
- permission card shifts from neutral → granted;
- lock icon opens/closes appropriately;
- 160–220ms.

Revoke:
- calm controlled transition;
- linked active capability visibly shuts down if applicable.

Stop Everything:
- confirmation modal enters calmly;
- after confirmed, active status indicators switch off in sequence over 300–500ms;
- strong clear final state.

Security alert:
- no flashing red;
- persistent semantic indicator.

# 28. GESTURE FEEDBACK MOTION

When gesture recognition is active:
- small skeleton/hand indicator optional;
- confidence ring appears only in Gesture Studio or debugging, not normal use.

Gesture recognized:
- subtle 100ms highlight;
- action begins.

Drag gesture:
- target follows gesture smoothly with filtering.

Swipe:
- content begins moving with gesture;
- releases with inertia.

Pinch:
- target highlights before activation.

Raised-hand stop:
- HEY speech visualizer contracts immediately.

False/ambiguous gesture:
- do nothing destructive;
- optional tiny “not recognized” indicator, no error spam.

# 29. GESTURE STUDIO TRAINING MOTION

Step 1 — camera activation:
- privacy curtain lifts only after permission.

Step 2 — show reference gesture:
- animated 3D/2D hand demonstration loops slowly.

Step 3 — record sample:
- countdown 3→2→1;
- capture indicator;
- success ring.

Step 4 — repeat:
- sample chips fill progressively.

Step 5 — conflict analysis:
- side-by-side gesture silhouettes.

Step 6 — binding:
- draggable gesture card connects to action card.

Step 7 — test:
- live action preview.

Step 8 — save:
- compact confirmation and tutorial completion.

# 30. ERROR / SUCCESS / PARTIAL SUCCESS MOTION

Success:
- icon morph to check 140–180ms;
- no excessive celebration.

Partial success:
- amber split-state indicator;
- completed items settle first;
- failed items remain visible.

Error:
- panel stays stable;
- semantic edge + icon.
- one 2px correction nudge permitted for invalid form field.

Recovery:
- error state morphs back into progress state rather than disappear/reappear.

# 31. OFFLINE / RECONNECT MOTION

Going offline:
- network badge transitions to offline;
- cloud-only actions subtly disable over 160ms;
- local-capable controls remain.

Reconnect:
- badge restores;
- queued tasks appear;
- do not automatically launch all queued high-cost work without policy.

No full-screen interruption unless active task requires network.

# 32. BACKGROUND / TRAY MOTION

Tray/menu-bar:
- native platform motion where possible.

Main window close while helper remains:
- HEY window fades/scales slightly;
- Dynamic Island remains.

Reopen:
- restore prior workspace with 220–320ms page reveal.

Background mission complete:
- OS notification;
- Island status changes when visible.

# 33. MOBILE MOTION

Use less distance than desktop.

Bottom sheet:
- velocity-responsive spring.

Bottom nav:
- active icon plate moves 160ms.

Swipe back:
- interactive with finger.

Cards:
- no hover.

Haptic:
- light on press;
- snap on drag;
- confirmation;
- error.

Respect OS Reduce Motion.

# 34. TABLET MOTION

Split-pane resize:
- direct.

Panel open:
- 180–240ms.

Widget drag:
- touch-lift after small hold if needed to avoid accidental scroll.

Stylus:
- direct manipulation, minimal animation delay.

# 35. TV / PROJECTOR MOTION

Use:
- larger slower transitions;
- 300–500ms;
- simple fades/slides;
- no small parallax;
- no tiny hover cues.

Gesture-controlled navigation:
- highlight target before activation.

# 36. REDUCED MOTION MASTER RULES

When OS or HEY setting requests reduced motion:

Replace:
- translation >8px → fade;
- zoom → fade;
- parallax → none;
- continuous breathing → static state;
- graph drift → static;
- page shared-element motion → crossfade;
- liquid morph → simple size/fade state;
- tutorial hand/path animations → step-by-step still frames with captions.

Keep:
- essential progress movement;
- focus states;
- pressed state;
- state color changes;
- direct drag response.

# 37. PERFORMANCE MOTION TIERS

## Full
High-end hardware:
- liquid reflections;
- subtle parallax;
- richer shadows;
- background blur.

## Balanced
Default:
- standard blur;
- essential motion;
- limited parallax.

## Lightweight
Weak/battery/thermal:
- reduced blur;
- no ambient parallax;
- static backgrounds;
- simplified shadows;
- fewer layered transitions.

Switching tiers must not visibly redesign layout.

# 38. COMPLETE TUTORIAL ANIMATION CATALOG

## 38.1 — First Launch Tutorial

**Purpose:** Introduce HEY

**Tutorial choreography:**  
wordmark reveal → quote → workspace materializes → chat/voice/Live previews → user performs one real task

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.2 — Home Dashboard Tutorial

**Purpose:** Explain dashboard

**Tutorial choreography:**  
spotlight HEY status → primary widget → drag one widget → show add widget → finish

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.3 — Chat Tutorial

**Purpose:** Teach prompt workflow

**Tutorial choreography:**  
highlight input → attach file → mode/context chips → send → artifact opens

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.4 — Voice Tutorial

**Purpose:** Teach voice

**Tutorial choreography:**  
mic button → listening visualizer → interrupt → mute → captions

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.5 — HEY Live Tutorial

**Purpose:** Teach screen/camera

**Tutorial choreography:**  
choose source → sensing badge → ask about visible item → pointer guidance → switch Guide/Assist/Act

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.6 — Dynamic Island Tutorial

**Purpose:** Teach persistent HEY

**Tutorial choreography:**  
collapsed pill → listening → expand → mini-chat → task controls → collapse

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.7 — Widgets Tutorial

**Purpose:** Teach widgets

**Tutorial choreography:**  
add from library → drag → resize → minimize → maximize → close

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.8 — Widget Library Tutorial

**Purpose:** Discover widgets

**Tutorial choreography:**  
search → preview size variants → add → customize

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.9 — Workspace Tutorial

**Purpose:** Teach canvas

**Tutorial choreography:**  
move widget → snap → group → overview → restore

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.10 — Projects Tutorial

**Purpose:** Teach project model

**Tutorial choreography:**  
create project → add file → see goal → open artifact → project memory

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.11 — Project DNA Tutorial

**Purpose:** Teach consistency

**Tutorial choreography:**  
show palette/type/reference → lock invariant → generate consistent output → drift warning

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.12 — Cosmos Tutorial

**Purpose:** Teach memory

**Tutorial choreography:**  
save memory → search → relationship connection → edit/delete/provenance

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.13 — Memory Inbox Tutorial

**Purpose:** Teach control

**Tutorial choreography:**  
candidate appears → why it matters → approve/edit/reject → category rule

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.14 — Image Generation Tutorial

**Purpose:** Teach create

**Tutorial choreography:**  
prompt → reference → variants → select → QA → save

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.15 — Pinpoint Precision Image Tutorial

**Purpose:** Teach surgical edit

**Tutorial choreography:**  
select object → lock everything else → request change → inspect before/after

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.16 — Image History Tutorial

**Purpose:** Teach branches

**Tutorial choreography:**  
V1 → branch A → return V1 → branch B → compare → merge

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.17 — Image Editor Tutorial

**Purpose:** Teach tools

**Tutorial choreography:**  
select → adjust → generative fill → compare → restore

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.18 — Storyboard Tutorial

**Purpose:** Teach sequence

**Tutorial choreography:**  
script → scenes → shot frame → reorder → continuity lock → first/last frames

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.19 — Video Studio Tutorial

**Purpose:** Teach timeline

**Tutorial choreography:**  
generate clips → preview → replace one shot → captions → export

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.20 — Motion Graphics Tutorial

**Purpose:** Teach recipes

**Tutorial choreography:**  
select recipe → edit text/timing → easing → preview → export

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.21 — Audio Tutorial

**Purpose:** Teach waveform

**Tutorial choreography:**  
import → transcript → cleanup → voiceover → sync → export

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.22 — Presentation Tutorial

**Purpose:** Teach deck

**Tutorial choreography:**  
generate outline → slides → edit one slide → transitions → presenter mode

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.23 — Document / Book Tutorial

**Purpose:** Teach structured doc

**Tutorial choreography:**  
import source → chapters → redesign page → lock content → derive teacher edition

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.24 — Research Tutorial

**Purpose:** Teach evidence

**Tutorial choreography:**  
question → plan → sources → evidence strength → synthesis → citations

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.25 — Browser Tutorial

**Purpose:** Teach Ask HEY

**Tutorial choreography:**  
select page → Ask HEY → summarize → save to project

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.26 — Files Tutorial

**Purpose:** Teach file actions

**Tutorial choreography:**  
select file → ask HEY → organize → preview change → undo

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.27 — Code Tutorial

**Purpose:** Teach repo workflow

**Tutorial choreography:**  
open repo → ask task → planned files → diff → tests → verification

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.28 — Tasks Tutorial

**Purpose:** Teach task provenance

**Tutorial choreography:**  
create task → success criteria → assign agent → complete/verify

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.29 — Calendar Tutorial

**Purpose:** Teach scheduling

**Tutorial choreography:**  
drag task → HEY suggests slot → confirm → reminder

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.30 — Mission Center Tutorial

**Purpose:** Teach long jobs

**Tutorial choreography:**  
start mission → watch stage → pause → resume → inspect receipt

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.31 — Automations Tutorial

**Purpose:** Teach automation

**Tutorial choreography:**  
choose template → trigger → steps → test → activate

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.32 — Teach HEY By Doing Tutorial

**Purpose:** Teach recorder

**Tutorial choreography:**  
start recording → perform routine → HEY extracts steps → edit variables → test → save

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.33 — Forge Tutorial

**Purpose:** Teach capability creation

**Tutorial choreography:**  
describe wish → duplicate check → permissions → sandbox test → install

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.34 — Skills Tutorial

**Purpose:** Teach reusable skill

**Tutorial choreography:**  
browse → permission manifest → install → run → inspect

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.35 — Agents Advanced Tutorial

**Purpose:** Teach agent panel

**Tutorial choreography:**  
show hidden advanced toggle → agent health → run → verifier → logs

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.36 — Modes Tutorial

**Purpose:** Teach mode transformation

**Tutorial choreography:**  
select Study Mode → workspace rearranges → notifications change → restore

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.37 — Focus Mode Tutorial

**Purpose:** Teach focused state

**Tutorial choreography:**  
start focus → distractions collapse → timer → held notifications → end

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.38 — Meeting Mode Tutorial

**Purpose:** Teach consent + notes

**Tutorial choreography:**  
start → sensing indicator → transcript → decisions/tasks → end summary

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.39 — Morning Mode Tutorial

**Purpose:** Teach briefing

**Tutorial choreography:**  
brief appears → expand item → mark focus → start day

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.40 — Devices Tutorial

**Purpose:** Teach pairing

**Tutorial choreography:**  
discover → verify code → assign role → handoff

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.41 — Cross-Device Handoff Tutorial

**Purpose:** Teach continuity

**Tutorial choreography:**  
desktop task → 'move to tablet' → context transfers → continue

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.42 — Smart Home Tutorial

**Purpose:** Teach control

**Tutorial choreography:**  
room card → adjust light → scene → high-risk lock confirmation

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.43 — Gesture Basics Tutorial

**Purpose:** Teach default gestures

**Tutorial choreography:**  
open palm → pinch → drag → swipe → stop palm

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.44 — Custom Gesture Tutorial

**Purpose:** Teach training

**Tutorial choreography:**  
record samples → conflict check → bind action → test

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.45 — Permissions Tutorial

**Purpose:** Teach trust

**Tutorial choreography:**  
just-in-time permission → scope → expiry → revoke

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.46 — Trust Center Tutorial

**Purpose:** Teach authority

**Tutorial choreography:**  
see active mic/screen → inspect grant → revoke → Stop Everything

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.47 — Private Mode Tutorial

**Purpose:** Teach privacy

**Tutorial choreography:**  
activate → memory write indicator off → local/cloud policy → exit

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.48 — Offline Mode Tutorial

**Purpose:** Teach fallback

**Tutorial choreography:**  
disconnect → local capabilities remain → queued cloud action explanation

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.49 — Notifications Tutorial

**Purpose:** Teach rules

**Tutorial choreography:**  
notification → why shown → snooze → set 'only notify if'

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.50 — Settings Appearance Tutorial

**Purpose:** Teach personalization

**Tutorial choreography:**  
theme → glass → density → live preview → reset

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.51 — Settings Voice Tutorial

**Purpose:** Teach voice personalization

**Tutorial choreography:**  
choose voice → preview → speed → wake phrase

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.52 — Settings Personality Tutorial

**Purpose:** Teach challenge/humor

**Tutorial choreography:**  
challenge slider → preview example → adaptive mode

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.53 — Provider Routing Advanced Tutorial

**Purpose:** Teach model control

**Tutorial choreography:**  
Auto → inspect route → pin provider → fallback

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.54 — Developer Console Tutorial

**Purpose:** Teach traces

**Tutorial choreography:**  
open events → mission → tool call → verification receipt

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.55 — Diagnostics Tutorial

**Purpose:** Teach health

**Tutorial choreography:**  
run checks → one degraded system → suggested fix → retest

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.56 — Time Machine Tutorial

**Purpose:** Teach restore

**Tutorial choreography:**  
create snapshot → make change → compare → restore

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.57 — Command Palette Tutorial

**Purpose:** Teach keyboard

**Tutorial choreography:**  
open shortcut → search command → run → recent commands

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.58 — Search Tutorial

**Purpose:** Teach universal search

**Tutorial choreography:**  
search vague phrase → files/memory/projects → filter → open result

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.59 — Share / Collaboration Tutorial

**Purpose:** Teach scope

**Tutorial choreography:**  
invite → choose role → show exactly what is shared → revoke

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.60 — Billing / Usage Tutorial

**Purpose:** Teach plan clarity

**Tutorial choreography:**  
usage gauge → limits → plan details → manage billing

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.61 — Accessibility Tutorial

**Purpose:** Teach accessibility presets

**Tutorial choreography:**  
open accessibility → select profile → preview → customize

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.62 — RTL / Language Tutorial

**Purpose:** Teach language switch

**Tutorial choreography:**  
switch Arabic/Kurdish → UI mirrors → voice/text language preview

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

## 38.63 — Tutorial Center Tutorial

**Purpose:** Teach learning hub

**Tutorial choreography:**  
search feature → watch demo → practice → mark complete

**Default duration:** 20–60 seconds depending on feature complexity.  
**Format:** interactive spotlight tutorial first; optional short animated demo; optional voice narration.  
**Controls:** Back, Next, Skip, Replay, Practice.  
**Completion:** subtle check + “You can replay this anytime from Tutorials.”  
**Reduced motion:** static annotated frames + step transitions.  
**Rules:** never auto-replay after completion; never block essential work; use real controls rather than fake video when interactive tutorial is possible.

# 39. MICROINTERACTION INVENTORY

## 39.1 — Button hover

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.2 — Button press

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.3 — Button release

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.4 — Toggle on

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.5 — Toggle off

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.6 — Checkbox select

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.7 — Radio select

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.8 — Segment change

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.9 — Input focus

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.10 — Input validation success

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.11 — Input validation error

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.12 — Password reveal

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.13 — Search expand

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.14 — Chip add

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.15 — Chip remove

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.16 — Attachment upload

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.17 — Upload complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.18 — Upload fail

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.19 — Download progress

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.20 — Download complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.21 — Tab switch

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.22 — Accordion open

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.23 — Accordion close

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.24 — Tooltip show

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.25 — Popover show

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.26 — Context menu show

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.27 — Modal open

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.28 — Modal close

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.29 — Drawer open

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.30 — Bottom sheet open

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.31 — Toast success

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.32 — Toast error

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.33 — Toast grouped

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.34 — Skeleton load

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.35 — Progress determinate

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.36 — Progress indeterminate

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.37 — Avatar status change

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.38 — Badge update

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.39 — Status dot update

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.40 — Breadcrumb change

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.41 — List insert

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.42 — List remove

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.43 — List reorder

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.44 — Filter apply

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.45 — Sort apply

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.46 — Card select

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.47 — Card deselect

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.48 — Card approve

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.49 — Card reject

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.50 — Favorite/pin

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.51 — Archive

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.52 — Restore

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.53 — Undo

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.54 — Redo

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.55 — Copy success

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.56 — Share success

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.57 — Permission grant

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.58 — Permission revoke

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.59 — Permission expire

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.60 — Connection online

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.61 — Connection offline

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.62 — Provider degraded

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.63 — Provider recovered

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.64 — Agent start

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.65 — Agent complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.66 — Agent fail

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.67 — Mission start

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.68 — Mission waiting

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.69 — Mission verifying

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.70 — Mission complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.71 — Mission fail

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.72 — Task start

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.73 — Task complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.74 — Task blocked

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.75 — Memory saved

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.76 — Memory updated

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.77 — Memory contradiction

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.78 — Memory deleted

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.79 — Device discovered

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.80 — Device paired

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.81 — Device offline

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.82 — Device handoff

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.83 — Widget add

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.84 — Widget drag

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.85 — Widget snap

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.86 — Widget resize

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.87 — Widget minimize

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.88 — Widget maximize

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.89 — Widget close

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.90 — Workspace overview

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.91 — Sidebar collapse

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.92 — Sidebar expand

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.93 — Command palette open

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.94 — Global quick add

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.95 — Dynamic Island listen

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.96 — Dynamic Island think

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.97 — Dynamic Island success

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.98 — Live pointer highlight

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.99 — Gesture recognized

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.100 — Gesture ambiguous

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.101 — Lock element

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.102 — Unlock element

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.103 — Version branch

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.104 — Version restore

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.105 — Compare slider

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.106 — Generation start

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.107 — Generation QA

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.108 — Generation repair

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.109 — Generation complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.110 — Generation cancel

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.111 — Export start

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.112 — Export complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.113 — Export fail

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.114 — Tutorial spotlight

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

## 39.115 — Tutorial complete

**Purpose:** communicate the state change immediately without stealing attention.  
**Default duration:** 80–220ms unless tied to a larger spatial transition.  
**Motion:** use the closest relevant global pattern from Sections 1–37.  
**Sound/haptic:** optional only if the action materially benefits from it.  
**Reduced motion:** opacity/color/depth state only.  
**Verification:** interaction must remain usable if animation is disabled.

# 40. TUTORIAL VISUAL LANGUAGE

Tutorial animations must match real product UI.

Never:
- draw fake buttons that do not exist;
- use old screenshots after UI changes;
- make a tutorial that teaches a shortcut the current app does not support;
- use cursor paths that do not correspond to actual hit targets.

Use:
- spotlight;
- animated pointer/finger;
- gesture silhouette;
- short caption;
- optional HEY narration;
- real UI response.

Pointer animation:
- 300–500ms move;
- 80ms press;
- target briefly highlights.

Touch animation:
- soft fingertip circle;
- tap pulse;
- swipe trail max 250ms.

Gesture animation:
- translucent hand skeleton or clean hand silhouette;
- directional path;
- start and end poses;
- speed close to real gesture.

# 41. TUTORIAL TRIGGER RULES

First-use trigger:
- only after user enters feature or asks to use it;
- not on app launch unless onboarding specifically covers it.

Contextual:
- if user hesitates/repeats failed interaction, HEY may offer tutorial.

Manual:
- Help → Tutorials;
- “HEY, show me how to use X.”

Never trigger:
- during emergency/high-risk confirmation;
- while media export is critical;
- over another modal;
- during active Live action unless user asks.

# 42. TUTORIAL PROGRESS & MEMORY

Store:
- tutorial id;
- version;
- completed;
- skipped;
- last viewed;
- practice completed.

When UI changes significantly:
- tutorial version increments;
- HEY may offer “This feature changed — see what’s new.”

Do not reset all tutorials after update.

# 43. FEATURE DISCOVERY ANIMATIONS

When a new feature becomes relevant:
- tiny “new” dot or subtle pill;
- one-time 1px lift/pulse;
- no animated banners.

Hover/click:
- short explanation;
- “Show me” opens tutorial.

Do not make new features compete for attention simultaneously.

# 44. LAUNCH / BRAND MOTION INSIDE PRODUCT

Splash:
- optional HEY wordmark reveal under 900ms;
- skip on warm launches if it slows access.

Brand quote:
“No limits to the sky.”
Use only in:
- first-run;
- selected loading/brand film;
- marketing.

Do not show every time app opens.

# 45. SOUND + MOTION COORDINATION

Optional sound palette:
- glass tick;
- soft tactile click;
- low confirm;
- subtle warning;
- wake sound;
- generation completion.

Synchronize:
- press sound at physical depression;
- success sound after verification, not merely after request starts;
- error sound after failure is known.

No loud sci-fi beeps.

# 46. HAPTIC + MOTION COORDINATION

Mobile/tablet:
- light press haptic on tactile buttons;
- snap haptic on widget/drag snapping;
- medium confirm on successful important action;
- warning haptic on failed high-importance action.

Gesture:
- optional recognition haptic on wearable/phone if applicable.

Respect system haptic disable.

# 47. ANIMATION QA

For every animation test:
- 60Hz;
- 120Hz;
- weak integrated GPU;
- battery saver;
- reduced motion;
- browser zoom 200%;
- RTL;
- mobile;
- tablet;
- desktop;
- keyboard;
- touch;
- screen reader focus;
- interrupted mid-animation.

No animation may:
- trap focus;
- move click targets unexpectedly during user press;
- delay permission/security action;
- hide content longer than needed;
- cause horizontal overflow;
- create motion sickness.

# 48. PERFORMANCE BUDGETS

Avoid:
- animating blur radius continuously;
- animating box-shadow on hundreds of nodes;
- animating width/height in large lists where transform can work;
- simultaneous 3D transforms on many cards;
- persistent particle systems.

Prefer:
- transform;
- opacity;
- FLIP;
- compositor-friendly effects;
- static blurred layers.

Dynamic ambient animations pause:
- when tab hidden;
- when battery saver active;
- when reduced motion active;
- when performance degrades.

# 49. MOTION IMPLEMENTATION ARCHITECTURE

Create centralized motion tokens.

Suggested modules:
- motionTokens
- easing
- durations
- springPresets
- reducedMotion
- performanceTier
- sharedTransitions
- tutorialMotion
- gestureFeedback
- dynamicIslandMotion
- widgetMotion
- voiceMotion

Do not hardcode animation timing independently in every component.

Expose:
- `useReducedMotion`
- `usePerformanceTier`
- `motionPreset(name)`
- shared enter/exit variants
- tutorial choreography primitives.

If using a motion library, keep wrappers thin and avoid making UI dependent on proprietary animation semantics.

# 50. ACCEPTANCE DEFINITION

The motion system is complete only when:

- every major page has intentional enter/exit behavior;
- every interactive control has hover/press/focus/disabled behavior;
- widgets drag/resize/minimize/maximize smoothly;
- Dynamic Island morphs cleanly;
- voice states are visually distinct;
- Live annotations are legible and restrained;
- gesture feedback is clear;
- generation progress is truthful;
- artifact version/compare motion is understandable;
- permissions/security motion is calm and unambiguous;
- offline/reconnect states transition correctly;
- all tutorials exist for major features;
- tutorials teach the real UI;
- tutorials have reduced-motion variants;
- weak hardware mode remains smooth;
- animations are interruptible;
- accessibility is preserved;
- no animation exists purely to show off.

# 51. FINAL MOTION NORTH STAR

HEY should never feel static, but it should also never feel restless.

The product should feel like it has weight, awareness, and restraint.

Buttons feel physical.
Glass feels dimensional.
Widgets feel spatial.
HEY feels alive.
Progress feels honest.
Tutorials feel obvious.
Gestures feel direct.
Transitions preserve place.
Nothing moves without a reason.

The user should not consciously think:
“Nice animation.”

They should think:
“This feels incredibly polished.”

**No limits to the sky.**


---

