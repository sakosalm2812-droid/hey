# Complete Tutorial, Onboarding & Feature Discovery System
## HEY V1 — Full-depth implementation specification

**Mission:** Teach every major HEY capability through real UI practice, not static help pages.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- First-use tutorials, Tutorial Center, contextual Show Me, animated demos, practice mode, tutorial versioning, completion, discovery nudges.
- 63+ major tutorials and replay.

# 2. User experience contract
- Tutorial appears on first meaningful use, not as startup spam.
- User can say 'show me how to use X'.
- Tutorial spotlights real controls and lets user practice.
- Skip/replay/reduced-motion always available.
- Changed UI increments tutorial version and can offer What's New.

# 3. Architecture / runtime contract
- Tutorial registry maps capability IDs to steps, selectors/anchors, voice copy, fallback static frames and version.
- Runtime validates target exists before starting.
- Analytics records completion without recording sensitive content.
- Tutorial overlay never blocks critical security flow.

# 4. Required state model
- not-started
- offered
- in-progress
- skipped
- completed
- outdated
- practice

# 5. Failure and recovery catalog
- Target missing → fallback explanation and report stale tutorial.
- User navigates away → pause.
- Reduced motion → still-step version.
- Feature unavailable → platform-specific tutorial.

# 6. Security / privacy / trust requirements
- Tutorials must not grant permissions automatically.
- Privacy-sensitive feature tutorial explains sensing indicators.

# 7. Data model / persistence
- tutorials
- tutorial_steps
- tutorial_progress
- tutorial_versions

# 8. Events / telemetry contracts
- tutorial.offered
- tutorial.started
- tutorial.step
- tutorial.skipped
- tutorial.completed
- tutorial.stale

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Voice tutorial by voice command.
- Live first-use tutorial.
- Replay.
- UI selector stale detection.
- Reduced-motion tutorial.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

