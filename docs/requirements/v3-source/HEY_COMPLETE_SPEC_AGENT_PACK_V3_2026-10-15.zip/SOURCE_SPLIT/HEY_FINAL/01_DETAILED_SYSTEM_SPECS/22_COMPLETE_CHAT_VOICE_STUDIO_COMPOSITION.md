# Complete Conversation Surface + Embedded Studios
## HEY V1 — Full-depth implementation specification

**Mission:** Make Chat, Voice and creation/editing feel like one continuous HEY experience.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat/Voice modality switching, embedded studios, artifact cards, context persistence, voice-call UI, studio full-screen expansion, conversational edits.
- Image/video/audio/presentation/document/storyboard/code/research composition.

# 2. User experience contract
- Sign-in lands here.
- Chat and Voice share the exact same conversation and project context.
- Voice is call-like and premium, not generic mic page.
- Creation requests spawn embedded Studio within conversation/workspace.
- Dedicated Studio route opens same artifact/state; not separate duplicate state.
- Chat/Voice commands can manipulate current studio using Pinpoint locks.

# 3. Architecture / runtime contract
- Conversation session owns references to active project, artifact, studio session and Live session.
- Studio session has canonical artifact ID/version and is rendered in embedded/full modes.
- Voice and text inputs feed same HEY Brain/orchestration.
- UI event bus/state store synchronizes studio changes back to conversation.

# 4. Required state model
- chat
- voice-idle
- voice-listening
- voice-thinking
- voice-speaking
- studio-embedded
- studio-expanded
- studio-minimized
- generation-running
- waiting-user
- error

# 5. Failure and recovery catalog
- Studio component crash → conversation remains alive.
- Voice disconnect → fallback to Chat without context loss.
- Provider failure → studio retains prompt/assets.
- Route change → persist unsaved studio draft.

# 6. Security / privacy / trust requirements
- Mic/screen/camera visible indicators.
- Studio file access scoped.
- Voice transcript privacy settings respected.

# 7. Data model / persistence
- conversations
- conversation_turns
- studio_sessions
- active_artifact_refs
- voice_sessions
- drafts

# 8. Events / telemetry contracts
- conversation.mode.changed
- studio.opened
- studio.expanded
- artifact.changed
- voice.started
- voice.interrupted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Chat→Voice same context.
- Voice→Chat same context.
- Chat request video opens embedded studio.
- Voice slide-three-only edit modifies only slide three.
- Reload restores studio draft.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

