# HEY V1 — COMPLETE FRONT-END DESIGN SYSTEM & PAGE-BY-PAGE SPECIFICATION
## Authoritative OpenCode Front-End Source of Truth

**Product:** HEY  
**Scope:** Every user-facing HEY V1 surface  
**Primary brand quote:** **“No limits to the sky.”**

This is the complete front-end design specification for HEY V1. It is not a mood board, not a loose style guide, and not a shortlist of important screens. It defines the visual language, page architecture, component behavior, responsive logic, motion, interactions, tutorials, accessibility, error states, and page-by-page content rules across the entire product.

HEY V1 must feel calm, premium, tactile, dimensional, highly capable, and unmistakably HEY. The signature combination is:

- **modern liquid-glass depth**
- **classic desktop-style tactile 3D feedback**
- **cinematic natural lighting**
- **near-black / ocean-deep surfaces**
- **restrained cyan / arctic accents**
- **editorial spacing**
- **strong hierarchy**
- **low visual clutter**
- **high functional density only when the user explicitly enters advanced/pro workspaces**

---

# 0. NON-NEGOTIABLE FRONT-END RULES

1. Every page must look intentionally designed.
2. No generic browser-default inputs, buttons, spinners, errors, or empty states.
3. No cyberpunk overload, neon-everywhere aesthetic, generic purple-blue AI gradients, glowing robot heads, or fake holograms.
4. No 12-card admin-dashboard grid as the default visual language.
5. Do not imitate old Windows literally. Borrow its tactile depth, bevel logic, physical button travel, and clarity of state.
6. Do not imitate Apple literally. Borrow liquid-glass depth, environmental reflection, precision, softness, and premium restraint.
7. HEY’s visual language must be original.
8. All pages support dark mode first; light mode, if present, must be deliberately designed.
9. Every major feature gets an animated, replayable, skippable tutorial.
10. Advanced controls remain hidden until needed.
11. Default layouts should minimize cognitive load.
12. Every page must have explicit loading, empty, success, partial-success, offline, permission-denied, unsupported, and error states where relevant.
13. Every destructive or high-impact action must visually communicate risk and reversibility.
14. The phrase **“No limits to the sky.”** is the main brand quote, but it must not be repeated everywhere.
15. Front-end implementation must use shared design tokens and reusable components rather than page-specific magic numbers.



# 1. DESIGN PSYCHOLOGY / HUMAN-FACTORS PRINCIPLES

No interface can literally be guaranteed to appeal to every human brain. HEY should instead use broadly robust human-factors principles:

- immediate orientation;
- progressive disclosure;
- recognition over recall;
- one dominant focal point per screen;
- predictable interaction placement;
- visible system state;
- safe reversibility;
- calm defaults;
- large touch targets;
- strong text hierarchy;
- natural grouping by proximity;
- low working-memory burden;
- clear cause/effect;
- consistency across devices;
- spatial continuity between states;
- reduced decision fatigue;
- contextual surfacing rather than giant permanent menus.

Every page should answer at a glance:
- Where am I?
- What is HEY doing?
- What can I do next?
- What needs my attention?
- What is optional?
- What is safe to ignore?

---

# 2. BRAND SYSTEM

## Brand quote
**No limits to the sky.**

Primary placements:
- landing hero;
- first-run welcome;
- product film end frame;
- selected marketing section;
- rare high-quality empty state.

Do not place it on:
- security warnings;
- billing errors;
- permission prompts;
- every dashboard card;
- destructive confirmations.

## Brand personality
Visual:
- calm;
- premium;
- alive;
- human;
- dimensional;
- intelligent;
- restrained.

Copy:
- direct;
- confident;
- short;
- elegant;
- never corporate-AI filler.

---

# 3. COLOR TOKENS

Core:
- `--bg-void: #020508`
- `--bg-deep: #020B14`
- `--bg-ocean: #061A2A`
- `--text-primary: #F5FBFF`
- `--text-secondary: rgba(245,251,255,.72)`
- `--text-tertiary: rgba(245,251,255,.48)`
- `--accent-arctic: #8ED8FF`
- `--accent-cyan: #00BFFF`
- `--accent-frost: #D8F4FF`

Glass:
- `--glass-0: rgba(8,12,17,.78)`
- `--glass-1: rgba(18,24,31,.72)`
- `--glass-2: rgba(28,34,42,.66)`
- `--glass-raised: rgba(38,46,55,.72)`

Semantic:
- success: muted natural green;
- warning: warm amber;
- destructive: coral/red;
- info: arctic blue;
- neutral: cool gray.

Use semantic icon + text, not color alone.

---

# 4. TYPOGRAPHY

Brand/display headings:
- Orbitron where expressive branding is useful.

UI/body:
- Rajdhani or validated readable fallback.

Do not use Orbitron for long body content.

Scale:
- Display XL: 64–80px desktop
- Display L: 48–64px
- H1: 40–48px
- H2: 32–36px
- H3: 24–28px
- Body L: 18–20px
- Body: 15–17px
- Small: 13–14px
- Micro: 11–12px

Long-form reading width:
- ~60–75 characters per line.

---

# 5. SPACING / GRID

8px base grid.

Spacing tokens:
4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96.

Gutters:
- wide desktop: 40–48px
- desktop: 28–32px
- tablet: 20–24px
- mobile: 16–20px

---

# 6. RADIUS / DEPTH

Radius:
- small control: 8–10px
- button: 12–16px
- input: 14–18px
- card: 20–24px
- large glass surface: 28–32px
- hero surface: 32–40px
- pills: full

Depth:
- Z0 canvas
- Z1 card
- Z2 floating widget
- Z3 modal / expanded Dynamic Island
- Z4 drag / critical floating state

---

# 7. LIQUID GLASS + CLASSIC 3D TACTILITY

Primary glass:
- dark translucent fill;
- `backdrop-filter: blur(24px) saturate(130%)` where performance allows;
- lighter top/left inner edge;
- darker lower/right edge;
- soft shadow;
- subtle environmental reflection.

Classic 3D influence:
- physical bevel;
- raised vs pressed state;
- visible tactile travel;
- directional edge-lighting;
- strong state clarity.

Do not recreate Windows 95 literally.

Button hover:
- lift 1px;
- edge highlight slightly stronger;
- shadow expands subtly.

Button pressed:
- translate down ~1px;
- outer shadow compresses;
- inset shadow increases;
- highlight shifts.

---

# 8. MOTION

Primary easing:
`cubic-bezier(.22,1,.36,1)`

Durations:
- micro: 120–180ms
- standard: 240–320ms
- large: 420–560ms
- cinematic onboarding only: 700–1200ms

Rules:
- motion explains hierarchy or state;
- no meaningless looped movement;
- reduced-motion mode disables parallax and continuous ambience.

---

# 9. GLOBAL SHELL

Desktop:
- collapsible left rail;
- top contextual toolbar;
- central workspace;
- optional right inspector;
- Dynamic Island;
- notification layer;
- command palette;
- modal layer.

Left rail:
- collapsed 68px;
- expanded 244px.

Core nav:
Home, Chat, Voice, Live, Projects, Cosmos, Create, Widgets, Automations, Forge, Library, Devices, Notifications, Settings.

Advanced-only:
Agents, Developer, Diagnostics, Logs, Provider Routing.

Bottom:
Profile, plan/usage, help, settings.

---

# 10. COMPONENT SYSTEM

Reusable components:
AppShell, Sidebar, TopBar, Breadcrumb, DynamicIsland, WidgetFrame, GlassCard, RaisedButton, IconButton, SplitButton, SegmentedControl, TextInput, PromptInput, SearchInput, Select, Slider, Toggle, Checkbox, Radio, Tabs, Tooltip, Popover, ContextMenu, Modal, Drawer, BottomSheet, Toast, ProgressBar, Skeleton, Avatar, Badge, Chip, StatusDot, EmptyState, ErrorState, TutorialOverlay, InspectorPanel, SplitPane, ResizablePane, Timeline, Canvas, FileTree, ArtifactCard, MissionCard, PermissionCard, DeviceCard, AgentCard, ProviderCard, Table, CommandPalette.

Every interactive component defines:
- default;
- hover;
- focus;
- pressed;
- selected;
- disabled;
- loading;
- error;
- success when relevant.

Minimum touch target: 44×44px.
Desktop compact controls should still be at least 36×36px.

---

# 11. GLOBAL CONTENT RULES

Buttons use verbs:
Create, Generate, Continue, Inspect, Compare, Restore, Ask HEY, Add Widget, Run, Verify, Retry.

Avoid vague CTA:
Submit, Proceed, Okay.

Tooltips:
- concise;
- 2–8 words;
- ~300ms hover delay;
- keyboard accessible.

Loading:
- prefer meaningful stages and skeletons;
- only show numeric progress if measurable.

Empty state:
- one primary action;
- optional examples;
- optional tutorial;
- no clutter.

Error state:
- what failed;
- why if known;
- retry;
- fallback;
- diagnostics for advanced users.

---

# 12. RESPONSIVE SYSTEM

Breakpoints:
- <640 mobile
- 640–767 large mobile
- 768–1023 tablet
- 1024–1439 desktop
- 1440–1919 large desktop
- >=1920 ultra-wide

Do not scale desktop layout down mechanically.

Mobile uses:
- bottom navigation;
- sheets;
- stacked cards;
- focused single-column flows.

Tablet uses:
- split panes;
- larger widgets;
- floating HEY.

Desktop uses:
- persistent shell;
- canvas;
- inspectors;
- multiple widgets.

---

# 13. ACCESSIBILITY

All pages:
- keyboard navigation;
- visible focus;
- proper labels;
- semantic headings;
- reduced motion;
- high contrast;
- text scaling;
- 200% zoom resilience;
- captions;
- minimum touch targets;
- screen-reader descriptions;
- RTL.

Focus ring:
- 2px arctic/frost;
- 2px offset.

---

# 14. RTL

For Kurdish/Arabic RTL:
- mirror navigation placement;
- reverse directional chevrons;
- mirror directional layouts where semantic;
- do not mirror play/media controls unless meaning requires it;
- preserve timeline direction based on content semantics.

---

# 15. GLOBAL Z-INDEX

- canvas: 0
- widgets: 100
- selected widget: 200
- top chrome: 300
- Dynamic Island: 500
- popovers: 700
- toasts: 800
- modal backdrop: 900
- modal: 1000
- critical security layer: 1200
- tutorial spotlight: 1300

---

# 16. GLOBAL INTERACTION RULES

Drag:
- widget lifts;
- shadow increases;
- snap guides appear;
- drop zone highlights.

Resize:
- handles appear on selection/hover;
- minimum useful size enforced.

Hover:
- useful secondary controls may appear;
- critical actions never hover-only.

Close/minimize/maximize:
- HEY-styled dimensional trio;
- do not exactly copy macOS geometry/colors.

---

# 17. GLOBAL TUTORIAL SYSTEM

Every major capability gets:
- first-use tutorial;
- replay tutorial;
- “show me how” command;
- animation;
- captions;
- voice explanation;
- skip;
- reduced-motion version;
- practice state.

Tutorial overlay:
- dim background;
- spotlight exact target;
- 1–3 steps per sequence;
- no repeated nagging.

---

# 18. VISUAL THINGS TO REMOVE / AVOID

Reject:
- giant permanent weather card;
- huge admin-dashboard grid;
- random motivational quotes on functional pages;
- excessive cyan borders;
- rainbow status colors;
- tiny 10px text;
- nested sidebars;
- 8 floating action buttons;
- moving backgrounds behind dense content;
- nested real backdrop blurs;
- card-within-card-within-card overload;
- center-aligning everything;
- fake retro skeuomorphism;
- generic blue-purple AI gradients;
- showing every capability simultaneously;
- 3D effects that reduce readability;
- glass on every tiny component.

Use one real blur layer per major surface where possible; inner glass often uses translucent fill without another expensive blur.



# 19. Landing Page

**Purpose:** Marketing entry point

## Must include
- Hero with HEY wordmark, headline 'No limits to the sky.', one supporting line, Start with HEY CTA, See what HEY can do CTA, premium live product visual, Product/Live/Create/Cosmos/Forge/Pricing/Download/Sign in nav.

## Must not include
- Pricing matrix above fold
- giant feature grid
- autoplay audio
- fake testimonials.

## Layout / visual hierarchy
Full-viewport hero, calm product demo, editorial sections; subtle parallax only.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Hero demo loads skeleton first; low-power mode uses static image.



# 20. Product Overview

**Purpose:** Explain HEY as one intelligence

## Must include
- One HEY everywhere, second brain, Create, Live, Cosmos, Forge, Pinpoint Precision, cross-device, privacy.

## Must not include
- Dense technical architecture.

## Layout / visual hierarchy
Alternating large editorial sections with real UI mockups.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Static fallback when motion reduced.



# 21. Pricing

**Purpose:** Plans and limits

## Must include
- Plan cards, usage/speed/capacity comparison, billing toggle if real, FAQs, invoices/help links.

## Must not include
- Manipulative countdowns
- hidden limits.

## Layout / visual hierarchy
Three clean raised cards; one recommended with subtle elevation.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Loading plan state; region unavailable; billing error.



# 22. Download

**Purpose:** Get native apps

## Must include
- OS cards, requirements, version, release notes, checksum/signature if used.

## Must not include
- Fake platform availability.

## Layout / visual hierarchy
Device-aware primary CTA; other platforms below.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Unsupported OS explanation.



# 23. Sign In

**Purpose:** Authenticate

## Must include
- Email, password/passkey/OAuth actually supported, forgot password, sign up, privacy link.

## Must not include
- Product tour clutter.

## Layout / visual hierarchy
Two-column desktop; brand panel + auth glass card.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Invalid credentials; offline; SSO failure.



# 24. Sign Up

**Purpose:** Create account

## Must include
- Short progressive steps: account, name, language, privacy basics, optional plan.

## Must not include
- 20-field form.

## Layout / visual hierarchy
Centered wizard card; progress.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Email exists; password error; verification pending.



# 25. Password Recovery

**Purpose:** Recover account

## Must include
- Email/identity method, confirmation, reset.

## Must not include
- Marketing content.

## Layout / visual hierarchy
Minimal secure card.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Expired link; throttled; success.



# 26. Welcome / First Launch

**Purpose:** Introduce HEY

## Must include
- Brand quote, language, voice, wake-word choice, Cosmos intro, privacy, one real guided task.

## Must not include
- Permission dump.

## Layout / visual hierarchy
Full-screen cinematic sequence with one focal action.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Skip available; resume later.



# 27. Home / Dashboard

**Purpose:** Daily anchor

## Must include
- Greeting, HEY state, command/search, clock, weather, usage, active missions, tasks/calendar, continue project
- prayer if enabled.

## Must not include
- 30 equal cards
- unrelated agent debug.

## Layout / visual hierarchy
One large focal zone + 2–4 supporting widgets; context-aware.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Empty new user; offline; mission active.



# 28. Chat

**Purpose:** Conversation and artifact workspace

## Must include
- Conversation, project/memory scope, assistant editorial responses, prompt box, attachments, voice, optional right artifact inspector.

## Must not include
- All replies forced into bubbles
- unrelated dashboard widgets.

## Layout / visual hierarchy
Open editorial canvas; user messages compact; assistant outputs can be full-width artifacts.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Thinking, tool-use, partial, error, offline.



# 29. Voice

**Purpose:** Hands-free HEY

## Must include
- Large HEY visualizer, mute/end/camera/screen/captions/device, transcript, quick actions.

## Must not include
- Dense nav inside center canvas.

## Layout / visual hierarchy
Immersive centered visualizer with side transcript when space permits.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Listening, thinking, speaking, interrupted, reconnecting.



# 30. HEY Live

**Purpose:** Continuous screen/camera copilot

## Must include
- Source selector, active source, pointer overlay, transcript, Guide/Assist/Act, sensing indicator, pause/end.

## Must not include
- Hidden sensing state.

## Layout / visual hierarchy
Live source dominates; HEY panel floats unobtrusively.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Permission denied; source lost; reconnecting.



# 31. Projects Index

**Purpose:** Browse projects

## Must include
- New Project, search/filter/sort, cards/list, last activity, progress, active mission.

## Must not include
- Generic file-manager look.

## Layout / visual hierarchy
Large project cards with strong thumbnail and status.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No projects; archived only; loading.



# 32. Project Overview

**Purpose:** Operate project

## Must include
- Goal, progress, recent work, current tasks, decisions, blockers, recent artifacts, collaborators.

## Must not include
- Full Project DNA editor by default.

## Layout / visual hierarchy
Overview cards with one project hero.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No recent work; sync conflict.



# 33. Project Files

**Purpose:** Project-bound files

## Must include
- Tree/list, preview, upload, source status, Ask HEY.

## Must not include
- Global file system by default.

## Layout / visual hierarchy
Split view.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Permission denied; missing source.



# 34. Project Artifacts

**Purpose:** Generated outputs

## Must include
- Artifact grid/list, versions, approved/final states, compare.

## Must not include
- Raw provider metadata by default.

## Layout / visual hierarchy
Visual-first gallery.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No artifacts.



# 35. Project Tasks

**Purpose:** Project tasks

## Must include
- List/board, task provenance, success criteria, agent status.

## Must not include
- Unrelated calendar data.

## Layout / visual hierarchy
Focused task board.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Blocked/dependency state.



# 36. Project Memory

**Purpose:** Scoped Cosmos

## Must include
- Project facts, decisions, goals, source provenance.

## Must not include
- Other-project memory.

## Layout / visual hierarchy
Structured sections.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Contradiction alert.



# 37. Project Activity

**Purpose:** Timeline

## Must include
- Meaningful changes, missions, decisions, uploads, edits.

## Must not include
- Raw noisy logs.

## Layout / visual hierarchy
Human-readable event timeline.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No activity.



# 38. Project Settings

**Purpose:** Project config

## Must include
- Name, privacy, members, DNA, cloud/local policy, export/archive/delete.

## Must not include
- Developer logs.

## Layout / visual hierarchy
Tabbed settings.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Danger zone separated.



# 39. Project DNA

**Purpose:** Project source of consistency

## Must include
- Purpose, goals, visual rules, typography, colors, terminology, canonical source, accepted/rejected references, locks.

## Must not include
- Raw JSON as normal UI.

## Layout / visual hierarchy
Specification editor with live visual preview.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Validation conflict.



# 40. Cosmos Home

**Purpose:** Second-brain entry

## Must include
- Search, Recent, Projects, People, Decisions, Preferences, Goals, optional visual universe toggle.

## Must not include
- Forced galaxy view.

## Layout / visual hierarchy
Practical structured view first; universe optional.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Memory off; empty memory.



# 41. Visual Cosmos

**Purpose:** Spatial memory visualization

## Must include
- Stars/planets/graphs, zoom, filters, search, relationship inspector.

## Must not include
- Dense text labels everywhere.

## Layout / visual hierarchy
Dark spatial canvas + compact controls.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Low-power simplified mode.



# 42. Memory Detail

**Purpose:** Inspect memory

## Must include
- Content, source, timestamp, confidence, scope, connections, last used, edit/pin/expire/delete.

## Must not include
- Irrelevant profile data.

## Layout / visual hierarchy
Single raised detail panel.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Source unavailable.



# 43. Memory Inbox

**Purpose:** Review candidate memories

## Must include
- Candidate, source, why important, approve/edit/reject/never category.

## Must not include
- All memory database rows.

## Layout / visual hierarchy
Card queue.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Nothing to review.



# 44. Create Hub

**Purpose:** Choose creative medium

## Must include
- Image, Frame, Video, Audio, Presentation, Document, Motion, Code, Custom
- recent creations.

## Must not include
- Icon wall of 50 tools.

## Layout / visual hierarchy
Large editorial cards.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No recent items.



# 45. Image Studio

**Purpose:** Generate images

## Must include
- Prompt/reference left, canvas center, properties/history/locks right
- model auto/manual, dimensions, variants, Project DNA.

## Must not include
- Unrelated widgets.

## Layout / visual hierarchy
Three-pane pro layout; collapsible sidebars.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Generating, QA, retry, provider fail.



# 46. Image Editor

**Purpose:** Surgical edits

## Must include
- Selection, crop, erase, fill, adjust, text, object list, layers, compare, Pinpoint locks.

## Must not include
- Photoshop clone.

## Layout / visual hierarchy
HEY-native simplified toolbar + context inspector.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No selection; locked region warning.



# 47. Frame / Storyboard Studio

**Purpose:** Plan shots

## Must include
- Scenes/shot list, large frame, metadata/continuity/locks, storyboard strip.

## Must not include
- Video editor complexity.

## Layout / visual hierarchy
Large frame focus + sequence strip.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Missing reference; continuity warning.



# 48. Video Studio

**Purpose:** Generate/edit video

## Must include
- Media bin, preview, timeline, inspector, HEY strip, shot locks, replace selected shot.

## Must not include
- All effects visible simultaneously.

## Layout / visual hierarchy
Professional but calm multi-pane layout.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Rendering; missing media; provider error.



# 49. Motion Graphics Studio

**Purpose:** Create motion design

## Must include
- Composition, timeline, layers, easing, recipes/presets, preview.

## Must not include
- AE clone.

## Layout / visual hierarchy
HEY-native structure with recipes.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Unsupported export warning.



# 50. Audio Studio

**Purpose:** Edit/generate audio

## Must include
- Tracks, waveform, transcript, cleanup, TTS, dubbing, alignment, export.

## Must not include
- Music dashboard clutter.

## Layout / visual hierarchy
Waveform center.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Mic missing; render fail.



# 51. Presentation Studio

**Purpose:** Build decks

## Must include
- Slide thumbnails, canvas, layout/content/visual/transitions/notes inspector, narrative strip.

## Must not include
- PowerPoint clone.

## Layout / visual hierarchy
Large canvas + clear slide rail.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Missing font; export fail.



# 52. Document / Book Studio

**Purpose:** Create long-form artifacts

## Must include
- Pages/chapters, paginated canvas, structure/style/source/locks inspector, transformations.

## Must not include
- Word clone.

## Layout / visual hierarchy
Editorial document canvas.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Pagination issue; source stale.



# 53. Research

**Purpose:** Deep research

## Must include
- Question, scope/depth, plan, sources, findings, evidence strength, citations, unresolved questions.

## Must not include
- Browser tabs everywhere.

## Layout / visual hierarchy
Source cards + synthesis workspace.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No sources; conflicting evidence.



# 54. Browser

**Purpose:** HEY-native web surface

## Must include
- Address/search, tabs, page, Ask HEY overlay, summarize/research/save.

## Must not include
- Heavy browser chrome.

## Layout / visual hierarchy
Minimal chrome.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Site blocked; offline.



# 55. Files

**Purpose:** Manage files

## Must include
- Folder tree, file list, preview, summarize/rename/move/organize/dedupe/add-to-project.

## Must not include
- Destructive batch controls prominent.

## Layout / visual hierarchy
Three-pane.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Permission denied; disk unavailable.



# 56. Code

**Purpose:** Developer workspace

## Must include
- Repo tree, editor, terminal, HEY task panel, tests, diff.

## Must not include
- Full IDE complexity for normal user.

## Layout / visual hierarchy
Collapsible pro panels.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Build/test failure.



# 57. Tasks

**Purpose:** Personal tasks

## Must include
- Today, Upcoming, Project, Board/List
- provenance, due, priority, success criteria.

## Must not include
- Busy productivity gamification.

## Layout / visual hierarchy
Clean list/board.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No tasks.



# 58. Calendar

**Purpose:** Schedule

## Must include
- Day/week/month/agenda, tasks, scheduling suggestions, focus blocks.

## Must not include
- Unrelated AI chat stream.

## Layout / visual hierarchy
Calendar dominant.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Disconnected account.



# 59. Reminders

**Purpose:** Manage reminders

## Must include
- Upcoming, recurring, completed, snoozed, source.

## Must not include
- Task-board complexity.

## Layout / visual hierarchy
Compact list.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No reminders.



# 60. Mission Center

**Purpose:** Track long-running work

## Must include
- Active, Waiting, Completed, Failed, Scheduled
- stage/progress/controls.

## Must not include
- Raw agent traces.

## Layout / visual hierarchy
Status-focused cards.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Blocked/permission required.



# 61. Automations

**Purpose:** Manage automations

## Must include
- Cards with trigger, status, last run, reliability, next run
- run/pause/edit/test.

## Must not include
- Node graph on index.

## Layout / visual hierarchy
Clean cards/list.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Broken integration warning.



# 62. Automation Editor

**Purpose:** Build workflows

## Must include
- List/node toggle, steps, input/output, permissions, retries, approval gates, Test/Save/Activate.

## Must not include
- Raw code first.

## Layout / visual hierarchy
Guided editor.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Validation error; test fail.



# 63. Forge Home

**Purpose:** Create capabilities

## Must include
- Natural language input, recent creations, templates, skills, agents, workflows, commands.

## Must not include
- Developer schema.

## Layout / visual hierarchy
Hero prompt + library below.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Duplicate capability found.



# 64. Forge Builder

**Purpose:** Design capability

## Must include
- Intent, duplicate check, design, permissions, tests, sandbox, preview, install.

## Must not include
- Raw JSON by default.

## Layout / visual hierarchy
Guided wizard with live definition pane.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Validation fail.



# 65. Skills Library

**Purpose:** Browse skills

## Must include
- Owned/installed/team/public, permission manifest, reliability, version.

## Must not include
- Marketplace hype.

## Layout / visual hierarchy
Large cards with trust details.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Offline; unavailable skill.



# 66. Skill Detail

**Purpose:** Inspect skill

## Must include
- Purpose, inputs, outputs, permissions, tests, version history, install/run.

## Must not include
- Marketing-only reviews.

## Layout / visual hierarchy
Technical yet approachable.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Permission conflict.



# 67. Agents

**Purpose:** Advanced agent list

## Must include
- Agent, category, health, model, runs, permissions, version.

## Must not include
- Normal-user nav exposure.

## Layout / visual hierarchy
Dense but polished table.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Agent degraded.



# 68. Agent Detail

**Purpose:** Inspect agent

## Must include
- Purpose, tools, permissions, health, latency, success, tests, versions, recent runs.

## Must not include
- Hidden chain-of-thought.

## Layout / visual hierarchy
Readable metrics + config.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Failed tests.



# 69. Widgets Library

**Purpose:** Browse widgets

## Must include
- Search/categories, interactive preview, size variants, add.

## Must not include
- 40 tiny cards per viewport.

## Layout / visual hierarchy
Large preview cards + search.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No results.



# 70. Widget Customizer

**Purpose:** Configure widget

## Must include
- Size, transparency, content, refresh, privacy, interaction, color accent, auto-collapse.

## Must not include
- Developer config.

## Layout / visual hierarchy
Live preview left, controls right.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Unsupported size.



# 71. Notifications Center

**Purpose:** Review alerts

## Must include
- Now/Today/Earlier, why notified, mark read, snooze, rules.

## Must not include
- Toast archive clutter.

## Layout / visual hierarchy
Grouped feed.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No notifications.



# 72. Devices

**Purpose:** Trusted devices

## Must include
- Cards with role, online, battery, trust, capabilities, last seen, handoff.

## Must not include
- Networking debug info.

## Layout / visual hierarchy
Device cards.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Offline device.



# 73. Device Detail

**Purpose:** Manage one device

## Must include
- Permissions, role, capabilities, local models, battery/network/storage, recent HEY activity.

## Must not include
- Unrelated profile info.

## Layout / visual hierarchy
Clear overview tabs.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Trust revoked.



# 74. Smart Home

**Purpose:** Control connected home

## Must include
- Rooms, lights, temperature, media, scenes, high-risk devices separated.

## Must not include
- All raw IoT entities.

## Layout / visual hierarchy
Room-first.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Hub offline.



# 75. Modes

**Purpose:** Choose environment modes

## Must include
- Study, Creator, Coding, Research, Business, Focus, Meeting, Presentation, Morning, Late Night, Private, Offline.

## Must not include
- Tiny mode toggles only.

## Layout / visual hierarchy
Large cards showing what changes.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
No custom modes.



# 76. Mode Editor

**Purpose:** Customize mode

## Must include
- Widgets, layout, notifications, voice, challenge level, agents, gesture profile, shortcuts, provider policy.

## Must not include
- Raw config.

## Layout / visual hierarchy
Sectioned live preview.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Conflicting shortcut.



# 77. Tutorial Center

**Purpose:** Learn HEY

## Must include
- New to HEY, Creator, Productivity, Advanced, Developer
- animated demos, practice.

## Must not include
- Long documentation dump.

## Layout / visual hierarchy
Video/animation cards.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Tutorial asset missing.



# 78. Trust Center

**Purpose:** Security control center

## Must include
- Mic, camera, screen, computer control, files, browser, devices, accounts, agents, automations, memory, cloud/local
- Stop Everything.

## Must not include
- Marketing or upsell.

## Layout / visual hierarchy
Exceptional clarity; status overview first.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Security alert state.



# 79. Permissions

**Purpose:** Permission grants

## Must include
- Capability, scope, grant, expiry, last used, revoke.

## Must not include
- Ambiguous scopes.

## Layout / visual hierarchy
Table + detail drawer.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Expired grant.



# 80. Connected Apps

**Purpose:** Integrations

## Must include
- Provider/account/scopes/status/last sync/disconnect.

## Must not include
- Unclear 'full access' labels.

## Layout / visual hierarchy
Permission-first cards.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Token expired.



# 81. Settings General

**Purpose:** Core settings

## Must include
- Language, region, startup, close behavior, default mode, notifications, accessibility.

## Must not include
- Provider debug.

## Layout / visual hierarchy
Grouped settings.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 82. Settings Appearance

**Purpose:** Visual personalization

## Must include
- Theme, accent, glass, transparency, contrast, radius, shadows, animation, background, scale, density, Island style
- live preview.

## Must not include
- Too many controls without preview.

## Layout / visual hierarchy
Preview + grouped controls.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 83. Settings Voice

**Purpose:** Voice controls

## Must include
- Voice, speed, pitch where supported, expressiveness, wake word, interruption, language, audio device.

## Must not include
- Unrelated personality controls.

## Layout / visual hierarchy
Voice preview.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 84. Settings Personality

**Purpose:** Behavior controls

## Must include
- Challenge, humor, directness, verbosity, formality, surprise me intelligently, proactive level.

## Must not include
- Sensitive diagnosis labels.

## Layout / visual hierarchy
Simple sliders/selectors.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 85. Settings Memory

**Purpose:** Cosmos preferences

## Must include
- Memory on/off, inbox, categories, retention, project memory, private sessions, export/delete.

## Must not include
- Raw database.

## Layout / visual hierarchy
Plain language.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 86. Settings Gestures

**Purpose:** Gesture config

## Must include
- Camera, enable, handedness, sensitivity, confidence, zone, cooldown, profiles, custom gestures.

## Must not include
- Always-on camera preview by default.

## Layout / visual hierarchy
Preview only when opened.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 87. Gesture Studio

**Purpose:** Train custom gesture

## Must include
- Camera preview, samples, confidence, conflict warnings, record/test/bind/save.

## Must not include
- Hidden recording.

## Layout / visual hierarchy
Clear sensing indicator.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 88. Settings Providers

**Purpose:** Advanced routing

## Must include
- Provider, type, health, quality, speed, cost, privacy, enable, auto routing.

## Must not include
- Normal users by default.

## Layout / visual hierarchy
Advanced table.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 89. Settings Offline/Local

**Purpose:** Local capability

## Must include
- Local mode, installed models, local speech, offline packs, LAN compute, never-cloud projects.

## Must not include
- Cloud upsell.

## Layout / visual hierarchy
Privacy-forward.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 90. Settings Developer

**Purpose:** Advanced dev settings

## Must include
- API, SDK, webhooks, feature flags, event viewer, logs, routing, diagnostics.

## Must not include
- Normal user exposure.

## Layout / visual hierarchy
Dense pro layout.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 91. Profile

**Purpose:** Personal account

## Must include
- Avatar, name, language, plan, devices, preferences, security, export.

## Must not include
- Social vanity metrics.

## Layout / visual hierarchy
Simple account page.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 92. Billing

**Purpose:** Payments

## Must include
- Current plan, usage, billing date, invoices, payment, change/cancel.

## Must not include
- Dark patterns.

## Layout / visual hierarchy
Clear factual layout.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 93. Usage

**Purpose:** Resource usage

## Must include
- Model, image, video, storage, agents, API
- limits.

## Must not include
- Gamified anxiety colors.

## Layout / visual hierarchy
Neutral charts.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 94. Support

**Purpose:** Help

## Must include
- Ask HEY, Help Center, Diagnostics, Contact, Report Bug, Feature Request.

## Must not include
- Aggressive chatbot takeover.

## Layout / visual hierarchy
Simple options.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 95. Diagnostics

**Purpose:** Health tests

## Must include
- Brain, Providers, Cosmos, Database, Mic, Camera, Wake, Notifications, Browser, Computer Use, Tauri, Integrations, Devices.

## Must not include
- Raw logs first.

## Layout / visual hierarchy
Health cards + run checks.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 96. Developer Console

**Purpose:** Advanced diagnostics

## Must include
- Events, Agents, Tools, Providers, Missions, Logs, API, Webhooks.

## Must not include
- Normal mode.

## Layout / visual hierarchy
Dense but readable tabs.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 97. Activity / Audit

**Purpose:** Action history

## Must include
- Actor/agent, action, target, permission, result, time, undo.

## Must not include
- Hidden sensitive details.

## Layout / visual hierarchy
Readable timeline/table.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 98. Time Machine

**Purpose:** Snapshots and restore

## Must include
- Project/workspace/artifact/settings snapshots, compare, restore.

## Must not include
- Automatic destructive restore.

## Layout / visual hierarchy
Timeline + compare.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 99. Search / Command Palette

**Purpose:** Global access

## Must include
- Search pages, commands, files, projects, memories, settings, workflows
- run/open/create.

## Must not include
- Marketing results.

## Layout / visual hierarchy
Keyboard-first centered overlay.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 100. Global Quick Add

**Purpose:** Fast creation

## Must include
- Task, note, project, reminder, automation, generation, upload.

## Must not include
- 20-item menu.

## Layout / visual hierarchy
Context-aware 5–8 items.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 101. Dynamic Island Compact

**Purpose:** Persistent status

## Must include
- Status icon, waveform/progress, one-line text, expand.

## Must not include
- Full chat content.

## Layout / visual hierarchy
Tiny tactile glass pill.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 102. Dynamic Island Expanded

**Purpose:** Quick control

## Must include
- Mini chat, controls, task state, approve/reject, pause/cancel.

## Must not include
- Full app duplication.

## Layout / visual hierarchy
Compact floating panel.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 103. Desktop Tray/Menu

**Purpose:** Closed-window control

## Must include
- Open HEY, listening, Island, missions, quick command, pause automations, settings, quit.

## Must not include
- Full settings.

## Layout / visual hierarchy
Native-lightweight menu.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 104. Mobile Home

**Purpose:** Mobile dashboard

## Must include
- Home cards, recent work, tasks, HEY status, bottom nav.

## Must not include
- Desktop sidebar.

## Layout / visual hierarchy
Vertical card hierarchy.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 105. Mobile Chat

**Purpose:** Phone conversation

## Must include
- Conversation, project/mode header, prompt, voice, attachments
- artifacts open sheet.

## Must not include
- Desktop inspector.

## Layout / visual hierarchy
Single column.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 106. Mobile Voice

**Purpose:** Phone voice mode

## Must include
- Visualizer, mute/end/camera/screen/captions.

## Must not include
- Desktop controls.

## Layout / visual hierarchy
Large touch controls.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 107. Mobile Live

**Purpose:** Phone multimodal

## Must include
- Camera/screen first, HEY overlay, action sheet.

## Must not include
- Tiny desktop replica.

## Layout / visual hierarchy
Immersive source-first.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 108. Mobile Widgets

**Purpose:** Mobile widgets

## Must include
- Stacked cards, pin/reorder/swipe.

## Must not include
- Freeform desktop canvas.

## Layout / visual hierarchy
Touch-first stack.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 109. Tablet Workspace

**Purpose:** Tablet productivity

## Must include
- Split panes, floating HEY, widgets, drag/drop.

## Must not include
- Phone stack only.

## Layout / visual hierarchy
Adaptive split workspace.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 110. TV / Projector

**Purpose:** Large-display mode

## Must include
- Large readable content, presentation/ambient, voice/gesture, private data minimized.

## Must not include
- Private notifications.

## Layout / visual hierarchy
Minimal large-scale UI.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 111. Onboarding Permissions

**Purpose:** Just-in-time permissions

## Must include
- Ask mic/camera/screen/files only when feature used
- why needed
- skip/fallback.

## Must not include
- All permissions at signup.

## Layout / visual hierarchy
Focused modal.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 112. Permission Denied

**Purpose:** Recover permission

## Must include
- Explain need, why, open settings, fallback.

## Must not include
- Dead-end error.

## Layout / visual hierarchy
Calm action card.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 113. Unsupported Platform

**Purpose:** Fallback page

## Must include
- Explain limitation, strongest supported fallback, device handoff.

## Must not include
- Fake capability.

## Layout / visual hierarchy
Informative card.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 114. Offline

**Purpose:** Offline operation

## Must include
- Connection state, what still works, queued tasks, retry.

## Must not include
- Blank screen.

## Layout / visual hierarchy
Local capability summary.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 115. 404

**Purpose:** Missing page

## Must include
- Simple message, return home, search.

## Must not include
- Marketing.

## Layout / visual hierarchy
Minimal.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 116. 500

**Purpose:** App error

## Must include
- HEY hit a problem, retry, diagnostics/status.

## Must not include
- Joke-heavy copy.

## Layout / visual hierarchy
Serious calm.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 117. Maintenance

**Purpose:** Service state

## Must include
- Affected systems, status, retry.

## Must not include
- Upsell.

## Layout / visual hierarchy
Minimal status.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 118. Share / Invite

**Purpose:** Collaboration

## Must include
- People, role, project scope, link settings, revoke.

## Must not include
- Overbroad access default.

## Layout / visual hierarchy
Permission-first modal.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 119. Collaboration Members

**Purpose:** Project people

## Must include
- Members, roles, pending invites, activity, remove.

## Must not include
- Private personal Cosmos.

## Layout / visual hierarchy
Project-scoped.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 120. Meeting Mode

**Purpose:** Meeting surface

## Must include
- Transcript, attendees if available, notes, decisions, tasks, privacy indicator.

## Must not include
- Unrelated widgets.

## Layout / visual hierarchy
Transcript + live summary.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 121. Focus Mode

**Purpose:** Distraction-reduced

## Must include
- Current mission, timer, blocked notifications summary, HEY minimal.

## Must not include
- Dashboard cards.

## Layout / visual hierarchy
Single focal mission.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 122. Morning Mode

**Purpose:** Daily brief

## Must include
- Date/weather/tasks/calendar/prayer if enabled/active missions/One Thing.

## Must not include
- News flood.

## Layout / visual hierarchy
Vertical curated briefing.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 123. Late Night Mode

**Purpose:** Soft interaction

## Must include
- Reduced brightness, softer voice, low-motion, essential info.

## Must not include
- Bright cyan.

## Layout / visual hierarchy
Warm dim glass.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 124. Private Mode

**Purpose:** No long-term memory

## Must include
- Visible privacy state, local/cloud policy, end session.

## Must not include
- Normal-memory ambiguity.

## Layout / visual hierarchy
Distinct but calm privacy banner.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# 125. Offline Mode

**Purpose:** Local-only work

## Must include
- Local capability badges, local files, local models, queued cloud-disabled tasks.

## Must not include
- Cloud actions without warning.

## Layout / visual hierarchy
Clear local indicator.

## Core interaction rules
- Primary action must be visually dominant.
- Secondary actions use lower-elevation glass controls.
- Tertiary actions use ghost/text controls.
- Dangerous actions are separated spatially and semantically.
- Advanced controls stay collapsed until requested.
- The page must expose HEY help/tutorial contextually without covering the main task.

## States
- loading;
- empty;
- ready;
- active/working if applicable;
- success;
- partial success if applicable;
- offline;
- permission denied if applicable;
- unsupported if applicable;
- error/recovery.

## Motion
- page enter uses subtle fade + 8–16px spatial transition;
- cards/widgets animate only if hierarchy changes;
- reduced-motion mode uses opacity only.

## Responsive behavior
- desktop uses page-specific multi-pane layout where useful;
- tablet collapses inspectors into side sheets;
- mobile prioritizes the primary task and moves secondary panels into bottom sheets/full-screen subviews.

## Accessibility
- keyboard reachable;
- visible focus;
- semantic labels;
- 200% zoom resilient;
- reduced motion;
- RTL-safe.

## Special state notes
Use the global page-state rules defined above.



# FINAL SYSTEM-WIDE FRONT-END RULES

## Visual regression
Capture approved references for every major page:
- desktop 1280/1440/1920;
- tablet;
- mobile;
- RTL;
- reduced motion;
- high-contrast state where applicable.

## Functional interaction tests
Test:
- sidebar collapse;
- command palette;
- Dynamic Island;
- widget drag/resize;
- Live source switching;
- prompt input;
- artifact compare;
- Pinpoint locks;
- version branch;
- Trust Center revoke;
- gesture training;
- Forge test flow;
- offline behavior;
- permission denial;
- error recovery;
- keyboard-only use.

## Performance
- lazy-load heavy studios;
- virtualize long lists;
- avoid nested backdrop blurs;
- avoid animating layout-heavy properties;
- reduce GPU effects on weak hardware;
- maintain responsive input even while generation jobs run.

## Sound / haptics
Optional:
- soft click;
- confirmation;
- warning;
- wake;
- generation completion;
- drag snap haptic on mobile/tablet.

Always user-disableable.

## Backgrounds
Preferred:
- near-black/ocean gradient;
- optional blurred natural environmental imagery;
- subtle vignette;
- no moving video background by default.

## HEY visual presence
Use:
- wordmark;
- subtle orb;
- organic waveform;
- light pulse.

Do not use:
- giant avatar;
- glowing humanoid AI head;
- robot mascot.

## Voice visualizer
Idle:
- slow breathing motion.

Listening:
- responsive waveform/organic ring.

Speaking:
- brighter but restrained.

Thinking:
- slower controlled energy.

No explosive particle storm.

## Dashboard composition
Use:
- one focal module;
- 2–4 supporting modules;
- whitespace;
- asymmetrical balance;
- contextual widget shelving.

Avoid:
- 12 equal admin cards;
- every metric shown simultaneously.

## Page-specific exclusion rule
Every page must omit unrelated complexity.

Examples:
- Voice does not show file management unless invoked.
- Trust Center does not show marketing.
- Billing does not show creator assets.
- Research does not show media controls.
- Image Studio does not show calendar widgets by default.
- Cosmos does not show upsell.
- Error pages do not show promotional CTAs.

## Default Home personalization
First launch:
- Clock
- Weather
- HEY state
- One task/calendar module
- Continue Project
- Usage if relevant

After usage:
- HEY may suggest layout changes;
- persistent changes require user acceptance or explicit personalization preference.

## Advanced Mode
When enabled:
- denser controls;
- agents;
- providers;
- logs;
- developer tools;
- deeper inspectors.

Default stays calm.

## Suggested global shortcuts
- Ctrl/Cmd + K → Command Palette
- Ctrl/Cmd + J → Show HEY
- Ctrl/Cmd + Shift + H → Ask about current selection
- Ctrl/Cmd + Shift + L → HEY Live
- Esc → close transient layer / cancel safe interaction

All remappable.

## Final acceptance checklist
Every user-facing surface must have:
- intentional layout;
- correct design tokens;
- correct typography;
- 3D tactile states;
- liquid-glass depth;
- responsive layout;
- keyboard support;
- touch support where relevant;
- RTL;
- reduced motion;
- loading;
- empty;
- error;
- offline;
- permission states;
- tutorial/help;
- correct mobile adaptation;
- consistent HEY personality;
- no fake controls;
- no placeholders;
- no developer leakage into normal mode.

# FRONT-END NORTH STAR

HEY is not another dashboard.

It is a personal intelligence environment.

It should feel:
- calmer than the operating system around it;
- more tactile than a flat web app;
- more alive than a productivity tool;
- more disciplined than a futuristic concept demo;
- more personal the longer it is used.

The interface should make extreme capability feel obvious rather than overwhelming.

Users should not think:
“Where is the feature?”

They should think:
“Of course HEY can do that.”

# **No limits to the sky.**


---

