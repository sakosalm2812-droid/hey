# Complete Navigation & Information Architecture
## HEY V1 — Full-depth implementation specification

**Mission:** Make every important HEY capability discoverable without exposing internal complexity.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Conversation Surface (Chat/Voice) is the default signed-in destination.
- Primary global navigation, contextual navigation, Create hierarchy, Explore More, + Add, Universal Search, Command Palette, recent/favorites, mobile bottom nav.
- Information scent, labels, hierarchy, advanced-mode disclosure, role/device/mode adaptations.
- Deep-link routing and return-to-previous-context behavior.

# 2. User experience contract
- Primary normal-user nav: Chat/Voice entry, Live, Projects, Create, Cosmos, Tasks/Missions, Widgets/Workspace, Search, Notifications, Settings.
- Important Create actions visible before Explore More: Image, Video, Presentation, Document, Audio.
- `+ Add` lets users pin additional capabilities without seeing raw agents.
- Advanced tools are discoverable through Advanced Mode, Search, Forge, Developer—not cluttering normal nav.
- Navigation never loses active project/conversation/artifact state.
- Breadcrumbs appear only where hierarchy is genuinely useful.
- Mobile uses bottom nav + More; desktop uses collapsible rail; tablet uses adaptive split shell.

# 3. Architecture / runtime contract
- Central route registry with capability metadata, permissions, feature flags, platform support and discovery rank.
- Navigation state is distinct from task/artifact state.
- Deep links restore intended resource with permission checks.
- Startup route resolver respects newest rule: default Conversation Surface, then explicit user override, then safe resume.
- Explore More reads from capability registry but filters by audience/platform/entitlements.

# 4. Required state model
- anonymous
- authenticating
- signed-in-first-run
- signed-in-returning
- conversation-active
- immersive-live
- embedded-studio
- full-studio
- modal
- offline
- unsupported-platform
- advanced-mode

# 5. Failure and recovery catalog
- Unknown/deprecated route → safe redirect with explanation.
- Feature flag off → remove dead nav and provide fallback if linked.
- Unauthorized deep link → permission/entitlement explanation.
- Stale project/artifact link → recovery and search, not blank page.
- Navigation state corruption → restore last valid route.

# 6. Security / privacy / trust requirements
- Never use client-only nav hiding as authorization.
- Sensitive routes require server/runtime enforcement.
- Do not leak advanced/debug routes to normal users.
- External URLs opened safely and clearly distinguished.

# 7. Data model / persistence
- navigation_preferences
- pinned_capabilities
- recent_capabilities
- startup_destination
- feature_flags
- entitlements
- capability_manifest
- workspace_route_state

# 8. Events / telemetry contracts
- nav.opened
- nav.pinned
- nav.unpinned
- search.opened
- capability.discovered
- capability.launched
- route.failed
- startup.resolved

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in lands Chat/Voice.
- Returning user resumes safe conversation state.
- Normal user finds Image/Video/Live/Cosmos without Explore More.
- + Add persists pinned tool.
- Deep link to project artifact restores context.
- Advanced Mode reveals developer areas without changing normal nav.

# 12. Non-goals / prohibited shortcuts
- Do not put all 229 agents in navigation.
- Do not make Explore More the only discovery path.
- Do not route sign-in to generic dashboard by default.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

