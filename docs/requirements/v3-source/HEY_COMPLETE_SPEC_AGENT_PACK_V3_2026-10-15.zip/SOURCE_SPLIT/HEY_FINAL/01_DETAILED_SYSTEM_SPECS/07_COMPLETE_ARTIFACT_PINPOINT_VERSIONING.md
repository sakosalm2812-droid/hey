# Complete Artifact / Pinpoint / Versioning System
## HEY V1 — Full-depth implementation specification

**Mission:** Guarantee exact-change editing, protected-state preservation, branches, comparison and recovery.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Artifacts across images, video, audio, slides, docs, UI, code, workflows, agents, data transforms.
- Locks, intended delta, protected state, actual delta, QA, repair, snapshots, branches, merge.

# 2. User experience contract
- User can say 'change only X' and HEY visibly understands what is protected.
- Before/After/Changes inspector available when useful.
- Approved versions can be named/finalized.
- Destructive edits create restore points automatically.

# 3. Architecture / runtime contract
- ChangeSet contains request, intended changes, invariants, allowed side effects, source version, output version, verification.
- Artifact graph supports branch/compare/restore/merge.
- Type-specific differ compares pixels/objects/text/code/layout/schema as appropriate.
- Verifier detects unintended changes before completion.

# 4. Required state model
- draft
- generating
- verifying
- needs-repair
- approved
- final
- branched
- merged
- restored
- failed

# 5. Failure and recovery catalog
- Diff unavailable → warn and require conservative verification.
- Merge conflict → explicit resolution.
- Provider regenerated too broadly → reject/repair.
- Corrupt version → restore parent.

# 6. Security / privacy / trust requirements
- Artifact permissions inherit project scope.
- Version history immutable audit where required.
- No cross-project reference leakage.

# 7. Data model / persistence
- artifacts
- artifact_versions
- change_sets
- locks
- diffs
- approvals
- snapshots
- branches
- merge_records

# 8. Events / telemetry contracts
- artifact.created
- change.requested
- change.verified
- change.rejected
- lock.added
- version.approved
- branch.created
- restore.completed

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Single-object image edit preserves rest.
- Slide-three-only edit preserves other slides.
- Code API lock regression.
- Data schema lock regression.
- Branch/restore/merge tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

