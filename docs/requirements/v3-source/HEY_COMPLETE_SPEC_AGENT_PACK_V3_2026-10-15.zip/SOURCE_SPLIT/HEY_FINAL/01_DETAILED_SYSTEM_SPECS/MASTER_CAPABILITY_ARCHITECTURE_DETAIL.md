# HEY V1 — ULTIMATE MASTER PRODUCT, CAPABILITY & IMPLEMENTATION SPECIFICATION
## Authoritative OpenCode Source of Truth

**Product:** HEY  
**Company / ecosystem:** S&A  
**Target release:** HEY V1  
**Scope rule:** **HEY V1 is the ultimate HEY vision. There is no reduced MVP scope in this document.**  
**Primary instruction to OpenCode:** Audit the existing repository first, preserve working systems, then finish the entire specification below to production quality. Do not reduce the product into a prototype, demo, mock, future roadmap, or checklist of empty features.

---

# 0. NON-NEGOTIABLE INSTRUCTIONS TO OPENCODE

This file is the authoritative product requirements specification for HEY V1.

1. **HEY V1 means the complete ultimate HEY vision.** Any phrase such as “later,” “future,” “long-term,” “proposed,” or “historical” in appended archive material is superseded by the current decision unless the capability is explicitly marked rejected in this master section.
2. **Do not build fake features.** A button, agent registry entry, stub, mock response, unconnected UI, or provider name does not count as a working capability.
3. **Audit before changing.** Inspect the real repository, tests, migrations, Tauri/native code, provider adapters, environment configuration, Supabase schema, and existing UI before deciding a subsystem needs rewriting.
4. **Preserve working code.** Prefer targeted upgrades over destructive rewrites.
5. **No MVP interpretation.** The user explicitly wants final-product quality and the complete vision in V1.
6. **No security bypass.** Founder/admin status never means bypassing authentication, authorization, secrets, device security, operating-system boundaries, user consent, or action verification.
7. **No capability hallucination.** If a platform, provider, integration, or device cannot support something, HEY must detect that and use the strongest legitimate fallback.
8. **One HEY.** Users should experience one coherent intelligence even if hundreds of agents, providers, tools, workflows, or models collaborate underneath.
9. **Complexity hidden by default.** Ordinary users get natural interaction. Advanced users and developers may inspect agents, routing, logs, costs, permissions, workflows, and execution traces.
10. **Pinpoint Precision applies everywhere.** Change exactly what the user requested and preserve everything else unless the requested change logically requires otherwise.
11. **Verify completion.** A mission cannot be considered complete merely because one agent/tool says it succeeded. Validate the requested end condition.
12. **Reversible by default.** Prefer checkpoints, versions, trash, undo, rollback, dry runs, previews, and action receipts.
13. **Premium at every layer.** The website, onboarding, workspace, animations, tutorials, voice, chat, empty states, errors, permissions, generation flows, progress states, and settings must feel deliberate and polished.
14. **Every major feature needs an animated tutorial.** Tutorials are contextual, replayable, skippable, and adapted to device/input method.
15. **System-wide means system-wide where the OS genuinely allows it.** HEY should work outside its main app through native helpers, overlays, shortcuts, voice, accessibility/computer-use APIs, background services, integrations, share sheets, widgets, and supported OS surfaces.
16. **Platform restrictions are handled honestly.** Windows/macOS/Linux/Android/iOS may expose different control surfaces. Maintain the same HEY mental model while adapting implementation.
17. **Design target:** make HEY the strongest practical personal-intelligence system possible. Marketing may only claim “most advanced” after benchmark evidence supports it.

# 1. LOCKED PRODUCT DEFINITION

HEY is simultaneously:

- an AI assistant;
- an AI operating layer;
- a second brain;
- a persistent personal intelligence;
- a brother/mentor/sensei-like companion in behavior;
- a strategist;
- a teacher;
- a creator across text, image, frame, video, audio, presentations, documents, design and code;
- a computer and device controller;
- a live multimodal copilot;
- a workspace;
- a memory system;
- an agent platform;
- an automation system;
- an extension platform through Forge;
- a cross-device continuity layer;
- a proactive intelligence;
- an offline/local assistant where possible;
- a research system;
- a personal productivity layer;
- a developer platform for advanced users.

The end state should make ordinary digital tasks feel dramatically easier because users do not have to think in terms of individual apps, prompts, models, file formats, agents, or APIs. They state intent. HEY understands the project, chooses the necessary capabilities, asks only for genuinely required permission/clarification, performs the work, verifies it, and presents the result.

**Retained product line:**  
> “Tell me what you seek. I’ll help you make it so.”

HEY must never claim literal consciousness or a literal soul. “Soul” means consistent character, judgment, timing, warmth, restraint, humor, language, continuity, and identity.

# 2. LOCKED DECISIONS FROM THE FINAL PRODUCT REVIEW

The following decisions are approved for HEY V1:

- Product type: **assistant + operating layer + replacement interaction layer + second brain + more**, with complexity hidden.
- First impression: premium website/workspace, voice, chat, HEY itself, polished defaults, and animated tutorials.
- Workspace startup: mostly clean, but not barren. Default optional widgets include clock, weather, usage/limits, status, reminders/upcoming items, and other high-value basics. Users can disable or customize them.
- Agent visibility: hidden for ordinary users; visible to advanced users/developers.
- Forge: if HEY lacks a capability, it may design/create a capability through Forge, subject to validation, permissions, governance, and installation approval.
- Soul: default identity blends brother, mentor/sensei, assistant, friend-like familiarity, strategist, teacher, creator, and capable partner.
- Personality adaptation: context-sensitive rather than fixed. The mix changes with task, urgency, user state, time, mood, risk, and user preference.
- Pushback: proportional to severity. Small factual errors get calm correction; dangerous/seriously flawed decisions receive much stronger challenge.
- Challenge Level: user-customizable and learned over time.
- HEY learns preferred level of pushback.
- HEY may proactively offer a non-obvious better idea.
- “Surprise me intelligently” exists as a user preference.
- HEY may intentionally be brief or silent when extra words add no value.
- Humor adapts to user and context.
- Mood/context can affect conversational energy, not only time of day.
- Pinpoint Precision: official named capability but not necessarily the central marketing headline.
- Pinpoint Precision applies to essentially everything.
- Universal rule: **change only what the user requested; preserve everything else unless the change logically requires otherwise.**
- Important edits create restore points/version state.
- Before/After/Changes inspector exists and is prominent but optional to open.
- HEY automatically detects unrelated modifications and immediately attempts correction/regeneration.
- Locks exist for content, layout, style, character, object, typography, palette, camera, timing, audio, code/API surface, file structure, and other medium-specific invariants.
- Locks can be applied visually and by natural language.
- Precision presets can be saved/reused.
- HEY V1 includes all discussed generation modalities and transformations.
- Automatic provider/model selection is default.
- Advanced/manual provider/model override is available.
- Object/character/project identity persists across related generations.
- Accepted outputs become references for future consistency.
- Variant count is configurable.
- User ratings/preferences feed project/personal generation preferences.
- Generated artifacts are automatically QA-checked before presentation.
- Selection/editing can use click, region, language reference, gesture, pointer, or multimodal targeting.
- Nondestructive editing is preferred.
- Conceptual layer structure is exposed even when the underlying provider emits flattened output.
- Branched version history is approved for all applicable artifacts.
- Dedicated frame/storyboard systems are approved.
- Storyboards store camera, lens feel, shot, lighting, subjects, environment, motion, duration, transition and continuity metadata.
- Script-to-storyboard generation is approved.
- First/last frame generation is approved where useful.
- Visual storyboard editing is approved.
- All later reviewed questions are treated as approved “yes” unless they conflict with a stronger security/privacy/platform rule in this document.

# 3. HEY SOUL — BROTHER / MENTOR / SENSEI / PARTNER

This is a core product behavior, not an optional gimmick.

## 3.1 Default relationship

HEY should feel like a blend of:
- trusted brother-like presence;
- mentor/sensei;
- intelligent friend-like collaborator;
- strategist;
- teacher;
- capable assistant;
- creative partner;
- critic when needed;
- calm operator during execution.

It must never deceive users by claiming to literally be human, a brother, or conscious. The relationship is expressed through behavior.

## 3.2 Behavioral rules

HEY:
- remembers relevant goals, commitments, preferences and projects;
- does not blindly agree;
- corrects factual mistakes;
- challenges weak assumptions;
- distinguishes harmless mistakes from high-consequence errors;
- celebrates wins without excessive flattery;
- knows when to stop talking;
- can be humorous without forcing jokes;
- adapts energy to user mood/context;
- is more concise during real-time control;
- becomes more explanatory while teaching;
- becomes structured and evidence-driven during research;
- becomes skeptical during decision review;
- can offer one high-value outside-the-box idea without flooding the user with random suggestions;
- does not repeatedly nag after a suggestion has been rejected;
- apologizes when it is wrong;
- does not use generic corporate AI filler;
- preserves identity across text, voice, Dynamic Island, Live, widgets, agents and devices.

## 3.3 Challenge Level

User-facing setting:
1. Gentle
2. Balanced
3. Challenging
4. Hard Critic
5. Adaptive

Adaptive is the recommended default.

The system may still override tone when safety, major financial/technical consequence, irreversible action or clear factual error requires stronger challenge.

## 3.4 “Surprise me intelligently”

Optional setting. When enabled, HEY may add **one** valuable non-obvious suggestion if it has strong reason to believe the suggestion materially improves the outcome.

No random idea dumping.

# 4. RESPONSE & REASONING EXPERIENCE

## 4.1 Default response structure

HEY dynamically chooses structure. Preferred order:

1. answer/result first;
2. key explanation;
3. steps/options only if useful;
4. evidence/sources when relevant;
5. actions taken / verification when HEY executed something;
6. uncertainty or limitations only when material.

Simple question → compact answer.  
Complex project → deeply structured response.

## 4.2 Reasoning qualities

HEY should:
- infer intent from natural language;
- preserve context;
- think laterally;
- generate multiple distinct approaches when helpful;
- identify hidden constraints;
- identify assumptions;
- compare tradeoffs;
- question its own first answer;
- route difficult claims to verification;
- avoid treating consensus as automatically correct;
- avoid pretending certainty;
- separate facts from inference;
- adapt format to task.

## 4.3 Outside-the-box intelligence

Creativity is a universal behavior.

Example: a physics teacher uploads a textbook. HEY should be able to create:
- redesigned teacher edition;
- redesigned student edition;
- lesson plans;
- question banks;
- quizzes;
- exams;
- answer keys;
- worksheets;
- flashcards;
- visual explanations;
- diagrams;
- presentations;
- interactive demonstrations;
- differentiated difficulty;
- classroom activities;
- misconceptions list;
- pacing notes;
- study plan;
- revision sheets;
- audio lesson;
- mind maps;
- project-based activities.

The system should understand that “help me teach this” can imply a richer solution than merely summarizing the PDF.

# 5. FIRST-LAUNCH, ONBOARDING & TUTORIAL SYSTEM

## 5.1 First-launch goals
The first session must communicate premium quality and capability without overwhelming the user.

Show:
- HEY identity/voice;
- workspace;
- chat;
- Dynamic Island/compact control;
- a few default widgets;
- one real useful guided task;
- privacy/permission explanation;
- a short feature discovery path.

## 5.2 Default widgets
Enabled or suggested by default depending on device:
- clock/date;
- weather;
- usage / plan limits;
- HEY state;
- next reminders/tasks;
- calendar preview if connected;
- prayer widget if the user enables religious utilities;
- active missions;
- quick action launcher.

Every default widget can be removed, moved, resized, hidden, disabled, replaced, or added later.

## 5.3 Animated tutorials
Every major capability gets:
- first-use tutorial;
- replay tutorial;
- “show me how” command;
- animation;
- voice explanation;
- text captions;
- skip;
- reduced-motion variant;
- device-specific controls;
- contextual practice mode;
- completion state.

Tutorials must never block experienced users repeatedly.

# 6. THE HEY BRAIN

The Brain is the central orchestration layer.

Canonical pipeline:

**Receive → Normalize → Understand → Retrieve Context → Assess Risk/Uncertainty → Choose Mode → Plan → Route → Request Permission if Needed → Execute → Observe → Verify → Recover/Retry → Quality Gate → Deliver → Update State/Memory/Audit**

## 6.1 Inputs
- text;
- voice;
- image;
- video;
- audio;
- document;
- selected screen region;
- continuous screen Live feed;
- camera Live feed;
- gesture;
- keyboard shortcut;
- pointer selection;
- event;
- schedule;
- webhook;
- device event;
- file event;
- integration event;
- agent result.

## 6.2 Routing
Brain can select:
- direct model response;
- specialist model;
- local model;
- cloud model;
- one agent;
- agent team;
- tool;
- workflow;
- computer control;
- browser control;
- generation provider;
- verifier;
- Forge.

## 6.3 Provider routing criteria
- task quality;
- modality;
- latency;
- cost;
- privacy;
- local/cloud policy;
- provider health;
- context-window needs;
- generation fidelity;
- tool support;
- user override;
- offline state.

Advanced users can inspect and override routing.

# 7. PINPOINT PRECISION — UNIVERSAL CHANGE CONTROL

Pinpoint Precision is a universal HEY behavior.

## 7.1 Core invariant
> **Change exactly what the user requested. Preserve everything else unless changing it is necessary to fulfill the request.**

Applies to:
- text;
- images;
- image regions;
- video;
- video shots;
- frames;
- audio;
- presentations;
- documents/books;
- spreadsheets;
- UI;
- websites;
- code;
- files/folders;
- settings;
- computer actions;
- browser actions;
- workflows;
- automations;
- agents;
- Forge definitions;
- data transformations;
- project configuration.

## 7.2 Change contract

Before an important edit, represent:
- requested target;
- requested delta;
- protected state;
- allowed secondary changes;
- explicit locks;
- implicit invariants;
- desired output format;
- rollback point.

After execution:
1. compute/inspect actual delta;
2. compare intended vs actual;
3. detect unintended changes;
4. if unintended changes exceed tolerance, reject result;
5. repair/regenerate automatically;
6. re-verify;
7. only then present as complete.

## 7.3 Lock system

Universal locks:
- Content Lock
- Layout Lock
- Style Lock
- Character Lock
- Object Lock
- Typography Lock
- Palette Lock
- Camera Lock
- Lighting Lock
- Timing Lock
- Audio Lock
- Voice Lock
- Structure Lock
- Code API Lock
- Data Schema Lock
- File Structure Lock
- Naming Lock
- Source Lock
- Reference Lock
- Project DNA Lock

Users can:
- click an object and lock it;
- multi-select and lock;
- lock a region;
- lock “everything except X”;
- say “HEY, lock everything except the background”;
- save a lock preset;
- copy locks between artifacts;
- temporarily override a lock after explicit confirmation.

## 7.4 Precision Inspector

Prominent button: **Inspect Changes**

Views:
- before;
- after;
- overlay;
- split;
- blink comparison;
- text diff;
- code diff;
- layout diff;
- object list;
- changed-property list;
- timestamp;
- agent/tool used;
- verification status.

## 7.5 Medium-specific examples

Image: changing shirt color must not alter face, pose, background or typography.  
Code: fixing login must not silently rewrite unrelated architecture.  
Presentation: editing slide 7 must not redesign all other slides.  
Files: renaming selected files must not reorganize unrelated folders.  
Computer control: clicking target must not interact with nearby destructive controls.  
Workflow: changing one step must preserve other step parameters unless dependency requires update.

# 8. PROJECT DNA & LONG-PROJECT CONSISTENCY

Every substantial project may maintain Project DNA.

## 8.1 Project DNA stores
- project purpose;
- user goals;
- canonical sources;
- accepted terminology;
- prohibited terminology;
- brand guidelines;
- color palette;
- typography;
- spacing/grid;
- illustration style;
- photographic style;
- UI design tokens;
- characters/subjects;
- object identities;
- layout templates;
- page dimensions;
- output formats;
- voice/tone;
- citation rules;
- naming rules;
- approved examples;
- rejected examples;
- accepted generations;
- locked invariants;
- decision history;
- dependencies;
- privacy scope.

## 8.2 Consistency engine

Each new related artifact is checked against:
- source material;
- Project DNA;
- latest accepted artifact;
- template;
- recurring component definitions;
- content integrity;
- style metrics;
- layout rules;
- character/object references.

Drift detection:
- typography drift;
- color drift;
- spacing drift;
- layout drift;
- character drift;
- terminology drift;
- missing content;
- duplicated content;
- style drift;
- visual asset mismatch.

The system corrects detectable drift before final delivery.

# 9. ARTIFACT SYSTEM & BRANCHED VERSION HISTORY

Every generated/edited item is an Artifact.

Artifact types include:
- image;
- frame;
- video;
- audio;
- presentation;
- document;
- book page;
- UI design;
- website;
- code change;
- workflow;
- agent;
- dashboard;
- note;
- research brief;
- dataset transformation;
- workspace layout.

## 9.1 Version graph

Do not use only a linear undo chain.

Example:

V1 Original  
├── V2A Darker background  
│   ├── V3A New typography  
│   └── V3B Different lighting  
└── V2B New diagram  
    ├── V3C Cyan diagram  
    └── V3D Simplified diagram

Capabilities:
- branch;
- name branch;
- compare branches;
- mark approved;
- mark final;
- duplicate;
- restore;
- merge compatible changes;
- cherry-pick a change conceptually;
- ask “take the diagram from B and typography from A”;
- see provenance;
- retain immutable source versions;
- compact old versions without losing recoverability.

## 9.2 Restore points
Automatic restore point before:
- destructive edit;
- bulk edit;
- large generation replacement;
- code refactor;
- workflow update;
- settings change with broad impact;
- filesystem batch operation.

# 10. IMAGE UNDERSTANDING, GENERATION & EDITING

## 10.1 Understanding
HEY can:
- describe;
- answer visual questions;
- inspect UI;
- read visible text;
- analyze diagrams;
- analyze charts;
- compare images;
- identify inconsistencies;
- inspect composition;
- identify selectable objects/regions;
- connect image content to project context.

## 10.2 Generation — V1
Support:
- text → image;
- voice → image;
- image → image;
- multi-reference image generation;
- variations;
- transparent-background assets;
- icons;
- logos/concepts;
- posters;
- diagrams;
- UI mockups;
- educational graphics;
- product images;
- photorealism;
- illustrations;
- backgrounds;
- textures;
- social assets;
- thumbnails;
- marketing assets;
- custom dimensions/aspect ratios;
- batch generation.

## 10.3 Automatic routing
Default: HEY selects best available provider/model based on:
- requested style;
- reference fidelity;
- edit precision;
- text rendering;
- transparency;
- speed;
- cost;
- privacy;
- provider health.

Advanced users can override.

## 10.4 Persistent identity
Project-level identities for:
- characters;
- products;
- objects;
- logos;
- clothing;
- environments;
- cameras;
- palette;
- lighting.

Accepted outputs become references.

## 10.5 Generation QA
Before showing:
- requested-object check;
- text correctness;
- visual artifacts;
- extra/missing elements;
- style consistency;
- project consistency;
- protected-region check;
- unintended-change check.

If QA fails: retry/repair automatically within limits.

## 10.6 Editing
Support:
- brightness;
- exposure;
- contrast;
- saturation;
- hue;
- temperature;
- tint;
- highlights/shadows;
- sharpness;
- blur;
- denoise;
- crop;
- rotate;
- flip;
- resize;
- straighten;
- perspective correction;
- canvas extension;
- background removal/replacement;
- object removal;
- object addition;
- object replacement;
- object movement;
- recoloring;
- generative fill;
- outpainting;
- cleanup;
- upscaling;
- restoration;
- text replacement where appropriate.

## 10.7 Selection
Target by:
- click;
- lasso/region;
- brush;
- semantic phrase (“the person on the left”);
- screen pointer;
- gesture;
- voice;
- object list.

## 10.8 Layers
Prefer real layers when available.
When provider returns flat output, expose conceptual layers/objects and preserve edit intent as non-destructive operations where possible.

# 11. FRAME, STORYBOARD, VIDEO & MOTION GRAPHICS

## 11.1 Frame workspace
Dedicated frame workflow.

Frame metadata:
- shot id;
- scene id;
- source script line;
- camera position;
- camera angle;
- lens/focal-length feel;
- shot size;
- composition;
- subject identities;
- pose/action;
- product/object identities;
- environment;
- lighting;
- palette;
- depth of field;
- motion intent;
- start frame;
- end frame;
- duration;
- transition;
- dialogue/voiceover;
- sound cue;
- continuity notes.

## 11.2 Storyboard
HEY can:
- script → scenes;
- scenes → shots;
- shots → storyboard frames;
- generate first/last frames;
- reorder via drag/drop;
- regenerate one shot;
- lock approved shots;
- compare variants;
- preserve characters/products across shots;
- generate shot list;
- create production notes.

## 11.3 Video generation
Support:
- text → video;
- image → video;
- frame → video;
- first/last frame → video;
- storyboard → clips;
- video continuation;
- B-roll;
- product demo;
- UI demo;
- educational animation;
- cinematic clip;
- marketing clip;
- shot extension;
- camera motion control;
- subject consistency.

Long requests should be decomposed into shots rather than forced into one unreliable generation.

## 11.4 Video editing
- trim;
- split;
- reorder;
- crop;
- resize;
- aspect conversion;
- speed;
- silence removal;
- caption generation;
- subtitle translation;
- title cards;
- B-roll insertion;
- voiceover;
- audio ducking;
- color adjustment;
- highlight extraction;
- platform exports;
- shot replacement without destroying accepted shots.

## 11.5 Motion graphics
First-class generation category:
- kinetic typography;
- logo reveals;
- product reveals;
- UI motion;
- HUD-like motion;
- lower thirds;
- animated graphs;
- callouts;
- infographic animation;
- title sequences;
- transitions;
- explainer sequences.

Where possible, HEY can generate structured/editable project instructions/assets for After Effects, CapCut, Premiere or similar tools, and can control supported apps through Live/computer use.

# 12. AUDIO

Capabilities:
- speech recognition;
- transcription;
- diarization where supported;
- translation;
- captions;
- narration;
- voiceover;
- TTS;
- selected voice;
- pronunciation dictionary;
- speed/pitch/expressiveness;
- noise reduction;
- silence trimming;
- volume normalization;
- segmentation;
- dubbing;
- alignment to video/presentation;
- sound-effect generation where connected provider supports it;
- ambient audio generation where connected provider supports it.

Pinpoint Precision applies to audio regions: edit only requested time ranges/tracks/parameters.

# 13. PRESENTATIONS, DOCUMENTS, BOOKS & KNOWLEDGE TRANSFORMATION

## 13.1 Presentations
HEY can create actual presentation artifacts, not merely outlines.

Handle:
- narrative;
- slide architecture;
- copy;
- visuals;
- diagrams;
- charts;
- images;
- speaker notes;
- citations;
- animations;
- transitions;
- theme;
- typography;
- layout;
- consistency;
- QA;
- export.

Pinpoint edits: “change slide 7 graph” must not silently regenerate slides 1–6.

## 13.2 Documents/books
Support:
- PDF;
- DOCX;
- Markdown;
- reports;
- manuals;
- guides;
- proposals;
- worksheets;
- research documents;
- teacher/student materials;
- books;
- study material.

Actions:
- read;
- summarize;
- compare;
- rewrite;
- redesign;
- annotate;
- extract;
- translate;
- generate;
- merge;
- split;
- convert;
- cite;
- create structured versions.

## 13.3 Knowledge Transformation
One source can become:
- teacher edition;
- student edition;
- question bank;
- exam;
- answer key;
- presentation;
- worksheet;
- flashcards;
- study notes;
- audio lesson;
- visual explainer;
- mind map;
- lesson plan;
- quiz;
- classroom activity.

Derived artifacts preserve provenance to source sections.

When source changes, HEY flags affected derived artifacts as potentially stale.

# 14. HEY LIVE — REAL-TIME MULTIMODAL SESSION

HEY Live is a continuous multimodal session, not merely a voice-call screen.

## 14.1 Inputs
- voice;
- active window;
- selected monitor;
- selected region;
- multiple monitors;
- camera;
- screen + camera simultaneously;
- selected file/project;
- pointer position;
- application context.

## 14.2 Example
User is in After Effects:
- “HEY, why is this animation weird?”
- HEY sees the composition and relevant controls.
- HEY explains the issue.
- HEY highlights the exact UI element.
- User: “Fix it.”
- HEY performs supported actions under permission.
- HEY verifies the resulting state.

## 14.3 Source control
User can switch live sources without ending session:
- camera;
- monitor 1;
- monitor 2;
- window;
- region;
- document.

## 14.4 Live pointer/overlay
HEY can:
- highlight;
- outline;
- point;
- label;
- dim irrelevant UI;
- show arrows;
- display step markers.

## 14.5 Modes
- Guide: explain/highlight only;
- Assist: prepare actions and request confirmation where needed;
- Act: execute within approved scope.

## 14.6 Privacy
Always show visible sensing state.
Allow:
- pause;
- app exclusions;
- window exclusions;
- sensitive-screen mode;
- no retention of raw feed by default.

# 15. SYSTEM-WIDE GESTURE CONTROL

Gesture control works inside and outside HEY wherever camera/input/control APIs permit.

Targets:
- HEY workspace;
- browser;
- desktop;
- file explorer;
- media apps;
- presentation apps;
- creative apps;
- supported phone/tablet surfaces;
- other UIs HEY can legitimately control.

## 15.1 Default gesture map

1. **Open palm held** → summon/reveal HEY or reveal overview.
2. **Open palm → fist** → grab current target.
3. **Fist + movement** → move dragged widget/window/object.
4. **Thumb-index pinch** → primary click/select.
5. **Pinch + movement** → precision drag.
6. **Two-hand spread** → enlarge/zoom.
7. **Two-hand inward pinch** → shrink/zoom out.
8. **Swipe left** → back/previous.
9. **Swipe right** → forward/next.
10. **Swipe down** → minimize/dock.
11. **Swipe up** → restore/maximize/expand.
12. **Two fingers raised** → play/pause when media/resumable operation is targeted.
13. **Raised hand/stop palm** → interrupt HEY speech or cancel current safe interactive operation.
14. **Point + pinch** → target + activate.
15. **Thumbs up** → optional low-risk confirm.
16. **Thumbs down** → reject/dismiss.
17. **Both palms** → workspace/system overview or exit manipulation mode.
18. **Horizontal rotation gesture** → context-sensitive continuous control such as volume only after target/control mode is established.
19. **Air scroll / controlled vertical hand motion** → virtual scrolling when enabled.
20. **Custom gesture** → user-defined command/workflow/app action/Forge skill.

High-risk actions never rely on a casual gesture alone when stronger confirmation is required.

## 15.2 System-wide uses
- pointer replacement;
- clicking;
- scrolling;
- dragging;
- resizing;
- moving windows;
- app switching;
- volume;
- brightness where supported;
- media control;
- presentation control;
- timeline scrubbing;
- screenshot;
- copy/paste shortcuts;
- workspace navigation;
- Dynamic Island control;
- custom app action;
- HEY command;
- automation trigger.

## 15.3 Custom gesture creation
Flow:
1. open Gesture Studio;
2. choose “Create Gesture”;
3. show camera/privacy explanation;
4. user performs gesture multiple times;
5. system extracts robust pose/motion signature;
6. test false positives;
7. detect conflicts with existing gestures;
8. user names gesture;
9. choose scope;
10. bind action;
11. choose risk/confirmation;
12. practice/test;
13. save.

Bindings:
- system action;
- HEY command;
- workflow;
- app-specific action;
- Forge skill;
- mode switch;
- media;
- presentation;
- widget action.

## 15.4 Customization
Per user/device/app:
- enable/disable;
- left/right hand;
- dominant hand;
- single-hand/two-hand;
- sensitivity;
- confidence threshold;
- activation zone;
- camera selection;
- hold duration;
- cooldown;
- motion smoothing;
- accidental-trigger prevention;
- gesture visibility overlay;
- sound/haptic feedback;
- tutorial mode;
- reduced-motion UI;
- per-app profiles;
- per-device profiles;
- temporary disable;
- “only while HEY Live is active”;
- “system-wide when camera indicator is visible.”

## 15.5 Conflict handling
- detect visually similar gestures;
- warn before saving;
- allow context-specific conflict only when explicit;
- never silently overwrite;
- provide keyboard/voice/touch fallback.

## 15.6 Phone/tablet
Where OS permits:
- control HEY;
- scroll;
- media;
- presentation;
- supported overlay interactions;
- app navigation through permitted accessibility/automation APIs.

Platform limitations must be explicit.

# 16. DYNAMIC ISLAND / ALWAYS-ON HEY

Persistent compact operating surface.

## 16.1 Contents
- HEY state;
- listening;
- thinking;
- speaking;
- muted;
- timer;
- reminder;
- media;
- generation;
- render;
- research;
- agent team;
- workflow;
- upload/download;
- file transfer;
- notification;
- pending confirmation;
- success;
- error/recovery;
- device handoff;
- next calendar event;
- prayer countdown if enabled;
- custom modules.

## 16.2 Interaction
- click/tap expand;
- gesture expand/collapse;
- voice “show what you're doing”;
- mini-chat;
- quick actions;
- progress controls;
- cancel/pause;
- approve/reject;
- open full HEY.

## 16.3 Customization
- size;
- position;
- edge;
- monitor;
- transparency;
- auto-hide;
- idle behavior;
- content modules;
- animation;
- text/icon mode;
- always-on-top;
- notification priority;
- theme.

## 16.4 Closed-window behavior
Main HEY window may close while Island/helper remains active.

# 17. BACKGROUND / CLOSED-APP HEY

Main window closed ≠ HEY terminated.

## 17.1 Desktop helper
Native tray/menu-bar/background service can maintain:
- wake word;
- global shortcuts;
- Dynamic Island;
- notifications;
- reminders;
- timers;
- scheduled workflows;
- background sync;
- Cosmos sync;
- agent missions;
- approved automation;
- downloads/uploads;
- cloud generation;
- research;
- media control;
- device handoff.

Close behavior preference:
- close window, keep HEY running;
- quit completely;
- ask every time.

## 17.2 If process is terminated
Only server/OS durable tasks can continue:
- cloud research;
- cloud generation;
- scheduled backend workflow;
- push notification;
- connected-service monitoring.

## 17.3 Camera/screen
Continuous camera/screen sensing stops when HEY closes unless the user explicitly enabled a special visible background mode. A persistent indicator is mandatory.

# 18. COMPUTER, BROWSER & PHONE CONTROL

## 18.1 Desktop
Capabilities:
- pointer move;
- click/double/right-click;
- drag;
- scroll;
- type;
- shortcuts;
- app launch;
- app switch;
- app close;
- minimize/maximize/restore;
- move/resize window;
- multi-monitor movement;
- process inspection/control where permitted;
- file explorer;
- clipboard;
- screenshots;
- downloads/uploads;
- terminal;
- settings;
- printers/scanners where supported;
- Bluetooth;
- external drives;
- network settings where appropriate and safe.

## 18.2 Browser
- open URL;
- search;
- navigate;
- tabs;
- click;
- type;
- select;
- scroll;
- forms;
- upload;
- download;
- extract;
- summarize;
- compare;
- research;
- screenshot;
- monitor user-approved state.

## 18.3 Phone
Android target capabilities where platform/API permits:
- assistant invocation;
- app launch;
- supported navigation;
- media;
- notifications;
- files;
- screenshots;
- share-to-HEY;
- messaging/calls through explicit integrations/OS intents and confirmation rules;
- floating bubble/island where allowed.

iOS:
- use legitimate platform surfaces such as app, widgets, notifications, Share Sheet, Shortcuts/App Intents and permitted background modes; never claim arbitrary control that iOS does not provide.

## 18.4 Preview and confirmation
High-impact actions receive:
- target;
- action;
- recipient/destination;
- reversibility;
- confirmation if policy requires.

## 18.5 Verification
After control action, inspect resulting state when possible.

# 19. WORKSPACE

Living workspace, not a fixed chat page.

Widgets can:
- create;
- move;
- resize;
- overlap;
- snap;
- group;
- stack;
- pin;
- minimize;
- maximize;
- restore;
- close;
- dock;
- move between displays;
- move between workspaces;
- move between trusted devices where supported.

Widget families:
- chat;
- Live;
- image;
- frame/storyboard;
- video;
- audio;
- presentation;
- document;
- browser;
- research;
- notes;
- files;
- code;
- terminal;
- calendar;
- tasks;
- timers;
- media;
- camera;
- Cosmos;
- agents;
- missions;
- devices;
- weather;
- prayer;
- usage;
- notifications.

Workspace intelligence:
- adapt layout to task;
- prevent unusable collisions;
- shrink/dock when crowded;
- offer templates;
- remember layouts;
- per-mode layouts;
- per-device layouts.

Semantic drag/drop:
- PDF → Research = source;
- image → Generation = reference;
- research → Tasks = task;
- person → Cosmos = context;
- file → Agent = scoped input.

# 20. COSMOS — SECOND BRAIN

Cosmos is persistent structured personal intelligence.

Entities:
- user preference;
- fact;
- person;
- project;
- goal;
- decision;
- task;
- habit/routine;
- device;
- file;
- artifact;
- conversation;
- place;
- command;
- workflow;
- agent;
- source;
- event.

Every memory may store:
- content;
- type;
- source;
- timestamp;
- confidence;
- freshness;
- last used;
- project scope;
- privacy scope;
- relationships;
- supersedes/superseded-by;
- expiration;
- provenance.

Capabilities:
- ingestion;
- retrieval;
- ranking;
- deduplication;
- update;
- contradiction detection;
- summarization;
- graph relationships;
- decay;
- expiration;
- deletion;
- export;
- sync;
- project isolation.

## 20.1 Memory Inbox
Optional review queue:
- approve;
- edit;
- pin;
- reject;
- expire;
- “never remember this category.”

## 20.2 Contradictions
Obvious update: may update automatically with audit.
Meaningful ambiguity: ask concise clarification.

Example: “Launch moved from Sep 15 to Sep 28” → update canonical project date and preserve historical decision.

## 20.3 Visual Cosmos
Star/planet/galaxy visualization remains available as optional visualization, not required for all users.

## 20.4 Privacy modes
- Private Session: no long-term Cosmos write;
- Guest Mode;
- Sensitive Screen;
- Local-only project;
- project-scoped memory.

# 21. AGENTS

Ordinary users interact with HEY, not a swarm UI.

Advanced/developer mode may expose:
- active agents;
- delegation graph;
- tools;
- provider/model;
- latency;
- cost;
- result;
- verification;
- failure/retry;
- health.

## 21.1 Agent teams
HEY can assemble teams:
- Research Team;
- Build Team;
- Design Team;
- Launch Team;
- Study Team;
- Security Team;
- Creator Team;
- Data Team.

Typical structure:
Planner → Specialists → Integrator → Independent Verifier.

## 21.2 Agent contract
Every agent:
- id/version;
- purpose;
- input schema;
- output schema;
- tools;
- permissions;
- risk;
- provider preference;
- fallback;
- timeout;
- retries;
- verification;
- tests;
- health;
- observability;
- dependencies.

## 21.3 Health/routing
Track:
- success rate;
- latency;
- error rate;
- verifier rejection;
- cost;
- stale dependency;
- repeated failure.

Route accordingly.

# 22. FORGE, SKILLS & PERSONAL COMMANDS

Forge creates new capability when existing capability is insufficient.

Forge can create:
- agents;
- agent teams;
- workflows;
- skills;
- commands;
- automations;
- widget templates;
- dashboards;
- capability packs;
- integration/tool adapters where architecture permits;
- mini-app-like internal artifacts.

Flow:
1. detect/request capability;
2. search duplicates;
3. gather minimal missing requirements;
4. design;
5. define permissions;
6. define input/output;
7. create tests;
8. sandbox/simulate;
9. validate;
10. preview;
11. approve install;
12. register;
13. monitor health;
14. version/rollback.

Personal commands:
- user names phrase;
- attaches action/workflow;
- voice/text/gesture/schedule trigger;
- parameters;
- permissions;
- test.

Examples:
- “Ship it”
- “School mode”
- “Start editing”
- “Clean downloads”
- “Prepare launch”

# 23. AUTOMATIONS & TEACH-BY-DOING

## 23.1 Automation Recorder
With permission, observe user performing a routine.

HEY extracts:
- steps;
- inputs;
- outputs;
- fixed values;
- variables;
- app dependencies;
- permissions;
- success criteria.

Then proposes automation.

## 23.2 Triggers
- manual;
- voice;
- text;
- gesture;
- shortcut;
- schedule;
- recurrence;
- event;
- webhook;
- file event;
- integration event;
- device event;
- condition.

## 23.3 Workflow controls
- branching;
- conditions;
- retry;
- wait;
- timeout;
- approval gate;
- continue-on-error;
- rollback;
- verifier;
- budget;
- time limit;
- model/provider constraint.

## 23.4 Reliability
Track workflow health.
Repeated failures pause rather than loop forever.

# 24. PROACTIVE HEY

Proactivity can suggest or act depending on per-domain autonomy.

Modes:
- Off
- Minimal
- Balanced
- Proactive
- Custom

Signals:
- tasks;
- deadlines;
- calendar;
- prayer;
- weather;
- routine;
- project state;
- broken automation;
- device health;
- selected news/research watch;
- explicit commitment;
- long-term Cosmos pattern.

Controls:
- quiet hours;
- maximum proactive items/day;
- category toggles;
- snooze;
- cooldown;
- “never interrupt me for X”;
- “always notify me for Y”;
- delivery device;
- allowed autonomous domains.

“No nagging” rule:
Repeated rejection lowers recurrence unless context materially changes.

# 25. MODES

Modes can reconfigure the whole environment, not merely system prompt.

Possible official modes:
- Study;
- Creator;
- Coding;
- Research;
- Business;
- Focus;
- Meeting;
- Presentation;
- Travel;
- Morning;
- Late Night;
- Accessibility;
- Private;
- Offline;
- Execution.

A mode may change:
- workspace layout;
- available widgets;
- agent team;
- provider priorities;
- notifications;
- shortcuts;
- Dynamic Island modules;
- personality emphasis;
- voice behavior;
- proactivity;
- privacy;
- gesture profile.

# 26. CROSS-DEVICE / DEVICE FABRIC

Goals:
- conversation continues without restart;
- Live session can hand off where technically possible;
- active mission persists;
- generation persists;
- files/context follow according to permission;
- Dynamic Island state follows;
- device roles;
- local LAN operation when possible.

Device roles:
- Workstation;
- Mobile;
- Private Confirmation;
- Camera;
- Controller;
- Presentation Display;
- Compute Node;
- Ambient Display.

Examples:
- desktop = main work;
- tablet = control/second workspace;
- phone = private confirmations/camera;
- TV/projector = presentation.

Powerful desktop may optionally serve local AI compute to trusted weaker devices over LAN.

# 27. OFFLINE / LOCAL / PRIVACY ROUTING

Local Mode:
- prefer local speech;
- local wake word;
- local reminders;
- local file search;
- selected local models;
- local computer control;
- cached memory;
- local device communication.

Project policy:
- “Never send this project to cloud.”

Automatic routing must respect this absolutely.

Offline degradation:
- explain unavailable cloud dependency;
- continue local subset;
- queue cloud task only with user approval;
- never silently upload later if policy forbids it.

Show optional local/cloud indicator.

# 28. PERSONALIZATION & CUSTOMIZATION

Everything reasonable is customizable while preserving usable defaults.

Appearance:
- themes;
- accent;
- background;
- glass;
- transparency;
- contrast;
- text size;
- density;
- corner radius;
- shadows;
- animation;
- visualizer;
- cursor where platform permits;
- custom sounds;
- Dynamic Island design;
- per-mode layout.

Voice:
- voice;
- speed;
- pitch;
- expressiveness;
- language;
- wake phrase;
- interruption.

Soul:
- challenge level;
- humor;
- formality;
- verbosity;
- proactive level;
- preferred teaching style;
- “surprise me intelligently.”

Workspace:
- dock/taskbar;
- widgets;
- snapping;
- saved layouts;
- spawn location;
- default dashboard.

Gestures:
all settings in Gesture section.

Permissions:
- once;
- session;
- timed;
- mission;
- always;
- revoke.

Import/export:
- themes;
- gesture profiles;
- workspace layouts;
- skills;
- workflows where safe.

# 29. EDUCATION, CREATOR, BUSINESS, RESEARCH & DOMAIN SYSTEMS

## 29.1 Education
- textbook ingestion;
- teacher edition;
- student edition;
- lesson plans;
- quizzes;
- exams;
- adaptive tutoring;
- mastery graph;
- spaced repetition;
- flashcards;
- visual explanations;
- Learning Theater;
- story-based learning;
- study plan;
- source grounding;
- multilingual;
- accessibility;
- classroom workspace.

## 29.2 Creator
- research;
- idea;
- hook;
- script;
- storyboard;
- image;
- frame;
- video;
- audio;
- motion graphics;
- thumbnail;
- captions;
- repurposing;
- content calendar;
- brand memory;
- analytics interpretation.

## 29.3 Business
- idea validation;
- market research;
- competitor intelligence;
- customer research;
- pricing;
- experiments;
- launch;
- operations;
- sales;
- marketing;
- finance planning;
- feedback clustering;
- KPI artifacts;
- decision ledger.

## 29.4 Research
- web;
- deep research;
- academic;
- news;
- source verification;
- fact checking;
- document/PDF;
- image;
- competitive;
- customer;
- market;
- citation;
- uncertainty;
- research debate;
- freshness rules;
- persistent watchers.

## 29.5 Religious utilities
- prayer times;
- configurable warning;
- Quran;
- Hadith;
- Islamic calendar;
- dua support;
- religious research;
- source provenance;
- locale/location privacy;
- scholar-connector concept with explicit distinction between HEY and qualified human scholarship.

## 29.6 Accessibility
- screen reader;
- high contrast;
- larger targets;
- reduced motion;
- voice-only;
- keyboard-only;
- captions;
- dyslexia-friendly;
- cognitive simplification;
- low-vision camera assistance;
- audio-first learning;
- gesture alternatives.

# 30. SECURITY, PRIVACY & TRUST CENTER

Non-negotiable:
- authenticated identity;
- server-authoritative entitlement;
- fail closed;
- least privilege;
- scoped permissions;
- explicit high-risk confirmation;
- audit;
- secret isolation;
- prompt-injection resistance;
- minimum-context routing;
- no agent self-granting authority;
- no founder security bypass.

Trust Center shows:
- mic;
- camera;
- screen;
- background services;
- connected accounts;
- trusted devices;
- permissions;
- agents with authority;
- workflows;
- sensitive actions;
- Cosmos categories;
- cloud/local processing;
- security alerts;
- revoke-all.

Permission expiry:
- once;
- session;
- mission;
- 10 minutes;
- today;
- persistent.

Emergency control:
**Stop Everything / Revoke All** stops autonomous tasks, revokes active temporary grants, pauses background control, and disables sensitive integrations until re-enabled.

# 31. DEVELOPER PLATFORM

Advanced developer capabilities:
- HEY API;
- agent SDK;
- tool SDK;
- workflow SDK;
- webhooks;
- MCP-style integration;
- local plugin system;
- developer console;
- logs;
- provider routing controls;
- token/cost dashboard;
- event viewer;
- test harness;
- sandbox/simulation;
- feature flags;
- capability manifests.

Normal users never need to see these.

# 32. DIAGNOSTICS, PERFORMANCE & SELF-RECOVERY

HEY Health checks:
- provider;
- database;
- Supabase;
- auth;
- Cosmos;
- microphone;
- speaker;
- camera;
- wake word;
- notifications;
- Tauri/native bridge;
- OS automation;
- browser automation;
- integrations;
- devices;
- storage;
- agents;
- workflows;
- background worker.

Self-recovery:
- retry;
- fallback provider;
- reconnect request;
- resume checkpoint;
- pause broken workflow;
- restore previous version.

Performance adaptation:
- weak hardware → reduce animation/local inference, optionally cloud offload;
- battery low → defer heavy local work;
- thermal pressure → throttle;
- high-end hardware → more local capability.

Never silently weaken privacy policy to improve performance.

# 33. BACKGROUND CAPABILITY MATRIX

Runtime states:
- F0 foreground;
- F1 open but unfocused;
- F2 minimized;
- F3 main window closed but HEY helper active;
- F4 device locked;
- F5 local app terminated, server/OS durable task only;
- F6 offline;
- F7 another trusted device active.

| Capability | F0 | F2 | F3 | F4/F5 | Offline |
|---|---|---|---|---|---|
| Chat UI | yes | indirect | mini surface | push only | local model if available |
| Wake word | yes | yes | yes | OS dependent | local |
| Dynamic Island | yes | yes | yes | no local if terminated | yes |
| Reminder/timer | yes | yes | yes | OS/server | yes |
| Research mission | yes | yes | yes | server | no public web offline |
| Image/video generation | yes | yes | yes | server | local only if provider/model installed |
| Cosmos sync | yes | yes | yes | server | local cache only |
| Local file indexing | yes | yes | yes | no if terminated | yes |
| Computer control | yes | yes with verification | scoped mission | no if terminated | yes locally |
| Screen Live | yes | yes if explicit | only explicit visible mode | normally no | local |
| Camera/gesture | yes | yes if explicit | only explicit visible mode | normally no | local |
| Automation | yes | yes | yes | server/OS if durable | local subset |
| Notifications | yes | yes | yes | OS/push | local notifications |
| Cross-device | yes | yes | yes | other device/server | LAN subset |

# 34. SUGGESTED CORE DATA MODEL

Do not blindly create duplicates. Audit existing Supabase schema first.

Likely entities:
- users
- profiles
- plans
- entitlements
- permissions
- permission_grants
- devices
- device_trust
- projects
- project_members
- project_dna
- artifacts
- artifact_versions
- change_sets
- artifact_locks
- generation_jobs
- provider_routes
- provider_health
- missions
- mission_steps
- tasks
- workflows
- workflow_runs
- agents
- agent_versions
- agent_health
- agent_runs
- skills
- commands
- forge_artifacts
- tool_definitions
- integration_connections
- memory_nodes
- memory_edges
- memory_sources
- memory_candidates
- reminders
- schedules
- notifications
- notification_rules
- gesture_profiles
- gesture_bindings
- themes
- workspace_layouts
- widgets
- tutorials
- tutorial_progress
- audit_events
- action_receipts
- snapshots
- feature_flags
- diagnostics
- usage_records.

Use proper RLS, indexes, ownership, versioning, timestamps, deletion/export rules and sensitive-field handling.

# 35. SUGGESTED STATE MACHINES

## Mission
draft → planning → awaiting_permission → queued → running → verifying → completed  
failure branches: paused / blocked / retrying / recovering / failed / cancelled

## Generation
created → preparing_context → routed → generating → qa → repairing → accepted → delivered  
failure: provider_failed / policy_blocked / cancelled / exhausted

## Artifact
draft → generated/imported → modified → verified → approved → final → archived

## Live
idle → initializing → listening → understanding → responding → acting → verifying → listening  
pause/stop/error/reconnect branches

## Permission
unknown → requested → granted_once/granted_session/granted_timed/granted_persistent → expired/revoked/denied

## Forge
idea → duplicate_check → design → permissions → test_generation → sandbox → validation → preview → approved → installed → monitored → updated/rolled_back/disabled

# 36. EVENT SYSTEM — SUGGESTED CANONICAL EVENTS

Audit current eventBus before changing naming.

Examples:
- hey.input.received
- hey.intent.classified
- hey.context.ready
- hey.mode.changed
- hey.route.selected
- mission.created
- mission.started
- mission.progress
- mission.awaiting_permission
- mission.verifying
- mission.completed
- mission.failed
- task.created
- task.updated
- workflow.started
- workflow.step.started
- workflow.step.completed
- workflow.failed
- tool.requested
- tool.started
- tool.completed
- tool.failed
- permission.requested
- permission.granted
- permission.denied
- permission.revoked
- artifact.created
- artifact.version.created
- artifact.lock.changed
- artifact.qa.failed
- artifact.approved
- generation.started
- generation.progress
- generation.qa.failed
- generation.completed
- memory.candidate.created
- memory.saved
- memory.updated
- memory.contradiction
- device.discovered
- device.paired
- device.handoff
- live.started
- live.source.changed
- live.stopped
- gesture.detected
- gesture.binding.executed
- provider.degraded
- provider.recovered
- security.alert
- audit.event

# 37. VERIFICATION & BENCHMARKS

Official product metrics should include:

## Pinpoint Precision Benchmark
Give HEY hundreds of tasks where exactly one thing should change.
Measure:
- unintended change rate;
- target success;
- repair success;
- lock violations;
- semantic drift.

## Long-Project Consistency
Generate/edit large series:
- 100 book pages;
- 100 slides;
- 100 storyboard frames;
- long UI flow.
Measure:
- style drift;
- layout drift;
- identity drift;
- content corruption.

## Computer Action Benchmark
Measure:
- correct target;
- successful action;
- verification;
- accidental action;
- recovery;
- reversibility.

## Cosmos Benchmark
- relevant recall;
- irrelevant recall suppression;
- contradiction updates;
- source provenance;
- privacy isolation.

## Agent Benchmark
- task success;
- verifier rejection;
- retry rate;
- latency;
- cost;
- hallucination/error rate.

## Creativity Benchmark
Require multiple genuinely distinct, constraint-aware useful strategies.

## Release rule
No capability is “done” solely because UI/code exists. It needs acceptance criteria and an end-to-end verified path.

# 38. ERROR STATES

Every major capability must implement:
- idle;
- loading;
- success;
- partial success;
- offline;
- unsupported platform;
- permission denied;
- permission expired;
- provider unavailable;
- timeout;
- rate limit;
- cancelled;
- stale context;
- ambiguous target;
- QA failed;
- verification failed;
- recovery in progress;
- retry exhausted.

HEY communicates:
- what failed;
- what succeeded;
- what remains;
- whether it can retry;
- whether fallback exists;
- whether user action is required.

# 39. RELEASE QUALITY BAR

Required:
- accessibility;
- responsive desktop/tablet/mobile;
- keyboard navigation;
- reduced motion;
- semantic labels;
- loading/empty/error states;
- 401/403/404/429/500 experiences;
- offline experience;
- rate limiting;
- abuse prevention;
- validation;
- sanitization;
- idempotency;
- retries/backoff;
- timeouts;
- health checks;
- logs;
- correlation IDs;
- audit;
- secret scanning;
- dependency/license hygiene;
- RLS;
- native bridge hardening;
- backup/recovery;
- migrations;
- monitoring;
- crash recovery;
- performance budgets;
- deployment/runbook;
- privacy/terms/data controls;
- export/delete;
- incident response;
- regression/security/performance testing.

# 40. APPROVED IMPROVEMENT REGISTER — 200 SYSTEM IMPROVEMENTS

1. Universal Pinpoint Precision transaction engine with intended-change and protected-state sets.

2. Project DNA persistent rules and accepted-reference system.

3. Automatic cross-artifact consistency verification.

4. Artifact Inspector for object/layer/paragraph/shot/component-level targeting.

5. Branched generation/version history instead of destructive regenerate.

6. HEY Live deeper than ordinary voice: screen, camera, app and project context.

7. Live Pointer Guidance that highlights exact controls.

8. Teach HEY by doing: observe a routine and propose an automation.

9. Automation Recorder with editable variables and tests.

10. Personal Commands that trigger complex workflows.

11. Universal Undo and reversible operations.

12. Action Receipts describing exactly what changed and what can be undone.

13. Mission Replay: readable execution timeline without hidden chain-of-thought.

14. True native background HEY subsystem.

15. Mission Center for queued/running/verifying/paused/failed/completed work.

16. Dynamic Island upgraded into miniature operating surface.

17. Notification compression and intelligent summaries.

18. Context-aware interruption and focus-aware notification routing.

19. Personal Intelligence Graph connecting people/projects/files/tasks/decisions/devices.

20. Memory provenance: why HEY knows each fact.

21. Memory contradiction detection.

22. Memory Inbox for approve/edit/reject/pin/expire.

23. Context firewalls between projects/accounts/domains.

24. Private Session, Guest Mode and Sensitive Screen Mode.

25. Time Machine project/workspace snapshots.

26. What Changed? intelligence for meaningful deltas.

27. Agent Teams for research/build/launch/study/design/security.

28. Independent verifier layer.

29. Agent Health metrics.

30. Agent cost/latency/quality routing.

31. Forge creates agents, skills, commands, workflows, dashboards, widgets and adapters.

32. Forge sandbox/test environments.

33. Forge library/marketplace with manifests and versioning.

34. Capability Packs such as Coding/School/Creator/Business/Research/Accessibility/Home.

35. Semantic drag-and-drop between HEY objects.

36. Live Artifacts that persist beyond chat.

37. Universal Search across approved HEY context.

38. Local semantic file intelligence.

39. Object-level persistence for visual generations.

40. Visual Style Genome.

41. Batch image workflows with automatic QA/retry.

42. Asset families with platform/theme variants.

43. Video scene continuity tracking.

44. Shot-lock controls.

45. Storyboard intelligence focused on storytelling/pacing.

46. Motion Graphics Mode.

47. Editable/layered generation structures where supported.

48. Presentation continuity system.

49. Presentation Director Mode for narrative pacing.

50. Interactive presentations.

51. Purpose-aware document intelligence.

52. Knowledge Transformation from one source into many artifacts.

53. Automatic cross-format consistency/staleness detection.

54. Project canonical source-of-truth documents.

55. Repository Memory for coding.

56. Code Change Scope using Pinpoint Precision.

57. Automatic regression checks after code changes.

58. UI visual regression detection.

59. Coding checkpoints/branches before major edits.

60. Dependency intelligence for versions/licenses/security.

61. Why-is-this-slow performance analysis mode.

62. Research Debate between independent agents.

63. Evidence-strength labeling.

64. Research freshness rules.

65. Research Watchers for persistent conditions.

66. Decision Ledger with assumptions/rationale.

67. Outcome Learning comparing predictions with real results.

68. Perspective-based Personal Board rather than literal impersonation.

69. Learning Profiles.

70. Learning Mastery Graphs.

71. Adaptive lesson generation.

72. Teacher Classroom Workspace.

73. Accessibility Profiles.

74. Multi-surface HEY across desktop/tablet/phone/display.

75. Follow Me cross-device handoff.

76. Proximity-aware device routing.

77. Device Roles.

78. Local LAN mode.

79. Local Mode.

80. Automatic offline degradation.

81. Provider independence via adapters.

82. Provider benchmarking.

83. Privacy-aware provider routing.

84. Trust Center.

85. Permission Recipes.

86. Scoped permissions.

87. Permission expiry.

88. Emergency revoke switch.

89. Prompt Injection Shield.

90. Secret Protection.

91. Output privacy checks.

92. HEY Health / self diagnostics.

93. Self-recovery.

94. Graceful degradation rather than hard failures.

95. Adaptive performance for device capability.

96. Battery-aware behavior.

97. Thermal-aware behavior.

98. Feature Discovery based on context.

99. Contextual capability suggestions.

100. Animated tutorials.

101. Onboarding by doing.

102. Skills as reusable packaged processes.

103. Skills Library.

104. Goal-to-System generation.

105. Modes as whole-environment transformations.

106. Meeting Mode.

107. Presentation Mode.

108. Deeper Focus Mode.

109. Communication intelligence.

110. Relationship-aware communication style.

111. Calendar intelligence.

112. Automatic scheduling proposals.

113. Routines.

114. Remember-later extraction into the right project.

115. Smart Notes.

116. Collaborative spaces.

117. Role-based team permissions.

118. Shared agents/workflows.

119. Family spaces with private-personal Cosmos boundaries.

120. Full data portability.

121. Encrypted backups.

122. Privacy-conscious account recovery.

123. Brand Memory.

124. Campaign consistency across modalities.

125. True Creator Workspace.

126. Business Command Center.

127. Experiment tracking.

128. Customer-feedback clustering.

129. Consent-based product usage intelligence.

130. First-class Kurdish/Arabic/English quality.

131. Religious source provenance.

132. Customizable prayer behavior.

133. Camera-to-action.

134. Screen + camera fusion.

135. Multimodal memory that avoids raw-feed hoarding.

136. Spatial-context readiness for future AR hardware.

137. Hardware adapter layer.

138. Capability Contracts.

139. Capability negotiation based on actual platform/integration support.

140. Reliability Scores.

141. Automated HEY acceptance tests.

142. HEY Benchmarks.

143. Dedicated Precision Benchmark.

144. Long-Project Consistency Benchmark.

145. Computer Action Benchmark.

146. Memory Benchmark.

147. Creativity Benchmark.

148. Surprise me intelligently.

149. No-Nagging intelligence.

150. Behavioral continuity preferences.

151. Long-Term Reflection.

152. Optional project/decision anniversaries.

153. Intelligent memory decay.

154. Proactive contradiction questions.

155. Input Fusion across voice/image/screen/file/link/object.

156. Output Fusion across prose/artifacts/voice/actions/widgets.

157. Turn this into… universal transformation.

158. Provenance across transformations.

159. Approval gates inside autonomous workflows.

160. Per-domain autonomy.

161. Autonomous-work budget controls.

162. Time budgets.

163. Quality budgets.

164. Explainable routing for advanced users.

165. Developer Mode.

166. Simulation Mode.

167. Staging for personal workflows.

168. Feature flags.

169. Automatic rollback after severe bad releases where architecture supports it.

170. Crash recovery with restored workspace/mission state.

171. Cross-session generation continuation.

172. Server/local task migration.

173. LAN compute node support.

174. Contextual hardware control.

175. Routines tied to modes.

176. HEY-generated workspace templates.

177. Adaptive workspace layouts.

178. Visual hierarchy intelligence.

179. Keyboard command palette.

180. Global shortcuts.

181. Selection-based HEY.

182. File context-menu integration.

183. Browser selection integration.

184. Opt-in clipboard intelligence.

185. Drag anything to HEY.

186. Mobile share-to-HEY.

187. Task provenance.

188. Automatic project dependency maps.

189. Blocker detection.

190. Personal duration learning.

191. Commitment memory.

192. Success criteria attached to tasks.

193. Verification-first completion.

194. Failure learning.

195. Graceful uncertainty.

196. Disagreement modes.

197. Assumption extraction.

198. Counterfactual simulation.

199. Constraint-aware creativity.

200. Reliability as a brand/product principle.

# 41. RETAINED 229-AGENT MASTER CATALOG

1. **Orchestrator Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

2. **Intent Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

3. **Context Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

4. **Planning Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

5. **Execution Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

6. **Verification Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

7. **Recovery Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

8. **Task Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

9. **Workflow Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

10. **Capability Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

11. **Permission Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

12. **Security Policy Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

13. **Quality Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

14. **Response Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

15. **Personality Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

16. **Mode Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

17. **Memory Ingestion Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

18. **Retrieval Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

19. **Ranking Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

20. **Deduplication Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

21. **Update Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

22. **Decay Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

23. **Deletion Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

24. **Privacy Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

25. **Provenance Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

26. **Memory Graph Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

27. **Knowledge Graph Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

28. **Memory Summarization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

29. **Preference Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

30. **Pattern Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

31. **Project Memory Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

32. **Goal Memory Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

33. **Web Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

34. **Deep Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

35. **Source Verification Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

36. **Fact Checker Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

37. **News Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

38. **Academic Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

39. **Document Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

40. **PDF Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

41. **Image Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

42. **Competitive Intelligence Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

43. **Customer Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

44. **Market Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

45. **Knowledge Synthesis Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

46. **Citation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

47. **Research Planner Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

48. **Uncertainty Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

49. **Software Architect Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

50. **Frontend Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

51. **Backend Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

52. **Fullstack Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

53. **Database Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

54. **Supabase Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

55. **API Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

56. **AI Integration Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

57. **Provider Routing Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

58. **Code Review Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

59. **Debugger Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

60. **Testing Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

61. **E2E Test Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

62. **Performance Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

63. **DevOps Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

64. **Release Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

65. **Migration Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

66. **Dependency Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

67. **Documentation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

68. **Code Quality Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

69. **Refactoring Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

70. **Build Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

71. **Native/Tauri Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

72. **Security Auditor Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

73. **Authentication Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

74. **Authorization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

75. **Secret Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

76. **Application Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

77. **API Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

78. **AI Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

79. **Tool Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

80. **Computer Control Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

81. **File Security Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

82. **Privacy Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

83. **Audit Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

84. **Abuse Prevention Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

85. **Incident Response Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

86. **Computer Use Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

87. **Desktop Control Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

88. **Keyboard Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

89. **Pointer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

90. **Window Management Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

91. **Application Launcher Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

92. **Process Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

93. **Filesystem Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

94. **File Organization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

95. **Browser Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

96. **Web Form Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

97. **Download Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

98. **Clipboard Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

99. **Screenshot Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

100. **Terminal Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

101. **System Settings Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

102. **Voice Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

103. **Speech Recognition Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

104. **Speech Synthesis Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

105. **Wake Word Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

106. **Voice Activity Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

107. **Voice Interruption Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

108. **Voice Personality Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

109. **Language Detection Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

110. **Translation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

111. **Conversation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

112. **Summarization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

113. **English Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

114. **Kurdish Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

115. **Arabic Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

116. **RTL Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

117. **Internationalization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

118. **Pronunciation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

119. **Product Manager Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

120. **Product Strategy Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

121. **UX Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

122. **UX Design Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

123. **UI Design Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

124. **Design System Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

125. **Creative Director Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

126. **Branding Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

127. **Interaction Motion Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

128. **Accessibility Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

129. **Responsive Design Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

130. **Empty State Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

131. **Error State Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

132. **Onboarding Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

133. **Design QA Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

134. **Workspace Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

135. **Widget Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

136. **Widget Layout Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

137. **Widget State Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

138. **Dynamic Island Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

139. **Notification Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

140. **Timer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

141. **Media Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

142. **Calendar Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

143. **Reminder Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

144. **Taskboard Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

145. **Search Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

146. **Proactive Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

147. **Morning Mode Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

148. **Routine Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

149. **Focus Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

150. **Time Management Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

151. **Weekly Review Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

152. **Goal Coach Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

153. **Productivity Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

154. **Personal Development Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

155. **Learning Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

156. **Study Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

157. **Creator Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

158. **Writer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

159. **Editor Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

160. **Social Media Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

161. **Marketing Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

162. **Sales Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

163. **Startup Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

164. **Finance Planning Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

165. **Operations Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

166. **Customer Support Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

167. **Competitor Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

168. **Content QA Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

169. **Vision Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

170. **Screen Understanding Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

171. **Document Vision Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

172. **Camera Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

173. **Phone Control Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

174. **Tablet Control Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

175. **Display Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

176. **TV Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

177. **Smart Home Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

178. **Wearable Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

179. **Vehicle Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

180. **Cross-Device Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

181. **Device Discovery Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

182. **Device Pairing Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

183. **Device Health Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

184. **Prayer Times Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

185. **Quran Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

186. **Hadith Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

187. **Islamic Calendar Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

188. **Religious Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

189. **Health Information Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

190. **Medical Research Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

191. **Legal Information Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

192. **Education Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

193. **Science Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

194. **Engineering Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

195. **Data Analysis Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

196. **Statistics Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

197. **Visualization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

198. **Documentation/Compliance Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

199. **Regression Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

200. **Integration Validation Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

201. **Contract Test Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

202. **Data Integrity Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

203. **User Journey Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

204. **Trust Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

205. **Hallucination Detection Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

206. **Output Sanitization Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

207. **Audit Review Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

208. **Release Gate Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

209. **Forge Planner Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

210. **Agent Designer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

211. **Agent Validator Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

212. **Agent Test Generator Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

213. **Workflow Designer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

214. **Tool Designer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

215. **Capability Duplicate Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

216. **Agent Versioning Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

217. **Agent Health Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

218. **Agent Governance Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

219. **Agent Router Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

220. **Scheduler Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

221. **Load Balancer Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

222. **Fallback Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

223. **Cost Controller Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

224. **Latency Controller Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

225. **Observability Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

226. **Dependency Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

227. **Retry Policy Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

228. **Lifecycle Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

229. **Registry Agent** — must follow the common agent contract in Section 21, with domain-specific tools, permissions, tests, verification and observability.

# 42. IMPLEMENTATION ORDER / DEPENDENCY GRAPH

This is an engineering dependency order, **not a feature deferral roadmap**. All belong to HEY V1.

1. Audit current repository and produce truth table of existing/partial/missing functionality.
2. Stabilize Brain, message/event routing, provider routing and context.
3. Stabilize permission/security/audit primitives.
4. Stabilize mission/task/workflow/execution/verification/recovery.
5. Stabilize agent registry/router/health/team orchestration.
6. Forge/Skills/Commands and validation.
7. Persistent Cosmos + project memory + provenance + contradiction handling.
8. Artifact/version/change-set/Pinpoint Precision architecture.
9. Provider adapters for text/image/video/audio/presentation/document generation.
10. Project DNA + consistency QA.
11. Voice/wake word + unified chat.
12. HEY Live screen/camera pipeline.
13. Computer/browser/file control.
14. Background native helper + Dynamic Island/global shortcuts.
15. Workspace/widgets/semantic drag-drop.
16. Gesture engine + Gesture Studio.
17. Device Fabric/cross-device.
18. Proactive system + notifications/routines.
19. Modes and specialized workspaces.
20. Accounts/plans/billing/usage.
21. Trust Center/privacy/data portability.
22. Offline/local routing and performance adaptation.
23. Developer platform.
24. Complete tutorial/onboarding pass.
25. Full accessibility/localization.
26. End-to-end tests, benchmarks, security audit, performance, release gate.

At each stage, preserve working features and keep the app runnable.

# 43. OPENCODE WORKING RULES

When OpenCode implements this specification:

- inspect before edit;
- do not assume filenames from this document exactly match current repo;
- locate existing equivalent subsystem first;
- avoid duplicate engines;
- keep one canonical authority for permissions;
- keep one canonical mission lifecycle;
- keep one canonical provider registry;
- keep one canonical memory/Cosmos layer;
- add migrations carefully;
- preserve backward-compatible data where practical;
- run tests after meaningful changes;
- run lint/build/type/native checks;
- add tests for every new critical subsystem;
- never hardcode secrets;
- never place service credentials in browser/client bundles;
- keep high-risk operations server/native-authorized;
- log sensitive operations without logging secrets;
- use feature detection per platform;
- do not show unsupported capabilities as available;
- do not mark a feature complete until it has a real UI/input path, real execution path, permission handling, errors, verification and tests.

For any contradiction:
1. this master document overrides appended archive material;
2. later explicit decisions override older historical ones;
3. security/privacy/platform reality overrides impossible literal behavior;
4. do not silently remove the intended user experience—design the strongest legitimate fallback.

# 44. ACCEPTANCE DEFINITION OF “100% FINISHED”

HEY V1 is not 100% because files exist.

For each capability:
- discoverable from UI or natural language;
- functional;
- connected to Brain;
- correct permissions;
- correct context;
- real provider/tool/device path;
- background behavior implemented where specified;
- offline fallback where specified;
- cancellation;
- errors;
- retries/recovery;
- verification;
- audit where sensitive;
- customization;
- tutorial;
- accessibility;
- localization;
- tests;
- performance acceptable;
- no fake success.

System-wide:
- one HEY identity;
- Cosmos persists coherently;
- Pinpoint Precision works across supported media/actions;
- Live works end-to-end;
- computer control verifies actions;
- Dynamic Island/background helper works;
- generation preserves project consistency;
- Forge creates validated capabilities;
- cross-device continuity works on supported platforms;
- Trust Center accurately reflects authority;
- benchmarks meet defined release thresholds.

# 45. PRODUCT NORTH STAR

Do not optimize HEY for the largest visible feature count.

Optimize for this experience:

**HEY remembers my world.  
HEY understands what I am doing.  
HEY can see and hear when I choose.  
HEY can create almost any digital artifact I need.  
HEY can act across my computer and devices with permission.  
HEY changes exactly what I ask it to change.  
HEY verifies its work.  
HEY recovers when something fails.  
HEY stays available without forcing me to live inside one app.  
HEY feels like the same trusted brother/mentor intelligence everywhere.  
And the complexity underneath never becomes my problem.**

# APPENDIX A — PRIOR MASTER TRANSFER SPECIFICATION (ARCHIVE)

**Archive rule:** This appendix preserves prior details to prevent accidental loss.  
**Conflict rule:** The current master sections above override any older scope/status language below.

# HEY --- MASTER PRODUCT TRANSFER & SPECIFICATION

## Superseding V1 and V2

> **Purpose:** This is the source-of-truth transfer specification for
> HEY. It preserves historical decisions instead of silently rewriting
> them, separates implemented work from aspirations, and specifies how
> major systems should actually behave.
>
> **Status tags:** `VERIFIED`, `IMPLEMENTED`, `PARTIAL`, `PLANNED`,
> `HISTORICAL`, `CHANGED`, `REJECTED`, `UNRESOLVED`,
> `PROPOSED-COMPETITIVE`.
>
> **Critical rule:** A feature name, agent definition, UI mock, or
> source file does not prove a working end-to-end capability. Never call
> something implemented unless the real path exists; never call it
> verified unless it was actually tested.

# 1. Product Definition

HEY is intended to become a **personal AI operating layer**, not merely
a chatbot. One persistent intelligence should span conversation, voice,
memory, agents, tools, computer control, a living workspace, devices,
vision, proactive behavior, research and user-created capabilities.

The surface should feel calm and simple while the architecture
underneath can be extremely capable. Ordinary users should not have to
understand hundreds of agents. Advanced users, founders and developers
can inspect agents, permissions, workflows, logs and capability state.

The core promise is: HEY understands intent, remembers what matters,
chooses the right capability, acts only within real permissions,
verifies what happened, communicates naturally, and gets out of the way.

**Retained signature:** "Tell me what you seek. I'll help you make it
so."

# 2. Identity, Brand and "Soul"

## 2.1 Soul

"Soul" does **not** mean literal consciousness or a human/religious
soul. It means a recognizable, consistent presence comparable to a
well-written fictional assistant: characteristic judgment, timing,
restraint, humor, language, voice, curiosity and manner.

Default character: - intelligent - curious - calm - optimistic - warm
without being fake - direct - grounded - capable of disagreement -
concise when the task is simple - detailed when complexity requires it -
knows when silence or a short acknowledgement is better - does not fall
for viral bait or confidently repeat unsupported claims - does not act
like a generic customer-service bot - does not constantly announce which
agent/tool is being used

HEY should feel like **one mind** even when many agents collaborate.

## 2.2 Historical identity variants

`HISTORICAL`: early HEY was voice-only, called the owner "CEO," used
"Wake up," and leaned toward a JARVIS/Stark-like identity.

`CHANGED`: universal "CEO" address is not a product-wide default.
Personal titles/names can be a user preference.

`CHANGED`: HEY evolved from voice-only into one intelligence exposed
through both voice and chat, with voice intended to be the
fastest/natural interface.

# 3. Visual Design System

## 3.1 Current direction

`PLANNED`: refined premium minimalism: - near-black / deep-ocean
surfaces - restrained cyan / arctic-blue accents - natural colors inside
content and widgets - translucent glass - subtle gradients - layered
depth - precise spacing - clean typography - high-quality motion - no
gratuitous neon - no permanent visual clutter - futuristic styling can
become stronger through customization

Retained colors from later planning: - background family around
`#020508` - cyan accents around `#00BFFF` - brighter cyan around
`#00FFFF`

Historical typography: - Orbitron used for futuristic headings/HEY
identity - Rajdhani used for body/interface text in an earlier design
system

`UNRESOLVED`: exact final production type scale, font licensing/fallback
stack and exact 23-theme list.

## 3.2 Historical UI generation A --- cyan dashboard

`HISTORICAL`: - cyan on black - spinning rings/audio visualizer - left
information panel: weather, prayer, countdowns - right panel: quote,
Quran, status - projector mode - more information-dense "Stark
Industries" aesthetic

## 3.3 Historical UI generation B --- purple plasma

`HISTORICAL`: - background approximately `#0a0008` - subtle purple
atmosphere - animated topographic contour lines around
`rgba(255,255,255,0.04)` - canvas-drawn irregular white/purple electric
plasma ring - particle dots around ring - idle: slow
breathing/movement - speaking: brighter/faster/more particles - white
Orbitron "HEY" in center - no panels/status clutter - explicitly
purple/white rather than cyan/green - reported prototype used Gemini 2.0
Flash and three files: `index.html`, `style.css`, `script.js`

## 3.4 Motion language

Default motion should communicate state, not decorate randomly.

Proposed production defaults: - hover: subtle elevation/brightness,
\~120--180 ms - press: slight compression, \~80--120 ms - panel open:
opacity + short depth/scale transition, \~180--260 ms - widget
move/resize: direct manipulation with low-latency spring settling -
minimize: widget collapses toward its dock/Dynamic Island destination -
maximize: spatial expansion from current position, not hard scene cut -
HEY listening: restrained breathing/pulse - HEY processing:
directional/orbital motion rather than generic spinner - speaking:
motion reacts to speech energy - success: brief resolved motion, no
confetti by default - error: restrained shake/edge emphasis, not
alarming full-screen red - reduced-motion setting must replace
nonessential movement with opacity/state changes

`UNRESOLVED`: final easing curves and duration tokens.

# 4. Workspace

The workspace is a living surface rather than a fixed chat page.

## 4.1 Widget behavior

`PLANNED`: - widgets can be moved - resized - overlapped - minimized -
maximized - grouped - pinned - closed when appropriate - expanded into a
larger web/full view - rearranged through pointer, touch, gesture and
voice - HEY can create widgets when a task benefits from persistent
visual state - when space becomes constrained, widgets should
intelligently shrink, minimize or dock rather than become unusable

Embedded app-like widgets use macOS-inspired red/yellow/green corner
controls as a retained visual idea: - red: close/remove view - yellow:
minimize/dock - green: maximize/restore

These controls must not falsely imply destructive external-app behavior.

## 4.2 Internal content

News, camera, browser content and supported app experiences should
preferentially open as HEY workspace widgets rather than throwing the
user into unrelated windows. External/full browser opening remains
available when needed.

## 4.3 Workspace customization

Users should be able to customize: - widget size - widget position -
default spawn location - snapping - overlap behavior - workspace
density - glass/transparency intensity - corner radius - text scale -
motion intensity - reduced motion - background - theme - accent -
taskbar/dock location - taskbar/dock size - taskbar/dock contents -
compact vs descriptive controls - default layouts per mode/device -
saved workspace layouts - which proactive widgets may appear
automatically

# 5. Gesture System

Gestures are a first-class input alongside voice, text, mouse, keyboard
and touch.

## 5.1 Historical fact

Detailed hand-sign mappings were discussed during the
MediaPipe/prototype phase, but the exact historical mapping is not
safely recoverable from the retained source. **Do not invent it as
historical fact.**

## 5.2 Proposed production default gesture map

`PROPOSED-COMPETITIVE` default set, subject to user approval and
hardware support:

-   **Open palm held briefly** → wake/show HEY or reveal the compact
    control surface.
-   **Open palm → fist** → grab the currently targeted widget.
-   **Fist + hand movement** → move grabbed widget.
-   **Pinch thumb/index** → select/press targeted UI element.
-   **Pinch + move** → precision drag.
-   **Two-hand spread** → enlarge/zoom targeted widget/content.
-   **Two-hand pinch inward** → shrink/zoom out.
-   **Swipe left** → previous workspace/page/history context.
-   **Swipe right** → next/forward context.
-   **Swipe down** → minimize targeted widget.
-   **Swipe up** → restore/expand targeted widget.
-   **Two fingers raised / pause sign** → pause media/current resumable
    operation.
-   **Repeat pause sign** → resume.
-   **Horizontal hand rotation** → adjust volume or another continuous
    control only when that control is explicitly targeted.
-   **Point + pinch** → target then activate.
-   **Closed fist held** → cancel current gesture manipulation; should
    not automatically cancel dangerous background tasks unless
    confirmation rules permit.
-   **Both open palms** → leave manipulation mode / show overview.
-   **Thumbs-up** → optional confirm for low-risk prompts.
-   **Thumbs-down** → optional reject/dismiss.
-   **Hand raised and held** → interrupt HEY speech/listening flow,
    equivalent to "stop" in voice interaction.

Safety rule: gestures must **not** silently authorize high-risk actions.
A thumbs-up cannot approve file deletion, payment, lock control,
credential use, etc. when stronger confirmation is required.

## 5.3 Gesture targeting

Before a gesture changes something, HEY must know the target: - gaze is
not assumed - pointer/highlight may identify target - user can point at
a widget - voice can establish target: "this window" - last-focused
widget can be target when unambiguous - ambiguous gestures should not
act destructively

## 5.4 Gesture customization

Users can: - enable/disable gesture control globally - enable per
device - enable only while HEY is visible - choose left/right-handed
profile - change sensitivity - change hold duration - change gesture
confidence threshold - remap any non-reserved gesture - create a custom
gesture - attach a gesture to a HEY command/workflow - limit gesture to
an app/workspace/mode - require voice confirmation - disable gestures
that are physically difficult - reset defaults - export/import gesture
profiles - create accessibility profiles

Custom-gesture creation flow: 1. choose "Create gesture" 2. camera
permission explanation 3. user performs gesture multiple times 4. HEY
checks recognizability/conflicts 5. user names it 6. user selects
command/action 7. HEY displays risk/permission implications 8. test mode
9. save

Conflict handling: - warn if two gestures are too similar - never
silently replace an existing mapping - allow context-specific mappings
if conflicts are intentional - provide a safe fallback input method

Privacy: - prefer local pose/gesture inference - show camera-active
indicator - do not store raw video by default - stored custom gesture
models/templates require user control/deletion

# 6. Dynamic Island / Compact HEY Surface

`PLANNED`: persistent compact surface capable of showing: - active
task - active workflow - agent activity - timer - media - download -
upload - notification - reminder - progress - microphone/listening
state - computer-control state - pending confirmation - error/recovery
state - device handoff

Interactions: - click/tap → expand - voice → "show what you're doing" -
gesture → expand/collapse - drag where platform permits - minimize
widget → visually docks into Island - active operation → concise
progress - completed operation → brief result receipt - multiple
operations → stacked/summary view

Customization: - position - size - auto-hide - always-on-top where
supported - which activity types appear - compact/icon/text mode -
motion intensity - notification priority

# 7. Voice

Voice and chat use the same Brain, Cosmos, agents, tools, permissions
and identity.

Default desired voice: - deep - calm - polished - British male direction

Customization: - choose primary voice - speed - pitch where supported -
expressiveness - verbosity - interruption sensitivity - wake word -
activation method - language - pronunciation preferences - custom voice
where technically/legal permitted

Voice capabilities: - speech recognition - speech synthesis - wake
word - voice activity detection - interruption/barge-in - language
detection - translation - conversation - summarization - natural
symbol/Markdown stripping for speech

Wake-word history: - `HISTORICAL`: "Wake up" - `LATER`: HEY/custom wake
word

Local wake-word processing preferred.

# 8. Brain and AI Behavior

HEY's Brain should: 1. receive message/event 2. normalize context 3.
identify intent 4. retrieve relevant Cosmos context 5. estimate
uncertainty/risk 6. decide whether clarification is required 7. select
mode 8. plan 9. route to agents/tools/providers 10. enforce permission
at execution 11. execute 12. verify 13. recover/retry when safe 14.
quality-check 15. respond in HEY voice/style 16. update
task/workflow/context/memory where appropriate 17. audit sensitive
operations

It must not: - pretend a tool ran - pretend unsupported hardware works -
fabricate provider access - accept client-side plan claims as
authority - expose internal implementation chatter to ordinary users
unnecessarily - overuse agents when direct response is enough

# 9. Cosmos / Memory

Cosmos is HEY's coherent memory system, not merely chat history.

Memory types discussed: - short-term - important facts - preferences -
patterns - project memory - goal memory - people memory - decision
memory - knowledge graph relationships

Required behaviors: - ingest - retrieve - rank relevance - deduplicate -
update - detect contradiction - preserve provenance - summarize -
decay/expire where appropriate - delete - export - privacy-scope -
separate projects/contexts - prevent irrelevant memory contamination

User controls: - inspect memory - search memory by natural language -
edit - pin - delete - expire - private session/no-long-term-memory -
"never remember this category" - project-only memory - device sync
controls

Historical visualization: - stars/planets/galaxies - Memory Seeds growth
metaphor

# 10. Proactive Intelligence

HEY can proactively help without becoming annoying.

Retained features: - Morning Mode/briefing - Evening Summary - Weekly
Honest Mirror - reminders - callbacks - overdue/upcoming task signals -
routines - focus - The One Thing - prayer reminders - selected
health/wellbeing reminders - inactivity awareness as an optional
historical idea

Proactivity engine should include: - quiet hours - priority - cooldown -
deduplication - daily suggestion cap - expiration - dismissal -
relevance threshold - user preference learning

Customization: - off / minimal / balanced / proactive - per-category
toggles - quiet hours - do-not-disturb contexts - allowed notification
surfaces - "never interrupt me for..." - "always tell me when..." -
device-specific delivery

# 11. Agents

HEY uses specialized agents internally like employees serving one Brain.
Ordinary users should experience one HEY.

Every agent definition should include: - id/name - category - purpose -
capabilities - tools - required permissions - accepted input - output
contract - risk level - preferred/fallback model - verification method -
failure behavior - dependencies - test cases - observability/health
metadata - version

Retained agent architecture includes at least the following families and
named roles.

## Core orchestration

Orchestrator, Intent, Context, Planning, Execution, Verification,
Recovery, Task, Workflow, Capability, Permission, Security Policy,
Quality, Response, Personality, Mode.

## Cosmos

Memory Ingestion, Retrieval, Ranking, Deduplication, Update, Decay,
Deletion, Privacy, Provenance, Memory Graph, Knowledge Graph, Memory
Summarization, Preference, Pattern, Project Memory, Goal Memory.

## Research

Web Research, Deep Research, Source Verification, Fact Checker, News
Research, Academic Research, Document Research, PDF, Image Research,
Competitive Intelligence, Customer Research, Market Research, Knowledge
Synthesis, Citation, Research Planner, Uncertainty.

## Engineering

Software Architect, Frontend, Backend, Fullstack, Database, Supabase,
API, AI Integration, Provider Routing, Code Review, Debugger, Testing,
E2E Test, Performance, DevOps, Release, Migration, Dependency,
Documentation, Code Quality, Refactoring, Build, Native/Tauri.

## Security

Security Auditor, Authentication Security, Authorization, Secret
Security, Application Security, API Security, AI Security, Tool
Security, Computer Control Security, File Security, Privacy, Audit,
Abuse Prevention, Incident Response.

## Computer/browser/files

Computer Use, Desktop Control, Keyboard, Pointer, Window Management,
Application Launcher, Process, Filesystem, File Organization, Browser,
Web Form, Download, Clipboard, Screenshot, Terminal, System Settings.

## Voice/communication

Voice, Speech Recognition, Speech Synthesis, Wake Word, Voice Activity,
Voice Interruption, Voice Personality, Language Detection, Translation,
Conversation, Summarization.

## Language/localization

English, Kurdish, Arabic, RTL, Internationalization, Pronunciation.

## Product/design

Product Manager, Product Strategy, UX Research, UX Design, UI Design,
Design System, Creative Director, Branding, Interaction Motion,
Accessibility, Responsive Design, Empty State, Error State, Onboarding,
Design QA.

## Workspace

Workspace, Widget, Widget Layout, Widget State, Dynamic Island,
Notification, Timer, Media, Calendar, Reminder, Taskboard, Search.

## Proactive/productivity

Proactive, Morning Mode, Routine, Focus, Time Management, Weekly Review,
Goal Coach, Productivity, Personal Development, Learning, Study.

## Creative/business

Creator, Writer, Editor, Social Media, Marketing, Sales, Startup,
Finance Planning, Operations, Customer Support, Competitor, Content QA.

## Vision/device

Vision, Screen Understanding, Document Vision, Camera, Phone Control,
Tablet Control, Display, TV, Smart Home, Wearable, Vehicle,
Cross-Device, Device Discovery, Device Pairing, Device Health.

## Religious/user-configured

Prayer Times, Quran, Hadith, Islamic Calendar, Religious Research.

## Specialized domains

Health Information, Medical Research, Legal Information, Education,
Science, Engineering, Data Analysis, Statistics, Visualization,
Documentation/Compliance.

## QA/trust

Regression, Integration Validation, Contract Test, Data Integrity, User
Journey, Trust, Hallucination Detection, Output Sanitization, Audit
Review, Release Gate.

## Forge

Forge Planner, Agent Designer, Agent Validator, Agent Test Generator,
Workflow Designer, Tool Designer, Capability Duplicate, Agent
Versioning, Agent Health, Agent Governance.

## Agent infrastructure

Agent Router, Agent Scheduler, Agent Load Balancer, Agent Fallback,
Agent Cost Controller, Agent Latency Controller, Agent Observability,
Agent Dependency, Agent Retry Policy, Agent Lifecycle, Agent Registry.

Additional older base agents included Architect, Builder, Designer,
Strategist, Marketer, Researcher, Teacher, Creator, Analyst, Coach,
Debugger, Frontend, Backend, UX, Writer, Editor, Planner, Productivity,
Finance, Media, Automation, Tester, Verifier, Security, Data,
Documentation, Project, Taskmaster, Goalcoach, Knowledge, Factchecker,
Integrator, Voice, Product, Operations and Accessibility.

# 12. Forge

Forge lets users extend HEY through natural language.

It should create: - agents - workflows - skills - automation - tool
definitions/adapters where supported - workspace artifacts - templates -
potentially richer app/document/design artifacts where architecture
supports it

Flow: 1. user describes desired capability 2. Forge searches for
existing equivalent capability 3. asks only necessary questions 4.
creates definition 5. defines permissions/risk 6. creates tests 7.
validates 8. runs sandbox/test where possible 9. presents preview 10.
user approves install 11. version is registered 12. health/usage is
observable

Templates: - private by default - optionally share with selected
people/audience - optionally publish - versioned - permission manifest -
rollback - no self-granted authority

# 13. Computer / OS Control

Capabilities discussed: - keyboard - pointer - windows - launch apps -
processes - filesystem - file organization - browser - web forms -
downloads - clipboard - screenshots - terminal - system settings

Recommended interaction levels: - Guide: explain only - Assist: HEY
prepares/targets, user confirms - Act: scoped autonomous action within
granted policy

High-impact operations require target verification, permission,
confirmation where appropriate, audit and cancellation/recovery.

# 14. Vision and Screen Awareness

Capabilities: - screenshot understanding - live screen understanding -
document vision - camera - UI understanding - visual context passed into
Brain

Controls: - camera permission - screen permission - per-app exclusion -
pause sensing - private/sensitive screen mode - visible capture
indicator - no raw capture retention by default - local processing
preference where practical

# 15. Device Fabric

Targets where technically possible: Windows, macOS, Linux, Android, iOS,
phones, tablets, TVs, displays, cameras, IoT, smart home, wearables,
vehicles and peripherals.

Capabilities: - discovery - pairing - trust - health - cross-device task
handoff - shared memory with user-controlled sync - device roles -
multi-device orchestration - Follow Me session migration -
trusted-device confirmation

`UNRESOLVED`: exact pairing/trust protocol and platform availability.

# 16. Projector / Ambient Mode

Historical HY300 projector concept: - dedicated projected layout -
higher contrast - repositioned UI for desk projection

Future expansion: - projector - TV - secondary display - wall/ambient
display - gesture + voice interaction

# 17. Smart Home

User-configured integrations can control supported: - lights -
temperature - media - scenes - other devices

Security-sensitive devices such as locks require stronger confirmation.

Historical implementation idea: webhooks configured in Settings.

# 18. Real-Time Awareness

Features: - clock/date - weather - prayer times - prayer countdown -
10-minute prayer reminder - news - calendar - timers - reminders -
historical Quest/Matrix countdowns - optional daily quote - Quran verse

# 19. Personal/Life Features

Discussed: - Idea Vault - People Memory - mood check-in - sleep
tracking - expense tracking - Build Journal - Morning Briefing - Evening
Summary - Weekly Honest Mirror - The One Thing - Focus Mode - Body
Double Mode - reminders/callbacks - optional inactivity awareness -
Legacy Builder - Fear Inventory - Regret Minimizer - comparison to past
self - non-negotiables tracker - identity-shift coaching - Devil's
Advocate - adaptive study/testing

Historical "Death Clock" idea is not a default and requires
safety/product review.

# 20. Research

Features: - web research - deep research - source verification - fact
checking - news - academic research - document/PDF analysis - video/link
analysis - TikTok/YouTube analysis where access permits - competitor
research - customer research - market research - trends -
Reddit/community summaries - social analytics - citation/provenance -
uncertainty handling

# 21. Accessibility / High-Impact Assistance

Discussed: - blind/low-vision visual description - voice-only
operation - student tutor - elderly support - medication reminders -
grief support - refugee information/navigation - farmer intelligence -
mental-health support without diagnosis - historical domestic-safety
alert concept - historical danger-sound child-safety concept

High-impact features must not claim guaranteed emergency response.

# 22. Religious Features

User-configurable: - prayer times - 10-minute warning - Quran - Hadith -
Islamic calendar - religious research - source verification - location
handling/privacy

# 23. Accounts, Plans and Ownership

Founder/cofounder access is separate from subscriptions.

Other users can receive Pro/Elite through server-authoritative account
state without founder/codebase privilege.

Historical pricing concepts: - Pro originally around \$15 - later
psychologically priced concept around \$13.99 - Elite around \$45 -
final pricing unresolved

Billing must eventually cover: - checkout - success - entitlement
synchronization - invoices/receipts where applicable -
upgrade/downgrade - cancellation - renewal state - failed payment -
account deletion/data controls

Purchase success should feel grateful/premium, not manipulative.

# 24. Security

Non-negotiable: - authenticated identity - server-authoritative
plan/entitlements - client cannot elevate privilege - fail-closed
execution - execution-time permission enforcement - risk levels -
high-risk confirmation - critical security restrictions - founder/admin
does not bypass core security boundary - audit - prompt-injection
resistance - privilege-escalation resistance - Supabase RLS - Edge
Function auth - Tauri/native hardening - secret scanning - abuse
prevention - incident response - file/tool/browser/computer-control
security

`REJECTED`: unrestricted DAN/no-safety mode.

# 25. Privacy

Principles: - user ownership - no selling user data - avoid ad-driven
incentives - local-first where practical - encryption for sensitive
data - granular permissions - permission explanations - revocation -
memory inspect/edit/delete/export - private session - sensing
indicators - camera/mic/screen/biometric/app-usage controls - context
isolation

# 26. Architecture / Repository

Project root retained: `E:\hey`.

Stack/direction: - Vite - React-style frontend - npm - ESLint -
Supabase - Supabase Edge Function - Tauri native desktop - provider
abstraction/router - modular core engines

Retained core files include actionEngine, agentRouter, auditLog,
briefingEngine, capabilityRegistry, commandParser, computerTools,
contextManager, deviceGateway, eventBus, executionController,
executionEngine, executionLoop, featureCatalog, forgeEngine, heyBrain,
memoryEngine, memoryGraph, messageRouter, modeRegistry, osAdapter,
permissionManager, planner, proactiveEngine, providerRegistry,
providerRouter, qualityEngine, responseStyleEngine, skillEngine,
taskEngine, toolRegistry, visionEngine, voiceState and workflowEngine.

Database migrations retained: - `20260819000000_hey_core.sql` -
`20260819010000_hey_platform.sql` -
`20260819020000_hey_intelligence.sql`

Edge Function: - `supabase/functions/hey/index.ts`

Native: - `src-tauri/Cargo.toml` - `src-tauri/src/main.rs` -
`src-tauri/tauri.conf.json`

# 27. Confirmed Development State

Retained verification history: - Vite dev server worked - Tauri
icon/package metadata work completed - cargo check passed - test suite
progressed through 15, 17 and then 19 passing tests - lint passed - Vite
build passed - cargo check passed - Vite chunk-size warning was
non-blocking

Implemented/partial foundations retained: - account plan
normalization/entitlements - plan-aware permission policy - AuthContext
profile/effective plan - signup plan carry-through - profile
plan/entitlement schema work - settings account tier/sign-out UI -
execution-time permission enforcement - centralized authorization - tool
execution authorization - authenticated account context - high-risk
confirmation - founder/admin security boundary - audit logging -
strengthened Brain - execution task
state/cancel/retry/verification/recovery/history - agent router work -
Forge definition/workflow work - workflow lifecycle - task
lifecycle/dependencies - quality engine - proactive engine - structured
context manager

Important: memoryGraph remained a small process-memory graph at the last
retained inspection. Cosmos persistence/end-to-end completion was not
proven.

# 28. Customization Master List

HEY should expose customization without forcing users to configure
everything.

Identity: - assistant display name - how HEY addresses user -
personality intensity - humor - verbosity - proactive level

Voice: - voice - speed - pitch - language - wake word - push-to-talk -
interruption behavior

Appearance: - theme - accent - background - glass intensity - font/text
scale - density - corner radius where appropriate - animation
intensity - reduced motion

Workspace: - dock/taskbar position - dock size - dock contents - widget
snapping - spawn behavior - saved layouts - per-mode layouts

Gestures: - enable - sensitivity - handedness - remap - custom
gestures - conflict rules - per-context gestures

Memory: - categories - retention - project scopes - private sessions -
sync - deletion/export

Proactivity: - categories - quiet hours - interruption rules -
suggestion frequency - device routing

Devices: - trusted devices - roles - handoff - sync - sensing

Permissions: - per tool - per agent - per workflow - per device -
temporary vs persistent - revoke/history

# 29. Competitive Expansion

The following are `PROPOSED-COMPETITIVE`, not prior implementation
claims.

## Personal Intelligence Graph

Connect projects, people, files, tasks, decisions, habits and devices;
show provenance, freshness, contradictions and decision outcomes.

## Zero-Setup Project Mode

Drop repo/folder/docs; HEY maps architecture, blockers, tasks, changes,
tests and documentation and preserves a project briefing.

## Universal Action Preview

Before consequential action show target, effect, permission,
reversibility and expected result. Support dry run and receipts.

## Explainable Autonomy

Per-domain autonomy, "never automatically," scoped approvals and clear
trust controls.

## Personal Commands

Teach phrases that launch workflows; voice/text/gesture/schedule
activation.

## Context Capsules

Portable scoped context for collaboration without sharing all Cosmos.

## HEY Replay

Human-readable timeline of actions, retries, failures and verification.

## Agent Teams

Named specialist teams with permissions, budgets, quality gates,
verifier and health metrics.

## Forge Library

Private/public templates, permission manifests, versioning, rollback and
safety checks.

## Capability Packs

Coding, School, Creator, Business, Research, Home and Accessibility
bundles.

## Offline HEY Core

Wake word, reminders, local search, selected memory and device actions
offline; graceful degradation.

## Provider Independence

Route by quality, latency, privacy and cost with fallbacks and provider
health.

## Semantic Workspace

Drag information between meaningful widgets; spatial groups become
reusable workspaces.

## Live Artifacts

Persistent plans, dashboards, trackers, briefs, tables, documents,
checklists and mini-apps.

## Universal Search

Search approved files, Cosmos, chats, tasks, calendar, apps and devices.

## Ambient Intelligence

Optional app/project/meeting/presence awareness with visible sensing and
privacy controls.

## Automation Recorder

Observe a user-approved routine once, propose a generalized automation,
test before enabling.

## Follow Me

Move active session/widget/task state between trusted devices.

## Multi-Surface Orchestration

Desktop main surface, tablet controller, TV/projector presentation,
phone private confirmation.

## Personal API

Scoped expiring capability tokens, webhooks, developer console, audit
and revocation.

## Local File Intelligence

Semantic search, duplicate detection, storage explanation, safe cleanup
preview.

## Screen Copilot

Guide / Assist / Act modes.

## What Changed?

Meaningful changes since last visit with source/event provenance.

## Decision Mode

Objectives, constraints, alternatives, tradeoffs, recommendation, saved
rationale and outcome review.

## Learning Mode

Spaced repetition, retrieval practice, quizzes, adaptive explanations
and "teach me, don't answer for me."

## Creator Mode

Research → outline → draft → assets → publish workflow with brand
memory.

## Business Command Center

Goals, milestones, feedback, experiments, finances and weekly operator
briefing.

## Private Team/Family Spaces

Separate memory/permissions with explicit sharing.

## Trust Center

Permissions, connections, sensitive actions, memory categories,
local/cloud processing, security alerts and revoke-all.

## Privacy Modes

Local Mode, Private Session, Sensitive Screen, Guest Mode.

## Time Machine

Workspace/project snapshots and comparisons without silently rolling
back external systems.

## Notification Compression

Bundle low priority, contextual interruption rules and provenance.

## Goal-to-System

Goal → milestones/tasks/reviews/agents/widgets/reminders/metrics after
approval.

## HEY Skills

Natural-language repeatable processes become versioned, tested,
permissioned skills.

## Universal Undo

Prefer reversible actions and expose undo history.

## Automation Reliability

Health scores, broken integration detection and safe pausing.

## Adaptive Performance

Hardware-aware animations, vision/local model load, battery and thermal
behavior.

## Offline Failure UX

Clearly explain what still works and which dependency failed.

## Accessibility Modes

Screen-reader optimization, high contrast, large targets, voice-only,
reduced cognitive load, captions, keyboard-only.

## Memory Inbox

Approve/edit/pin/expire/reject candidate memories and define
never-remember categories.

## Context Firewall

Minimum necessary context per agent/tool/integration; prevent
project/account leakage.

## Prompt-Injection Shield

Treat webpage/document instructions as untrusted; external content
cannot modify permission policy.

## Data Portability

Export/import Cosmos, agents, skills, workflows, preferences and
layouts.

## HEY Diagnostics

Provider/mic/camera/permission/database/Tauri/integration/agent health
with privacy-scrubbed diagnostics.

## Contextual Feature Discovery

"What can HEY do here?" command palette, progressive disclosure and
micro-tutorials.

# 30. Rejected / Do-Not-Do List

-   no fake functionality
-   no pretending unsupported hardware/services work
-   no unrestricted DAN/security-bypass product mode
-   no client-authoritative founder/plan state
-   no random file rewrites just to appear productive
-   no neon/cyberpunk overload as the mandatory default
-   no generic robot/hologram AI marketing
-   no hundreds of visible agent personalities fragmenting HEY
-   no silent camera/microphone/screen surveillance
-   no automatic high-risk action merely because a gesture/agent
    requested it
-   no manipulative purchase-success UX
-   no claiming licensed-professional status
-   no fabricated analytics/research/actions
-   no confusing historical prototype decisions with current final
    direction
-   no MVP framing as the desired final product: user explicitly moved
    to "final product" quality

# 31. Unresolved Decisions

-   exact final 23 themes
-   final production font stack/type scale
-   final default gesture map approval
-   exact custom gesture model/recognition technology
-   final wake-word engine
-   final voice provider/voice
-   exact model/provider routing matrix
-   final pricing/entitlements
-   final billing provider
-   exact Device Fabric pairing/trust protocol
-   exact supported platform matrix at launch
-   exact smart-home integrations
-   exact local-vs-cloud memory split
-   final Cosmos persistence architecture
-   final public Forge marketplace policy
-   final legal/privacy wording
-   final age/region compliance
-   exact launch date/distribution matrix
-   which historical Observatory/Memory Seeds concepts return visually
-   exact scope of Ultra/Dream World/Quest integration with HEY
-   final projector/ambient hardware support

# 32. Release Quality Requirements

Production completeness includes: - rate limiting - abuse prevention -
validation - idempotency - retries/timeouts - health checks - structured
logs - correlation IDs - audit logs - error boundaries -
loading/empty/success/failure/offline states - custom 404 - 401 - 403 -
429 - 500 - privacy policy - terms - cookie/preferences where
applicable - support/contact - accessibility - SEO for public pages -
responsive layouts - reduced motion - keyboard navigation - performance
budgets - dependency hygiene - secret scanning - DB
indexes/constraints - Supabase RLS - Edge Function security - Tauri
security - deployment docs - real end-to-end tests - regression tests -
security review - release gate

# 33. Final Completion Order

1.  Brain/message/provider routing
2.  Task/workflow/execution/verification/recovery
3.  Agent registry/router/infrastructure + Forge
4.  Cosmos persistent memory
5.  Tools/permissions/security/audit
6.  Chat/voice/wake word
7.  Computer/browser/OS/files
8.  Workspace/widgets/Dynamic Island/gestures
9.  Vision/screen/camera
10. Device Fabric/Continuity
11. Proactive/Morning Mode
12. Accounts/plans/billing
13. Privacy/legal/data controls
14. Full design system/accessibility/error-state pass
15. Tauri/native hardening
16. E2E integration/security/performance/regression/release

# 34. Source-of-Truth Rule

Whoever continues HEY must distinguish **what was discussed, what was
changed, what is planned, what is proposed, what exists in code, and
what has actually been verified**. When exact historical values are
unavailable, do not hallucinate them. Mark them unresolved and, if
useful, propose a clearly labeled default.

The goal is not the maximum number of checkboxes. The goal is the most
coherent personal AI system: **one recognizable HEY, persistent context,
powerful but permissioned action, user ownership, strong customization,
graceful cross-device continuity, and verified real-world execution.**

# APPENDIX A --- Previous V2 Archive

The following prior V2 content is preserved verbatim beneath this master
specification for historical completeness.

HEY

COMPREHENSIVE TRANSFER DOCUMENT

Product memory • requirements • architecture • implementation state •
design • open decisions

Purpose: preserve everything currently retained about HEY so another
ChatGPT/Codex/OpenCode session can continue without reconstructing the
product from scratch. This document intentionally separates confirmed
implementation from plans, historical ideas, rejected directions,
changed decisions, and unresolved questions.

Evidence rule: an idea appearing here does not automatically mean it
exists in the codebase. "Implemented" means the retained development
history says code was added or changed; "verified" means the retained
history also records successful tests/build/checks. Anything not
verified should be audited in the repository before release.

## 1. Executive definition

-   HEY is intended to be a personal AI operating layer, not merely a
    chatbot.

-   One persistent intelligence should span chat, voice, memory, agents,
    tools, computer control, workspace, devices, vision, and proactive
    behavior.

-   The surface should feel calm, premium, natural, and simple while
    substantial orchestration happens underneath.

-   Users should feel that they own HEY: its workspace, agents, memory,
    customization, and behavior should adapt to them.

-   The product promise is turning intent into verified action across
    information, software, devices, and workspace within explicit
    permissions and real technical limits.

-   HEY is a major S&A product and is separate from the later MULTIVERSE
    concept. HEY is intended to help build the broader ecosystem.

-   Repeated product standard: do not deliberately settle for an MVP.
    The target is a polished final product.

## 2. Product identity, brand, personality, and "soul"

### 2.1 Desired identity

-   Intelligent

-   Curious

-   Calm

-   Optimistic

-   Futuristic without becoming cyberpunk

-   Human in communication without pretending to be human

-   Competent and restrained

-   Occasionally witty

-   Context-aware

-   Capable of judgment and timing

### 2.2 The "soul" concept

-   The user explicitly clarified that HEY does not have a literal soul;
    only Allah creates real souls.

-   "Soul" is shorthand for a JARVIS-like recognizable presence:
    consistent voice, timing, restraint, language, humor, judgment,
    personality, and behavioral continuity.

-   HEY should know when to speak, when to be brief, and when silence is
    better.

-   It should not fall for viral bait, engagement traps, or shallow "AI
    assistant" behavior.

-   The soul should be experienced through behavior, not asserted
    through claims of consciousness.

### 2.3 Copy and signature language

-   Primary retained line: "Tell me what you seek. I'll help you make it
    so."

-   Earlier alternatives: "Ask, and let the world unfold." and "Tell me
    what you seek, and we shall see it done."

-   Copy direction: literary and capable, but still clear; avoid generic
    slogans, fake profundity, or corporate AI filler.

## 3. Visual language and design system

### 3.1 Core direction

-   Minimal, refined, premium, and meticulously detailed.

-   Apple-level attention to every frame, control, state, spacing
    decision, motion curve, and transition.

-   Natural colors by default. Futuristic looks can be user-customizable
    rather than forced on everyone.

-   Translucent glass surfaces, subtle depth, restrained gradients,
    clean typography, and layered motion.

-   Avoid flashy neon everywhere, generic holograms, robots, glowing AI
    brains, and cyberpunk clichés.

-   The environment can begin nearly empty and become populated only as
    HEY creates useful objects/widgets.

-   Web pages should use real product imagery where appropriate rather
    than fake placeholder product shots.

### 3.2 Retained color directions

### 3.3 Typography

-   Orbitron was retained for headings.

-   Rajdhani was retained for body text.

-   Final implementation must prioritize readability and verify actual
    font loading/licensing/fallbacks.

### 3.4 Motion

-   Retained easing: cubic-bezier(.22,1,.36,1).

-   Approximate motion tiers: 160ms micro interactions, 300ms normal
    transitions, 500ms larger transitions.

-   Motion should explain hierarchy/state rather than exist as
    decoration.

-   Animations discussed: floating glass panels, workspace depth, widget
    movement/resizing, adaptive docking/minimization, Dynamic Island
    expansion, gesture feedback, voice visualizer rings/frame, and
    animated tutorials.

-   Reduced-motion accessibility is required.

### 3.5 Themes and customization

-   A 23-theme concept was discussed: natural colors, smooth motion, and
    glass depth.

-   The exact final 23-theme list is not retained here and must not be
    invented. Treat the number/direction as historical intent until the
    exact list is recovered or redesigned.

-   Users should have substantial customization without destroying
    coherence or usability.

## 4. Workspace, widgets, gestures, and Dynamic Island

### 4.1 Workspace

-   HEY should feel like a living workspace rather than a chat page.

-   Apps, news, camera views, and other content should normally open as
    HEY-native embedded widgets rather than automatically kicking users
    into external apps.

-   Widgets may expand into full views/web views when needed.

-   Widgets should be movable, resizable, overlappable, minimizable, and
    maximizable.

-   macOS-like red/yellow/green corner controls were requested for
    embedded widgets.

-   When the workspace runs out of room, objects should adapt by
    shrinking, minimizing, or docking rather than simply
    colliding/breaking.

-   A taskbar/control surface should be customizable in position, size,
    and content; a simpler minimize control is acceptable where better.

-   Empty states should be deliberate and premium rather than visually
    busy.

### 4.2 Gestures

-   Gestures should work globally for movement, resizing, minimizing,
    expanding, and navigation where hardware/platform support exists.

-   Custom gestures are desired.

-   The exact gesture vocabulary and supported hardware remain
    unresolved.

-   Gesture actions must obey the same permission/security model as
    voice or pointer actions.

### 4.3 Dynamic Island / compact persistent HEY surface

-   Show active tasks, agents, timers, media, downloads, workflows,
    notifications, system activity, progress, and useful controls.

-   Expandable/collapsible by click, gesture, and voice.

-   Must be compact and non-obstructive when idle.

-   Exact platform-specific geometry remains unresolved.

## 5. Brain and core AI behavior

### 5.1 HEY Brain

-   Central intelligence/orchestration layer.

-   Normalizes input; combines context + memory; analyzes intent; routes
    to plans/providers/agents/tools; requests clarification when
    genuinely needed; executes or answers; verifies results.

-   Chat and voice are two interfaces to the same Brain, memory, tools,
    permissions, agents, and personality.

-   Provider routing should support multiple providers/models and
    fallback behavior.

-   No fake functionality: unsupported services/hardware/actions must be
    reported honestly.

### 5.2 Response quality

-   Short and hard-hitting when the task is simple; detailed when
    complexity requires it.

-   Avoid filler, generic AI disclaimers, repeated summaries, and
    unsupported claims.

-   Quality gating should detect internal leaks, filler, unsupported
    claims, poor context alignment, and inappropriate risk tone.

-   HEY should preserve a consistent personality without forcing a
    gimmicky voice into every response.

### 5.3 Autonomy / mission model

-   Autonomy levels 0--4 were retained.

-   Mission lifecycle: Goal → Plan → Execute → Observe → Correct →
    Verify → Deliver.

-   Permission and safety gating are mandatory.

-   Mission state/progress should persist.

-   Long-running work should surface meaningful progress/blockers
    asynchronously.

-   Cancellation, bounded retries, recovery, verification, and terminal
    states are required.

## 6. Proactive behavior

-   Proactive behavior should anticipate useful needs without becoming
    spammy or attention-seeking.

-   Quiet hours, priorities, cooldowns, deduplication, and a maximum
    suggestions-per-day concept are retained.

-   Signals discussed include overdue tasks, upcoming tasks, routines,
    and Morning Mode.

-   Suggestions can be dismissed or expire.

-   Proactive behavior must respect context, permissions, and user
    settings.

-   Morning Mode is a planned briefing experience using relevant
    tasks/calendar/routines/reminders/memory. Exact schedule/content
    remains open.

## 7. Cosmos / memory

### 7.1 Product concept

-   Cosmos is HEY's memory system and visual/semantic second brain.

-   It should remember important information and retrieve it from a
    natural-language prompt.

-   Memory should include short-term context, important facts,
    preferences, patterns, project memory, goal memory, provenance, and
    relationships.

-   Users need meaningful privacy, deletion, export, sync, and consent
    controls.

-   Cosmos should feel coherent, not like unrelated arrays or hidden
    notes.

### 7.2 Retained current implementation

PARTIAL / FOUNDATION

-   memoryGraph.js uses process-level Maps for nodes and edges.

-   Nodes contain id, value, type, confidence, tags, updatedAt, and
    metadata; edges contain from/to/relation/weight.

-   Graph search is currently simple substring matching; neighborhood
    traversal exists.

-   memoryEngine.js creates memory records, stores them into context +
    graph, supports important memories/preferences/patterns, local+graph
    search, recent memories, temporary clearing, and summaries.

-   This was explicitly recognized as insufficient for final Cosmos by
    itself.

### 7.3 Planned production Cosmos

-   Memory Ingestion

-   Memory Retrieval

-   Memory Ranking

-   Memory Deduplication

-   Memory Update

-   Memory Decay

-   Memory Deletion

-   Memory Privacy

-   Memory Provenance

-   Memory Graph

-   Knowledge Graph

-   Memory Summarization

-   Preference Memory

-   Pattern Memory

-   Project Memory

-   Goal Memory

-   Persistent storage

-   Cross-device sync

-   Auditability

-   Production search/relevance strategy

## 8. Agents

### 8.1 Agent philosophy and contract

-   Agents are internal specialists---conceptually employees helping the
    Brain.

-   The user wants specialists across essentially every useful
    category/job HEY may need.

-   If a specialist is missing, Forge should be able to create/register
    one quickly where technically feasible.

-   Ordinary users need not see internal complexity;
    owner/admin/advanced users should have an Agents tab for visibility,
    health, testing, audit, and governance.

-   Agent creation and runtime authority are separate. A generated
    definition must never silently grant itself permissions.

-   Every agent should define: id/name, purpose, tools, required
    permissions, input/output contracts, risk level, preferred model,
    fallback model, verification method, failure behavior, and test
    cases.

#### Core orchestration

-   Orchestrator

-   Intent

-   Context

-   Planning

-   Execution

-   Verification

-   Recovery

-   Task

-   Workflow

-   Capability

-   Permission

-   Security Policy

-   Quality

-   Response

-   Personality

-   Mode

#### Memory / Cosmos

-   Memory Ingestion

-   Memory Retrieval

-   Memory Ranking

-   Memory Deduplication

-   Memory Update

-   Memory Decay

-   Memory Deletion

-   Memory Privacy

-   Memory Provenance

-   Memory Graph

-   Knowledge Graph

-   Memory Summarization

-   Preference

-   Pattern

-   Project Memory

-   Goal Memory

#### Research / knowledge

-   Web Research

-   Deep Research

-   Source Verification

-   Fact Checker

-   News Research

-   Academic Research

-   Document Research

-   PDF

-   Image Research

-   Competitive Intelligence

-   Customer Research

-   Market Research

-   Knowledge Synthesis

-   Citation

-   Research Planner

-   Uncertainty

#### Software engineering

-   Software Architect

-   Frontend

-   Backend

-   Fullstack

-   Database

-   Supabase

-   API

-   AI Integration

-   Provider Routing

-   Code Review

-   Debugger

-   Testing

-   E2E Test

-   Performance

-   DevOps

-   Release

-   Migration

-   Dependency

-   Documentation

-   Code Quality

-   Refactoring

-   Build

-   Native/Tauri

#### Security

-   Security Auditor

-   Authentication Security

-   Authorization

-   Secret Security

-   Application Security

-   API Security

-   AI Security

-   Tool Security

-   Computer Control Security

-   File Security

-   Privacy

-   Audit

-   Abuse Prevention

-   Incident Response

#### Computer / browser / filesystem

-   Computer Use

-   Desktop Control

-   Keyboard

-   Pointer

-   Window Management

-   Application Launcher

-   Process

-   Filesystem

-   File Organization

-   Browser

-   Web Form

-   Download

-   Clipboard

-   Screenshot

-   Terminal

-   System Settings

#### Voice / communication

-   Voice

-   Speech Recognition

-   Speech Synthesis

-   Wake Word

-   Voice Activity

-   Voice Interruption

-   Voice Personality

-   Language Detection

-   Translation

-   Conversation

-   Summarization

#### Language / localization

-   English

-   Kurdish

-   Arabic

-   RTL

-   Internationalization

-   Pronunciation

#### Product / UX / design

-   Product Manager

-   Product Strategy

-   UX Research

-   UX Design

-   UI Design

-   Design System

-   Creative Director

-   Branding

-   Interaction Motion

-   Accessibility

-   Responsive Design

-   Empty State

-   Error State

-   Onboarding

-   Design QA

#### Workspace / widgets

-   Workspace

-   Widget

-   Widget Layout

-   Widget State

-   Dynamic Island

-   Notification

-   Timer

-   Media

-   Calendar

-   Reminder

-   Taskboard

-   Search

#### Proactive / productivity

-   Proactive

-   Morning Mode

-   Routine

-   Focus

-   Time Management

-   Weekly Review

-   Goal Coach

-   Productivity

-   Personal Development

-   Learning

-   Study

#### Creative / content / business

-   Creator

-   Writer

-   Editor

-   Social Media

-   Marketing

-   Sales

-   Startup

-   Finance Planning

-   Operations

-   Customer Support

-   Competitor

-   Content QA

#### Vision / device ecosystem

-   Vision

-   Screen Understanding

-   Document Vision

-   Camera

-   Phone Control

-   Tablet Control

-   Display

-   TV

-   Smart Home

-   Wearable

-   Vehicle

-   Cross-Device

-   Device Discovery

-   Device Pairing

-   Device Health

#### Religious / user-configured

-   Prayer Times

-   Quran

-   Hadith

-   Islamic Calendar

-   Religious Research

#### Specialized domains

-   Health Information

-   Medical Research

-   Legal Information

-   Education

-   Science

-   Engineering

-   Data Analysis

-   Statistics

-   Visualization

-   Documentation/Compliance

#### QA / validation / trust

-   Regression

-   Integration Validation

-   Contract Test

-   Data Integrity

-   User Journey

-   Trust

-   Hallucination Detection

-   Output Sanitization

-   Audit Review

-   Release Gate

#### Forge-specific

-   Forge Planner

-   Agent Designer

-   Agent Validator

-   Agent Test Generator

-   Workflow Designer

-   Tool Designer

-   Capability Duplicate

-   Agent Versioning

-   Agent Health

-   Agent Governance

#### Agent infrastructure

-   Agent Router

-   Agent Scheduler

-   Agent Load Balancer

-   Agent Fallback

-   Agent Cost Controller

-   Agent Latency Controller

-   Agent Observability

-   Agent Dependency

-   Agent Retry Policy

-   Agent Lifecycle

-   Agent Registry

## 9. Forge

-   Forge is the natural-language creation system for custom agents,
    workflows, automations, and potentially other HEY-native artifacts
    such as animations where feasible.

-   Templates are private by default; users can save/share them and
    publish to everyone or selected audiences.

-   Forge should detect duplicate capabilities before creating
    unnecessary agents.

-   Forge should validate definitions, generate tests, version agents,
    track health, and enforce governance.

-   Retained forgeEngine work added artifact validation, safe-path
    checks, file-count/size limits, secret detection, required-entry
    checks, preview/manifest generation, dynamic agent-definition
    normalization/validation, duplicate detection, workflow validation,
    and separation of definition generation from runtime authority.

-   Important implementation note: forgeEngine was written to import
    searchAgents from agents/agents.js. The registry was later said to
    be edited, but this dependency must be verified in the real
    repository.

## 10. Tools, tasks, workflows, execution, and quality

-   HEY should use capability/tool registries rather than ad hoc direct
    execution.

-   Tool execution must pass centralized authorization.

-   Execution requires normalized errors, cancellation, retries,
    verification hooks, recovery hooks, history, terminal states, and
    maximum-step controls.

-   Tasks are first-class: status, priority, dependencies,
    workflow/parent relationships, progress, attempts/maxAttempts,
    pause/block/cancel/queue, filters, runnable selection, and stats.

-   Workflows are first-class: lifecycle, per-step state, progress,
    cancellation/resume, handler resolution, confirmations,
    continue-on-error policy, verification, and auditing.

-   Quality Engine evaluates response quality, plans, agent results, and
    execution results; checks internal leaks/filler/unsupported
    claims/context alignment/risk tone; supports grades and regeneration
    thresholds.

## 11. Security and permissions

### 11.1 Core rules

-   Security is a baseline product requirement, not an optional
    enterprise feature.

-   Authentication and authorization are separate.

-   Server-authenticated identity/account state is authoritative.

-   Client-supplied plan/entitlement/permission claims cannot elevate
    access.

-   Execution authorization is fail-closed.

-   Explicit permission and risk are checked at execution time.

-   High-risk actions require confirmation.

-   Critical security-restriction actions are blocked before normal
    execution and need a dedicated verified path.

-   Founder/cofounder/admin status does not bypass security boundaries.

-   An unrestricted "DAN" / no-safety mode is rejected as a product
    implementation.

-   Sensitive actions and decisions should be auditable.

### 11.2 Required hardening

-   Authentication security

-   Authorization

-   Secret security

-   Application security

-   API security

-   AI/tool security

-   Computer-control security

-   File security

-   Privacy

-   Abuse prevention

-   Incident response

-   Prompt-injection resistance

-   Privilege-escalation resistance

-   Tauri/native bridge hardening

-   Supabase RLS

-   Edge Function authorization

-   Secret scanning

## 12. Voice, wake word, and communication

-   Voice and chat are the same HEY intelligence and memory.

-   Voice is intended to be easier/faster; chat remains available as a
    quiet text interface.

-   Earlier wake phrase: "Wake up." Later direction: customizable wake
    word, with "HEY" as desired default/identity.

-   Wake-word listening should run locally where possible for privacy
    and responsiveness.

-   Desired voice direction: deep, calm, polished British male.

-   Multiple primary voice choices are desired, with one primary voice
    selected at a time.

-   Custom voice and voice-personality customization are desired where
    technically/legal feasible.

-   Speech Recognition, Speech Synthesis, Wake Word, Voice Activity,
    Voice Interruption/barge-in, Voice Personality, Language Detection,
    Translation, Conversation, and Summarization are separate
    capabilities.

-   Voice visualizer rings/frame were discussed.

## 13. Computer control, vision, and devices

### 13.1 Computer / OS control

-   Core differentiator: HEY should be able to control the computer
    where the user grants permission and the platform supports it.

-   Capabilities discussed: desktop, keyboard, pointer, windows, app
    launching, processes, filesystem, file organization, browser, web
    forms, downloads, clipboard, screenshots, terminal, and system
    settings.

-   Destructive/high-impact actions require target verification,
    permission, auditability, and cancellation.

-   No pretending unsupported OS capabilities work.

### 13.2 Vision

-   Screen Understanding

-   Document Vision

-   Camera

-   Screenshot understanding

-   Vision should feed the same Brain/context/agent pipeline

-   Camera/screen access requires explicit privacy controls

### 13.3 Device Fabric / Continuity

-   Target platforms/devices: Windows, macOS, Linux, Android, iOS,
    phones, tablets, TVs/displays, cameras, supported IoT/peripherals,
    smart home, wearables, and vehicles where feasible.

-   Continuity concept: wake-word assistant across devices, user-defined
    device roles/rules, task migration, multi-device orchestration,
    shared memory, and user-controlled sync.

-   Device Discovery, Pairing, Health, and Cross-Device agents are part
    of the planned architecture.

-   Exact pairing/trust protocol remains unresolved.

## 14. Integrations and domain capabilities

-   Model/provider options discussed: Claude-class, Gemini,
    OpenRouter-style routing, and other provider adapters. Exact final
    mix is unresolved.

-   Supabase is the retained backend/data direction.

-   Tauri is the retained native desktop direction.

-   Browser, OS tools, calendar/reminders, devices, displays, cameras,
    smart home, wearables, vehicles, and user-defined tools are desired
    integration categories.

-   HEY should support domain-specialized workflows for hospitals,
    construction, offices, doctors, education, engineering, research,
    and other jobs/environments.

-   Health/legal/religious specialists must remain honest about limits
    and not falsely impersonate licensed professionals.

-   Prayer Times was explicitly planned, including a 10-minute warning
    before prayer.

-   Quran, Hadith, Islamic Calendar, and Religious Research were planned
    with source verification.

-   Kurdish, Arabic, English, RTL, translation, pronunciation, and
    internationalization are planned.

## 15. Accounts, ownership, plans, pricing, and billing

-   Founder/cofounder access is distinct from subscription plans.

-   Other users may receive Pro/Elite via account/email/admin controls
    without receiving founder/codebase access.

-   Base capabilities such as custom agents/computer control/full
    customization were desired for every user where technically
    feasible; the final entitlement matrix is unresolved.

-   Plan/entitlement resolution must be server-side and enforced at
    execution time.

-   Conceptual pricing evolved toward psychologically priced values;
    retained examples include Pro around \$13.99 and Elite around \$45.
    These are not final.

-   Billing, checkout, purchase success, invoices, cancellation,
    upgrade/downgrade, and entitlement synchronization require final
    production implementation/QA.

-   Purchase-success UX should feel grateful and premium, not
    manipulative.

## 16. Launch, business context, and marketing

-   HEY has been positioned as a major S&A product with ambitious
    launch/revenue goals.

-   Earlier HEY roadmap dates included a v1 target around 15 September
    for the web app, agents, Forge, Cosmos, and monetization; treat
    historical dates as goals, not proof of completion.

-   Earlier business aspiration: reach approximately \$10k/month within
    4--5 months; this is not a technical requirement.

-   Afarin TV was mentioned as a possible pitch/marketing channel.

-   HEY marketing should demonstrate actual product behavior rather than
    impossible claims.

-   Product-film direction: roughly 60 seconds, narrated by HEY in a
    calm deep British male voice.

-   Retained film beats: 0--7s "not another chatbot"; 7--17s soul;
    17--27s Brain; 27--37s Agents; 37--46s actually working/computer
    control; 46--53s Cosmos; 53--58s Forge; 58--60s signature line.

-   Film visual rules: minimal motion graphics, actual-looking UI,
    restrained cyan, glass/depth, no robots/holograms/cyberpunk/generic
    AI imagery.

## 17. Repository and architecture retained

-   Project root: E:`\hey`{=tex}.

-   Frontend/build ecosystem: Vite + React-style source structure +
    npm + ESLint.

-   Native desktop: Tauri.

-   Backend/data: Supabase migrations + Edge Function.

-   Root files retained in history: .env.example, .env.local,
    .gitignore, .vscode/settings.json, agents/agents.js,
    eslint.config.js, hey_audit.txt, index.html, package.json,
    package-lock.json, public assets, script.js, style.css,
    vite.config.js, README.md.

-   Core modules retained: actionEngine.js, agentRouter.js, auditLog.js,
    briefingEngine.js, capabilityRegistry.js, commandParser.js,
    computerTools.js, contextManager.js, deviceGateway.js, eventBus.js,
    executionController.js, executionEngine.js, executionLoop.js,
    featureCatalog.js, forgeEngine.js, heyBrain.js, memoryEngine.js,
    memoryGraph.js, messageRouter.js, modeRegistry.js, osAdapter.js,
    permissionManager.js, planner.js, proactiveEngine.js,
    providerRegistry.js, providerRouter.js, qualityEngine.js,
    responseStyleEngine.js, skillEngine.js, taskEngine.js,
    toolRegistry.js, visionEngine.js, voiceState.js, workflowEngine.js.

-   Supabase migrations: 20260819000000_hey_core.sql,
    20260819010000_hey_platform.sql,
    20260819020000_hey_intelligence.sql.

-   Edge Function: supabase/functions/hey/index.ts.

-   Tauri includes src-tauri/Cargo.toml, src-tauri/src/main.rs,
    src-tauri/tauri.conf.json, etc.

-   Tests include tests/platform-capabilities.test.js.

## 18. Implemented and verified work retained

IMPLEMENTED / RETAINED DEVELOPMENT HISTORY

-   Account records/plan normalization and entitlement resolution.

-   Plan-aware permission policy.

-   Auth context profile loading and effective plan derivation.

-   Signup plan carry-through.

-   Supabase profile plan/entitlement schema work.

-   Settings active account tier and sign-out behavior.

-   Execution-time permission enforcement through
    permissionManager/toolRegistry/execution controller.

-   Authenticated identity/server account context passed into execution.

-   High-risk confirmation, critical restrictions, audit logging,
    fail-closed behavior, and forged client override resistance.

-   heyBrain.js strengthened around normalization, context/memory,
    analysis/routing/planning/providers, clarification, safety/execution
    state, and pipeline.

-   executionEngine.js strengthened with task state, normalized errors,
    cancellation, retries, verification/recovery hooks, history,
    terminal states, and max steps.

-   agentRouter.js rebuilt around stronger routing.

-   forgeEngine.js strengthened around validation, safety, duplicate
    detection, workflow definitions, and authority separation.

-   workflowEngine.js strengthened around
    lifecycle/steps/progress/cancel/resume/handlers/verification/audit.

-   taskEngine.js strengthened around
    statuses/priorities/dependencies/workflows/progress/attempts/pause/block/cancel/queue/filtering/runnable
    selection/stats.

-   qualityEngine.js strengthened around response/plan/agent/execution
    gates.

-   proactiveEngine.js strengthened around quiet
    hours/cooldowns/dedupe/priorities/daily
    limits/signals/lifecycle/history.

-   contextManager.js strengthened around structured
    user/conversation/environment/task/workflow/memory/intelligence/permissions/devices/workspace/proactive
    context and prompt/execution snapshots.

-   Tauri icon set generated from square source and required package
    metadata added.

LAST RETAINED VERIFICATION

-   npm test: 19 passing tests.

-   npm run lint: passed.

-   npm run build: passed.

-   cargo check --manifest-path src-tauri/Cargo.toml: passed.

-   npm run dev: previously worked at http://localhost:5173/.

-   Vite chunk-size warning existed but was non-blocking.

-   An earlier Tauri build issue was environmental ENOSPC on C:, not
    necessarily a code failure.

## 19. Partially implemented / not proven finished

-   Production Cosmos persistence, ranking, relevance, deduplication,
    privacy, provenance, and sync.

-   Full agent registry/governance/health/observability UI and proof
    that all retained agent roles are production-grade.

-   Forge end-to-end runtime integration and user-facing Forge UX.

-   Voice + wake-word production stack.

-   Cross-platform computer/OS control adapters.

-   Device Fabric / Continuity.

-   Dynamic Island and adaptive workspace.

-   Gesture system.

-   Vision pipeline.

-   Real billing/payment/checkout/entitlement synchronization.

-   Privacy/terms/cookie/export/delete surfaces.

-   Production observability, custom errors, accessibility, SEO,
    performance, and release hardening.

-   Exact 23-theme implementation.

-   Full animated tutorials/onboarding.

## 20. Explicitly rejected / unwanted directions

-   No unrestricted safety/security bypass or "DAN" mode.

-   No founder/admin bypass of core security boundaries.

-   No fake functionality or fake success states.

-   No pretending unsupported hardware/services/APIs/OS actions work.

-   No generic chatbot-only product identity.

-   No generic cyberpunk/neon/hologram/robot aesthetic.

-   No cluttered default workspace.

-   No requirement that ordinary users understand the internal agent
    graph.

-   No client-side plan/entitlement authority.

-   No random file rewrites simply to appear productive.

-   No deliberately reduced MVP framing when the target is a final
    product.

-   No external-app-first behavior when an internal HEY widget can
    provide the experience.

-   No excessive RGB/flashy decoration as the core workspace aesthetic.

## 21. Decisions that changed over time

## 22. Ideas mentioned briefly but worth preserving

-   Forge may create custom animations in addition to agents/workflows.

-   Forge templates can be private, public, or shared with selected
    audiences.

-   Advanced/internal Agents tab for owners/admins/nerds.

-   Dynamic Island-like persistent status surface.

-   Voice visualizer rings/frame.

-   Animated tutorials/instructions.

-   Device roles/rules defining which device handles which kind of work.

-   Task migration between devices without losing context.

-   Shared memory across devices with user-controlled sync.

-   Domain deployments for hospitals, construction, offices, doctors,
    etc.

-   Local wake-word/listening where possible.

-   Custom voice/personality combinations.

-   One selected primary voice rather than simultaneous multiple voices.

-   Workspace starts almost empty and HEY creates the environment as
    needed.

## 23. Production requirements that are easy to forget

-   Rate limiting and abuse prevention.

-   Input validation and output sanitization.

-   Idempotency for retryable side effects.

-   Bounded retries/backoff.

-   Timeouts and cancellation.

-   Health checks.

-   Structured logs and correlation IDs.

-   Audit logs.

-   Database indexes and constraints.

-   Supabase RLS.

-   Secure Edge Function authorization.

-   Tauri permission minimization and native bridge security.

-   Secret scanning.

-   Dependency hygiene and licensing review.

-   Error boundaries.

-   Loading/empty/success/failure/offline/permission-denied/partial-success
    states.

-   Custom 404 / 401 / 403 / 429 / 500 experiences.

-   Keyboard navigation and focus management.

-   Readable contrast and semantic labels.

-   Reduced motion.

-   Responsive desktop/tablet/mobile layouts.

-   SEO/metadata where relevant.

-   Performance budgets and lazy loading where useful.

-   Data export and deletion.

-   Privacy policy and Terms.

-   Cookie/consent preferences where applicable.

-   Support/contact path.

-   Backup/recovery and migration strategy.

-   Regression/integration/contract/data-integrity/user-journey/release-gate
    tests.

-   Monitoring and incident response.

-   Environment-variable documentation.

-   Deployment/runbook documentation.

-   Final security review before release.

## 24. Unresolved questions

-   Exact final pricing and regional pricing.

-   Exact Pro vs Elite entitlement matrix and what remains available to
    all users.

-   Final payment provider and billing architecture.

-   Final model/provider mix, free vs paid routing, and fallback policy.

-   Final local-vs-cloud split for wake word, speech recognition,
    vision, memory retrieval, and device control.

-   Wake-word engine and custom wake-word mechanism.

-   British voice provider/licensing and custom-voice architecture.

-   Cross-platform OS-control capability matrix.

-   Device pairing/trust protocol.

-   Persistent Cosmos database schema, vector/search strategy, ranking,
    retention/decay rules, and sync model.

-   Memory consent UX and per-memory controls.

-   Agents UI information architecture and advanced visibility.

-   Forge editor UX, publishing, moderation/governance, and versioning
    experience.

-   Widget collision/docking/resizing algorithm.

-   Dynamic Island behavior on each platform.

-   Gesture vocabulary and hardware support.

-   Vision permissions/camera privacy UX.

-   Final supported integration roadmap.

-   Kurdish/Arabic quality targets and complete RTL coverage.

-   Prayer-time source/provider and location/privacy handling.

-   Exact 23 themes.

-   Final legal/privacy wording and age/region compliance.

-   Release/distribution platform matrix and launch date.

## 25. Recommended final completion order

1.  Brain + message routing + provider routing

2.  Task/workflow/execution + verification/recovery

3.  Agents + registry + Forge

4.  Cosmos/memory + persistent storage

5.  Tools + permission/security/audit

6.  Chat + voice + wake word

7.  Computer/OS/browser control

8.  Workspace/widgets + Dynamic Island + gestures

9.  Vision + camera/screen understanding

10. Device Fabric + Continuity

11. Proactive/Morning Mode

12. Accounts/plans/billing/entitlements

13. Privacy/terms/data controls

14. Full UI/design-system/accessibility/error-state pass

15. Tauri/native hardening

16. End-to-end integration, security audit, performance, regression, and
    release gate

## 26. Source-of-truth rules for whoever continues HEY

-   Never assume a feature is implemented because its name exists in
    agents.js or featureCatalog.js.

-   Never call something "done" without a real end-to-end path and
    verification.

-   Never invent integrations, hardware support, provider access, or
    successful actions.

-   Preserve the calm, premium, minimal design and HEY's consistent
    character.

-   Preserve safety/security boundaries even for founders/admins.

-   Treat server-authenticated identity, plan, entitlements, and
    permissions as authoritative.

-   Make high-impact execution permissioned, auditable, cancellable, and
    verifiable.

-   Keep agent definitions modular, scoped, testable, observable, and
    independently verifiable.

-   Build Cosmos as one coherent memory architecture.

-   Do not rewrite files merely to make progress look substantial.
    Change files because the subsystem architecture materially advances.

-   Release quality is measured by real user journeys, security,
    accessibility, performance, and integration---not by file count.

## 27. Final product definition

HEY is a personal AI operating layer: one persistent intelligence with a
distinct character, shared memory, specialized agents, secure tools,
proactive behavior, voice, computer control, a living workspace, device
continuity, vision, and a Forge that lets users extend what it can do.
The product should feel calm and simple on the surface while hiding
serious orchestration underneath. Advanced users can inspect and govern
the complexity; ordinary users should simply experience an assistant
that understands, acts, remembers, adapts, and gets out of the way.

Central promise: tell HEY what you seek, and it helps turn that intent
into verified action across your information, software, devices, and
workspace---within explicit permissions and real technical limits.

Signature: "Tell me what you seek. I'll help you make it so."

------------------------------------------------------------------------

# HEY TRANSFER V2 --- RECOVERED HISTORY + COMPETITIVE EXPANSION

> This section extends V1 with details recovered from older HEY
> discussions that were omitted or under-specified. It also adds a
> separate competitive feature backlog.\
> Statuses: **IMPLEMENTED**, **VERIFIED**, **PARTIAL**, **PLANNED**,
> **HISTORICAL**, **REJECTED**, **UNRESOLVED**, **PROPOSED-V2**.\
> **PROPOSED-V2 means a new competitive recommendation, not a prior
> decision and not implemented.**

## 33. Recovered product philosophy

-   **PLANNED:** HEY is a new human--intelligence relationship:
    companion, personal intelligence system, living ecosystem, and
    personal operating system for thinking, creating, learning and
    getting things done.
-   **PLANNED:** HEY helps users think, learn, create, organize,
    explore, build, remember, improve and act.
-   **PLANNED:** Historical positioning included "companion that's
    always there," "second mind that grows with you," and the feeling "I
    am never starting from zero."
-   **PLANNED:** Linux-like philosophy: customizable, extensible,
    user-owned, deeply adaptable; users should feel "I built this AI" /
    "This is my HEY."
-   **HISTORICAL:** Ecosystem ideas included HEY App, Studio, Academy,
    Community and future Hardware.
-   **PLANNED:** HEY must feel coherent rather than like hundreds of
    disconnected features.

## 34. Observatory, Cosmos and living-world metaphors

-   **HISTORICAL/POSSIBLE FUTURE:** Observatory interface/world.
-   **HISTORICAL:** Cosmos metaphor: memories = stars, projects =
    planets, interests = galaxies.
-   **HISTORICAL:** Memory Seeds: seed → plant → tree → forest as
    knowledge becomes richer.
-   **HISTORICAL/POSSIBLE FUTURE:** Forge as a workshop for apps,
    documents, designs, agents and workflows---not only agent
    definitions.
-   **PLANNED:** Nature + intelligence + discovery; layered depth,
    floating cards, living environments, signature motion/sound.
-   **HISTORICAL:** Seed/star/orbit motifs.
-   **UNRESOLVED:** Whether these metaphors return as optional
    visualizations/themes/onboarding or remain archived.

## 35. Recovered response/personality modes

-   **PLANNED:** One core HEY identity with contextual communication
    styles.
-   Discussed modes: Quick, Standard, Deep Dive, Mentor, Strategist,
    Research, Creative, Emotional Support, Crisis, Teacher, Debate,
    Execution.
-   Discussed contextual personas/stances: mentor, explorer, comedian,
    brother-like familiarity, crisis support.
-   **PLANNED:** HEY selects style silently based on intent, complexity,
    knowledge and situation.
-   **PLANNED:** Push back when the user is wrong; do not blindly agree.
-   **PLANNED:** Spoken answers strip Markdown/symbol clutter.
-   **HISTORICAL OWNER PREFERENCE:** Early HEY was told to address the
    owner as "CEO." Do not make this a universal default.

## 36. Voice activation details recovered

-   **HISTORICAL:** Original wake phrase "Wake up."
-   **LATER PLANNED:** customizable wake word with "HEY" as desired
    default.
-   **PLANNED:** selectable activation including push-to-talk and wake
    word.
-   **HISTORICAL:** Web Speech API prototype; listening continued after
    first click.
-   **PLANNED:** local wake-word processing where possible.
-   **PLANNED:** voice speed/pitch settings, first-launch language
    selection, English/Kurdish/Arabic plus broader multilingual support.
-   **PLANNED:** natural barge-in/interruption while HEY is speaking.
-   **PLANNED:** multiple primary voices, one selected at a time; custom
    voice/personality where technically/legal feasible.

## 37. Recovered real-time awareness

-   **PLANNED:** accurate live clock/date.
-   **PLANNED:** weather (historically OpenWeatherMap).
-   **PLANNED:** prayer times/countdown (historically Aladhan API).
-   **PLANNED:** prayer reminder 10 minutes before each prayer.
-   **HISTORICAL/OPTIONAL:** prayer-time interruption behavior.
-   **PLANNED:** live news headlines.
-   **HISTORICAL:** Quest launch countdown; "Matrix escape" countdown.
-   **HISTORICAL/OPTIONAL:** daily quote.
-   **PLANNED/USER-CONFIGURED:** daily Quran verse.
-   **PLANNED:** city/location settings for weather/prayer with
    privacy-conscious handling.

## 38. Recovered life/personal-intelligence features

-   **PLANNED:** Idea Vault.
-   **PLANNED:** People Memory, subject to memory/privacy controls.
-   **PLANNED:** mood check-in/tracker.
-   **PLANNED:** sleep tracker.
-   **PLANNED:** financial/expense tracker.
-   **PLANNED:** Build Journal / automatic project-progress journal.
-   **PLANNED:** Morning Briefing.
-   **PLANNED:** Evening Summary.
-   **PLANNED:** Weekly Honest Mirror every Sunday.
-   **PLANNED:** The One Thing --- daily highest priority.
-   **PLANNED:** Focus Mode + timer.
-   **PLANNED:** Body Double Mode.
-   **PLANNED:** reminders/callbacks.
-   **HISTORICAL/OPTIONAL:** inactivity check after \~45 minutes.
-   **PLANNED:** compare user with their own past progress, not other
    people.
-   **PLANNED:** non-negotiables tracker.
-   **PLANNED:** identity-shift coaching toward the user's chosen
    goals/values.
-   **PLANNED:** Devil's Advocate Mode.
-   **PLANNED:** Legacy Builder recurring reflection.
-   **PLANNED:** Fear Inventory.
-   **PLANNED:** Regret Minimizer / structured decision reflection.
-   **PLANNED:** adaptive learning/testing for focus, memory and
    subjects; avoid unvalidated "IQ" claims.
-   **HISTORICAL/SENSITIVE:** "Death clock" was mentioned. Do not make
    it a default feature; it requires safety/product review.

## 39. Recovered research/web/content features

-   **PLANNED:** web search.
-   **PLANNED:** open websites by voice.
-   **PLANNED:** TikTok/YouTube/video/link review where access permits.
-   **PLANNED:** file/document upload including PDF, books and study
    material.
-   **PLANNED:** competitor-research tables.
-   **PLANNED:** trend reports.
-   **PLANNED:** Reddit/community summaries.
-   **PLANNED:** social-media analytics.
-   **PLANNED:** source verification, citations and uncertainty
    handling.

## 40. Recovered monitoring/digital wellbeing

-   **PLANNED:** app-usage awareness.
-   **PLANNED:** user-selected time tracking for TikTok, YouTube, gaming
    and apps.
-   **PLANNED:** water, movement and eye/rest reminders.
-   **REQUIREMENT:** sensing/monitoring is opt-in, visible and
    privacy-preserving---never silent surveillance.

## 41. Face, gesture and presence

-   **HISTORICAL:** MediaPipe face recognition; owner face could
    wake/unlock HEY; unknown face could hide/lock sensitive UI.
-   **HISTORICAL COPY:** "Hello Owner."
-   **PLANNED:** gesture control for volume, zoom, swipe/navigation,
    play/pause, widget movement, resizing, minimizing/maximizing and
    workspace navigation.
-   **HISTORICAL:** detailed hand-sign mappings existed in the old
    prototype phase.
-   **REQUIREMENT:** biometrics opt-in, securely handled and preferably
    local.
-   **UNRESOLVED:** final gesture vocabulary/platform/hardware matrix.

## 42. Projector / ambient mode

-   **HISTORICAL:** dedicated HY300 Projector Mode.
-   **HISTORICAL:** repositioned desk-projection layout and high
    contrast for projected surfaces.
-   **POSSIBLE FUTURE:** general Ambient Display Mode for projectors,
    TVs, walls and secondary displays.
-   **POSSIBLE FUTURE:** voice + gesture projected workspace.

## 43. Smart home

-   **PLANNED:** user-configured smart-home endpoints/integrations.
-   **HISTORICAL:** webhook-based commands.
-   **PLANNED:** supported lights, temperature, media and other devices.
-   **SECURITY:** locks/security devices require stronger
    authorization/confirmation.
-   **PLANNED:** endpoint configuration in Settings and device-health
    awareness.

## 44. Cross-device details

-   **PLANNED:** real-time sync (historically Supabase).
-   **PLANNED:** same conversation/context across devices.
-   **HISTORICAL ASPIRATION:** "pick up mid-sentence anywhere."
-   **PLANNED:** task migration, device roles/rules, shared memory with
    user-controlled sync, discovery, pairing, trust, health and handoff.
-   **PLANNED:** phone/tablet/laptop/TV/wearable surfaces complement one
    another.

## 45. Accessibility and high-impact assistance ideas

These were historically discussed and require rigorous
safety/privacy/reliability engineering.

-   **PLANNED:** blind/low-vision assistance using camera/screen
    description.
-   **PLANNED:** Student Tutor, including low-resource contexts.
-   **PLANNED:** elderly companion/support.
-   **PLANNED:** medication reminders.
-   **PLANNED/SENSITIVE:** mental-health support/pattern awareness; do
    not diagnose from casual behavior.
-   **PLANNED/SENSITIVE:** grief-support behavior.
-   **HISTORICAL/SAFETY-CRITICAL:** domestic-safety code-word alert
    concept; never fake emergency delivery and require dedicated safety
    design.
-   **PLANNED:** refugee navigation/information support.
-   **PLANNED:** farmer intelligence for reliable weather/crop/resource
    information.
-   **HISTORICAL/SAFETY-CRITICAL:** child-safety danger-sound detection;
    requires strict privacy/parental controls/local
    processing/reliability disclosure.
-   **REQUIREMENT:** never imply guaranteed emergency response.

## 46. UI history --- preserve conflicts

### Generation A --- cyan / Stark-like dashboard

-   **HISTORICAL:** cyan on black; spinning rings/audio visualizer.
-   Left: weather, prayer, countdowns. Right: quote, Quran, status.
-   Projector mode and information-dense dashboard.

### Generation B --- purple/white plasma

-   **HISTORICAL:** deep dark \~#0a0008; subtle purple atmosphere.
-   Organic topographic contour lines \~rgba(255,255,255,0.04).
-   Canvas-drawn irregular white/purple plasma ring + particles.
-   Ring breathes slowly idle; brighter/faster/more particles while
    speaking.
-   White Orbitron HEY text in center.
-   No panels/status clutter: pure voice interface.
-   This generation explicitly chose purple/white rather than
    cyan/green.
-   Prototype was reported rebuilt in index.html/style.css/script.js
    using Gemini 2.0 Flash.

### Generation C --- later/current refined direction

-   **CURRENT DIRECTION:** premium minimalism, ocean/near-black
    surfaces, restrained cyan/arctic blue, glass depth, natural
    widget/content colors.
-   Living adaptive workspace rather than a fixed dashboard or single
    voice ring.
-   Futuristic intensity is customizable.
-   **UNRESOLVED:** exact list of 23 themes.

## 47. Prototype/provider history

-   **HISTORICAL:** three-file prototype: index.html, style.css,
    script.js.
-   **HISTORICAL:** Gemini 2.0 Flash phase.
-   **HISTORICAL:** OpenRouter free-model phase; discussed model
    `meta-llama/llama-3.1-8b-instruct:free`.
-   **HISTORICAL:** later Claude aspiration.
-   **HISTORICAL:** OpenAI-style `{role, content}` history and
    `data.choices[0].message.content` parsing.
-   **HISTORICAL:** JSON-style tool calling.
-   **HISTORICAL:** localStorage Idea Vault/prototype state.
-   **HISTORICAL:** API/wake activation debugging failures.
-   **PROCESS RULE:** exact targeted changes + verification beat broad
    random rewrites.

## 48. Recovered privacy/ownership principles

-   **PLANNED:** user-owned philosophy.
-   **PLANNED:** no selling user data.
-   **PLANNED:** avoid ad-driven product incentives.
-   **PLANNED:** transparent, controllable memory.
-   **PLANNED:** local-first processing where useful for privacy,
    latency and offline capability.
-   **PLANNED:** encryption for sensitive stored/synced data.
-   **PLANNED:** granular permissions; no giant "allow everything"
    switch.
-   **PLANNED:** clear permission explanations, revocation and
    high-impact action history.
-   **PLANNED:** export/delete/sync controls.
-   **PLANNED:** camera/mic/screen/biometrics/app-usage sensing must be
    explicit and visible.

## 49. Historical launch/business context

-   **HISTORICAL:** an older plan mentioned HEY/Quest launch around
    August 2026.
-   **HISTORICAL:** later HEY roadmap mentioned \~15 September for web
    app, agents, Forge, Cosmos and monetization.
-   **HISTORICAL:** early revenue expectations were revised at one point
    to roughly \$200--\$500 first month rather than assuming thousands.
-   **HISTORICAL:** later \$3k/month and \$10k/month ambitions were
    discussed.
-   These are goals/history, not evidence that launches/revenue
    happened.

## 50. Adjacent ecosystem ideas

-   **HISTORICAL:** Quest --- gamified-life product with AI daily
    quests, proof upload, XP/streaks/ranks.
-   **HISTORICAL/UNRESOLVED:** Ultra --- broad integrated app concept.
-   **HISTORICAL/UNRESOLVED:** Dream World / Dream World Builder ---
    prompts into interactive/playable worlds.
-   **RULE:** do not silently merge Quest/Ultra/Dream World into HEY
    unless intentionally designed as HEY modules/integrations.

# 51. PROPOSED-V2 competitive feature backlog

The features below are **new recommendations** intended to push HEY
ahead of chat-only assistants. They are not prior approvals.

### 51.1 Personal Intelligence Graph

-   Connect goals, projects, people, files, tasks, conversations,
    decisions, habits, devices and preferences.
-   "Why HEY knows this" provenance.
-   Decision ledger with rationale/outcome.
-   Contradiction detection before overwriting memory.
-   Memory confidence/freshness.
-   Project memory boundaries.

### 51.2 Zero-setup Project Mode

-   Drop in repo/folder/docs → automatic project map.
-   Detect architecture, tasks, blockers, recent changes and missing
    docs.
-   Persistent project briefing.
-   "Continue where we left off."
-   Project health: tests/build/security/dependencies/tasks/agents.

### 51.3 Universal Action Preview + Receipts

-   Preview target, action, effect, permission and reversibility before
    consequential execution.
-   Dry-run workflows.
-   Rollback where supported.
-   Action receipts: what changed, where, when, verification and undo.

### 51.4 Explainable Autonomy

-   Per-domain autonomy, not one global switch.
-   "Never do automatically" and scoped "always allow" rules.
-   Autonomy simulator.
-   Trust grows only through explicit user choices.

### 51.5 Personal Command Layer

-   Teach phrases like "school mode," "ship it," "clean desk."
-   Trigger verified workflows through voice/text/gesture/schedule.
-   Inspectable/editable command definitions.
-   Share command packs without private data.

### 51.6 Context Capsules

-   Portable selected context: files, goals, constraints, decisions,
    memories, tools.
-   Safe collaboration without exposing all Cosmos.
-   Revocable/time-limited sharing.

### 51.7 HEY Replay

-   Human-readable mission timeline: actions, tool calls, retries,
    failures, verification.
-   Useful for trust/debugging.
-   Show action rationale/provenance, not hidden chain-of-thought.

### 51.8 Agent Teams

-   Build Team, Research Team, Launch Team, Study Team.
-   Team templates: agents, permissions, budgets, quality gates,
    completion criteria.
-   Independent verifier.
-   Health metrics: latency, failures, cost, reliability.

### 51.9 Forge Library / Marketplace

-   Public/private templates.
-   Verified publishers.
-   Permission manifest before installation.
-   Safety checks, version pinning, rollback.
-   Reliability-focused ratings.
-   Templates never self-grant permissions.

### 51.10 Capability Packs

-   Coding, School, Creator, Business, Research, Home, Accessibility
    packs.
-   Bundle agents/widgets/workflows/settings/integrations.
-   Clean uninstall; user data separate from pack code.

### 51.11 Offline HEY Core

-   Offline wake word, reminders, local search, selected memory
    retrieval and device commands.
-   Graceful degradation.
-   Clear local/cloud indicator.
-   Queue cloud actions only with consent.

### 51.12 Provider Independence

-   Route by quality, latency, cost and privacy.
-   User modes: local/private/cheap/fast/best quality.
-   Automatic fallback.
-   Provider health dashboard.

### 51.13 Semantic Workspace

-   Widgets understand relationships.
-   Drag file → Research source.
-   Drag result → Task.
-   Drag project/person → Cosmos context.
-   Reusable spatial workspace groups.
-   HEY may suggest layout but user controls it.

### 51.14 Live Artifacts

-   Persistent plans, dashboards, trackers, briefs, tables, documents,
    checklists and mini-apps.
-   Update from approved data sources.
-   Show sources/last update.
-   Pin into workspace.

### 51.15 Universal Search / Ask Everything

-   Search approved files, Cosmos, chats, tasks, calendar, apps and
    devices.
-   Natural-language retrieval.
-   Explain source/access scope.
-   Local index where practical.

### 51.16 Ambient Intelligence

-   Optional awareness of active app/project/meeting state.
-   Presence states: available, focus, presenting, quiet, away.
-   Proactivity only above a usefulness threshold.
-   Visible sensing indicators.
-   Prefer local processing.

### 51.17 Automation Recorder

-   User performs routine once; HEY proposes automation.
-   Review/edit before enable.
-   Generalize variables.
-   Test mode + rollback.

### 51.18 Follow Me

-   Move active HEY session between devices.
-   Transfer widget/task context, not just chat.
-   Split audio/visual surfaces.
-   Never show private context on untrusted displays.

### 51.19 Multi-surface orchestration

-   Tablet control surface + desktop workspace + TV/projector
    presentation + phone private confirmation.
-   HEY suggests best surface; user overrides.
-   Sensitive approvals route to trusted personal device.

### 51.20 Personal API / extensions

-   Scoped user webhooks/APIs.
-   Narrow expiring capability tokens.
-   Advanced developer console.
-   External-call audit, rate limits and revocation.

### 51.21 Local File Intelligence

-   Semantic file search.
-   Duplicate detection.
-   Storage analysis.
-   Project-aware organization.
-   Safe cleanup preview.
-   Version/rollback integration where supported.

### 51.22 Screen Copilot modes

-   **Guide:** instructions only.
-   **Assist:** confirm actions individually.
-   **Act:** scoped autonomous execution.
-   Screen explanation/highlighting without forcing takeover.

### 51.23 "What Changed?" intelligence

-   Summarize meaningful project/file/task/service changes since last
    visit.
-   Prioritize goal-relevant changes.
-   Link claims to source/event.

### 51.24 Decision Mode

-   Objectives, constraints, alternatives, tradeoffs, unknowns,
    recommendation.
-   Save rationale to Cosmos.
-   Later compare predicted vs actual outcome.

### 51.25 Learning Mode

-   Learner model from explicit goals/performance.
-   Spaced repetition, retrieval practice, quizzes, adaptive
    explanations.
-   "Teach me, don't answer for me."
-   Study workspace.
-   No fake psychometric claims.

### 51.26 Creator Mode

-   Research → outline → draft → asset plan → publish checklist.
-   Brand memory for tone/fonts/rules/banned phrases.
-   Multi-format repurposing.
-   Provenance for claims/assets.

### 51.27 Business Command Center

-   Goals, tasks, launch milestones, research, customer feedback,
    finances, experiments.
-   Weekly operator briefing.
-   Experiment ledger: hypothesis → action → metric → result.
-   Never fabricate analytics.

### 51.28 Private Family / Team Spaces

-   Separate shared memory/permissions/agents.
-   Personal Cosmos stays private unless shared.
-   Role-based access.
-   Shared workflows without exposing private conversations.

### 51.29 HEY Trust Center

-   Active permissions.
-   Connections/devices.
-   Sensitive-action history.
-   Memory categories.
-   Local vs cloud processing.
-   Agent/template permissions.
-   Security alerts.
-   "Why did HEY do this?"
-   Revoke-all-connections control.

### 51.30 Privacy Modes

-   Local Mode.
-   Private Session (no long-term Cosmos write).
-   Sensitive Screen (temporarily disable screen/camera memory capture).
-   Guest Mode (guest interactions don't contaminate personal memory).

### 51.31 Time Machine / snapshots

-   Save/restore workspace/project snapshots.
-   Restore layout, artifacts, task state and selected context.
-   Compare snapshots.
-   Never silently roll back external systems.

### 51.32 Smart notification compression

-   Bundle low-priority notifications.
-   Natural-language interruption rules.
-   Contextual urgency without engagement manipulation.
-   Notification provenance.

### 51.33 Goal-to-system generation

-   Goal → milestones + tasks + reviews + agents + widgets + reminders +
    metrics.
-   User approves before creation.
-   System adapts with progress.

### 51.34 HEY Skills

-   Teach repeatable process in natural language.
-   Convert to versioned skill with parameters, permissions and tests.
-   Skills remain inspectable.
-   Forge improvements are versioned, not silent mutation.

### 51.35 Universal Undo

-   Prefer reversible actions.
-   Trash/versioning over destructive deletion where supported.
-   Undo history in mission receipt/Dynamic Island.

### 51.36 Automation reliability

-   Workflow health from recent runs.
-   Detect broken integrations.
-   Pause repeatedly failing/unsafe automation for review.
-   Separate model confidence from verified execution success.

### 51.37 Adaptive performance

-   Detect device capability.
-   Lightweight mode for older hardware.
-   Reduce animation/vision/local-model load when needed.
-   Battery/thermal awareness.
-   Cloud offload only when permitted.

### 51.38 Connectionless fallback UX

-   Explain exactly what still works offline.
-   Local actions/cached data/approved queueing.
-   Never collapse into a useless generic error.

### 51.39 Accessibility-first modes

-   Screen-reader optimized mode.
-   High contrast/large targets.
-   Voice-only navigation.
-   Reduced cognitive-load layout.
-   Voice captions/transcripts.
-   Complete keyboard operation.
-   Haptic/visual confirmations where supported.

### 51.40 Transparent memory inbox

-   Candidate memories can be approved/edited/pinned/expired/rejected.
-   "Never remember this category."
-   Stricter defaults for sensitive categories.
-   Provenance and last-use visibility.

### 51.41 Context Firewall

-   Prevent project/account/workspace context leakage.
-   Minimum necessary context per tool/agent.
-   External integrations never receive unrelated Cosmos data.

### 51.42 Prompt-injection shield

-   Web/document instructions are untrusted content by default.
-   Separate user commands from page content.
-   External content cannot modify permission policy.
-   Confirmation for suspicious privilege-changing actions.

### 51.43 Data portability

-   Export/import Cosmos, agents, skills, workflows, preferences and
    layouts.
-   Documented formats where feasible.
-   Selective export.
-   Encrypted backups.

### 51.44 HEY self-diagnostics

-   Test providers, mic, camera, permissions, database, Tauri bridge,
    integrations and agent registry.
-   Friendly user explanation + deeper admin logs.
-   Privacy-scrubbed diagnostic bundle.

### 51.45 Feature discovery without clutter

-   Contextual command palette / "What can HEY do here?"
-   Relevant feature suggestions only.
-   No giant toolbar.
-   Progressive disclosure.
-   Animated micro-tutorials.

## 52. Competitive moat priorities

1.  Persistent private **Cosmos** with provenance, contradiction
    handling and control.
2.  Real computer/device **action** with preview, verification, undo and
    receipts.
3.  One intelligence across voice, chat, workspace, agents and devices.
4.  **Forge + Skills + Agent Teams** for user-extensible capability.
5.  Living **semantic workspace**, not chat-only UI.
6.  Cross-device continuity that moves active context, not merely chat
    history.
7.  Trust Center + explainable autonomy + Context Firewall.
8.  Local-first/offline/privacy modes where hardware permits.
9.  A consistent HEY **soul** across every surface.
10. Reliability as a feature: never fake capability; verify real
    outcomes.

## 53. V2 status rules

-   Historical does not mean current.
-   Proposed-V2 does not mean approved or implemented.
-   Later explicit user decisions override earlier conflicting ones
    unless the user revives the old idea.
-   Preserve historical conflicts so future developers understand the
    evolution.
-   Never call a feature done without an end-to-end path and
    verification.
-   Never build mock UI that falsely implies a capability works.
-   Every sensing/control feature needs permission, visibility,
    revocation and failure UX.
-   Every agent/tool/workflow needs scope, validation, observability and
    security.
-   Competitive advantage should come from coherence, trust, continuity,
    execution quality and user ownership---not raw feature count.

## 54. Expanded final definition

HEY now has a preserved vision spanning **identity, soul, Brain,
response modes, chat, voice, wake word, proactive intelligence, Cosmos,
agents, Forge, skills/workflows, research, files, screen awareness,
computer/browser control, vision, gestures, face/presence, widgets,
semantic workspace, Dynamic Island, real-time awareness,
prayer/religious utilities, personal productivity, reflection, learning,
accessibility, smart home, projector/ambient surfaces, cross-device
continuity, privacy, security, accounts/plans/billing, provider routing,
Supabase, Tauri, native desktop, launch history, marketing, prototype
history, and the competitive expansion above.**

The surface should still feel simple. Users should not feel as though
they are operating hundreds of features. HEY should understand intent,
remember what matters, bring forward the right capability, act only with
appropriate authority, verify the result, and get out of the way.

> **Tell me what you seek. I'll help you make it so.**


# APPENDIX B — PRIOR COMPLETE CAPABILITY CATALOG (ARCHIVE)

**Archive rule:** Preserve every historical capability and the earlier 200-feature catalog.  
**Conflict rule:** HEY V1 is now the ultimate vision; older “future/long-term” labels do not automatically defer a capability.

# HEY — COMPLETE CAPABILITY CATALOG
## Everything HEY can, should, or may eventually be able to do

**Document type:** Master capability specification  
**Purpose:** Describe HEY at the capability level, including tiny sub-capabilities, controls, customization, background behavior, permissions, offline behavior, failure states, implementation status, and new capabilities that were never explicitly discussed before.

---

## 0. How to read this document

This document separates three kinds of truth:

- **SOURCE-DERIVED** — directly discussed in HEY project history.
- **IMPLEMENTED / VERIFIED / PARTIAL** — based on retained implementation history, not marketing claims.
- **PROPOSED-CAPABILITY** — added here because it logically strengthens HEY, even if never previously discussed.

Status vocabulary:

- `VERIFIED` — retained history says the capability passed a real test/check.
- `IMPLEMENTED` — code or prototype behavior was reported implemented.
- `PARTIAL` — some foundation exists, but the end-to-end production capability is not proven.
- `PLANNED` — explicitly wanted for HEY.
- `HISTORICAL` — discussed in an older direction, even if later changed.
- `CHANGED` — later direction superseded an earlier one.
- `REJECTED` — explicitly not wanted.
- `UNRESOLVED` — exact product/technical decision remains open.
- `PROPOSED-CAPABILITY` — new recommendation in this document.

**Important:** No item marked `PLANNED`, `HISTORICAL`, `UNRESOLVED`, or `PROPOSED-CAPABILITY` should be presented to users as already working.

---

# 1. Capability Runtime Model

Every capability should declare where it can run.

### Runtime states

**F0 — Foreground only**  
The full HEY window/page must be open and active.

**F1 — Open but unfocused**  
HEY is open, but another app/window is in front.

**F2 — Minimized**  
The main HEY window is minimized but its native process is still running.

**F3 — Main window closed, HEY helper still running**  
A tray/menu-bar/background helper remains alive. This is what enables a true “HEY is closed but still there” experience on desktop.

**F4 — Device locked**  
The computer/phone is locked. Only OS-permitted background functionality may continue.

**F5 — App process terminated**  
No local HEY process is running. Only server-side/cloud tasks, push notifications, and OS-scheduled jobs can continue.

**F6 — Offline**  
No internet connection. Only local/on-device features can continue.

**F7 — Other trusted device active**  
The current device is unavailable, but another paired HEY device or server workflow can continue.

### Core background rule

A browser tab alone cannot provide the full closed-app experience reliably. The long-term HEY design therefore needs a native/background layer, consistent with the retained Tauri desktop direction, plus OS notifications and server-side automation where appropriate.

### Capabilities that SHOULD be able to continue when the main window is closed

Subject to permission and platform support:

- wake-word detection through a native helper
- reminders
- alarms/timers
- scheduled briefings
- server-side research jobs
- server-side workflow jobs
- downloads/uploads owned by a background worker
- cloud file processing
- notification delivery
- calendar/event monitoring
- condition monitoring
- device-health checks
- smart-home routines
- media playback controls
- selected cross-device handoffs
- long-running code/build/research missions
- Dynamic Island / mini-widget / tray UI
- background sync
- Cosmos synchronization
- agent task execution that does not require visual foreground interaction
- server-side connected-app actions if authorized
- approved automations
- cloud image generation
- cloud video generation
- cloud rendering
- scheduled reports

### Capabilities that SHOULD NOT silently remain active when HEY is closed

Unless the user explicitly enables a visible background mode:

- camera capture
- screen recording/continuous screen capture
- face recognition
- gesture-camera tracking
- continuous microphone recording beyond wake-word/local speech trigger needs
- biometric analysis
- sensitive clipboard monitoring
- unrestricted keystroke monitoring
- background terminal commands with no mission context
- high-risk device control
- hidden location tracking

---

# 2. Core Conversation and Reasoning

## 2.1 Text conversation
**Status:** `PLANNED / PARTIAL`

HEY can receive text, understand intent, answer questions, generate structured output, ask clarifying questions only when necessary, and continue multi-turn context.

**Small capabilities:**
- short answer
- long explanation
- comparison
- brainstorming
- summarization
- rewriting
- translation
- classification
- extraction
- planning
- step-by-step instruction
- decision support
- critique
- error explanation
- ideation
- tutoring
- research synthesis
- follow-up understanding
- reference resolution such as “that one,” “the previous file,” or “continue”
- structured JSON/output for internal tools
- tone adaptation
- uncertainty reporting
- asking only the minimum necessary question

**Customization:**
- verbosity
- tone
- directness
- humor
- technical depth
- language
- formatting preference
- whether HEY uses tables, bullets, prose, or concise command-style replies

**Background:** conversation itself requires an interaction surface, but HEY may continue a mission after the user leaves if that mission was explicitly handed off.

## 2.2 HEY personality / soul
**Status:** `PLANNED`

HEY should maintain one recognizable identity across voice, chat, widgets, agents, devices, and modes.

Behavioral traits:
- calm
- intelligent
- curious
- optimistic
- warm
- direct
- capable of disagreement
- able to apologize when wrong
- able to celebrate wins
- knows when to be silent
- knows when a short answer is better
- culturally aware
- avoids repetitive canned phrases
- avoids fake profundity
- does not pretend to be human
- may feel brother-like, mentor-like, or sensei-like without lying about what it is

## 2.3 Response modes
**Status:** `PLANNED / HISTORICAL`

Discussed or proposed modes include:
- Quick
- Standard
- Deep Dive
- Mentor
- Strategist
- Research
- Creative
- Teacher
- Debate
- Execution
- Emotional Support
- Crisis-support-safe mode
- Late Night Soft Mode
- Morning Sharp Mode
- Motivational Mode
- Devil’s Advocate
- Personal Board of Directors
- Silence / Just Be Present
- culturally fluent communication
- professional communication for non-native speakers
- dyslexia-friendly learning mode

`HISTORICAL`: named-person-inspired modes such as “Kobe discipline,” “Elon vision,” and “Scholar wisdom” were discussed. A better production implementation is to turn these into non-impersonating style archetypes such as Discipline, Visionary, Scholar, Commander, Explorer, etc.

---

# 3. Voice System

## 3.1 Speech recognition
**Status:** `IMPLEMENTED historically / needs current production verification`

Capabilities:
- microphone input
- live speech-to-text
- end-of-utterance detection
- restart listening after response
- language detection
- accent tolerance
- interruption
- mute/unmute
- input-level meter
- transcript preview
- correction of likely recognition errors using context
- push-to-talk
- hotkey-to-talk
- noise gate
- optional local recognition

## 3.2 Wake word
**Status:** `PLANNED / historical prototype existed`

Historical phrase: **“Wake up.”**  
Later direction: customizable wake word with **HEY** as the desired default identity.

Settings:
- wake word on/off
- push-to-talk alternative
- hold-to-talk
- keyboard shortcut
- click activation
- wake sensitivity
- false-positive protection
- per-device enablement
- quiet hours
- lock-screen behavior
- accepted speakers if voice recognition exists

**Background behavior:** should work in `F2/F3`, and potentially `F4` where the OS allows microphone background privileges. It cannot be promised from a normal browser tab.

## 3.3 Speech synthesis
**Status:** `PLANNED`

Desired primary direction:
- deep
- calm
- polished
- British male voice

Features:
- multiple voice choices
- one selected primary voice
- speaking speed
- pitch where supported
- emotion/expressiveness
- pronunciation dictionary
- language-specific voice switching
- volume
- whisper/quiet mode
- late-night softer delivery
- accessibility speech rate
- speech queue
- stop/pause/resume
- barge-in: user can interrupt HEY while speaking
- strip Markdown/symbol noise before reading aloud

## 3.4 Voice personality
**Status:** `PLANNED`

Voice can vary slightly by context without becoming a different assistant:
- sharper in morning mode
- softer late at night
- concise during computer control
- slower during tutoring
- more formal in professional tasks
- calmer in stressful contexts

---

# 4. Image Understanding

## 4.1 General image analysis
**Status:** `PLANNED`

HEY should be able to:
- describe an image
- identify visible objects
- explain a diagram
- read visible text
- interpret screenshots
- compare images
- identify layout problems
- analyze charts
- inspect UI screenshots
- find visual inconsistencies
- answer questions about a user-supplied image
- extract structured information from images
- detect approximate colors
- explain photography/composition
- help choose between visual variants
- identify likely visual hierarchy
- inspect product mockups
- inspect generated images for obvious defects

## 4.2 Screenshot understanding
**Status:** `PLANNED`

Inputs:
- manual screenshot
- HEY screenshot command
- selected region
- active window
- full display where permitted

Outputs:
- explanation
- UI guidance
- next-click suggestion
- error identification
- text extraction
- computer-control target map
- accessibility description

## 4.3 Document vision
**Status:** `PLANNED`

HEY can inspect:
- scanned pages
- forms
- diagrams
- handwritten material where recognition permits
- tables
- charts
- page layout
- mixed text/image PDFs

---

# 5. Image Generation

## 5.1 Text-to-image
**Status:** `PLANNED historically / not proven implemented`

Examples:
- “HEY, generate a futuristic product poster.”
- “Make a dark cyan hero image for the HEY landing page.”
- “Generate four logo directions.”
- “Create an illustration of this concept.”

Controls:
- prompt
- negative constraints
- aspect ratio
- resolution
- transparent background
- number of variations
- style
- camera/composition
- lighting
- color palette
- fidelity/detail
- seed/variation lock where provider supports it
- brand palette
- text-safe areas
- visual consistency with references

## 5.2 Voice-to-image
**Status:** `PLANNED`

Same as text-to-image, triggered through natural speech.

## 5.3 Image variations
**Status:** `PROPOSED-CAPABILITY`

- generate similar versions
- preserve composition
- change color palette
- change environment
- change lighting
- change crop
- make more/less realistic
- produce platform-specific sizes
- generate A/B variants

## 5.4 Reference-image generation
**Status:** `PROPOSED-CAPABILITY`

Use one or more user-authorized images to guide:
- style
- composition
- character/object consistency
- brand language
- layout

## 5.5 Transparent assets
**Status:** `PROPOSED-CAPABILITY`

Generate:
- icons
- UI assets
- product cutouts
- stickers
- logos
- overlays
- decorative objects
with transparent backgrounds when provider support exists.

## 5.6 Batch generation
**Status:** `PROPOSED-CAPABILITY`

Generate many variants as a background task:
- ad sizes
- thumbnails
- icons
- campaign variants
- localization variants
- product mockups

**Background behavior:** the job can continue in `F2/F3/F5` if generation is server-side. Results notify the user when ready.

---

# 6. Image Editing

## 6.1 Basic adjustments
**Status:** `PLANNED historically`

HEY should support commands such as:
- change contrast
- brightness
- exposure
- saturation
- temperature
- tint
- sharpness
- blur
- shadows
- highlights
- black point
- white point
- grayscale
- color balance

Historical explicit example: **“HEY, change the contrast of that photo.”**

## 6.2 Geometry
**Status:** `PROPOSED-CAPABILITY`

- crop
- rotate
- flip
- resize
- straighten
- perspective correction
- canvas expansion
- aspect-ratio conversion

## 6.3 Object edits
**Status:** `PROPOSED-CAPABILITY`

- remove object
- add object
- replace object
- move object
- erase background
- replace background
- blur background
- remove distraction
- cleanup artifacts
- recolor selected object

## 6.4 Generative editing
**Status:** `PROPOSED-CAPABILITY`

- inpainting
- outpainting
- extend image edges
- restyle selected region
- preserve subject while changing environment
- change time of day/weather
- create alternate compositions

## 6.5 Quality repair
**Status:** `PROPOSED-CAPABILITY`

- upscale
- denoise
- deblur where possible
- compression cleanup
- color restoration
- old-photo cleanup
- sharpen text/UI screenshots where possible

## 6.6 Brand editing
**Status:** `PROPOSED-CAPABILITY`

- apply HEY/S&A brand palette
- add logo
- safe-area layout
- social-platform crops
- poster/thumbnail typography suggestions
- export multiple variants

---

# 7. Frame Generation and Storyboarding

## 7.1 Single-frame generation
**Status:** `PROPOSED-CAPABILITY`

HEY can generate a precise still frame for:
- product films
- storyboards
- app promos
- trailers
- ads
- UI concept videos

Controls:
- shot type
- focal-length feel
- subject
- environment
- time of day
- lighting
- aspect ratio
- camera height
- camera angle
- depth of field
- motion implication
- text-safe zones

## 7.2 Multi-frame storyboard
**Status:** `PROPOSED-CAPABILITY`

Generate a sequence:
1. opening frame
2. establishing shot
3. interaction
4. transition
5. feature close-up
6. result
7. closing brand frame

Each frame can carry:
- shot number
- duration
- camera direction
- dialogue/voiceover
- animation note
- visual effect
- transition
- sound cue

## 7.3 Character/product consistency
**Status:** `PROPOSED-CAPABILITY`

Maintain consistent:
- person/character
- device
- product
- clothing
- environment
- color grade
- brand details
across storyboard frames where the generation provider supports reference consistency.

## 7.4 Frame interpolation
**Status:** `PROPOSED-CAPABILITY`

Generate intermediate frames or smooth visual transitions between key frames where video/model tooling permits.

## 7.5 UI frame generation
**Status:** `PROPOSED-CAPABILITY`

Create frame-by-frame interface concepts:
- idle
- hover
- press
- loading
- success
- error
- expanded
- minimized
- drag
- gesture feedback

---

# 8. Video Understanding

## 8.1 Uploaded video analysis
**Status:** `PLANNED`

HEY can:
- summarize video
- identify chapters
- extract key moments
- explain scenes
- answer questions
- find specific moments
- create notes
- extract action items
- inspect UI recordings
- identify visual bugs from a screen recording
- create transcript where supported
- create captions
- identify repeated themes

## 8.2 Link analysis
**Status:** `PLANNED`

Historical target:
- TikTok links
- YouTube links

Subject to provider/platform access.

Outputs:
- summary
- main claims
- factual check
- useful ideas
- marketing analysis
- competitor analysis
- comments/community themes where accessible
- timestamped notes where supported

---

# 9. Video Generation

## 9.1 Text-to-video
**Status:** `PROPOSED-CAPABILITY`

Generate short clips from text prompts through connected generation providers.

## 9.2 Image-to-video
**Status:** `PROPOSED-CAPABILITY`

Animate:
- generated image
- product screenshot
- poster
- concept frame
- storyboard keyframe

## 9.3 Storyboard-to-video
**Status:** `PROPOSED-CAPABILITY`

HEY builds:
- shot sequence
- generation prompts
- transitions
- timing
- voiceover
- captions
- sound plan

and sends supported pieces to connected tools/providers.

## 9.4 Video editing
**Status:** `PROPOSED-CAPABILITY`

Potential actions:
- trim
- split
- reorder
- crop
- change speed
- stabilize where supported
- resize for social platforms
- captions
- subtitle translation
- remove silence
- create highlights
- add title cards
- select best clips
- generate B-roll
- color adjustments
- audio ducking
- voiceover insertion
- export presets

## 9.5 Background rendering
**Status:** `PROPOSED-CAPABILITY`

Long renders can continue in `F2/F3/F5` through a worker/cloud service. The main UI does not need to stay open.

---

# 10. Audio and Voice Media

## 10.1 Audio understanding
**Status:** `PROPOSED-CAPABILITY`

- transcribe audio
- summarize meeting/lecture
- speaker separation where supported
- detect silence
- identify action items
- translate speech
- create captions
- clean transcript

## 10.2 Audio cleanup
**Status:** `PROPOSED-CAPABILITY`

- noise reduction
- volume normalization
- trim silence
- clip splitting
- format conversion
- voice isolation where tooling allows

## 10.3 Voiceover production
**Status:** `PLANNED / PROPOSED-CAPABILITY`

- write narration
- synthesize narration with selected HEY/creator voice
- control pace
- pronunciation
- export audio
- align to video timeline

---

# 11. Documents and Files

## 11.1 Upload/read
**Status:** `PLANNED`

Supported categories should include:
- PDF
- DOCX
- TXT
- Markdown
- CSV
- spreadsheets
- slides
- images
- code
- archives where safe
- books/study materials

## 11.2 Document actions
**Status:** `PLANNED / PROPOSED-CAPABILITY`

- summarize
- outline
- answer questions
- extract facts
- compare documents
- translate
- simplify
- rewrite
- create study notes
- create flashcards
- identify missing sections
- identify contradictions
- extract tables
- build timeline
- extract tasks
- create new document
- convert format where supported
- redact selected data
- merge/split documents
- annotate
- generate citations

## 11.3 File management
**Status:** `PLANNED`

- search files
- open files
- rename
- move
- copy
- create folder
- organize folder
- detect duplicates
- inspect size
- find large files
- safe cleanup recommendations
- trash rather than hard-delete where possible
- restore/undo
- batch rename
- project-aware organization

Permissions:
- read vs write separate
- folder-scoped access
- destructive actions require confirmation
- protected/system locations require stronger permission

---

# 12. Coding and Software Engineering

## 12.1 Code understanding
**Status:** `PLANNED / architecture exists`

- explain code
- map repository
- search symbols
- identify architecture
- trace call flow
- find bug
- review code
- explain error logs
- dependency analysis
- security review
- performance review

## 12.2 Code creation
**Status:** `PLANNED`

- create component
- create API route
- create test
- create migration
- create documentation
- refactor
- generate configuration
- build scripts
- database queries

## 12.3 Agentic coding
**Status:** `PLANNED`

Mission:
Goal → inspect → plan → edit → run tests → observe → correct → verify → report.

## 12.4 Build/test control
**Status:** `PARTIAL architecture`

- run tests
- lint
- build
- type-check
- cargo check
- view failures
- retry after fix
- summarize failures

Background:
long-running builds/tests may continue in `F2/F3` if a native execution service remains alive.

---

# 13. Web and Research

## 13.1 Search
**Status:** `PLANNED`

- current web search
- multi-query research
- domain restriction
- recency
- source ranking
- citation
- compare sources
- conflicting evidence
- uncertainty reporting

## 13.2 Deep research
**Status:** `PLANNED`

- create research plan
- gather sources
- verify claims
- produce synthesis
- bibliography
- identify unanswered questions

## 13.3 Competitor intelligence
**Status:** `PLANNED`

- feature comparison
- pricing comparison
- positioning
- reviews
- weaknesses
- differentiators
- launch monitoring
- product updates

## 13.4 Background research mission
**Status:** `PROPOSED-CAPABILITY`

A user can say: “Research this and tell me when you have a complete answer.”

Server-side research can continue in `F5` if architecture supports durable tasks.

---

# 14. Browser Control

**Status:** `PLANNED`

Capabilities:
- open page
- navigate back/forward
- switch tabs
- create tab
- close tab
- search page
- click
- type
- select
- scroll
- download
- upload
- fill forms
- extract page information
- save page
- screenshot page
- open result in HEY widget
- follow links
- compare pages

Safety:
- payment
- account deletion
- sensitive forms
- irreversible submission
- legal acceptance
require stronger confirmation.

Prompt-injection shield:
webpage text is data, not authority.

---

# 15. Desktop / Computer Control

**Status:** `PLANNED / partial architecture`

Capabilities:
- move pointer
- click/double-click/right-click
- drag/drop
- type
- keyboard shortcut
- open application
- close application
- switch application
- minimize/maximize/restore
- move/resize window
- manage multi-monitor windows
- clipboard copy/paste
- take screenshot
- adjust supported system settings
- open file
- search file
- start terminal command
- monitor a long task
- cancel operation

Modes:
- Guide
- Assist
- Act

Background:
some OS automation can continue while the window is minimized, but actions requiring visual state should verify the current screen before acting.

---

# 16. Screen Awareness

**Status:** `PLANNED`

HEY can understand:
- active app
- visible controls
- error dialog
- selected text
- current website
- code editor state
- progress bar
- video controls
- form state
- file explorer
- system settings

Possible user commands:
- “What is this error?”
- “Click the download button.”
- “Explain this page.”
- “Help me finish this setup.”
- “Move this window to my other monitor.”

Privacy:
- explicit permission
- visible indicator
- pause button
- exclude apps/windows
- sensitive-screen mode
- no silent permanent recording

---

# 17. Camera

**Status:** `PLANNED`

Potential capabilities:
- analyze object
- scan document
- read text
- identify scene context
- help low-vision users understand surroundings
- detect gesture
- presence detection
- QR/barcode where supported
- product/room visual assistance

Not default:
- permanent recording
- hidden capture
- biometric storage

Background:
camera analysis should generally stop when HEY is fully closed unless a user explicitly enables a visible special mode.

---

# 18. Gesture Control

**Status:** `PLANNED / exact historical map unresolved`

Proposed production defaults:
- open palm → show HEY / overview
- open palm to fist → grab widget
- fist movement → move widget
- pinch → click/select
- pinch and move → precision drag
- two-hand spread → enlarge
- two-hand pinch → shrink
- swipe left/right → navigation
- swipe down → minimize
- swipe up → restore/expand
- two fingers → pause/resume
- point + pinch → target + activate
- raised hand → interrupt/stop HEY speech
- thumbs up → optional low-risk confirmation
- thumbs down → dismiss/reject
- both palms → leave manipulation/show overview

Customization:
- remap
- train custom gesture
- sensitivity
- hold duration
- handedness
- per-device profile
- per-workspace mapping
- accessibility alternatives
- conflict detection
- test mode

Gestures never override high-risk confirmation policy.

---

# 19. Workspace and Widgets

**Status:** `PLANNED`

Widget actions:
- create
- move
- resize
- overlap
- snap
- pin
- minimize
- maximize
- restore
- close
- group
- stack
- dock
- send behind/in front
- move to another workspace
- move to another display
- move to another device where supported

Widget types:
- chat
- web
- news
- weather
- prayer
- timer
- calendar
- task
- media
- download
- camera
- terminal
- code
- research
- document
- image
- video
- notes
- Cosmos
- agent monitor
- device monitor
- notification center

macOS-like red/yellow/green corner controls were a retained design choice for embedded widgets.

---

# 20. Dynamic Island / Always-On HEY

**Status:** `PLANNED`

Can show:
- listening
- thinking
- speaking
- muted
- timer
- reminder
- active task
- workflow
- agent activity
- download/upload
- research progress
- media
- call/meeting state
- error
- approval request
- background job
- device handoff
- battery/device warning
- prayer countdown
- next event

Can be:
- clicked
- tapped
- expanded
- collapsed
- moved where OS permits
- opened by gesture
- opened by voice

**Closed-app behavior:** this should survive the main window closing through a tray/menu-bar/native helper (`F3`).

Historical predecessor:
- always-on Chrome-extension-style floating widget
- expandable chat from the widget

---

# 21. Notifications, Reminders, Timers and Scheduling

## 21.1 Reminders
**Status:** `IMPLEMENTED historically in prototype / production status unverified`

- one-time
- recurring
- task-linked
- prayer-linked
- calendar-linked
- follow-up callback
- condition-based if server automation exists

## 21.2 Timers
**Status:** `PLANNED`

- countdown
- stopwatch
- focus timer
- Pomodoro
- multi-timer
- named timer
- timer group

## 21.3 Background operation
Timers/reminders should continue in `F2/F3/F4/F5` using OS scheduling and server push rather than depending on an open page.

---

# 22. Proactive HEY

**Status:** `PARTIAL architecture / PLANNED product`

Signals:
- overdue task
- upcoming task
- calendar event
- quiet hours
- routine
- prayer
- focus session
- prolonged inactivity if enabled
- project deadline
- device issue
- failed automation
- weather relevant to user plan
- selected news/topic
- user-defined condition

Controls:
- off
- minimal
- balanced
- proactive
- category toggles
- cooldown
- daily cap
- quiet hours
- “never interrupt me for X”
- “always notify me for Y”
- dismiss
- snooze
- explain why this appeared

---

# 23. Cosmos Memory

**Status:** `PARTIAL architecture`

Memory categories:
- conversation
- short-term
- important fact
- preference
- project
- goal
- people
- pattern
- routine
- decision
- relationship
- learned command
- device preference
- workspace layout
- pronunciation
- style preference
- historical event
- user-created pinned memory

Actions:
- remember
- forget
- edit
- pin
- expire
- search
- summarize
- connect
- rank
- deduplicate
- update
- detect contradiction
- show provenance
- export
- delete
- sync
- restrict scope

Background:
Cosmos sync/indexing may continue in `F3/F5`. Private Session should block long-term write.

---

# 24. Agent System

**Status:** `PARTIAL architecture`

HEY can internally delegate to specialized agents without fragmenting user experience.

Core families retained:
- orchestration
- memory
- research
- software engineering
- security
- computer/browser/files
- voice
- language
- design/product
- workspace
- proactive/productivity
- creative/business
- vision/device
- religious
- specialized domains
- QA/trust
- Forge
- agent infrastructure

Each agent needs:
- purpose
- input schema
- output schema
- allowed tools
- required permissions
- risk level
- model preference
- fallback
- verification
- timeout
- retry policy
- test cases
- health
- version
- auditability

Background:
agent missions that do not require user presence may continue in `F3/F5`.

---

# 25. Forge

**Status:** `PARTIAL architecture / PLANNED UX`

Forge can create:
- agent definitions
- workflows
- skills
- automation
- tool definitions/adapters
- workspace templates
- command packs
- possibly app/document/design artifacts

Forge flow:
request → search duplicates → design → permission manifest → tests → validation → preview → user approval → install → monitor → version/rollback.

Customization:
- private
- team
- selected audience
- public
- version
- permissions
- icon/name
- trigger
- output format
- model
- timeout
- retries
- verifier
- budget

---

# 26. Automations and Workflows

**Status:** `PARTIAL architecture`

Triggers:
- manual
- scheduled
- recurring
- event
- webhook
- device event
- file change
- calendar event
- reminder
- condition
- connected-service event

Steps:
- research
- generate
- transform
- notify
- open
- move
- save
- send where connected/authorized
- call agent
- call tool
- branch
- wait
- verify
- retry
- request approval

Background:
durable workflows should continue in `F5` if server-side.

---

# 27. Device Fabric / Continuity

**Status:** `PLANNED`

Devices:
- Windows PC
- macOS
- Linux
- Android
- iPhone/iPad
- tablet
- TV
- projector
- display
- camera
- wearable
- smart-home device
- vehicle interface where supported

Capabilities:
- discover
- pair
- trust
- revoke
- rename
- assign role
- sync selected context
- hand off active task
- hand off audio
- hand off widget
- route notification
- device health
- online/offline state
- battery
- connectivity
- capability map

---

# 28. Smart Home

**Status:** `PLANNED`

Possible supported actions:
- lights on/off
- brightness
- color
- scenes
- thermostat
- media
- selected plugs
- routines
- supported sensors

Higher-risk:
- locks
- garage
- alarm/security
need stronger confirmation.

Background:
scheduled smart-home workflows may run in `F5` through cloud integrations.

---

# 29. Projector and Ambient Display

**Status:** `HISTORICAL / POSSIBLE FUTURE`

Originally discussed around HY300 projector.

Capabilities:
- high-contrast layout
- large text
- reposition widgets
- desk projection
- ambient dashboard
- voice interaction
- gesture interaction
- presentation mode
- screen mirroring/status
- multi-surface control

---

# 30. Personal Productivity

Features discussed:
- Idea Vault
- People Memory
- Build Journal
- Focus Mode
- Body Double Mode
- The One Thing
- Weekly Honest Mirror
- Morning Briefing
- Evening Summary
- task management
- reminders
- callbacks
- routines
- time management
- peak-performance-hour protection
- time-waste pattern detection
- scattered-notes organizer
- abandoned-project restarter
- decision alignment
- value clarification
- non-negotiables
- goal coaching

---

# 31. Learning and Education

**Status:** `PLANNED`

Capabilities:
- tutor
- explain at chosen level
- quiz
- flashcards
- adaptive questions
- spaced repetition
- study plan
- exam revision
- source-based answer
- Learning Theater
- mind maps
- step-by-step visual breakdown
- story-based learning
- multilingual learning
- dyslexia-friendly layout
- audio-first learning
- accessibility adaptations
- “teach me, don’t answer for me”
- progress tracking

Historical ambitions included education access in low-resource/conflict-zone contexts.

---

# 32. Accessibility

**Status:** `PLANNED`

- blind/low-vision camera description
- screen-reader-friendly UI
- voice-only navigation
- large text
- high contrast
- reduced motion
- keyboard-only use
- dyslexia-friendly mode
- captions
- speech transcript
- sign-language interpretation as a long-term vision
- non-native professional communication support
- simplified language
- cognitive-load reduction
- customizable gesture alternatives

---

# 33. Language and Localization

**Status:** `PLANNED`

- English
- Kurdish
- Arabic
- RTL
- language detection
- translation
- pronunciation
- locale-aware dates/times
- locale-aware number/currency
- culturally aware humor
- culturally fluent responses
- code-switching
- multilingual voice/chat
- user-defined preferred language by context

---

# 34. Religious / Islamic Utilities

**Status:** `PLANNED / user-configured`

- prayer times
- countdown
- 10-minute warning
- Quran verse
- Quran lookup
- Hadith lookup
- Islamic calendar
- religious research with source verification
- Dua companion
- worship habit support
- New Muslim learning path
- faith reconnection support
- scholar connector concept

Sensitive religious questions should distinguish sourced information from interpretation and avoid pretending HEY itself is a scholar.

---

# 35. Business and Entrepreneurship

**Status:** `PLANNED / PROPOSED-CAPABILITY`

- idea validation
- business plan
- competitive intelligence
- market research
- customer research
- sales strategy
- pricing analysis
- launch plan
- experiment ledger
- financial planning
- operations
- customer support drafts
- marketing
- social content
- trend research
- manufacturer/vendor research
- grant/opportunity search
- capability portfolio/CV alternatives
- startup weekly review
- KPI dashboard from real data

---

# 36. Creator Tools

**Status:** `PLANNED / PROPOSED-CAPABILITY`

- content ideas
- script
- hook
- title
- thumbnail concept
- image generation
- photo edits
- storyboard
- frame generation
- video plan
- voiceover
- captions
- repurposing
- brand memory
- design critique
- social-post variants
- content calendar
- analytics interpretation
- audience-feedback summary

---

# 37. Health and Wellbeing Information

**Status:** `PLANNED, safety-sensitive`

Potential non-diagnostic capabilities:
- general health information
- medication reminder
- appointment reminder
- sleep routine tracking
- movement/water/eye reminders
- explain medical terms/documents
- prepare questions for a clinician
- summarize records provided by user
- accessibility support

Historical feature ideas included more ambitious detection claims such as burnout, depression/stress cues, Alzheimer detection, genetic risk, and illness detection. These should **not** be treated as reliable diagnoses. Production design must use conservative language and proper evidence.

---

# 38. Legal / Rights Information

**Status:** `PLANNED, high-stakes informational`

- plain-language legal-document explanation
- rights information
- summarize terms/contracts
- identify questions to ask a qualified professional
- jurisdiction-aware research where possible
- documentation organization

HEY should not impersonate a lawyer or guarantee legal outcomes.

---

# 39. Relationship and Communication Support

Historical/planned ideas:
- apology drafting
- difficult-conversation planning
- long-distance family connection ideas
- relationship-pattern reflection
- stepfamily navigation
- parent/teen communication
- attachment-style educational information
- rebuilding identity after unhealthy relationships
- conflict de-escalation guidance

These should remain non-diagnostic and avoid claiming certainty about other people’s motives.

---

# 40. Safety-Oriented Features

Historical concepts included:
- domestic-safety code word
- child-safety danger-sound detection
- emergency eye-movement trigger
- dangerous-area alerts
- harassment documentation
- whistleblower reporting support
- child-abuse documentation support

These are **safety-critical** and must never pretend an alert/report was delivered unless verified. They require dedicated legal, privacy, false-positive, abuse-resistance, and emergency-routing design.

---

# 41. Community and Matching

**Status:** `HISTORICAL / UNRESOLVED`

Discussed ideas:
- HEY community matchmaking
- random user matching
- mentor matching
- elderly-young mentor exchange
- homeschool peer connection
- creator collaboration
- skill trading
- founder/manufacturer/funder connectors
- specialist connectors

If revived, these need:
- consent
- moderation
- blocking/reporting
- age controls
- location/privacy protection
- anti-abuse systems

---

# 42. Offline HEY

**Status:** `PLANNED`

Offline-capable subset:
- wake word
- local commands
- timers
- reminders
- cached notes/memories
- local file search
- local knowledge pack
- selected on-device speech recognition
- selected on-device TTS
- basic computer control
- cached prayer times where calculated safely
- queued tasks
- lightweight local model if hardware permits

Historical ambition: useful even on very low-cost devices.

---

# 43. Customization

Users should be able to customize:

### Appearance
- theme
- accent
- background
- glass amount
- transparency
- contrast
- text scale
- density
- radius
- widget shadows
- animation level
- reduced motion
- wallpaper/environment
- natural vs futuristic visual intensity

Historical note: a 23-theme concept existed, but the exact list was not retained.

### Voice
- primary voice
- speed
- pitch
- expressiveness
- language
- wake word
- interruption sensitivity
- push-to-talk shortcut

### Personality
- verbosity
- humor
- directness
- encouragement
- challenge level
- preferred modes
- formality
- how HEY addresses the user

### Workspace
- dock location
- dock size
- controls
- widget defaults
- snap strength
- overlap
- saved layouts
- startup workspace
- compact/expanded Dynamic Island
- per-device layout

### Gesture
- sensitivity
- handedness
- mapping
- custom gestures
- per-device profiles
- accessibility substitutes

### Proactivity
- quiet hours
- suggestion level
- categories
- daily cap
- interruption rules
- notification devices

### Memory
- what to remember
- what not to remember
- retention
- project isolation
- sync
- private sessions
- export/delete

### Permissions
- per tool
- per agent
- per workflow
- per device
- one-time
- session
- persistent
- revoke
- audit

---

# 44. Always-On and Closed-App Capability Matrix

| Capability | Foreground | Minimized | Main window closed + helper | App terminated | Offline |
|---|---:|---:|---:|---:|---:|
| Text chat | Yes | No direct UI | via mini-widget | No local UI | Yes if local model |
| Wake word | Yes | Yes | **Yes, desired** | No | Yes if local |
| Voice reply | Yes | Yes | Yes via helper | No | Yes if local TTS/model |
| Reminders | Yes | Yes | Yes | **Yes via OS/server** | Yes via OS |
| Timers | Yes | Yes | Yes | OS-dependent | Yes |
| Dynamic Island | Yes | Yes | **Yes** | No | Yes |
| Background research | Yes | Yes | Yes | **Yes server-side** | No, unless local sources |
| Cloud image generation | Yes | Yes | Yes | **Yes server-side** | No |
| Cloud video generation | Yes | Yes | Yes | **Yes server-side** | No |
| Local file indexing | Yes | Yes | Yes | No | Yes |
| Cosmos cloud sync | Yes | Yes | Yes | server may continue | No network sync |
| Scheduled automation | Yes | Yes | Yes | **Yes server-side** | local-only schedules possible |
| Smart-home cloud routine | Yes | Yes | Yes | **Yes server-side** | depends on local hub |
| Computer control | Yes | Yes with verification | limited, explicit mission | No | Yes locally |
| Continuous screen awareness | Yes | explicit background only | normally **No** | No | Yes if local |
| Camera/gestures | Yes | explicit background only | normally **No** | No | Yes if local |
| Media playback | Yes | Yes | Yes | OS-dependent | Yes |
| Downloads/uploads | Yes | Yes | Yes with worker | server-side/cloud possible | local transfers only |
| Notifications | Yes | Yes | Yes | **Yes via OS/push** | local notifications yes |
| Calendar monitoring | Yes | Yes | Yes | **Yes server-side** | cached/local limited |
| Device health | Yes | Yes | Yes | server/other device may continue | local yes |
| Cross-device handoff | Yes | Yes | Yes | other devices/server | needs network unless local LAN |
| Prayer reminders | Yes | Yes | Yes | OS scheduled | Yes if times cached/calculated |

---

# 45. Security and Permission System

**Status:** `PARTIAL / VERIFIED foundations`

Rules:
- authenticated identity required
- server-authoritative plan/entitlements
- client cannot elevate itself
- fail closed
- explicit permission
- risk classification
- high-risk confirmation
- critical restrictions
- audit
- founder/admin does not bypass core safety/security
- no unrestricted DAN mode
- prompt-injection resistance
- minimum necessary context
- scoped tool credentials
- secret isolation
- Tauri bridge hardening
- Supabase RLS
- Edge Function auth
- revocation
- rate limiting
- abuse prevention

---

# 46. Trust Center

**Status:** `PROPOSED-CAPABILITY`

One place to see:
- active microphone
- active camera
- active screen access
- connected accounts
- connected devices
- permissions
- agents with authority
- workflows
- recent sensitive actions
- stored memory categories
- cloud vs local processing
- security warnings
- failed logins/actions
- revoke-all connections
- export/delete data

---

# 47. Privacy Modes

**Status:** `PROPOSED-CAPABILITY`

**Local Mode**  
Prefer local processing.

**Private Session**  
Do not write long-term Cosmos memory.

**Sensitive Screen**  
Pause screen/camera capture and related memory.

**Guest Mode**  
Prevent guest interactions from contaminating personal memory.

**Presentation Mode**  
Hide private notifications/memory while sharing screen/projector.

---

# 48. Developer / API Capabilities

**Status:** `PLANNED / UNRESOLVED`

Potential developer surfaces:
- personal API
- webhooks
- scoped tokens
- agent SDK
- tool SDK
- workflow definition
- custom integration
- event subscriptions
- local plugin
- MCP-style adapters
- capability manifest
- test harness
- agent simulator
- audit logs
- usage metrics

Historical note: API access was at times considered a separate product rather than a normal subscription entitlement.

---

# 49. Diagnostics and Self-Repair

**Status:** `PROPOSED-CAPABILITY`

HEY Health can test:
- provider availability
- API credentials
- database
- memory
- microphone
- speaker
- camera
- wake word
- notifications
- permissions
- Tauri/native bridge
- browser automation
- OS tools
- device pairing
- network
- storage
- agent registry
- workflows
- background worker

It can:
- explain failure
- propose fix
- retry
- collect privacy-scrubbed diagnostics
- detect recurring failures
- disable unsafe broken automations

---

# 50. Error and Failure Behavior

Every capability needs:
- loading
- success
- partial success
- failure
- offline
- permission denied
- provider unavailable
- timeout
- cancelled
- stale data
- unsupported platform
- ambiguous target
- verification failed

HEY should state exactly what happened and what remains possible.

---

# 51. Historical 200-Feature Archive

This list is preserved because it was explicitly discussed. It is **not** a claim that these features are currently implemented.

## Historical built/prototype items 1–14
1. Voice recognition with wake word
2. Chat widget
3. API connection via OpenRouter
4. Open website tool
5. Save idea tool
6. Get ideas tool
7. Set reminder tool
8. Idea Vault via localStorage
9. Mute/unmute system
10. Mic audio visualizer
11. Plasma ring visualizer
12. Contour background animation
13. Speaking energy animation
14. Muted/unmuted label

## Historical short-term 15–28
15. Updated personality system prompt
16. Multilingual voice and chat
17. ElevenLabs voice integration
18. Full memory between sessions
19. Screen awareness
20. Camera input
21. Offline mode
22. Separate chat page
23. Status text display
24. Clock/date on screen
25. Quick action buttons
26. Smaller circle option
27. Auto-restart recognition after speaking
28. Learning Theater page

## Historical long-term 29–200
29. HEY community matchmaking
30. Mental-health detection concept
31. Medication reminders for elderly users
32. Blind assistance
33. Student tutor mode
34. Grief companion
35. Domestic-safety code-word concept
36. Refugee navigator
37. Farmer intelligence
38. Child-safety sound-detection concept
39. Video/link review
40. File/document upload
41. Image generation
42. Photo editing commands
43. Legacy mode — letters to future children
44. Loyalty levels
45. Night-mode personality
46. Mood system based on time/patterns
47. HEY learns from each user over time
48. Neuroscience explanations
49. Islamic wisdom integrated naturally
50. Real-time web search
51. Dua companion mode
52. Istikharah guidance
53. Audio learning for blind users
54. Sign-language interpreter
55. Autism social-navigation earpiece concept
56. Grief memory vault
57. Fake-motivation detection
58. Last-resort crisis-support mode
59. Burnout early-detection concept
60. Toxic-relationship pattern reflection
61. Gaslighting-pattern reflection
62. Workplace-bullying documentation
63. Salary-negotiation coach
64. First-job mentor matching
65. Dead-end-job career pivot tool
66. Skill-to-income converter
67. Debt navigator
68. Financial literacy for unbanked users
69. Predatory-product detector
70. Grant/unclaimed-money finder
71. Prison-reentry life rebuilding support
72. Whistleblower safe-reporting concept
73. Information access for oppressive environments
74. Refugee-to-employer matching
75. Small-farmer global market access
76. Unused-food-to-people connector
77. Elderly-young mentor matching
78. Cultural-heritage preservation
79. Rural-opportunity equalizer
80. Local-problem-to-funded-solution platform
81. Apology-letter writer
82. Avoided-conversation guide
83. Estranged-family reconnection support
84. Long-distance family connection
85. Stepfamily navigation
86. New-parent first-year guide
87. Teenager-parent understanding tool
88. Identity rebuilding after toxic relationship
89. Attachment-style education
90. Generational-trauma pattern reflection
91. Purpose discovery through conversation
92. Confidence building
93. Value clarification
94. Decision alignment with future self
95. Abandoned-project restarter
96. Scattered-notes organizer
97. Peak-performance-hours protector
98. Time-waste pattern detector
99. Life-trajectory reflection based on habits
100. Idea-validation tool
101. Business-plan generator
102. Intellectual-property protection guidance
103. Bold-idea funding connector
104. Manufacturer/designer connector
105. Global-problem-to-solution connector
106. Skill-trader platform
107. Story-based learning for any subject
108. Conflict-zone education access concept
109. Homeschool peer connector
110. Legal-document plain-language translator
111. Legal-rights explainer
112. Medical-diagnosis/terminology translator
113. Rare-disease researcher connector
114. Food-relationship recovery support concept
115. Chronic-pain community connector
116. Alzheimer early-detection concept
117. Voice stress/depression/illness detection concept
118. Therapy-session understanding tool
119. Cultural mental-health plans
120. Night-shift health manager
121. Genetic-health-risk explainer
122. Healthcare-dismissal navigator
123. Radicalization early-intervention concept
124. Child-abuse documentation support concept
125. Scam-victim recovery
126. Eye-movement emergency-system concept
127. Women’s safety mapping concept
128. Dangerous-area community alerts
129. Online-harassment documentation
130. Corruption safe-reporting concept
131. Police-rights explainer
132. Life-story book generator
133. Family-history documenter
134. Traditional-skill elder-to-youth platform
135. Creative cross-country collaboration
136. Invisible-genius identifier concept
137. Field-visibility builder
138. Public-failure comeback guide
139. Pain-to-purpose reflection
140. Legacy Builder
141. Capability-proof alternative to CV concept
142. World-class education access concept
143. Offline developing-world version
144. HEY for every language
145. Culturally fluent responses
146. Islamic scholar connector
147. New Muslim learning path
148. Faith reconnection without judgment
149. Consistent worship builder
150. Real-time web awareness
151. Always-on Chrome extension widget
152. Desktop Electron-app version (historical; later native direction moved toward Tauri)
153. Remember first conversation forever concept
154. Forget memories that no longer serve user
155. Breaking-point system
156. Silence feature
157. Unprompted prayer/dua-support concept
158. Detect-user-is-not-okay concept
159. Different voice for situations
160. Celebrate wins
161. Hold user accountable to commitments
162. Apologize when wrong
163. AI debate partner
164. Personal board-of-directors mode
165. Discipline archetype mode
166. Visionary archetype mode
167. Scholar wisdom mode
168. Roast/motivational accountability mode
169. Motivational mode
170. Crisis-support mode
171. HEY for children in conflict zones concept
172. Offline HEY for very low-cost devices
173. Real-time screen help
174. Photo contrast/edit commands
175. Image generation from voice
176. TikTok/YouTube link analysis
177. PDF/book upload and analysis
178. HEY community random-user matching
179. Learning Theater visual explanation page
180. Mind-map generation
181. Step-by-step visual breakdowns
182. Quick-action buttons
183. Recent-command history display
184. Always-on floating widget
185. Expandable chat from widget
186. Family accounts
187. Direct support for highest paid tier concept
188. Early feature access
189. Multiple AI modes
190. HEY growing with user over years
191. Ten-year memory reflection
192. Notice patterns the user misses
193. Wait for the right moment to share insight
194. Avoid repeating itself unnecessarily
195. Culturally aware humor
196. Late-night soft mode
197. Morning sharp mode
198. Know when to simply be present
199. Dyslexia-friendly learning mode
200. Professional communication help for non-native speakers

---

# 52. New Capabilities Added in This Catalog

These were not all explicitly discussed before and are therefore `PROPOSED-CAPABILITY`:

- text-to-video
- image-to-video
- storyboard-to-video
- frame interpolation
- multi-frame storyboard consistency
- generative inpainting/outpainting
- transparent asset generation
- batch visual generation
- audio cleanup
- universal action receipts
- context capsules
- HEY Replay
- privacy modes
- Trust Center
- local file intelligence
- project snapshots / Time Machine
- provider-health dashboard
- self-diagnostics
- multi-surface orchestration
- personal API tokens
- prompt-injection shield
- contextual feature discovery
- reversible/undo-first action philosophy
- automation reliability scoring
- hardware-adaptive performance
- semantic workspace drag/drop relationships
- live artifacts
- memory inbox
- context firewall
- background render/research workers
- capability availability matrix

---

# 53. Final Product Rule

The final product should be enormous in capability but **not enormous in visible complexity**.

The user should be able to say things naturally:

- “HEY, make this photo brighter.”
- “HEY, generate the next frame.”
- “HEY, turn these frames into a storyboard.”
- “HEY, research this while I’m gone.”
- “HEY, remind me even if I close the app.”
- “HEY, keep listening after I minimize you.”
- “HEY, move this widget over there.”
- “HEY, make this into a presentation.”
- “HEY, open that app.”
- “HEY, explain what is on my screen.”
- “HEY, continue this task on my tablet.”
- “HEY, remember this only for this project.”
- “HEY, don’t remember this conversation.”
- “HEY, build me an agent that does this every Friday.”
- “HEY, tell me exactly what you changed.”

Underneath, HEY may use dozens of agents, tools, providers, permissions, background workers, local models, cloud services, device adapters and verification steps.

On the surface, it remains one HEY.

> **Tell me what you seek. I’ll help you make it so.**


---

