# Complete Project System
## HEY V1 — Full-depth implementation specification

**Mission:** Give every substantial effort a persistent container for context, artifacts, decisions, memory, tasks and Project DNA.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Project creation, overview, files, artifacts, tasks, memory, agents, activity, members, settings, Project DNA, canonical source, archival/export.
- Project isolation and cross-project references.

# 2. User experience contract
- Project switch is obvious and never silently mixes context.
- Project overview shows goal, current work, blockers, recent artifacts, decisions and tasks.
- Accepted artifacts and decisions become first-class project state.
- Project DNA is editable, lockable and auditable.

# 3. Architecture / runtime contract
- Project ID scopes memory, files, tasks, missions, artifacts and provider/privacy policy.
- Canonical sources and approved references are versioned.
- Cross-project access requires explicit link or user action.
- Project snapshots support restore.

# 4. Required state model
- active
- paused
- archived
- shared
- local-only
- syncing
- conflicted
- deleted-pending

# 5. Failure and recovery catalog
- Sync conflict → compare/resolve.
- Missing canonical source → warning, not silent substitution.
- Member removed → revoke access immediately.
- Archive preserves data.

# 6. Security / privacy / trust requirements
- RLS/project membership enforcement.
- Project context firewall.
- Local-only projects never route content to cloud.
- Exports exclude unauthorized connected data.

# 7. Data model / persistence
- projects
- project_members
- project_dna
- canonical_sources
- project_decisions
- project_snapshots
- project_links

# 8. Events / telemetry contracts
- project.created
- project.switched
- dna.updated
- decision.recorded
- source.canonicalized
- project.archived

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Project isolation test.
- Shared project permission test.
- Local-only routing test.
- Archive/restore.
- Project DNA drift detection.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

