# Complete PWA Install, Download & Update System
## HEY V1 — Full-depth implementation specification

**Mission:** Make HEY genuinely installable as a PWA and clearly distinguish PWA from native downloads.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Manifest, service worker, install CTA, beforeinstallprompt, manual instructions, standalone startup, icons, offline shell, updates, deep links, shortcuts.
- Download page/platform detection.

# 2. User experience contract
- Website has clear Install HEY/Download HEY.
- Do not nag immediately; suggest after meaningful use.
- Supported browser gets real install prompt after user click.
- Unsupported prompt path gets accurate manual instructions.
- Installed PWA starts at Conversation Surface.
- Update prompt is clear and preserves active work.

# 3. Architecture / runtime contract
- Manifest validated in CI.
- Service worker versioned and scoped correctly.
- Cache shell/static assets; do not cache sensitive dynamic data indiscriminately.
- Install event tracked privacy-safely.
- Update uses waiting worker with safe activation policy.

# 4. Required state model
- browser-not-installable
- install-available
- prompt-dismissed
- installed
- update-available
- updating
- offline
- uninstalled-unknown

# 5. Failure and recovery catalog
- Manifest invalid → diagnostics.
- Service worker install fail → web still works.
- Update cache conflict → rollback/clear safely.
- Prompt dismissed → cooldown.

# 6. Security / privacy / trust requirements
- Service worker must not cache auth tokens/secrets.
- Offline pages respect data privacy.
- Deep links re-check authorization.

# 7. Data model / persistence
- pwa_install_state
- pwa_update_state
- manifest_version
- install_prompt_history

# 8. Events / telemetry contracts
- pwa.install.available
- pwa.install.prompted
- pwa.installed
- pwa.update.available
- pwa.update.applied

# 9. Platform behavior
- Desktop Chromium: use real install prompt when eligible.
- iOS/iPadOS browsers: show accurate Add to Home Screen guidance where programmatic install prompt is unavailable.
- Android: PWA install flow + app shortcuts where supported.
- Unsupported browser: normal web experience plus truthful installation alternatives.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Chrome/Edge install.
- Safari/iOS manual install guidance where applicable.
- Standalone startup route.
- Offline shell.
- Update with unsaved draft.
- Icon/maskable validation.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

