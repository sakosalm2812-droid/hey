# Complete Event & State-Machine Contracts
## HEY V1 — Full-depth implementation specification

**Mission:** Give HEY deterministic lifecycle semantics across missions, generations, Live, permissions, Forge and artifacts.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Event naming/versioning, correlation IDs, idempotency, ordering, replay safety, state transitions.
- Mission, Task, Workflow, Generation, Artifact, Live, Permission, Forge, Device Handoff state machines.

# 2. User experience contract
- UI state must derive from canonical lifecycle, not ad-hoc booleans.
- Progress labels correspond to real states.
- Cancel/pause/resume behavior is consistent.

# 3. Architecture / runtime contract
- Events include schema version, actor, timestamp, correlation/causation IDs, project/user scope.
- State transitions validated server/runtime-side.
- Idempotent handlers for retries.
- Dead-letter/failed-event visibility in diagnostics.

# 4. Required state model
- created
- queued
- running
- waiting-user
- waiting-resource
- paused
- verifying
- completed
- partially-completed
- failed
- cancelled
- recovering

# 5. Failure and recovery catalog
- Duplicate event → idempotent no-op.
- Out-of-order event → reject/defer.
- Crash mid-transition → recover from durable state.
- Invalid transition → diagnostics alert.

# 6. Security / privacy / trust requirements
- Events must not contain secrets/raw sensitive context unnecessarily.
- Audit security-relevant transitions.

# 7. Data model / persistence
- events
- state_snapshots
- transition_history
- correlation_context
- dead_letters

# 8. Events / telemetry contracts
- hey.input.received
- intent.resolved
- mission.*
- task.*
- workflow.*
- tool.*
- permission.*
- artifact.*
- generation.*
- memory.*
- device.*
- live.*
- provider.*
- security.alert

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Retry duplicate command.
- Crash/restart during generation.
- Cancel during verify.
- Permission wait/resume.
- Event schema backward compatibility.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

