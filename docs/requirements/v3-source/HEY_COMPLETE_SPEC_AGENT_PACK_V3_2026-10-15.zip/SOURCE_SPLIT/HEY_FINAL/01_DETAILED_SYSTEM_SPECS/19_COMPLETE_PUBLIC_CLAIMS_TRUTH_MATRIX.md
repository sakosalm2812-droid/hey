# Complete Public Claims & Truth Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Ensure every website/social/pricing claim corresponds to a verified production capability.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Feature claims, platform claims, pricing, privacy, performance, 'works in background', device control, generation, memory, integrations.
- Claim evidence and owner.

# 2. User experience contract
- Marketing may be bold but cannot imply unsupported access or reliability.
- Platform limitations are clear where material.
- Demo footage must match real achievable product behavior.

# 3. Architecture / runtime contract
- Claims registry maps public sentence → capability ID → supported platforms → test evidence → last verified release.
- Release process revalidates high-risk claims.

# 4. Required state model
- verified
- verified-with-limitations
- temporarily-disabled
- unverified
- retired

# 5. Failure and recovery catalog
- Capability disabled → website copy/feature flag update.
- Test fails → claim blocked.
- Platform changed → matrix update.

# 6. Security / privacy / trust requirements
- Privacy/security claims require security review.
- No deceptive pricing/limits.

# 7. Data model / persistence
- public_claims
- claim_evidence
- claim_platforms
- claim_reviews

# 8. Events / telemetry contracts
- claim.created
- claim.verified
- claim.blocked
- claim.retired

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Background-island claim verified native.
- PWA install claim verified.
- Computer-control claim per platform.
- Pricing limits match entitlements.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

