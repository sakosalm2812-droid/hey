# HEY V1 — LAUNCH BLOCKERS, UX PROBLEMS & EXPECTATION-GAP FIX SPEC
## Living remediation document for OpenCode / implementation agents

**Product:** HEY  
**Status:** Pre-launch critical remediation  
**Brand:** No limits to the sky.

This document records problems discovered during final HEY V1 review. It is intentionally a **living issue document**: append every new problem as it is found. Do not delete an issue until its acceptance tests pass end-to-end.

---

# 0. MASTER FIX RULE

Do not treat these as isolated cosmetic bugs. For every issue:

1. identify the root cause;
2. compare current behavior against intended HEY V1 behavior;
3. fix architecture and UX where necessary;
4. preserve working systems;
5. verify real states, not screenshots;
6. test foreground, minimized, closed-main-window, background, offline, permission-denied, error, recovery and resume states where relevant;
7. never mark something complete because a route/component merely exists;
8. never hide an incomplete feature instead of completing it unless explicitly approved;
9. never fake native/background functionality with a web-only visual;
10. keep HEY feeling like **one intelligence environment**, not a collection of separate apps.

---

# 1. P0 — DYNAMIC ISLAND IS WEB-ONLY

## Current problem

The Dynamic Island currently exists only while the HEY web/main UI is visible. When the main app/window closes, the island disappears.

That is not the intended HEY V1 behavior.

## Required behavior

On supported desktop platforms, the Dynamic Island must be backed by HEY's native/helper layer and remain available when:

- the main window is unfocused;
- minimized;
- closed while HEY is still running;
- a mission is running;
- HEY Voice is active;
- a timer/reminder is active;
- media is active;
- a generation/render is running;
- research is running;
- an upload/download is running;
- an approval is waiting;
- a device handoff is occurring.

It should disappear only when:
- the user disables it;
- HEY fully quits;
- the platform truly cannot support that surface.

## Required state model

- F0: main window foreground
- F1: unfocused
- F2: minimized
- F3: main window closed + HEY helper alive
- F4: device locked where platform permits limited status
- F5: HEY fully terminated
- F6: offline
- F7: another trusted device is continuing the task

The Dynamic Island must be designed around F0–F3, not around the lifecycle of one web page.

## Acceptance test

1. Open HEY.
2. Start a timer or mission.
3. Close the main window.
4. Island remains.
5. Status continues updating.
6. Click island.
7. Relevant controls open.
8. Reopen HEY.
9. State matches.
10. Fully quit HEY.
11. Island disappears.

---

# 2. P0 — DYNAMIC ISLAND EXPANSION IS WRONG

## Current problem

Clicking the island currently mostly shows “Activity.”

That is too narrow and does not match the intended HEY experience.

## New product rule

The Dynamic Island is a **context-aware compact control surface**.

When clicked, it should show the UI most relevant to what is happening **right now**.

Activity history is only one secondary view.

## Required modes

### 2.1 Idle HEY
Show:
- HEY state;
- quick command;
- mic/listening state;
- recent useful context;
- open full HEY.

### 2.2 HEY Voice / call-like state
Show the call-like design direction previously specified:
- HEY visualizer/waveform;
- listening / thinking / speaking state;
- elapsed session time;
- mute;
- end;
- captions;
- expand to Voice;
- device/output control if relevant.

### 2.3 Media state
Show:
- artwork;
- title;
- artist/source;
- play/pause;
- previous/next if supported;
- progress;
- output/volume access.

### 2.4 Mission / HEY working state
Show:
- mission title;
- what HEY is doing now;
- current stage;
- real progress when measurable;
- pause;
- cancel;
- expand;
- verification state.

### 2.5 Generation state
Show:
- preview/thumbnail when available;
- current generation stage;
- item/frame count when real;
- cancel;
- open result;
- QA/verification state.

### 2.6 Research state
Show:
- topic;
- searching/reading/synthesizing/verifying stage;
- real source count if available;
- pause/cancel;
- open research.

### 2.7 Upload / download
Show:
- filename;
- destination/source;
- real progress;
- pause/cancel;
- open file/location.

### 2.8 Timer / reminder
Show:
- title;
- countdown/time;
- pause/resume;
- stop/dismiss.

### 2.9 Approval
Show:
- exactly what HEY wants to do;
- target;
- important consequence;
- approve;
- reject;
- details.

### 2.10 Cross-device handoff
Show:
- source device;
- target device;
- handoff state;
- continue here;
- cancel.

### 2.11 Error/recovery
Show:
- concise failure;
- retry;
- fallback;
- open details.

### 2.12 Completion
Show:
- what completed;
- result preview;
- open;
- dismiss.

## Visual rule

The expanded island should visually transform based on context:
- call-like for Voice;
- media-like for music;
- mission-like for background work;
- generation-like for creation;
- compact, tactile, liquid-glass and immediately controllable.

It must **not** always become a generic activity drawer.

## Acceptance test

Test Voice, media, generation, research, timer, mission, approval, error and completion. Each must produce the correct expanded state.

---

# 3. P0 — STUDIOS FEEL LIKE SEPARATE APPS/PAGES

## Current problem

Creative studios feel too independent from HEY.

The intended product is not:
HEY → leave HEY → separate studio app.

The intended product is:
HEY → open capability **inside HEY**.

## Required model

These should operate inside the HEY workspace:

- Image Studio
- Image Editor
- Storyboard / Frame Studio
- Video Studio
- Motion Graphics Studio
- Audio Studio
- Presentation Studio
- Document / Book Studio
- Research workspace
- Code workspace

## Required behavior

From Chat, Voice, Create, Project or an artifact:
1. user invokes a capability;
2. studio opens in the HEY workspace;
3. current project remains attached;
4. HEY remains accessible;
5. conversation/context remains accessible;
6. studio can expand to occupy most of the canvas;
7. it can minimize/collapse back into the workspace;
8. reopening restores exact state.

The studio can have its own toolbar, timeline and inspector, but it must still feel like HEY.

## Do not

- use a completely separate product shell;
- lose Chat/Voice context;
- lose project context;
- replace HEY's navigation with unrelated studio navigation;
- force users into separate “apps.”

## Acceptance test

Start in Chat → ask for image creation → studio opens inside HEY → minimize studio → continue chatting → reopen studio → exact state is preserved.

---

# 4. P0 — IMPORTANT CAPABILITIES ARE BURIED IN “EXPLORE MORE”

## Current problem

Explore More may technically contain many capabilities, but a normal user will not discover them.

Capabilities that matter most need to be visible before users know to search for them.

## Required hierarchy

### Tier 1 — primary and immediately visible

Normal users should quickly discover:

- Chat
- Voice
- HEY Live
- Create
- Projects
- Cosmos
- Research
- Files
- Tasks / Missions
- Automations
- Widgets

Important Create entries should surface prominently:
- Image
- Video
- Presentation
- Document
- Audio

### Tier 2 — `+ Add`

A visible **+** control must exist beside primary capability groups.

It opens a clean picker where users can add:
- tools;
- studios;
- widgets;
- shortcuts;
- modes;
- integrations;
- frequently used actions.

### Tier 3 — Explore More

Explore More remains the complete discovery catalog for:
- less common capabilities;
- advanced tools;
- integrations;
- Forge-created capabilities;
- specialized workflows;
- new/experimental tools.

It must not be the only place the important features live.

## Personalized ordering

Allow:
- pinning;
- manual reorder;
- context-aware recommended tools;
- recently/frequently used tools rising in prominence.

Never expose internal agent complexity just to solve discoverability.

---

# 5. P0 — THE `+ ADD` PERSONALIZATION MODEL IS MISSING/UNCLEAR

## Required UI

Examples:

`Create     Image   Video   Docs   +`

`Widgets    Clock   Tasks   Calendar   +`

`Quick tools    Live   Research   Files   +`

Clicking `+` should:
1. open capability picker;
2. show recommended first;
3. provide search;
4. group by category;
5. preview each item;
6. allow Add;
7. allow later pin/reorder/remove.

Do not dump hundreds of items in one grid.

---

# 6. P0 — TUTORIALS ARE NOT PRESENT / DISCOVERABLE ENOUGH

## Current problem

The expected animated tutorial system is not visible enough or appears missing.

For HEY, that is a product-level problem, not optional documentation.

## Required tutorial entry points

- first-use;
- Help;
- Tutorial Center;
- contextual `?`;
- “Show me how”;
- voice request: “HEY, show me how to use X”;
- command palette;
- feature empty states where useful.

## Required first-use tutorials

At minimum:
- Chat
- Voice
- HEY Live
- Dynamic Island
- Workspace
- Widgets
- Projects
- Project DNA
- Cosmos
- Memory Inbox
- Image generation
- Pinpoint Precision
- Image editing
- Storyboard
- Video
- Motion Graphics
- Audio
- Presentation
- Document / Book
- Research
- Browser
- Files
- Code
- Tasks
- Missions
- Automations
- teach-by-doing / recorder
- Forge
- Skills
- Modes
- Devices
- cross-device handoff
- gestures
- custom gestures
- permissions
- Trust Center
- Private Mode
- Offline Mode
- Notifications
- appearance
- voice settings
- personality
- diagnostics
- Time Machine
- Command Palette
- Universal Search

## Tutorial format

Each tutorial supports:
- animated demonstration;
- real UI spotlight;
- captions;
- optional HEY narration;
- Back;
- Next;
- Skip;
- Practice;
- Replay;
- reduced-motion version.

Tutorials must teach the **current real UI**, not stale mockups.

## Acceptance test

Fresh account → enter Live → tutorial offered → skip → Tutorial Center → replay Live tutorial → complete → completion is stored → ask HEY by voice to show Live tutorial → correct tutorial opens.

---

# 7. P0/P1 — HEY DOES NOT FEEL “ALIVE” ENOUGH

## Current problem

The product is not currently living up to the expected feeling.

This is not fixed by adding random animations.

HEY should feel like a persistent intelligence that visibly reacts to real state.

## HEY should visibly respond to

- listening;
- thinking;
- speaking;
- acting;
- waiting;
- verifying;
- completing;
- failing;
- recovering;
- current project;
- current mode;
- current mission;
- connected devices;
- background tasks;
- generation;
- media;
- approvals.

## Required living-system cues

- voice visualizer state;
- Dynamic Island real context;
- meaningful mission state;
- contextual workspace adaptation;
- useful widget surfacing;
- background continuity;
- clear generation progress;
- completion result surfaces;
- intelligent notifications;
- subtle context-aware suggestions.

## Do not fake “alive” with

- random glowing;
- fake progress;
- endless pulsing;
- particles;
- meaningless AI-thinking animation;
- excessive moving backgrounds.

“Alive” must come from real product state.

---

# 8. P1 — ACTIVITY IS THE WRONG DEFAULT MENTAL MODEL FOR THE ISLAND

The Dynamic Island should answer:

- What is happening?
- What is HEY doing?
- Is HEY listening/speaking?
- Can I pause/cancel?
- Is media playing?
- Is something waiting for approval?
- Did something finish?
- What stage is my mission at?
- Can I jump into it?

Activity history may exist, but it is secondary.

---

# 9. P0/P1 — NORMAL-USER DISCOVERABILITY IS TOO WEAK

A feature that exists but cannot reasonably be discovered is not finished.

Every major feature must be discoverable through some combination of:

- primary navigation;
- Home;
- Create;
- `+ Add`;
- command palette;
- Universal Search;
- contextual suggestions;
- tutorials;
- capability cards;
- example prompts;
- “What can you do?”;
- Explore More.

Normal users should not need to know HEY's internal terminology.

---

# 10. REQUIRED EXPECTATION-GAP AUDIT

Implementation agents must audit every major HEY V1 capability using:

> “Does this merely exist, or does it actually behave and feel like the HEY product specified?”

For each surface inspect:
- discoverability;
- integration;
- visual quality;
- animation;
- background behavior;
- native behavior;
- customization;
- tutorial;
- permission model;
- error state;
- recovery;
- continuity;
- responsive behavior;
- accessibility;
- localization;
- actual E2E functionality.

A route/component/button is not proof of completion.

---

# 11. PRIORITY ORDER

## P0 — pre-launch blockers

1. Native/background Dynamic Island
2. Context-aware Dynamic Island expansion
3. Studios integrated inside HEY
4. Important capability discoverability
5. `+ Add` personalization
6. Tutorials present and reachable
7. Normal-user information architecture
8. Real HEY state feedback

## P1 — launch-quality gaps

9. adaptive workspace behavior
10. richer island context designs
11. tutorial coverage completeness
12. motion/polish consistency
13. mode-specific layouts
14. background task continuity
15. full loading/error/empty/offline polish

---

# 12. WRONG FIXES — DO NOT DO THESE

Do not:
- delete Explore More;
- put every capability in top navigation;
- hide studios;
- make the island a larger Activity page;
- fake native persistence with a browser tab;
- reduce tutorials to static documentation;
- solve “alive” with decorative animation;
- expose the 229-agent registry to normal users;
- replace HEY with a generic dashboard;
- rewrite already-working subsystems without cause.

---

# 13. VERIFICATION SCENARIOS

## A — Island persistence
Start timer → close main window → island remains → timer updates → click → timer controls → reopen HEY → same state → full quit → island gone.

## B — Voice island
Start Voice → minimize/close main window → island becomes call-like → click → mute/end/captions/status → stop → idle island.

## C — Generation island
Start generation → leave studio → island shows generation → click → stage/preview/cancel → completion → result preview → open result.

## D — Studio integration
Chat → ask HEY to create image → studio opens inside HEY → Chat still accessible → minimize → continue Chat → reopen exact studio state.

## E — Discoverability
Give a fresh user no instructions. They must reasonably find:
Voice, Live, Create, Image, Video, Projects, Cosmos, Research and Widgets.

## F — Tutorials
Fresh account → open feature → tutorial offered → skip → Tutorial Center → replay → Practice → complete → state saved.

---

# 14. OPEN ISSUES QUEUE

Append new problems here as they are found.

Use:

## ISSUE HEY-XXX
**Problem:**  
**Expected behavior:**  
**Current behavior:**  
**Severity:** P0 / P1 / P2  
**Affected surfaces:**  
**Root cause if known:**  
**Required fix:**  
**Do not:**  
**Acceptance criteria:**  
**Verification:** NOT TESTED / FAIL / PASS

---

# 15. PRODUCT EXPECTATION

HEY must not feel like:
- a website with AI pages;
- a dashboard full of links;
- disconnected studios;
- an activity log;
- a feature directory;
- a chat app with plugins.

HEY must feel like:

**one persistent intelligence that stays with the user, opens capabilities inside itself, exposes what it is doing, teaches the user how to use it, surfaces important functionality before it is searched for, and lets advanced users go deeper without forcing normal users through complexity.**

That is the standard for HEY V1.

**No limits to the sky.**


---

