# Complete First-Run, Sign-In & Account Lifecycle
## HEY V1 — Full-depth implementation specification

**Mission:** Make entry into HEY immediate, premium and safe from account creation through deletion.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Sign up, verification, sign in, recovery, first run, onboarding, returning user, sign out, account switch, deletion/export.
- Startup destination and install prompts.

# 2. User experience contract
- Successful sign-in defaults to Chat/Voice Conversation Surface.
- Onboarding requests permissions just-in-time, not all at once.
- First real task teaches HEY by doing.
- Returning users skip onboarding and resume safely.
- PWA/native install suggestion occurs after demonstrated value.

# 3. Architecture / runtime contract
- Auth session managed server-side/securely.
- Startup resolver checks onboarding state, last safe conversation, active mission, explicit preference.
- Account deletion/export is durable and auditable.
- Plan/entitlement state cannot be forged client-side.

# 4. Required state model
- anonymous
- signing-up
- verification-pending
- onboarding
- active
- session-expired
- locked
- deletion-pending
- deleted

# 5. Failure and recovery catalog
- Expired session → reauth preserving local draft.
- Verification email failure → resend.
- Account deletion partial failure → retry/report.
- Entitlement mismatch → server truth wins.

# 6. Security / privacy / trust requirements
- Secure tokens, no secrets in local storage where avoidable.
- Rate-limit recovery/login abuse.
- Reauthentication for sensitive account actions.

# 7. Data model / persistence
- users
- profiles
- sessions
- onboarding_progress
- account_exports
- deletion_jobs
- startup_preferences

# 8. Events / telemetry contracts
- auth.signed_in
- onboarding.step
- startup.route
- session.expired
- account.exported
- account.deleted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in → Conversation Surface.
- Returning sign-in → safe resume.
- Session expiry preserves draft.
- Delete/export test.
- PWA install prompt timing test.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

