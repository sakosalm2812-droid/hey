# Complete Native Dynamic Island & Persistent Surface
## HEY V1 — Full-depth implementation specification

**Mission:** Make the Dynamic Island a real contextual HEY surface outside the main app on supported desktop platforms.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Native window/helper, always-on-top behavior, monitor selection, positioning, idle/listening/thinking/media/mission/generation/research/download/timer/approval/handoff/error/completion modes.
- Click/hover/voice/gesture expansion and full-app handoff.

# 2. User experience contract
- Island persists after main window closes while HEY helper remains.
- Click shows context-specific controls, not Activity-only.
- User can reposition/customize size/transparency/monitor/auto-hide.
- Island never blocks important OS UI and respects fullscreen apps per preference.
- Multiple concurrent activities resolve to one primary state + compact secondary indicators.

# 3. Architecture / runtime contract
- Native host window controlled by helper process; web UI rendered inside or native equivalent.
- Canonical activity selector ranks current states.
- IPC bridges task/media/voice/generation state from runtime to island.
- Island reconnects after UI/native helper restart.

# 4. Required state model
- idle
- listening
- thinking
- speaking
- media
- mission
- generation
- research
- transfer
- timer
- approval
- handoff
- error
- complete
- hidden

# 5. Failure and recovery catalog
- Helper crash → restart.
- IPC lost → degraded status + reconnect.
- Multiple activities → priority resolution.
- Monitor removed → move to primary display.

# 6. Security / privacy / trust requirements
- Always-visible sensing indicators.
- Lock-screen/private-screen redaction.
- Island cannot approve high-risk action without required confirmation details.

# 7. Data model / persistence
- island_preferences
- island_state
- active_surfaces
- native_helper_state

# 8. Events / telemetry contracts
- island.mode.changed
- island.expanded
- island.action
- helper.connected
- helper.disconnected

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Close main window persistence.
- Voice controls.
- Media controls.
- Generation controls.
- Monitor unplug.
- Full quit removes island.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

