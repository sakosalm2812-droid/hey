# Complete Background / Closed-App Runtime
## HEY V1 — Full-depth implementation specification

**Mission:** Make HEY coherent across foreground, minimized, closed-main-window, lock, termination and offline states.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Native helper, tray/menu bar, Dynamic Island, wake word, reminders, schedules, missions, cloud jobs, file transfers, notifications, device handoff.
- Background privacy and resource budgets.

# 2. User experience contract
- Closing window does not silently terminate HEY unless user chose that behavior.
- Visible indicator for background sensing.
- Camera/screen normally stop on close unless explicit visible background mode.
- Cloud tasks can continue after local window closes.

# 3. Architecture / runtime contract
- Native supervisor owns durable local background capabilities.
- Server scheduler owns durable cloud jobs.
- Main UI reconnects to canonical task state rather than restarting.
- Background tasks have resumable checkpoints where possible.

# 4. Required state model
- F0 foreground
- F1 unfocused
- F2 minimized
- F3 main closed/helper alive
- F4 locked
- F5 terminated
- F6 offline
- F7 remote device

# 5. Failure and recovery catalog
- Helper crash → restart/recover state.
- Network loss → queue/retry.
- OS suspends app → server durable fallback where valid.
- Task cannot run background → explicit pause.

# 6. Security / privacy / trust requirements
- Background sensing requires persistent visible indicator and consent.
- No covert camera/screen.
- Lock-screen notifications redact sensitive data.

# 7. Data model / persistence
- background_preferences
- background_jobs
- task_checkpoints
- helper_sessions
- sensing_sessions

# 8. Events / telemetry contracts
- app.backgrounded
- helper.started
- helper.stopped
- task.resumed
- sensing.paused
- window.reopened

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Close main window during timer/mission.
- Lock device.
- Network drop/resume.
- Helper restart.
- Full quit stops local background surfaces.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

