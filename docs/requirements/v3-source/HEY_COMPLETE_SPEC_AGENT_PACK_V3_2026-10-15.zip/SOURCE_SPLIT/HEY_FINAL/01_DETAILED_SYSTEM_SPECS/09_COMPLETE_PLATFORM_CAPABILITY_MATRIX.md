# Complete Platform Capability Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Define truthful, strongest-possible behavior for web, PWA, Windows, macOS, Linux, Android and iOS.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat, Voice, Live, screen/camera, computer control, background helper, Dynamic Island, notifications, files, gestures, local models, device handoff, install/update.
- Per-platform fallback behavior.

# 2. User experience contract
- UI labels unavailable capabilities honestly.
- Same conceptual feature can have platform-specific implementation.
- User sees the strongest supported fallback rather than a dead button.

# 3. Architecture / runtime contract
- Capability registry includes platform support: native/full, supported-with-limits, guided-only, unavailable.
- Runtime capability detection, not user-agent assumptions alone.
- Native helper interfaces are abstracted behind capability contracts.

# 4. Required state model
- supported
- supported-limited
- permission-required
- unsupported
- temporarily-unavailable
- degraded

# 5. Failure and recovery catalog
- OS API unavailable → fallback.
- Permission denied → guide.
- Browser restrictions → native/PWA suggestion.
- Background suspension → cloud/server durable task fallback.

# 6. Security / privacy / trust requirements
- No fake arbitrary iOS control.
- No security bypass.
- Platform permissions explicit.

# 7. Data model / persistence
- platform_capabilities
- device_capabilities
- capability_health
- permission_grants

# 8. Events / telemetry contracts
- capability.detected
- capability.unavailable
- fallback.selected
- native.helper.connected

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Windows closed-window island.
- PWA install.
- Android assistant integration where supported.
- iOS fallback contracts.
- Linux/macOS background tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

