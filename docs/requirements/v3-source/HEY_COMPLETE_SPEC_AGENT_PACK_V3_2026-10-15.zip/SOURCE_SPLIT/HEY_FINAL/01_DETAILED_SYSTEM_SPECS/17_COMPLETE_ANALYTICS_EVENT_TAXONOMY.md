# Complete Product Analytics & Event Taxonomy
## HEY V1 — Full-depth implementation specification

**Mission:** Learn whether HEY is discoverable, reliable and useful without collecting unnecessary private content.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Acquisition, onboarding, navigation, feature discovery, activation, mission success, tutorial completion, errors, retention, conversion, support.
- Privacy-preserving event design and experiment tracking.

# 2. User experience contract
- Analytics should answer: can users find it, use it, finish it, and recover when it fails?
- No raw prompt/content collection by default just for analytics.
- Internal quality metrics are separated from marketing vanity metrics.

# 3. Architecture / runtime contract
- Event registry with owner, schema, purpose, retention and privacy classification.
- Anonymous/pre-auth IDs merge cautiously after sign-in.
- Server events for authoritative completion/payment/security, client events for UI interactions.

# 4. Required state model
- queued
- sent
- dropped-by-consent
- sampled
- invalid

# 5. Failure and recovery catalog
- Offline → queue within limits.
- Schema mismatch → drop/report.
- Ad blocker → product still functions.
- Duplicate event → dedupe.

# 6. Security / privacy / trust requirements
- Consent/region requirements honored.
- Never sell user data.
- Minimize personal data.
- Sensitive events can be aggregate-only.

# 7. Data model / persistence
- analytics_events
- event_schemas
- experiments
- funnels
- consent_state

# 8. Events / telemetry contracts
- activation.started
- activation.completed
- tutorial.completed
- mission.success
- mission.failure
- feature.discovered
- install.prompted
- pwa.installed

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Event schema validation.
- No raw prompt leak.
- Payment conversion uses server truth.
- Tutorial funnel.
- Feature discoverability metrics.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---

