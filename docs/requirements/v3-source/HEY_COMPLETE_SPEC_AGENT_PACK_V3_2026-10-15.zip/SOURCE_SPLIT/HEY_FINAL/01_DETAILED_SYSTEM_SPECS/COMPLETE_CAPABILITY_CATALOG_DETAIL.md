# HEY — COMPLETE CAPABILITY CATALOG
## Everything HEY can, should, or may eventually be able to do

**Document type:** Master capability specification  
**Purpose:** Describe HEY at the capability level, including tiny sub-capabilities, controls, customization, background behavior, permissions, offline behavior, failure states, implementation status, and new capabilities that were never explicitly discussed before.

---

## 0. How to read this document

This document separates three kinds of truth:

- **SOURCE-DERIVED** — directly discussed in HEY project history.
- **IMPLEMENTED / VERIFIED / PARTIAL** — based on retained implementation history, not marketing claims.
- **PROPOSED-CAPABILITY** — added here because it logically strengthens HEY, even if never previously discussed.

Status vocabulary:

- `VERIFIED` — retained history says the capability passed a real test/check.
- `IMPLEMENTED` — code or prototype behavior was reported implemented.
- `PARTIAL` — some foundation exists, but the end-to-end production capability is not proven.
- `PLANNED` — explicitly wanted for HEY.
- `HISTORICAL` — discussed in an older direction, even if later changed.
- `CHANGED` — later direction superseded an earlier one.
- `REJECTED` — explicitly not wanted.
- `UNRESOLVED` — exact product/technical decision remains open.
- `PROPOSED-CAPABILITY` — new recommendation in this document.

**Important:** No item marked `PLANNED`, `HISTORICAL`, `UNRESOLVED`, or `PROPOSED-CAPABILITY` should be presented to users as already working.

---

# 1. Capability Runtime Model

Every capability should declare where it can run.

### Runtime states

**F0 — Foreground only**  
The full HEY window/page must be open and active.

**F1 — Open but unfocused**  
HEY is open, but another app/window is in front.

**F2 — Minimized**  
The main HEY window is minimized but its native process is still running.

**F3 — Main window closed, HEY helper still running**  
A tray/menu-bar/background helper remains alive. This is what enables a true “HEY is closed but still there” experience on desktop.

**F4 — Device locked**  
The computer/phone is locked. Only OS-permitted background functionality may continue.

**F5 — App process terminated**  
No local HEY process is running. Only server-side/cloud tasks, push notifications, and OS-scheduled jobs can continue.

**F6 — Offline**  
No internet connection. Only local/on-device features can continue.

**F7 — Other trusted device active**  
The current device is unavailable, but another paired HEY device or server workflow can continue.

### Core background rule

A browser tab alone cannot provide the full closed-app experience reliably. The long-term HEY design therefore needs a native/background layer, consistent with the retained Tauri desktop direction, plus OS notifications and server-side automation where appropriate.

### Capabilities that SHOULD be able to continue when the main window is closed

Subject to permission and platform support:

- wake-word detection through a native helper
- reminders
- alarms/timers
- scheduled briefings
- server-side research jobs
- server-side workflow jobs
- downloads/uploads owned by a background worker
- cloud file processing
- notification delivery
- calendar/event monitoring
- condition monitoring
- device-health checks
- smart-home routines
- media playback controls
- selected cross-device handoffs
- long-running code/build/research missions
- Dynamic Island / mini-widget / tray UI
- background sync
- Cosmos synchronization
- agent task execution that does not require visual foreground interaction
- server-side connected-app actions if authorized
- approved automations
- cloud image generation
- cloud video generation
- cloud rendering
- scheduled reports

### Capabilities that SHOULD NOT silently remain active when HEY is closed

Unless the user explicitly enables a visible background mode:

- camera capture
- screen recording/continuous screen capture
- face recognition
- gesture-camera tracking
- continuous microphone recording beyond wake-word/local speech trigger needs
- biometric analysis
- sensitive clipboard monitoring
- unrestricted keystroke monitoring
- background terminal commands with no mission context
- high-risk device control
- hidden location tracking

---

# 2. Core Conversation and Reasoning

## 2.1 Text conversation
**Status:** `PLANNED / PARTIAL`

HEY can receive text, understand intent, answer questions, generate structured output, ask clarifying questions only when necessary, and continue multi-turn context.

**Small capabilities:**
- short answer
- long explanation
- comparison
- brainstorming
- summarization
- rewriting
- translation
- classification
- extraction
- planning
- step-by-step instruction
- decision support
- critique
- error explanation
- ideation
- tutoring
- research synthesis
- follow-up understanding
- reference resolution such as “that one,” “the previous file,” or “continue”
- structured JSON/output for internal tools
- tone adaptation
- uncertainty reporting
- asking only the minimum necessary question

**Customization:**
- verbosity
- tone
- directness
- humor
- technical depth
- language
- formatting preference
- whether HEY uses tables, bullets, prose, or concise command-style replies

**Background:** conversation itself requires an interaction surface, but HEY may continue a mission after the user leaves if that mission was explicitly handed off.

## 2.2 HEY personality / soul
**Status:** `PLANNED`

HEY should maintain one recognizable identity across voice, chat, widgets, agents, devices, and modes.

Behavioral traits:
- calm
- intelligent
- curious
- optimistic
- warm
- direct
- capable of disagreement
- able to apologize when wrong
- able to celebrate wins
- knows when to be silent
- knows when a short answer is better
- culturally aware
- avoids repetitive canned phrases
- avoids fake profundity
- does not pretend to be human
- may feel brother-like, mentor-like, or sensei-like without lying about what it is

## 2.3 Response modes
**Status:** `PLANNED / HISTORICAL`

Discussed or proposed modes include:
- Quick
- Standard
- Deep Dive
- Mentor
- Strategist
- Research
- Creative
- Teacher
- Debate
- Execution
- Emotional Support
- Crisis-support-safe mode
- Late Night Soft Mode
- Morning Sharp Mode
- Motivational Mode
- Devil’s Advocate
- Personal Board of Directors
- Silence / Just Be Present
- culturally fluent communication
- professional communication for non-native speakers
- dyslexia-friendly learning mode

`HISTORICAL`: named-person-inspired modes such as “Kobe discipline,” “Elon vision,” and “Scholar wisdom” were discussed. A better production implementation is to turn these into non-impersonating style archetypes such as Discipline, Visionary, Scholar, Commander, Explorer, etc.

---

# 3. Voice System

## 3.1 Speech recognition
**Status:** `IMPLEMENTED historically / needs current production verification`

Capabilities:
- microphone input
- live speech-to-text
- end-of-utterance detection
- restart listening after response
- language detection
- accent tolerance
- interruption
- mute/unmute
- input-level meter
- transcript preview
- correction of likely recognition errors using context
- push-to-talk
- hotkey-to-talk
- noise gate
- optional local recognition

## 3.2 Wake word
**Status:** `PLANNED / historical prototype existed`

Historical phrase: **“Wake up.”**  
Later direction: customizable wake word with **HEY** as the desired default identity.

Settings:
- wake word on/off
- push-to-talk alternative
- hold-to-talk
- keyboard shortcut
- click activation
- wake sensitivity
- false-positive protection
- per-device enablement
- quiet hours
- lock-screen behavior
- accepted speakers if voice recognition exists

**Background behavior:** should work in `F2/F3`, and potentially `F4` where the OS allows microphone background privileges. It cannot be promised from a normal browser tab.

## 3.3 Speech synthesis
**Status:** `PLANNED`

Desired primary direction:
- deep
- calm
- polished
- British male voice

Features:
- multiple voice choices
- one selected primary voice
- speaking speed
- pitch where supported
- emotion/expressiveness
- pronunciation dictionary
- language-specific voice switching
- volume
- whisper/quiet mode
- late-night softer delivery
- accessibility speech rate
- speech queue
- stop/pause/resume
- barge-in: user can interrupt HEY while speaking
- strip Markdown/symbol noise before reading aloud

## 3.4 Voice personality
**Status:** `PLANNED`

Voice can vary slightly by context without becoming a different assistant:
- sharper in morning mode
- softer late at night
- concise during computer control
- slower during tutoring
- more formal in professional tasks
- calmer in stressful contexts

---

# 4. Image Understanding

## 4.1 General image analysis
**Status:** `PLANNED`

HEY should be able to:
- describe an image
- identify visible objects
- explain a diagram
- read visible text
- interpret screenshots
- compare images
- identify layout problems
- analyze charts
- inspect UI screenshots
- find visual inconsistencies
- answer questions about a user-supplied image
- extract structured information from images
- detect approximate colors
- explain photography/composition
- help choose between visual variants
- identify likely visual hierarchy
- inspect product mockups
- inspect generated images for obvious defects

## 4.2 Screenshot understanding
**Status:** `PLANNED`

Inputs:
- manual screenshot
- HEY screenshot command
- selected region
- active window
- full display where permitted

Outputs:
- explanation
- UI guidance
- next-click suggestion
- error identification
- text extraction
- computer-control target map
- accessibility description

## 4.3 Document vision
**Status:** `PLANNED`

HEY can inspect:
- scanned pages
- forms
- diagrams
- handwritten material where recognition permits
- tables
- charts
- page layout
- mixed text/image PDFs

---

# 5. Image Generation

## 5.1 Text-to-image
**Status:** `PLANNED historically / not proven implemented`

Examples:
- “HEY, generate a futuristic product poster.”
- “Make a dark cyan hero image for the HEY landing page.”
- “Generate four logo directions.”
- “Create an illustration of this concept.”

Controls:
- prompt
- negative constraints
- aspect ratio
- resolution
- transparent background
- number of variations
- style
- camera/composition
- lighting
- color palette
- fidelity/detail
- seed/variation lock where provider supports it
- brand palette
- text-safe areas
- visual consistency with references

## 5.2 Voice-to-image
**Status:** `PLANNED`

Same as text-to-image, triggered through natural speech.

## 5.3 Image variations
**Status:** `PROPOSED-CAPABILITY`

- generate similar versions
- preserve composition
- change color palette
- change environment
- change lighting
- change crop
- make more/less realistic
- produce platform-specific sizes
- generate A/B variants

## 5.4 Reference-image generation
**Status:** `PROPOSED-CAPABILITY`

Use one or more user-authorized images to guide:
- style
- composition
- character/object consistency
- brand language
- layout

## 5.5 Transparent assets
**Status:** `PROPOSED-CAPABILITY`

Generate:
- icons
- UI assets
- product cutouts
- stickers
- logos
- overlays
- decorative objects
with transparent backgrounds when provider support exists.

## 5.6 Batch generation
**Status:** `PROPOSED-CAPABILITY`

Generate many variants as a background task:
- ad sizes
- thumbnails
- icons
- campaign variants
- localization variants
- product mockups

**Background behavior:** the job can continue in `F2/F3/F5` if generation is server-side. Results notify the user when ready.

---

# 6. Image Editing

## 6.1 Basic adjustments
**Status:** `PLANNED historically`

HEY should support commands such as:
- change contrast
- brightness
- exposure
- saturation
- temperature
- tint
- sharpness
- blur
- shadows
- highlights
- black point
- white point
- grayscale
- color balance

Historical explicit example: **“HEY, change the contrast of that photo.”**

## 6.2 Geometry
**Status:** `PROPOSED-CAPABILITY`

- crop
- rotate
- flip
- resize
- straighten
- perspective correction
- canvas expansion
- aspect-ratio conversion

## 6.3 Object edits
**Status:** `PROPOSED-CAPABILITY`

- remove object
- add object
- replace object
- move object
- erase background
- replace background
- blur background
- remove distraction
- cleanup artifacts
- recolor selected object

## 6.4 Generative editing
**Status:** `PROPOSED-CAPABILITY`

- inpainting
- outpainting
- extend image edges
- restyle selected region
- preserve subject while changing environment
- change time of day/weather
- create alternate compositions

## 6.5 Quality repair
**Status:** `PROPOSED-CAPABILITY`

- upscale
- denoise
- deblur where possible
- compression cleanup
- color restoration
- old-photo cleanup
- sharpen text/UI screenshots where possible

## 6.6 Brand editing
**Status:** `PROPOSED-CAPABILITY`

- apply HEY/S&A brand palette
- add logo
- safe-area layout
- social-platform crops
- poster/thumbnail typography suggestions
- export multiple variants

---

# 7. Frame Generation and Storyboarding

## 7.1 Single-frame generation
**Status:** `PROPOSED-CAPABILITY`

HEY can generate a precise still frame for:
- product films
- storyboards
- app promos
- trailers
- ads
- UI concept videos

Controls:
- shot type
- focal-length feel
- subject
- environment
- time of day
- lighting
- aspect ratio
- camera height
- camera angle
- depth of field
- motion implication
- text-safe zones

## 7.2 Multi-frame storyboard
**Status:** `PROPOSED-CAPABILITY`

Generate a sequence:
1. opening frame
2. establishing shot
3. interaction
4. transition
5. feature close-up
6. result
7. closing brand frame

Each frame can carry:
- shot number
- duration
- camera direction
- dialogue/voiceover
- animation note
- visual effect
- transition
- sound cue

## 7.3 Character/product consistency
**Status:** `PROPOSED-CAPABILITY`

Maintain consistent:
- person/character
- device
- product
- clothing
- environment
- color grade
- brand details
across storyboard frames where the generation provider supports reference consistency.

## 7.4 Frame interpolation
**Status:** `PROPOSED-CAPABILITY`

Generate intermediate frames or smooth visual transitions between key frames where video/model tooling permits.

## 7.5 UI frame generation
**Status:** `PROPOSED-CAPABILITY`

Create frame-by-frame interface concepts:
- idle
- hover
- press
- loading
- success
- error
- expanded
- minimized
- drag
- gesture feedback

---

# 8. Video Understanding

## 8.1 Uploaded video analysis
**Status:** `PLANNED`

HEY can:
- summarize video
- identify chapters
- extract key moments
- explain scenes
- answer questions
- find specific moments
- create notes
- extract action items
- inspect UI recordings
- identify visual bugs from a screen recording
- create transcript where supported
- create captions
- identify repeated themes

## 8.2 Link analysis
**Status:** `PLANNED`

Historical target:
- TikTok links
- YouTube links

Subject to provider/platform access.

Outputs:
- summary
- main claims
- factual check
- useful ideas
- marketing analysis
- competitor analysis
- comments/community themes where accessible
- timestamped notes where supported

---

# 9. Video Generation

## 9.1 Text-to-video
**Status:** `PROPOSED-CAPABILITY`

Generate short clips from text prompts through connected generation providers.

## 9.2 Image-to-video
**Status:** `PROPOSED-CAPABILITY`

Animate:
- generated image
- product screenshot
- poster
- concept frame
- storyboard keyframe

## 9.3 Storyboard-to-video
**Status:** `PROPOSED-CAPABILITY`

HEY builds:
- shot sequence
- generation prompts
- transitions
- timing
- voiceover
- captions
- sound plan

and sends supported pieces to connected tools/providers.

## 9.4 Video editing
**Status:** `PROPOSED-CAPABILITY`

Potential actions:
- trim
- split
- reorder
- crop
- change speed
- stabilize where supported
- resize for social platforms
- captions
- subtitle translation
- remove silence
- create highlights
- add title cards
- select best clips
- generate B-roll
- color adjustments
- audio ducking
- voiceover insertion
- export presets

## 9.5 Background rendering
**Status:** `PROPOSED-CAPABILITY`

Long renders can continue in `F2/F3/F5` through a worker/cloud service. The main UI does not need to stay open.

---

# 10. Audio and Voice Media

## 10.1 Audio understanding
**Status:** `PROPOSED-CAPABILITY`

- transcribe audio
- summarize meeting/lecture
- speaker separation where supported
- detect silence
- identify action items
- translate speech
- create captions
- clean transcript

## 10.2 Audio cleanup
**Status:** `PROPOSED-CAPABILITY`

- noise reduction
- volume normalization
- trim silence
- clip splitting
- format conversion
- voice isolation where tooling allows

## 10.3 Voiceover production
**Status:** `PLANNED / PROPOSED-CAPABILITY`

- write narration
- synthesize narration with selected HEY/creator voice
- control pace
- pronunciation
- export audio
- align to video timeline

---

# 11. Documents and Files

## 11.1 Upload/read
**Status:** `PLANNED`

Supported categories should include:
- PDF
- DOCX
- TXT
- Markdown
- CSV
- spreadsheets
- slides
- images
- code
- archives where safe
- books/study materials

## 11.2 Document actions
**Status:** `PLANNED / PROPOSED-CAPABILITY`

- summarize
- outline
- answer questions
- extract facts
- compare documents
- translate
- simplify
- rewrite
- create study notes
- create flashcards
- identify missing sections
- identify contradictions
- extract tables
- build timeline
- extract tasks
- create new document
- convert format where supported
- redact selected data
- merge/split documents
- annotate
- generate citations

## 11.3 File management
**Status:** `PLANNED`

- search files
- open files
- rename
- move
- copy
- create folder
- organize folder
- detect duplicates
- inspect size
- find large files
- safe cleanup recommendations
- trash rather than hard-delete where possible
- restore/undo
- batch rename
- project-aware organization

Permissions:
- read vs write separate
- folder-scoped access
- destructive actions require confirmation
- protected/system locations require stronger permission

---

# 12. Coding and Software Engineering

## 12.1 Code understanding
**Status:** `PLANNED / architecture exists`

- explain code
- map repository
- search symbols
- identify architecture
- trace call flow
- find bug
- review code
- explain error logs
- dependency analysis
- security review
- performance review

## 12.2 Code creation
**Status:** `PLANNED`

- create component
- create API route
- create test
- create migration
- create documentation
- refactor
- generate configuration
- build scripts
- database queries

## 12.3 Agentic coding
**Status:** `PLANNED`

Mission:
Goal → inspect → plan → edit → run tests → observe → correct → verify → report.

## 12.4 Build/test control
**Status:** `PARTIAL architecture`

- run tests
- lint
- build
- type-check
- cargo check
- view failures
- retry after fix
- summarize failures

Background:
long-running builds/tests may continue in `F2/F3` if a native execution service remains alive.

---

# 13. Web and Research

## 13.1 Search
**Status:** `PLANNED`

- current web search
- multi-query research
- domain restriction
- recency
- source ranking
- citation
- compare sources
- conflicting evidence
- uncertainty reporting

## 13.2 Deep research
**Status:** `PLANNED`

- create research plan
- gather sources
- verify claims
- produce synthesis
- bibliography
- identify unanswered questions

## 13.3 Competitor intelligence
**Status:** `PLANNED`

- feature comparison
- pricing comparison
- positioning
- reviews
- weaknesses
- differentiators
- launch monitoring
- product updates

## 13.4 Background research mission
**Status:** `PROPOSED-CAPABILITY`

A user can say: “Research this and tell me when you have a complete answer.”

Server-side research can continue in `F5` if architecture supports durable tasks.

---

# 14. Browser Control

**Status:** `PLANNED`

Capabilities:
- open page
- navigate back/forward
- switch tabs
- create tab
- close tab
- search page
- click
- type
- select
- scroll
- download
- upload
- fill forms
- extract page information
- save page
- screenshot page
- open result in HEY widget
- follow links
- compare pages

Safety:
- payment
- account deletion
- sensitive forms
- irreversible submission
- legal acceptance
require stronger confirmation.

Prompt-injection shield:
webpage text is data, not authority.

---

# 15. Desktop / Computer Control

**Status:** `PLANNED / partial architecture`

Capabilities:
- move pointer
- click/double-click/right-click
- drag/drop
- type
- keyboard shortcut
- open application
- close application
- switch application
- minimize/maximize/restore
- move/resize window
- manage multi-monitor windows
- clipboard copy/paste
- take screenshot
- adjust supported system settings
- open file
- search file
- start terminal command
- monitor a long task
- cancel operation

Modes:
- Guide
- Assist
- Act

Background:
some OS automation can continue while the window is minimized, but actions requiring visual state should verify the current screen before acting.

---

# 16. Screen Awareness

**Status:** `PLANNED`

HEY can understand:
- active app
- visible controls
- error dialog
- selected text
- current website
- code editor state
- progress bar
- video controls
- form state
- file explorer
- system settings

Possible user commands:
- “What is this error?”
- “Click the download button.”
- “Explain this page.”
- “Help me finish this setup.”
- “Move this window to my other monitor.”

Privacy:
- explicit permission
- visible indicator
- pause button
- exclude apps/windows
- sensitive-screen mode
- no silent permanent recording

---

# 17. Camera

**Status:** `PLANNED`

Potential capabilities:
- analyze object
- scan document
- read text
- identify scene context
- help low-vision users understand surroundings
- detect gesture
- presence detection
- QR/barcode where supported
- product/room visual assistance

Not default:
- permanent recording
- hidden capture
- biometric storage

Background:
camera analysis should generally stop when HEY is fully closed unless a user explicitly enables a visible special mode.

---

# 18. Gesture Control

**Status:** `PLANNED / exact historical map unresolved`

Proposed production defaults:
- open palm → show HEY / overview
- open palm to fist → grab widget
- fist movement → move widget
- pinch → click/select
- pinch and move → precision drag
- two-hand spread → enlarge
- two-hand pinch → shrink
- swipe left/right → navigation
- swipe down → minimize
- swipe up → restore/expand
- two fingers → pause/resume
- point + pinch → target + activate
- raised hand → interrupt/stop HEY speech
- thumbs up → optional low-risk confirmation
- thumbs down → dismiss/reject
- both palms → leave manipulation/show overview

Customization:
- remap
- train custom gesture
- sensitivity
- hold duration
- handedness
- per-device profile
- per-workspace mapping
- accessibility alternatives
- conflict detection
- test mode

Gestures never override high-risk confirmation policy.

---

# 19. Workspace and Widgets

**Status:** `PLANNED`

Widget actions:
- create
- move
- resize
- overlap
- snap
- pin
- minimize
- maximize
- restore
- close
- group
- stack
- dock
- send behind/in front
- move to another workspace
- move to another display
- move to another device where supported

Widget types:
- chat
- web
- news
- weather
- prayer
- timer
- calendar
- task
- media
- download
- camera
- terminal
- code
- research
- document
- image
- video
- notes
- Cosmos
- agent monitor
- device monitor
- notification center

macOS-like red/yellow/green corner controls were a retained design choice for embedded widgets.

---

# 20. Dynamic Island / Always-On HEY

**Status:** `PLANNED`

Can show:
- listening
- thinking
- speaking
- muted
- timer
- reminder
- active task
- workflow
- agent activity
- download/upload
- research progress
- media
- call/meeting state
- error
- approval request
- background job
- device handoff
- battery/device warning
- prayer countdown
- next event

Can be:
- clicked
- tapped
- expanded
- collapsed
- moved where OS permits
- opened by gesture
- opened by voice

**Closed-app behavior:** this should survive the main window closing through a tray/menu-bar/native helper (`F3`).

Historical predecessor:
- always-on Chrome-extension-style floating widget
- expandable chat from the widget

---

# 21. Notifications, Reminders, Timers and Scheduling

## 21.1 Reminders
**Status:** `IMPLEMENTED historically in prototype / production status unverified`

- one-time
- recurring
- task-linked
- prayer-linked
- calendar-linked
- follow-up callback
- condition-based if server automation exists

## 21.2 Timers
**Status:** `PLANNED`

- countdown
- stopwatch
- focus timer
- Pomodoro
- multi-timer
- named timer
- timer group

## 21.3 Background operation
Timers/reminders should continue in `F2/F3/F4/F5` using OS scheduling and server push rather than depending on an open page.

---

# 22. Proactive HEY

**Status:** `PARTIAL architecture / PLANNED product`

Signals:
- overdue task
- upcoming task
- calendar event
- quiet hours
- routine
- prayer
- focus session
- prolonged inactivity if enabled
- project deadline
- device issue
- failed automation
- weather relevant to user plan
- selected news/topic
- user-defined condition

Controls:
- off
- minimal
- balanced
- proactive
- category toggles
- cooldown
- daily cap
- quiet hours
- “never interrupt me for X”
- “always notify me for Y”
- dismiss
- snooze
- explain why this appeared

---

# 23. Cosmos Memory

**Status:** `PARTIAL architecture`

Memory categories:
- conversation
- short-term
- important fact
- preference
- project
- goal
- people
- pattern
- routine
- decision
- relationship
- learned command
- device preference
- workspace layout
- pronunciation
- style preference
- historical event
- user-created pinned memory

Actions:
- remember
- forget
- edit
- pin
- expire
- search
- summarize
- connect
- rank
- deduplicate
- update
- detect contradiction
- show provenance
- export
- delete
- sync
- restrict scope

Background:
Cosmos sync/indexing may continue in `F3/F5`. Private Session should block long-term write.

---

# 24. Agent System

**Status:** `PARTIAL architecture`

HEY can internally delegate to specialized agents without fragmenting user experience.

Core families retained:
- orchestration
- memory
- research
- software engineering
- security
- computer/browser/files
- voice
- language
- design/product
- workspace
- proactive/productivity
- creative/business
- vision/device
- religious
- specialized domains
- QA/trust
- Forge
- agent infrastructure

Each agent needs:
- purpose
- input schema
- output schema
- allowed tools
- required permissions
- risk level
- model preference
- fallback
- verification
- timeout
- retry policy
- test cases
- health
- version
- auditability

Background:
agent missions that do not require user presence may continue in `F3/F5`.

---

# 25. Forge

**Status:** `PARTIAL architecture / PLANNED UX`

Forge can create:
- agent definitions
- workflows
- skills
- automation
- tool definitions/adapters
- workspace templates
- command packs
- possibly app/document/design artifacts

Forge flow:
request → search duplicates → design → permission manifest → tests → validation → preview → user approval → install → monitor → version/rollback.

Customization:
- private
- team
- selected audience
- public
- version
- permissions
- icon/name
- trigger
- output format
- model
- timeout
- retries
- verifier
- budget

---

# 26. Automations and Workflows

**Status:** `PARTIAL architecture`

Triggers:
- manual
- scheduled
- recurring
- event
- webhook
- device event
- file change
- calendar event
- reminder
- condition
- connected-service event

Steps:
- research
- generate
- transform
- notify
- open
- move
- save
- send where connected/authorized
- call agent
- call tool
- branch
- wait
- verify
- retry
- request approval

Background:
durable workflows should continue in `F5` if server-side.

---

# 27. Device Fabric / Continuity

**Status:** `PLANNED`

Devices:
- Windows PC
- macOS
- Linux
- Android
- iPhone/iPad
- tablet
- TV
- projector
- display
- camera
- wearable
- smart-home device
- vehicle interface where supported

Capabilities:
- discover
- pair
- trust
- revoke
- rename
- assign role
- sync selected context
- hand off active task
- hand off audio
- hand off widget
- route notification
- device health
- online/offline state
- battery
- connectivity
- capability map

---

# 28. Smart Home

**Status:** `PLANNED`

Possible supported actions:
- lights on/off
- brightness
- color
- scenes
- thermostat
- media
- selected plugs
- routines
- supported sensors

Higher-risk:
- locks
- garage
- alarm/security
need stronger confirmation.

Background:
scheduled smart-home workflows may run in `F5` through cloud integrations.

---

# 29. Projector and Ambient Display

**Status:** `HISTORICAL / POSSIBLE FUTURE`

Originally discussed around HY300 projector.

Capabilities:
- high-contrast layout
- large text
- reposition widgets
- desk projection
- ambient dashboard
- voice interaction
- gesture interaction
- presentation mode
- screen mirroring/status
- multi-surface control

---

# 30. Personal Productivity

Features discussed:
- Idea Vault
- People Memory
- Build Journal
- Focus Mode
- Body Double Mode
- The One Thing
- Weekly Honest Mirror
- Morning Briefing
- Evening Summary
- task management
- reminders
- callbacks
- routines
- time management
- peak-performance-hour protection
- time-waste pattern detection
- scattered-notes organizer
- abandoned-project restarter
- decision alignment
- value clarification
- non-negotiables
- goal coaching

---

# 31. Learning and Education

**Status:** `PLANNED`

Capabilities:
- tutor
- explain at chosen level
- quiz
- flashcards
- adaptive questions
- spaced repetition
- study plan
- exam revision
- source-based answer
- Learning Theater
- mind maps
- step-by-step visual breakdown
- story-based learning
- multilingual learning
- dyslexia-friendly layout
- audio-first learning
- accessibility adaptations
- “teach me, don’t answer for me”
- progress tracking

Historical ambitions included education access in low-resource/conflict-zone contexts.

---

# 32. Accessibility

**Status:** `PLANNED`

- blind/low-vision camera description
- screen-reader-friendly UI
- voice-only navigation
- large text
- high contrast
- reduced motion
- keyboard-only use
- dyslexia-friendly mode
- captions
- speech transcript
- sign-language interpretation as a long-term vision
- non-native professional communication support
- simplified language
- cognitive-load reduction
- customizable gesture alternatives

---

# 33. Language and Localization

**Status:** `PLANNED`

- English
- Kurdish
- Arabic
- RTL
- language detection
- translation
- pronunciation
- locale-aware dates/times
- locale-aware number/currency
- culturally aware humor
- culturally fluent responses
- code-switching
- multilingual voice/chat
- user-defined preferred language by context

---

# 34. Religious / Islamic Utilities

**Status:** `PLANNED / user-configured`

- prayer times
- countdown
- 10-minute warning
- Quran verse
- Quran lookup
- Hadith lookup
- Islamic calendar
- religious research with source verification
- Dua companion
- worship habit support
- New Muslim learning path
- faith reconnection support
- scholar connector concept

Sensitive religious questions should distinguish sourced information from interpretation and avoid pretending HEY itself is a scholar.

---

# 35. Business and Entrepreneurship

**Status:** `PLANNED / PROPOSED-CAPABILITY`

- idea validation
- business plan
- competitive intelligence
- market research
- customer research
- sales strategy
- pricing analysis
- launch plan
- experiment ledger
- financial planning
- operations
- customer support drafts
- marketing
- social content
- trend research
- manufacturer/vendor research
- grant/opportunity search
- capability portfolio/CV alternatives
- startup weekly review
- KPI dashboard from real data

---

# 36. Creator Tools

**Status:** `PLANNED / PROPOSED-CAPABILITY`

- content ideas
- script
- hook
- title
- thumbnail concept
- image generation
- photo edits
- storyboard
- frame generation
- video plan
- voiceover
- captions
- repurposing
- brand memory
- design critique
- social-post variants
- content calendar
- analytics interpretation
- audience-feedback summary

---

# 37. Health and Wellbeing Information

**Status:** `PLANNED, safety-sensitive`

Potential non-diagnostic capabilities:
- general health information
- medication reminder
- appointment reminder
- sleep routine tracking
- movement/water/eye reminders
- explain medical terms/documents
- prepare questions for a clinician
- summarize records provided by user
- accessibility support

Historical feature ideas included more ambitious detection claims such as burnout, depression/stress cues, Alzheimer detection, genetic risk, and illness detection. These should **not** be treated as reliable diagnoses. Production design must use conservative language and proper evidence.

---

# 38. Legal / Rights Information

**Status:** `PLANNED, high-stakes informational`

- plain-language legal-document explanation
- rights information
- summarize terms/contracts
- identify questions to ask a qualified professional
- jurisdiction-aware research where possible
- documentation organization

HEY should not impersonate a lawyer or guarantee legal outcomes.

---

# 39. Relationship and Communication Support

Historical/planned ideas:
- apology drafting
- difficult-conversation planning
- long-distance family connection ideas
- relationship-pattern reflection
- stepfamily navigation
- parent/teen communication
- attachment-style educational information
- rebuilding identity after unhealthy relationships
- conflict de-escalation guidance

These should remain non-diagnostic and avoid claiming certainty about other people’s motives.

---

# 40. Safety-Oriented Features

Historical concepts included:
- domestic-safety code word
- child-safety danger-sound detection
- emergency eye-movement trigger
- dangerous-area alerts
- harassment documentation
- whistleblower reporting support
- child-abuse documentation support

These are **safety-critical** and must never pretend an alert/report was delivered unless verified. They require dedicated legal, privacy, false-positive, abuse-resistance, and emergency-routing design.

---

# 41. Community and Matching

**Status:** `HISTORICAL / UNRESOLVED`

Discussed ideas:
- HEY community matchmaking
- random user matching
- mentor matching
- elderly-young mentor exchange
- homeschool peer connection
- creator collaboration
- skill trading
- founder/manufacturer/funder connectors
- specialist connectors

If revived, these need:
- consent
- moderation
- blocking/reporting
- age controls
- location/privacy protection
- anti-abuse systems

---

# 42. Offline HEY

**Status:** `PLANNED`

Offline-capable subset:
- wake word
- local commands
- timers
- reminders
- cached notes/memories
- local file search
- local knowledge pack
- selected on-device speech recognition
- selected on-device TTS
- basic computer control
- cached prayer times where calculated safely
- queued tasks
- lightweight local model if hardware permits

Historical ambition: useful even on very low-cost devices.

---

# 43. Customization

Users should be able to customize:

### Appearance
- theme
- accent
- background
- glass amount
- transparency
- contrast
- text scale
- density
- radius
- widget shadows
- animation level
- reduced motion
- wallpaper/environment
- natural vs futuristic visual intensity

Historical note: a 23-theme concept existed, but the exact list was not retained.

### Voice
- primary voice
- speed
- pitch
- expressiveness
- language
- wake word
- interruption sensitivity
- push-to-talk shortcut

### Personality
- verbosity
- humor
- directness
- encouragement
- challenge level
- preferred modes
- formality
- how HEY addresses the user

### Workspace
- dock location
- dock size
- controls
- widget defaults
- snap strength
- overlap
- saved layouts
- startup workspace
- compact/expanded Dynamic Island
- per-device layout

### Gesture
- sensitivity
- handedness
- mapping
- custom gestures
- per-device profiles
- accessibility substitutes

### Proactivity
- quiet hours
- suggestion level
- categories
- daily cap
- interruption rules
- notification devices

### Memory
- what to remember
- what not to remember
- retention
- project isolation
- sync
- private sessions
- export/delete

### Permissions
- per tool
- per agent
- per workflow
- per device
- one-time
- session
- persistent
- revoke
- audit

---

# 44. Always-On and Closed-App Capability Matrix

| Capability | Foreground | Minimized | Main window closed + helper | App terminated | Offline |
|---|---:|---:|---:|---:|---:|
| Text chat | Yes | No direct UI | via mini-widget | No local UI | Yes if local model |
| Wake word | Yes | Yes | **Yes, desired** | No | Yes if local |
| Voice reply | Yes | Yes | Yes via helper | No | Yes if local TTS/model |
| Reminders | Yes | Yes | Yes | **Yes via OS/server** | Yes via OS |
| Timers | Yes | Yes | Yes | OS-dependent | Yes |
| Dynamic Island | Yes | Yes | **Yes** | No | Yes |
| Background research | Yes | Yes | Yes | **Yes server-side** | No, unless local sources |
| Cloud image generation | Yes | Yes | Yes | **Yes server-side** | No |
| Cloud video generation | Yes | Yes | Yes | **Yes server-side** | No |
| Local file indexing | Yes | Yes | Yes | No | Yes |
| Cosmos cloud sync | Yes | Yes | Yes | server may continue | No network sync |
| Scheduled automation | Yes | Yes | Yes | **Yes server-side** | local-only schedules possible |
| Smart-home cloud routine | Yes | Yes | Yes | **Yes server-side** | depends on local hub |
| Computer control | Yes | Yes with verification | limited, explicit mission | No | Yes locally |
| Continuous screen awareness | Yes | explicit background only | normally **No** | No | Yes if local |
| Camera/gestures | Yes | explicit background only | normally **No** | No | Yes if local |
| Media playback | Yes | Yes | Yes | OS-dependent | Yes |
| Downloads/uploads | Yes | Yes | Yes with worker | server-side/cloud possible | local transfers only |
| Notifications | Yes | Yes | Yes | **Yes via OS/push** | local notifications yes |
| Calendar monitoring | Yes | Yes | Yes | **Yes server-side** | cached/local limited |
| Device health | Yes | Yes | Yes | server/other device may continue | local yes |
| Cross-device handoff | Yes | Yes | Yes | other devices/server | needs network unless local LAN |
| Prayer reminders | Yes | Yes | Yes | OS scheduled | Yes if times cached/calculated |

---

# 45. Security and Permission System

**Status:** `PARTIAL / VERIFIED foundations`

Rules:
- authenticated identity required
- server-authoritative plan/entitlements
- client cannot elevate itself
- fail closed
- explicit permission
- risk classification
- high-risk confirmation
- critical restrictions
- audit
- founder/admin does not bypass core safety/security
- no unrestricted DAN mode
- prompt-injection resistance
- minimum necessary context
- scoped tool credentials
- secret isolation
- Tauri bridge hardening
- Supabase RLS
- Edge Function auth
- revocation
- rate limiting
- abuse prevention

---

# 46. Trust Center

**Status:** `PROPOSED-CAPABILITY`

One place to see:
- active microphone
- active camera
- active screen access
- connected accounts
- connected devices
- permissions
- agents with authority
- workflows
- recent sensitive actions
- stored memory categories
- cloud vs local processing
- security warnings
- failed logins/actions
- revoke-all connections
- export/delete data

---

# 47. Privacy Modes

**Status:** `PROPOSED-CAPABILITY`

**Local Mode**  
Prefer local processing.

**Private Session**  
Do not write long-term Cosmos memory.

**Sensitive Screen**  
Pause screen/camera capture and related memory.

**Guest Mode**  
Prevent guest interactions from contaminating personal memory.

**Presentation Mode**  
Hide private notifications/memory while sharing screen/projector.

---

# 48. Developer / API Capabilities

**Status:** `PLANNED / UNRESOLVED`

Potential developer surfaces:
- personal API
- webhooks
- scoped tokens
- agent SDK
- tool SDK
- workflow definition
- custom integration
- event subscriptions
- local plugin
- MCP-style adapters
- capability manifest
- test harness
- agent simulator
- audit logs
- usage metrics

Historical note: API access was at times considered a separate product rather than a normal subscription entitlement.

---

# 49. Diagnostics and Self-Repair

**Status:** `PROPOSED-CAPABILITY`

HEY Health can test:
- provider availability
- API credentials
- database
- memory
- microphone
- speaker
- camera
- wake word
- notifications
- permissions
- Tauri/native bridge
- browser automation
- OS tools
- device pairing
- network
- storage
- agent registry
- workflows
- background worker

It can:
- explain failure
- propose fix
- retry
- collect privacy-scrubbed diagnostics
- detect recurring failures
- disable unsafe broken automations

---

# 50. Error and Failure Behavior

Every capability needs:
- loading
- success
- partial success
- failure
- offline
- permission denied
- provider unavailable
- timeout
- cancelled
- stale data
- unsupported platform
- ambiguous target
- verification failed

HEY should state exactly what happened and what remains possible.

---

# 51. Historical 200-Feature Archive

This list is preserved because it was explicitly discussed. It is **not** a claim that these features are currently implemented.

## Historical built/prototype items 1–14
1. Voice recognition with wake word
2. Chat widget
3. API connection via OpenRouter
4. Open website tool
5. Save idea tool
6. Get ideas tool
7. Set reminder tool
8. Idea Vault via localStorage
9. Mute/unmute system
10. Mic audio visualizer
11. Plasma ring visualizer
12. Contour background animation
13. Speaking energy animation
14. Muted/unmuted label

## Historical short-term 15–28
15. Updated personality system prompt
16. Multilingual voice and chat
17. ElevenLabs voice integration
18. Full memory between sessions
19. Screen awareness
20. Camera input
21. Offline mode
22. Separate chat page
23. Status text display
24. Clock/date on screen
25. Quick action buttons
26. Smaller circle option
27. Auto-restart recognition after speaking
28. Learning Theater page

## Historical long-term 29–200
29. HEY community matchmaking
30. Mental-health detection concept
31. Medication reminders for elderly users
32. Blind assistance
33. Student tutor mode
34. Grief companion
35. Domestic-safety code-word concept
36. Refugee navigator
37. Farmer intelligence
38. Child-safety sound-detection concept
39. Video/link review
40. File/document upload
41. Image generation
42. Photo editing commands
43. Legacy mode — letters to future children
44. Loyalty levels
45. Night-mode personality
46. Mood system based on time/patterns
47. HEY learns from each user over time
48. Neuroscience explanations
49. Islamic wisdom integrated naturally
50. Real-time web search
51. Dua companion mode
52. Istikharah guidance
53. Audio learning for blind users
54. Sign-language interpreter
55. Autism social-navigation earpiece concept
56. Grief memory vault
57. Fake-motivation detection
58. Last-resort crisis-support mode
59. Burnout early-detection concept
60. Toxic-relationship pattern reflection
61. Gaslighting-pattern reflection
62. Workplace-bullying documentation
63. Salary-negotiation coach
64. First-job mentor matching
65. Dead-end-job career pivot tool
66. Skill-to-income converter
67. Debt navigator
68. Financial literacy for unbanked users
69. Predatory-product detector
70. Grant/unclaimed-money finder
71. Prison-reentry life rebuilding support
72. Whistleblower safe-reporting concept
73. Information access for oppressive environments
74. Refugee-to-employer matching
75. Small-farmer global market access
76. Unused-food-to-people connector
77. Elderly-young mentor matching
78. Cultural-heritage preservation
79. Rural-opportunity equalizer
80. Local-problem-to-funded-solution platform
81. Apology-letter writer
82. Avoided-conversation guide
83. Estranged-family reconnection support
84. Long-distance family connection
85. Stepfamily navigation
86. New-parent first-year guide
87. Teenager-parent understanding tool
88. Identity rebuilding after toxic relationship
89. Attachment-style education
90. Generational-trauma pattern reflection
91. Purpose discovery through conversation
92. Confidence building
93. Value clarification
94. Decision alignment with future self
95. Abandoned-project restarter
96. Scattered-notes organizer
97. Peak-performance-hours protector
98. Time-waste pattern detector
99. Life-trajectory reflection based on habits
100. Idea-validation tool
101. Business-plan generator
102. Intellectual-property protection guidance
103. Bold-idea funding connector
104. Manufacturer/designer connector
105. Global-problem-to-solution connector
106. Skill-trader platform
107. Story-based learning for any subject
108. Conflict-zone education access concept
109. Homeschool peer connector
110. Legal-document plain-language translator
111. Legal-rights explainer
112. Medical-diagnosis/terminology translator
113. Rare-disease researcher connector
114. Food-relationship recovery support concept
115. Chronic-pain community connector
116. Alzheimer early-detection concept
117. Voice stress/depression/illness detection concept
118. Therapy-session understanding tool
119. Cultural mental-health plans
120. Night-shift health manager
121. Genetic-health-risk explainer
122. Healthcare-dismissal navigator
123. Radicalization early-intervention concept
124. Child-abuse documentation support concept
125. Scam-victim recovery
126. Eye-movement emergency-system concept
127. Women’s safety mapping concept
128. Dangerous-area community alerts
129. Online-harassment documentation
130. Corruption safe-reporting concept
131. Police-rights explainer
132. Life-story book generator
133. Family-history documenter
134. Traditional-skill elder-to-youth platform
135. Creative cross-country collaboration
136. Invisible-genius identifier concept
137. Field-visibility builder
138. Public-failure comeback guide
139. Pain-to-purpose reflection
140. Legacy Builder
141. Capability-proof alternative to CV concept
142. World-class education access concept
143. Offline developing-world version
144. HEY for every language
145. Culturally fluent responses
146. Islamic scholar connector
147. New Muslim learning path
148. Faith reconnection without judgment
149. Consistent worship builder
150. Real-time web awareness
151. Always-on Chrome extension widget
152. Desktop Electron-app version (historical; later native direction moved toward Tauri)
153. Remember first conversation forever concept
154. Forget memories that no longer serve user
155. Breaking-point system
156. Silence feature
157. Unprompted prayer/dua-support concept
158. Detect-user-is-not-okay concept
159. Different voice for situations
160. Celebrate wins
161. Hold user accountable to commitments
162. Apologize when wrong
163. AI debate partner
164. Personal board-of-directors mode
165. Discipline archetype mode
166. Visionary archetype mode
167. Scholar wisdom mode
168. Roast/motivational accountability mode
169. Motivational mode
170. Crisis-support mode
171. HEY for children in conflict zones concept
172. Offline HEY for very low-cost devices
173. Real-time screen help
174. Photo contrast/edit commands
175. Image generation from voice
176. TikTok/YouTube link analysis
177. PDF/book upload and analysis
178. HEY community random-user matching
179. Learning Theater visual explanation page
180. Mind-map generation
181. Step-by-step visual breakdowns
182. Quick-action buttons
183. Recent-command history display
184. Always-on floating widget
185. Expandable chat from widget
186. Family accounts
187. Direct support for highest paid tier concept
188. Early feature access
189. Multiple AI modes
190. HEY growing with user over years
191. Ten-year memory reflection
192. Notice patterns the user misses
193. Wait for the right moment to share insight
194. Avoid repeating itself unnecessarily
195. Culturally aware humor
196. Late-night soft mode
197. Morning sharp mode
198. Know when to simply be present
199. Dyslexia-friendly learning mode
200. Professional communication help for non-native speakers

---

# 52. New Capabilities Added in This Catalog

These were not all explicitly discussed before and are therefore `PROPOSED-CAPABILITY`:

- text-to-video
- image-to-video
- storyboard-to-video
- frame interpolation
- multi-frame storyboard consistency
- generative inpainting/outpainting
- transparent asset generation
- batch visual generation
- audio cleanup
- universal action receipts
- context capsules
- HEY Replay
- privacy modes
- Trust Center
- local file intelligence
- project snapshots / Time Machine
- provider-health dashboard
- self-diagnostics
- multi-surface orchestration
- personal API tokens
- prompt-injection shield
- contextual feature discovery
- reversible/undo-first action philosophy
- automation reliability scoring
- hardware-adaptive performance
- semantic workspace drag/drop relationships
- live artifacts
- memory inbox
- context firewall
- background render/research workers
- capability availability matrix

---

# 53. Final Product Rule

The final product should be enormous in capability but **not enormous in visible complexity**.

The user should be able to say things naturally:

- “HEY, make this photo brighter.”
- “HEY, generate the next frame.”
- “HEY, turn these frames into a storyboard.”
- “HEY, research this while I’m gone.”
- “HEY, remind me even if I close the app.”
- “HEY, keep listening after I minimize you.”
- “HEY, move this widget over there.”
- “HEY, make this into a presentation.”
- “HEY, open that app.”
- “HEY, explain what is on my screen.”
- “HEY, continue this task on my tablet.”
- “HEY, remember this only for this project.”
- “HEY, don’t remember this conversation.”
- “HEY, build me an agent that does this every Friday.”
- “HEY, tell me exactly what you changed.”

Underneath, HEY may use dozens of agents, tools, providers, permissions, background workers, local models, cloud services, device adapters and verification steps.

On the surface, it remains one HEY.

> **Tell me what you seek. I’ll help you make it so.**


---

