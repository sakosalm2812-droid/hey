# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---

