# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---

