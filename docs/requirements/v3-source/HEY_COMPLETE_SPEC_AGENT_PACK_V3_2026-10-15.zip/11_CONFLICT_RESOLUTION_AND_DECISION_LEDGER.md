# HEY — EXPLICIT DECISION/CONFLICT LEDGER (2026-10-15)

This is a working contract, not a claim to know inaccessible private conversations. All proposed resolutions below follow the visible user's stated priorities and available dated sources. The coordinator must verify newer signed decisions and record overrides with citations.

| Topic | Older rule | Effective rule and implementation consequence |
|---|---|---|
| Post-login page | Dashboard or conversation in different archived drafts | **Chat/Voice Conversation Surface** by default; customizable startup; Home/Tools/Spaces/Activity/Settings discoverable. |
| HEY scope | 4,210 historical ledger referenced; 1,460 numbered Bible inventory | Not arbitrary count of visible features. Preserve all approved behavior; inventory includes 229 internal agent roles and historical items. Trace it without inventing 4,210 details. |
| Specialist agents | Exactly 229 built-ins | Historical seed roster; newer unlimited Agent Foundry may create specialists as useful, loaded on demand. 229 are not individual user chatbots. |
| Models | Every specialist a distinct LLM | 75 logical roles; minimum shared pretrained model fleet, tools and scoped adapters, with specialist weights only if evaluation justifies them. |
| Local AI | Complete massive model on laptop | Lightweight HEY Edge for native actions; large model inference hosted/remotely or chosen local inference; no false claims 8 GB machines can serve very large checkpoints. |
| Model ownership | 400B/10T claims in promotional ideas | HEY One only claims verifiably owned adapters/orchestration; third-party model foundation provenance retained; speculative parameter targets not marketed as trained weights. |
| UltraSparse latency | Under 1ms vague total response | Under 1ms p95 **in-process expert selection**, on specified benchmark hardware where achievable; full end-to-end latency measured separately. |
| Fusion | Always run many models | Cost/quality-driven routing; parallel deliberation only for tasks that warrant it; signed device mandates unaffected by model choice. |
| Onboarding | Fixed restricted modes | Multi-select intents personalize starting layout only; cross-category Tool Library available subject to real entitlements/permissions. |
| Teacher Mode | Generic school chatbot | Complete teacher tools, organization isolation, editable exports, smartboard gestures; only synthetic pupil data until school consent and review. |
| Widgets | Static dashboard decorations | Functional Living Answers + persistent widgets across Chat/Voice/Spaces, typed actions, sandboxed generated mini-apps. |
| Completion | Unit tests/feature flags/registry entries | Real UI + backend + services + security + native device test as applicable + independent outcome verification. |
| Release schedule | Sept 15 then Oct 15 target | Those are past goals, not evidence of present readiness. New release requires independent gate; no invented date/guarantee. |
| Budget | Free-only or no limit | Initial $25–50/mo total, no unapproved purchases or dedicated GPU expense; managed services usage capped. |
| Open-source core | Open-source ecosystem aspirations | Closed-source HEY core; supported API/SDK and vetted extensions; model licensing respected. |
| Evolution/autonomy | Autonomous self-upgrade without oversight | Research and owner approvals governed by original three-owner rules; critical security emergency logic follows verified policy and auditable rollback. |
| Dynamic Island | React-only overlay | Native helper overlay where OS legitimately permits; PWA alone cannot simulate persistent native overlay. |
| Chat and Voice | Separate experiences | One conversation and Brain, different modality presentation. |
| School payments | Automatic full subscription assumption | Iraqi merchant eligibility is not assumed; provider-independent entitlement state, legal adult/business representation and verifiable payment provider arrangements. |

## Open questions that cannot be fabricated

Final domain/organization hosting accounts, school data-sharing agreement, supported smartboard camera model, OS-specific native entitlement permissions, signed app distribution, actual model-provider pricing/availability on enrollment, owner identities and admin provisioning, full historical 4,210-item ledger and inaccessible prior conversations. Document as `DECISION_REQUIRED` or `EXTERNAL_BLOCKER`, never resolve by hallucination. Continue unrelated implementable work.

## Decisions approval protocol

`proposal` is not `approved`; store `candidate → reviewed → approved/rejected → implemented → independently verified`, linked to the user's actual approval message or signed administrator decision. A newer decision only supersedes the conflicting dimensions of earlier ones. Later model-generated engineering ideas remain recommendations until approved, unless they are necessary technical implementation details within an approved feature and its safety/quality contract.
