# HEY ONE + FUSION + COMPLETE SPECIALIST MODEL FLEET

## M00. What “our own AI model” means in engineering terms

A **capability role** (Coder, Editor, Presenter, Tutor, etc.) is not automatically a separately trained neural network. HEY should maintain *logical specialist contracts* and select the least costly reliable realization: deterministic algorithm, constrained prompt/tool schema, a licensed hosted model, a dedicated open-weight fine-tuned adapter, or a full separately trained model only when cost/evaluation warrants it. Otherwise 60 specialist models would create high GPU bills, version drift and inconsistent permissions. Do not mislead users by branding APIs as weights that S&A owns; differentiate `HEY One branded routing`, `HEY One adapted model checkpoint`, `licensed third-party foundation`, `S&A-trained adapter` and `S&A-trained-from-scratch model`.

HEY One initially = strongest legally usable foundation chosen through benchmarks + adapted LoRA/QLoRA specialists + system tool orchestration + verified memory/retrieval/action layer. Fine-tuning improves an existing foundation; retrieval changes the evidence available at inference; tooling performs actual actions; hard permission rules are enforced outside the model. A model should never be the sole authority for security or payments. Private proprietary third-party APIs do not give ownership of their weights, and their outputs are not automatically authorized training data.

## M01. Where to obtain genuine weights — verified starting points as of 2026-10-15

**Model acquisition portal:** https://huggingface.co/models and the **original publisher's model card**, not arbitrary Telegram links or unofficial repacks. Download by exact repo ID and pinned revision/commit, retain SHA-256, model card, license, README, dependencies, allowed uses and attribution. Some model cards are gated and require individual account approval. Re-check current card, model revision and rights before commercial use, redistribution or training; a model-hosting website's availability is not licensing permission.

| Model / family (candidate, not deployed) | Official source | Role / why evaluate | Public card license observation / caveat |
|---|---|---|---|
| Qwen3-8B | https://huggingface.co/Qwen/Qwen3-8B | multilingual general Brain, reasoning/router, base for specialist adapters | Apache-2.0 on publisher card (verify pinned version) |
| Qwen3-Coder-30B-A3B-Instruct | https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct | code creation, refactor, test generation, repair | Apache-2.0 on publisher card; large total weights demand suitable server memory |
| OpenAI gpt-oss-20b | https://huggingface.co/openai/gpt-oss-20b | open-weight reasoning/tool use; compare vs Qwen | Apache-2.0 plus applicable use policy; do not call it an API-hosted OpenAI model |
| OpenAI gpt-oss-120b | https://huggingface.co/openai/gpt-oss-120b | high-end remote hosted/open-weight reasoning candidate | Apache-2.0 plus applicable use policy; far outside small local laptop capacity |
| Qwen3-Embedding-0.6B | https://huggingface.co/Qwen/Qwen3-Embedding-0.6B | memory/document vector search | Apache-2.0 on publisher card |
| BAAI bge-m3 | https://huggingface.co/BAAI/bge-m3 | multilingual dense/sparse lexical retrieval benchmark | MIT on publisher card; evaluate Kurdish recall explicitly |
| Whisper large-v3-turbo | https://huggingface.co/openai/whisper-large-v3-turbo | cloud/server speech transcription benchmark | MIT on publisher card; language accuracy must be measured |
| Kokoro-82M | https://huggingface.co/hexgrad/Kokoro-82M | economical English speech synthesis candidate | Apache-2.0 on publisher card; voices have separate ethical/usage review |
| pyannote community diarization | https://huggingface.co/pyannote/speaker-diarization-community-1 | speaker turns/diarization where necessary | CC-BY-4.0 published; gated access and separate downstream obligations |
| FLUX.1-schnell | https://huggingface.co/black-forest-labs/FLUX.1-schnell | image-generation foundation candidate | Apache-2.0 published; gated acceptance, check separate conditioning/adapters |
| SAM2.1 Hiera Tiny | https://huggingface.co/facebook/sam2.1-hiera-tiny | image/video masks and visual tracking | Apache-2.0 on publisher card |
| PaddleOCR-VL-1.5 | https://huggingface.co/PaddlePaddle/PaddleOCR-VL-1.5 | document/page/layout/OCR extraction candidate | Apache-2.0 on publisher card; custom-code loading and deps require audit |
| Helsinki English→Arabic OPUS | https://huggingface.co/Helsinki-NLP/opus-mt-en-ar | translation baseline where language pair supported | Apache-2.0 publisher card; assess quality instead of assuming it solves Sorani |

**Not automatically selected:** Gemma/Llama/Mistral families may offer attractive quality but terms differ; specific FLUX dev/pro, audio cloning and commercial video/music models may have narrower licensing and explicit restrictions. Unverified families such as Wan, Qwen VL/TTS or newer releases remain candidate searches only until publisher card/model artifact/license are confirmed. Do not invent license terms.

**Official acquisition and training references:**
- Model cards/licensing: https://huggingface.co/docs/hub/model-cards
- Gated access: https://huggingface.co/docs/hub/models-gated
- Hugging Face CLI: https://huggingface.co/docs/huggingface_hub/guides/cli
- Transformers: https://huggingface.co/docs/transformers
- TRL SFT/PEFT/LoRA/QLoRA: https://huggingface.co/docs/trl/peft_integration
- Unsloth: https://unsloth.ai/docs/get-started
- Diffusers training: https://huggingface.co/docs/diffusers/training/overview
- vLLM OpenAI compatible serving: https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/
- llama.cpp: https://github.com/ggml-org/llama.cpp
- Ollama: https://docs.ollama.com/
- MediaPipe hand detection: https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker

**RECOMMENDATION:** Organize model artifacts in a licensed private registry, containing `repo_id`, `revision`, `artifact_sha`, `architecture`, `role`, `context_limit`, `modalities`, `languages`, `license`, `allowed_commercial_use`, `license_review_date`, `dataset provenance`, `tool reliability`, `quantization`, `runtime`, `RAM/VRAM requirements`, `per-token cost`, `latency p50/p95`, `evaluation score`, `fallback`, `rollback`, `approval status`. Never copy training data or API keys into a model repo accidentally.

## M02. Model training/adaptation is an evaluation-driven pipeline, not a model-count race

### Step-by-step acquisition

1. Define one specialist output contract, target users, input language/mode, allowed tools, required factual/procedural correctness and latency/cost budget.
2. Build 100–1000 representative **licensed and consented** evaluation cases before training, including English/Sorani/Arabic where appropriate, ambiguous/malicious inputs, realistic failure cases and counterfactual consistency tests. Separate public and private datasets; no real pupil records for experimental model training.
3. Benchmark 2–4 foundation candidates zero-shot/few-shot, then with deterministic tools/retrieval. If baseline + scaffolding meets acceptance, **do not train** a separate model simply for branding.
4. If a measurable gap remains, acquire publisher original weights, pin revision/hash/license and run a secure weight-loader vulnerability/dependency review. Prefer `safetensors` when available, avoiding blindly executing model repo code or pickle checkpoints.
5. Prepare role-focused dataset. Clean, de-identify, deduplicate, verify provenance, separate train/dev/test by project/user and time, remove test leakage. Example supervised records contain `messages` with explicit role and permitted structured tool plans, not model hallucinated success receipts.
6. Fine-tune LoRA (e.g. r=16/32, alpha adapted to rank, dropout, bf16, gradient checkpointing where supported); use QLoRA 4-bit for feasible GPUs and model/runtime compatibility. Treat parameter values as tuning *starting points*, not universal best settings. GPU must have headroom for gradients/optimizer/KV/sequences, not just weight sizes. The 8GB laptop is NOT a suitable platform for broad full-model training.
7. Compare new adapter against frozen base on blind task-level evaluation, red-team security and regression suite. Require measurable improvement, confidence intervals and no material deterioration in tool/authorization behavior.
8. Optional preference optimization (DPO/RL) only with qualified pairwise examples/reward specifications; never train a model to falsely claim tasks completed or to bypass policy. Never teach real secrets or private user memory into model weights without specific lawful permission and deletion plan.
9. Produce versioned adapter artifacts, reproducible configs, exact dataset versions/consent ledger, training metrics, eval results, model card and rollback. Export/merge only if license, dtype and adapter-runtime support allow it; keep original immutable checkpoint.
10. Deploy canary to limited user segment through service API, profile p50/p95, tool correctness, feedback and cost; instant rollback. A promoted model must be shown to outperform incumbent under production-relevant conditions, not based on benchmark cherry-picking.

### Concrete acquisition commands (illustrative, run only with licensed access and sufficient disk)

```bash
python -m pip install --upgrade huggingface_hub
hf auth login
# Replace REVISION_SHA with the validated commit ID from the publisher card.
hf download Qwen/Qwen3-8B --revision REVISION_SHA --local-dir ./models/qwen3-8b
# Verify artifact manifests/SHA-256 and run license/dependency checks BEFORE loading.
```

For no-account public artifacts `hf auth login` may be unnecessary; gated access requires valid publisher-approved credentials. Use service tokens stored in a secrets manager, not shell history, for automation. Do NOT try to download 8B/30B/120B models onto an almost-full weak laptop just because the CLI command exists; send this work to funded remote GPU infrastructure. If using `.safetensors`, still audit config, tokenizer, custom code, weights origin and dependency versions.

### Dataset example (format contract; synthetic example only)

```json
{"messages":[{"role":"system","content":"You are HEY Code Editor. Propose minimal verifiable patches; never claim tests ran without tool results."},{"role":"user","content":"Change only the login button label from Enter to Sign in."},{"role":"assistant","content":"{\"operations\":[{\"type\":\"edit\",\"target\":\"LoginButton\",\"scope\":\"text_only\",\"value\":\"Sign in\"}],\"verification_needed\":[\"UI renders new label\",\"all other DOM behavior unchanged\"]}"}]}
```

Dataset annotation must include the exact before/after artifact, preservation constraints, failed examples, evaluator label, permission and proof of requested outcome. A model's generated JSON proposal is *not* an authorization or executed side effect; a trusted code/tool runtime executes and verifies.

### Training configuration example (starting point, not a completed training job)

```yaml
run_name: hey-coder-editor-lora-v0
base_model: Qwen/Qwen3-Coder-30B-A3B-Instruct # candidate; VRAM must be available
base_revision: REQUIRED_PINNED_SHA
training_method: QLoRA
peft:
  method: lora
  rank: 16
  alpha: 32
  dropout: 0.05
quantization: nf4_4bit_if_supported
gradient_checkpointing: true
train_data: s3://private-datasets/hey-code-editor/train-v0.jsonl
validation_data: s3://private-datasets/hey-code-editor/validation-v0.jsonl
test_data: s3://private-datasets/hey-code-editor/blind-test-v0.jsonl
security:
  secrets_in_data: forbidden
  student_data_in_data: forbidden
  cross_tenant_samples: forbidden
  tool_authority_from_model: forbidden
promotion:
  code_patch_preservation_must_improve: true
  no_critical_security_regressions: true
  required_independent_evaluation: true
  rollback_revision_required: true
```

Training scripts must be pinned to actual current Transformers/TRL/PEFT API versions; example configuration is intentionally declarative rather than an unverified copy-paste script. Consider Unsloth only when hardware/kernel compatibility and benchmark justify. For image adapters use Diffusers official task-specific LoRA scripts after license verification. For TTS, training a cloned voice is permitted only with verified speaker consent and correct voice rights; don't use scraping or unconsented impersonation.

### Required data assets and eval harness per specialist

- Model card: model/version/base/license/training lineage/intended uses/known limitations/languages/performance/energy and cost.
- Gold dataset: examples labeled by domain experts, realistic target actions and expected state checks.
- Training split and blind holdout, data rights, ownership, deletion/retraining policy.
- Quality metrics *per role*: e.g. unit-test pass + patch diff size for code, edit preservation for design, OCR field accuracy, teacher factual accuracy, TTS intelligibility, gesture false-activation per hour.
- Hard security gates: tenant leakage, instruction-in-data attack, invalid tool invocation, refusal to invent receipts, malicious content processing, privacy compliance.
- Runtime metrics: accuracy/precision/recall as appropriate, success@k, latency, tokens, GPU memory, throughput, cold start, concurrency, pricing and routing confidence.
- A/B evaluation: compare one model role against shared base+prompt/tool/retrieval baseline; retire role if no measured benefit.

### Provider/hosting separation

`Provider Model API` ≠ `Licensed Open Weights` ≠ `Trained Adapter` ≠ `Hardware Execution Engine` ≠ `HEY Agent`.

A provider may host Qwen/gpt-oss/other permitted foundation and return a model response, but **provider access does not make its weight files available for editing**. HEY can fine-tune the original open weights if license/training rights permit and separately host the result on GPUs later, or use provider-supported fine-tuning of that provider's endpoint. Adaptation is not performed by “editing a prompt and renaming the API model”. Routing/Tools/Memory give a branded experience without false claims of underlying weight ownership.

With $25–50 monthly infrastructure and ~$12 of prepaid AI credits, use low-cost hosted calls and tiny classifiers, no always-on dedicated GPU, no unbounded high-end video generation, and no promise of full-model training. Research/finetuning should run only when separately approved GPU credits/funding exists. Key issuance, usage caps and multi-request spend reservations are part of deployment.

## M03. Model selection / router and self-hosted serving

Model Router input: `task_type, modality, language, risk, complexity, required_context, tool_requirements, budget_remaining, latency_target, privacy, region, user_pref, device_capabilities`. Return `candidate_model_role, provider_endpoint, adapter_revision, max_cost, expected_latency, fallback, confidence, tool schema`. **Risk policy** may restrict endpoints or demand permission; it is not a model's self-granted privilege. Deterministic tasks (arithmetic, authorization, timezone calculations, hashing, storage state) bypass LLM when possible. Routing tiers: deterministic → tiny classifer/embedding → fast language model → specialist LoRA/API → powerful model → bounded Fusion council. Use uncertainty escalation and calibration, not naïve keyword matching. Keep continuity budget reserve bounded.

Remote serving candidate vLLM/SGLang-compatible stack with HTTPS gateway, auth outside raw runtime, rate limiting, streaming, tracing, adapter management and autoscaled GPU if eligible. vLLM `--api-key` must not be trusted as the only internet security boundary because not all paths are protected; use isolated network and a reverse proxy/service authorization. Local optional llama.cpp/Ollama/MLX for quantized compatible models; do not force this onto low-RAM Windows clients. The model registry lists resident/adapted variants and permitted inference locations. Multi-model Fusion can use parallel council, sequential critic/revise, independent scoring, and evidence synthesis with hard caps; final action executor remains canonical.

## M04. Model role inventory — role ≠ mandatory separate costly checkpoint

The following is the intended **specialist-role coverage matrix**. “Recommended realization” is an engineering starting point; choose based on measured results, license and actual device/GPU budget. Every role must have a typed input/output contract and permitted tool set, escalation/fallback strategy, security boundaries, language/format support and blind evaluation set. Do not train fifty role variants automatically; benchmark the shared base first.

| ID | Specialist role | Technical realization | Candidate baseline | Training/adaptation target | Acceptance benchmark |
|---|---|---|---|---|---|
| M-001 | Orchestrator / HEY One General | general LLM + tool runtime | Qwen3-8B or gpt-oss-20b | multi-step mission traces, precise final state, correct tool selection | task success, evidence fidelity, cost and latency |
| M-002 | Intent and task classifier | small typed classifier/rules | small encoder or Qwen3-8B as temporary | user utterances labeled intents and uncertainty | macro-F1, OOD abstention, multilingual |
| M-003 | MicroDecision router | calibrated small classifier | linear/GBDT/tiny transformer | routes labeled by successful provider outcomes | calibration ECE, expected cost, regret |
| M-004 | Complex reasoning | reasoning LLM endpoint/open weights | gpt-oss-120b hosted candidate | challenging constraint reasoning and verified answers | task correctness, tool consistency, spend |
| M-005 | Researcher | general model + web connectors | Qwen3-8B or hosted powerful reasoning | source analysis and citations with freshness | citation precision, source traceability |
| M-006 | Evidence and citation verifier | deterministic URL/source validator + LLM | text entailment model + browser fetch | claim/source entailment adversarial pairs | unsupported-claim catch rate |
| M-007 | Summarizer | general LLM adapter | Qwen3-8B or smaller candidate | faithful summaries of long docs/meetings | fact preservation, omissions |
| M-008 | Fact-checker / epistemic critic | separate model pass + retrieval | gpt-oss-20b or separate provider | contradictions, uncertainty, evidence checking | hallucination detection precision |
| M-009 | Strategist / business analyst | general LLM tools + spreadsheet models | Qwen3-8B plus verified numerical tools | business planning, constraints and assumptions | financial consistency, missing risks |
| M-010 | Missing-requirement hunter | retrieval + change graph + reasoning | Qwen3-8B or gpt-oss-20b | multi-turn specs, supersession and omission labels | recall of omitted approved requirements |
| M-011 | Decision historian / conflict resolver | temporal database + NLI/LLM | Qwen3-8B + graph query | approval/rejection/override labeled conversation cases | false approval rate, lineage accuracy |
| M-012 | Coding architect | code specialist + repository tools | Qwen3-Coder-30B-A3B | code architecture and module maps | implementation acceptance, contract compatibility |
| M-013 | Coder / code generator | code-specialized LLM | Qwen3-Coder-30B-A3B | licensed source-to-patch examples and tests | compile/pass real project tests, patch quality |
| M-014 | Code editor / surgical refactor | code LLM with AST/diff validator | Qwen3-Coder-30B-A3B | minimal before/after diffs with locked content | unrequested diff count, unit tests |
| M-015 | Debugger / repair | code model + debugger/test runner | Qwen3-Coder-30B-A3B | failing logs, root causes, verified repair patches | independent reproduced-fix rate |
| M-016 | Test writer | code LLM + test oracle | Qwen3-Coder-30B-A3B | edge/failure/integration test pairs | fault detection mutation score |
| M-017 | Security code reviewer | rule scans + separate reasoning | gpt-oss-20b or code model | CWE and permission-boundary labeled code | true critical findings; false positives |
| M-018 | Dependency/license auditor | deterministic SBOM + policy + reasoning | no separate weights required | package manifests/model cards/licenses | known-vulnerability detection, compliance |
| M-019 | DevOps / release engineer | structured code/infra model | Qwen3-Coder-30B-A3B | CI/deploy/config migration fixtures | deploy/rollback reproducibility |
| M-020 | SQL/database specialist | code/general model + query parser | Qwen3-Coder-30B-A3B | schema migration/RLS/queries + expected plans | query correctness, tenancy policy tests |
| M-021 | API integration specialist | code/general + protocol validators | Qwen3-Coder-30B-A3B | real provider SDK/schema/error specimens | contract compatibility and real calls |
| M-022 | Frontend UI engineer | code model + browser screenshot comparator | Qwen3-Coder-30B-A3B | accessible React/layout tasks and references | DOM/interactions/a11y/visual regression |
| M-023 | UI/UX creative designer | multimodal general + design tokens | hosted vision-language model plus rules | premium interface preference labeled designs | human usability, design-system compliance |
| M-024 | Product/design editor | vision+layout constraints / programmatic renderer | licensed image/editing model if needed | before/after exact-region preservation | locked-region pixel/structural changes |
| M-025 | Image prompt engineer | LLM + image model | Qwen3-8B → FLUX.1-schnell | prompt-to-image alignment examples | prompt fidelity, subject preservation |
| M-026 | Image generator | diffusion/flow model | FLUX.1-schnell | licensed image-text pairs; optional LoRA | human preference, artifact issues, cost |
| M-027 | Image inpainting / masked editor | inpainting-licensed model + masks | diffusers compatible checkpoint after license review | mask+reference edits | outside-mask preservation, edit precision |
| M-028 | Image upscaler/restorer | super-resolution model | publisher-reviewed ESRGAN-like licensed model | low/high-resolution pairs | detail fidelity, hallucination artifacts |
| M-029 | Visual detector / region locator | vision model + grounding | verified VLM + SAM2.1 | screen/object bounding boxes | mAP, target accuracy |
| M-030 | Image/video segmenter | segmentation model | facebook/sam2.1-hiera-tiny | labeled masks/temporal continuity | IoU, boundary stability |
| M-031 | Camera and screen understanding | multimodal LLM + OCR/detection | licensed visual-language model evaluated | screen/frame questions with target IDs | UI ground truth, privacy/prompt injection |
| M-032 | Document OCR/layout | OCR-VL / rules | PaddleOCR-VL-1.5 | document lines, tables, formulas and layout | CER/WER, table structure accuracy |
| M-033 | Chart/table interpreter | OCR/layout + numerical validators | PaddleOCR-VL + deterministic parser | data chart source/ground-truth values | numerical extraction and provenance |
| M-034 | Video planner/storyboard | LLM + editable timeline schema | Qwen3-8B | scripts → shots, continuity constraints | script-to-storyboard completeness |
| M-035 | Video generator | video diffusion/flow API or licensed weights | publisher-verified video provider/model | text/video aligned short clips and controls | motion coherence, clip defects, dollars/sec |
| M-036 | Video editor/shot consistency | scene graph + video tools + VLM | code+vision + ffmpeg | shot-level edit instructions, locked clip cases | edit locality, audio/video sync |
| M-037 | Motion graphics generator | code/scene renderer + LLM | Qwen3-Coder-30B-A3B + renderer | typographic/vector animation scene graphs | editable output, timing, export fidelity |
| M-038 | Music/sound generator | licensed audio generation | publisher-approved audio model/provider | licensed prompt/audio examples | quality, rights compliance, latency |
| M-039 | Automatic speech recognizer | ASR model | Whisper large-v3-turbo | consented multilingual/accent/noise speech | WER/CER, Sorani/Arabic tests |
| M-040 | Wake-word detector | compact on-device keyword spotter | openWakeWord-like licensed tool | positive/negative background and accent clips | false activations/hr; detection latency |
| M-041 | Voice activity detection | small audio classifier | Silero VAD candidate after review | speech/non-speech samples | missed speech, false triggers |
| M-042 | Voice TTS synthesizer | TTS model | Kokoro-82M for English candidate | speaker-consented text/audio pairs | MOS/intelligibility, latency |
| M-043 | British voice adaptation | consented TTS speaker/style adapter | licensed TTS family + authorized voice | speaker-owned voice recordings | speaker consent, intelligibility/accent |
| M-044 | Speaker diarization | speaker embedding+clustering | pyannote Community-1 | consented speaker-labeled audio | DER and privacy retention |
| M-045 | Audio enhancement/noise suppression | DSP/audio denoiser | RNNoise-class DSP or vetted open model | noisy/clean speech pairs | PESQ/STOI proxy, latency |
| M-046 | Speech translator/dubber | ASR + translation + TTS chain | Whisper + approved multilingual LLM + TTS | consented parallel languages | meaning fidelity, timestamps |
| M-047 | Sorani Kurdish language assistant | multilingual LLM adapter + lexicon | Qwen3-8B, benchmark only | licensed Sorani prompts/transcripts/reviews | native-speaker quality, orthography |
| M-048 | Kurmanji language assistant | multilingual LLM + lexicon | Qwen3-8B, benchmark only | native vetted Kurmanji dialogues | native-speaker adequacy |
| M-049 | Arabic language assistant | multilingual LLM | Qwen3-8B | MSA/dialect benchmark/teaching materials | grammar, dialect quality |
| M-050 | Translator / localization QA | translation model + glossary | Qwen3-8B or OPUS specialized pair | parallel corpora, glossary constraints | COMET-like + human preference |
| M-051 | Teacher lesson planner | general LLM + curriculum tools | Qwen3-8B education adapter | teacher-authored approved curriculum lessons | curriculum alignment and teacher ratings |
| M-052 | Quiz and worksheet writer | general LLM + validators | Qwen3-8B teacher adapter | difficulty/rubric aligned question-answer pairs | correct answer rate, diversity, editability |
| M-053 | Tutor / misconception detector | general LLM + retrieval | Qwen3-8B + curriculum documents | age-appropriate misconception/hint dialogs | pedagogical quality, correctness |
| M-054 | Rubric/assessment assistant | typed rubric engine + LLM | Qwen3-8B | rubric-scored synthetic/sample answers | fairness, agreement, rationale |
| M-055 | Math solver / verifier | symbolic tools + LLM | SymPy + general reasoner | equations and numeric proofs | exact result consistency |
| M-056 | Science reasoning assistant | general LLM + sourced knowledge | Qwen3-8B with retrieval | labeled physics/chemistry/biology QA | verified scientific correctness |
| M-057 | Memory embedding indexer | embedding encoder | Qwen3-Embedding-0.6B or bge-m3 | consented semantic search pairs | Recall@k, leakage prevention |
| M-058 | Reranker | cross encoder / lexical re-ranker | publisher-verified reranker | query-relevant passage pairs | nDCG@k, retrieval latency |
| M-059 | Knowledge extraction/entity linker | NER + temporal graph + LLM | compact encoder / Qwen3-8B | typed fact/relationship/temporal annotations | entity precision, privacy scope |
| M-060 | Intent for computer use | typed parser / general model | Qwen3-8B structured output | UI task plans constrained by capabilities | action proposal validity |
| M-061 | GUI element locator | vision/OCR/geometry model | PaddleOCR-VL + image grounding | screenshots and element coordinates | exact target click accuracy |
| M-062 | Gesture recognizer | MediaPipe landmark tracker + tiny temporal classifier | MediaPipe + trained custom gesture head | consented hand landmarks, gesture labels | per-gesture F1, false trigger/hour |
| M-063 | Device resource scheduler | deterministic control + prediction | small regression/GBDT | device load, memory/battery forecasts | p95 lag, energy, fairness |
| M-064 | Anomaly and fraud monitor | rules + calibrated model | small classifier/GBDT | abuse/billing anomaly labels | recall at low false-positive |
| M-065 | Safety / prompt-injection detector | policy rules + separate text classifier | small encoder + validator | prompt injection/test attacks | attack catch rate, false refusals |
| M-066 | Compliance/privacy assistant | rules and retrieval-first LLM | Qwen3-8B plus policy library | policy/age/data examples | policy adherence, no unsupported legal claims |
| M-067 | Cost/latency forecaster | statistical model / rules | gradient boosting / regression | real per-provider usage logs | forecast error p95, spend overshoot |
| M-068 | Agent selector / council builder | small classifier + graph | MicroDecision Fabric | task to agents + measured outcome cases | useful agent selection, marginal benefit |
| M-069 | Risk Twin | separate critical reasoning + scanners | gpt-oss-20b / independent provider | adversarial failure patterns | severity-weighted true positives |
| M-070 | Solution Twin | code/architecture reasoner | Qwen3-Coder + gpt-oss-20b | mitigations preserving capabilities | risk reduction without function loss |
| M-071 | Product Integrity reviewer | requirements graph retrieval + model | Qwen3-8B + deterministic diff | conflict/omission/source provenance examples | omission catch, false authority claims |
| M-072 | Living Answer component selector | small UI schema classifier / LLM | Qwen3-8B + allowlisted renderer | tasks → typed components, no unsafe markup | widget usefulness, schema validity |
| M-073 | Sandbox mini-app builder | code model + isolated runtime | Qwen3-Coder + secure app sandbox | bounded app specs + tests | functional controls, sandbox escapes=0 |
| M-074 | Customer support/help | small general + knowledge retrieval | Qwen3-8B | documentation/support case with verified resolution | resolution, escalation accuracy |
| M-075 | Agent evaluator/independent outcome judge | deterministic checks + external model | independent provider or exact state tests | task outcome truth labels and receipts | false success rate, independence |

### How specialists connect without wasting compute

Task “create school lesson and presentation” uses shared HEY context: Intent Router → scoped curriculum/document retriever → Teacher Planner (text model) → Quiz Writer (same base adapter or separate if justified) → Presentation Studio (structured slide scene graph) → formatter/exporter (deterministic) → independent fact/layout verification → result. Do not wake a dedicated GPU each for Tutor, Writer, Layout, Reviewer if a shared hosted model can perform the role reliably and economically.

Task “fix code” uses Repo Reader (deterministic/embeddings) → Coder Model → Patch Editor (AST/diff invariants) → Test Runner (real) → Independent Verifier. Distinguish tests *proposed* from *run*. Task “generate an image then change only object A” uses Image Foundation API → mask/segmentation → Inpainting Model → pixel/semantic preservation verifier and user compare UI. Task “say next slide” uses Wake/VAD/ASR (device) → typed command parser → app capability/authorization → real presentation adapter → state verification. High confidence narrow commands should avoid expensive Fusion.

### Decision table: prompt vs fine-tune vs own weights

| Desired change | Cheapest correct method first | When train | When NOT train |
|---|---|---|---|
| Branded personality/writing style | System instructions + user settings | If robust style consistency fails on blind evaluations | No verified eval gap |
| User-specific memory | RAG/database + ACL | Only for general reusable skill on consented dataset | Never encode private mutable user memory into public weights |
| Editing exact 1 slide/region | Structured document model + diff/locks | When target interpretation remains systematically weak | Do not replace precise code diff with stochastic global regeneration |
| Coding | Code-capable licensed base + repo tools | Measured patch defects reduced by LoRA | Baseline + tests already meets bar |
| UI design | Design system + scene renderer + vision model | Distinct brand dataset and licensed design pairs | Fine-tuning worsens generalization |
| Image/video/music | Appropriate licensed media foundation/provider | Specialized brand LoRA with data rights/compute | Training full media foundation inside $50/mo budget |
| Gesture/wake word | Landmark/audio tiny classifier | Custom devices/gestures need learned recognizer | Full LLM cannot beat deterministic latency/privacy |
| Safety/auth | Deterministic policy + measured detector | Detector labels show relevant gap | Never “train permission checks” as sole protection |
| Multilingual Sorani | Native-speaker evaluated retrieval/lexicon/LoRA | Adequate rights + performance evidence | Assuming generic multilingual label equals Sorani fluency |

### Example live model routing contract

```json
{
  "request_id":"uuid",
  "role":"code_editor",
  "organization_id":"server_authorized_id",
  "context_policy":"project_scoped",
  "routing_mode":"auto",
  "privacy":"provider_approved_only",
  "required_capabilities":["structured_output","tool_calling"],
  "latency_target_ms":2500,
  "maximum_estimated_cost_usd":0.02,
  "fallback_roles":["general_editor"],
  "permissions":"resolved_by_trust_kernel_not_model",
  "result_state":"proposal_not_executed",
  "verification_required":["diff_preserves_locked_regions","tests_really_ran"]
}
```

**Important measurement:** the UltraSparse `p95 under 1ms` idea applies only to an in-process lightweight selector on specified hardware/workload; full inference includes tokenization, model cold start, GPU compute, network, tool work, output and postcondition verification. Measure separately. Avoid fake claims of 10T parameters or “more intelligent than all models” without independently reproducible evidence.

---
