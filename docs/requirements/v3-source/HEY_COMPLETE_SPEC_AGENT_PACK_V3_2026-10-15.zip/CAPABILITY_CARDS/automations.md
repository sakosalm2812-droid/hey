# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Automations

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-0796 — Workflow creation
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Workflow creation` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Workflow creation” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0797 — Automation recorder
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Automation recorder` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Automation recorder” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0798 — Teach-by-doing
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Teach-by-doing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Teach-by-doing” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0799 — Scheduled automations
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Scheduled automations` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Scheduled automations” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0800 — Trigger-based automations
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Trigger-based automations` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Trigger-based automations” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0801 — Conditional automations
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Conditional automations` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Conditional automations” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0802 — Multi-step workflows
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Multi-step workflows` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Multi-step workflows” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0803 — Tool actions in workflows
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Tool actions in workflows` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Tool actions in workflows” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0804 — Approval gates
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Approval gates` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Approval gates” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0805 — Retry logic
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Retry logic` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Retry logic” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0806 — Verification steps
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Verification steps` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Verification steps” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0807 — Pause/resume
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Pause/resume` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Pause/resume” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0808 — Workflow history
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Workflow history` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Workflow history” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0809 — Workflow versioning
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Workflow versioning` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Workflow versioning” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0810 — Workflow rollback
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Workflow rollback` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Workflow rollback” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0811 — Custom commands
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Custom commands` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Custom commands” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0812 — Voice-triggered commands
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Voice-triggered commands` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Voice-triggered commands” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0813 — Text commands
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Text commands` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Text commands” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0814 — Gesture-triggered commands
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Gesture-triggered commands` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Gesture-triggered commands” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0815 — Scheduled commands
**Kind:** historical_capability_or_behavior; **Historical group:** Automations
**Source-derived label:** `Scheduled commands` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Scheduled commands” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Use persistent state, idempotency, dedup, stop/cancel and real side-effect receipts.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** duplicate dispatch, restart, out-of-order callback, timezone boundary
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
