# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Pinpoint Precision

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-0173 — “Change exactly this and nothing else” editing
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `“Change exactly this and nothing else” editing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs ““Change exactly this and nothing else” editing” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0174 — Intended-change detection
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Intended-change detection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Intended-change detection” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0175 — Protected-state detection
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Protected-state detection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Protected-state detection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0176 — Allowed-secondary-change detection
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Allowed-secondary-change detection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Allowed-secondary-change detection” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0177 — Explicit invariants
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Explicit invariants` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Explicit invariants” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0178 — Implicit invariants
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Implicit invariants` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Implicit invariants” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0179 — Automatic restore points
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Automatic restore points` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Automatic restore points” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0180 — Actual-vs-intended delta comparison
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Actual-vs-intended delta comparison` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Actual-vs-intended delta comparison” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0181 — Unintended-change detection
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Unintended-change detection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Unintended-change detection” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0182 — Automatic repair
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Automatic repair` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Automatic repair” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0183 — Content locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Content locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Content locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0184 — Layout locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Layout locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Layout locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0185 — Style locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Style locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Style locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0186 — Character locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Character locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Character locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0187 — Object locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Object locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Object locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0188 — Typography locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Typography locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Typography locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0189 — Palette locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Palette locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Palette locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0190 — Camera locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Camera locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Camera locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0191 — Lighting locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Lighting locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Lighting locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0192 — Timing locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Timing locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Timing locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0193 — Audio locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Audio locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Audio locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0194 — Voice locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Voice locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Voice locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0195 — Structure locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Structure locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Structure locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0196 — Code API locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Code API locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Code API locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0197 — Data-schema locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Data-schema locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Data-schema locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/13_COMPLETE_DATA_SCHEMA_CONTRACT.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0198 — File-structure locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `File-structure locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “File-structure locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0199 — Naming locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Naming locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Naming locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0200 — Source/reference locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Source/reference locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User requests “Source/reference locks”; system returns the correct authorized object(s) or a truthful no-result, with source/freshness and access boundaries.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Query known authorized and unauthorized fixtures, compare returned IDs and provenance to ground truth.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/VISUAL_REFERENCE_MASTER.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0201 — Project DNA locks
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Project DNA locks` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Project DNA locks” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/06_COMPLETE_PROJECT_SYSTEM.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0202 — Before/After inspector
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Before/After inspector` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Before/After inspector” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0203 — Split comparison
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Split comparison` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Split comparison” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0204 — Overlay comparison
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Overlay comparison` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Overlay comparison” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0205 — Blink comparison
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Blink comparison` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Blink comparison” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0206 — Text diff
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Text diff` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Text diff” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0207 — Code diff
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Code diff` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Code diff” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0208 — Layout diff
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Layout diff` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Layout diff” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0209 — Object diff
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Object diff` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Object diff” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0210 — Change metadata
**Kind:** historical_capability_or_behavior; **Historical group:** Pinpoint Precision
**Source-derived label:** `Change metadata` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Change metadata” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
