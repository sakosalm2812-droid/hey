# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Provider System

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-1118 — Multi-provider AI routing
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Multi-provider AI routing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Multi-provider AI routing” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1119 — OpenRouter integration
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `OpenRouter integration` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “OpenRouter integration” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1120 — OpenAI-class provider support
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `OpenAI-class provider support` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “OpenAI-class provider support” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1121 — Anthropic-class provider support
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Anthropic-class provider support` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Anthropic-class provider support” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1122 — Gemini-class provider support
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Gemini-class provider support` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Gemini-class provider support” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1123 — Local-model support
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Local-model support` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Local-model support” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1124 — Image-provider adapters
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Image-provider adapters` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Image-provider adapters” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1125 — Video-provider adapters
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Video-provider adapters` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Video-provider adapters” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1126 — Audio-provider adapters
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Audio-provider adapters` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Audio-provider adapters” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1127 — Provider health monitoring
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider health monitoring` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Provider health monitoring” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1128 — Provider benchmarking
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider benchmarking` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Provider benchmarking” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1129 — Provider fallback
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider fallback` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Provider fallback” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1130 — Provider circuit breaker
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider circuit breaker` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Provider circuit breaker” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1131 — Cost-aware routing
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Cost-aware routing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Cost-aware routing” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1132 — Latency-aware routing
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Latency-aware routing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Latency-aware routing” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1133 — Quality-aware routing
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Quality-aware routing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Quality-aware routing” subsystem makes its declared classification/routing/verification decision on representative real inputs and records reproducible reasoning metadata and outcome metrics.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Use labeled baseline and held-out adversarial cases, compare measured accuracy/latency/cost with claimed quality.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1134 — Privacy-aware routing
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Privacy-aware routing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The “Privacy-aware routing” control makes an actual server/runtime allow/deny or isolation decision based on current real policy and auditable evidence, not UI-only state.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Test allowed exact-scope operation and known-denied operation through actual backend, not hidden UI control.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1135 — Manual provider override
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Manual provider override` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Manual provider override” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1136 — Provider budgets
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider budgets` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Provider budgets” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/16_COMPLETE_PERFORMANCE_BUDGETS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1137 — Provider usage tracking
**Kind:** historical_capability_or_behavior; **Historical group:** Provider system
**Source-derived label:** `Provider usage tracking` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Provider usage tracking” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
