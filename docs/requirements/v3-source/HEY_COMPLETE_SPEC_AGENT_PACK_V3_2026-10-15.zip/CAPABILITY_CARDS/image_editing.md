# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Image Editing

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-0267 — Brightness adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Brightness adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Brightness adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0268 — Exposure adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Exposure adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Exposure adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0269 — Contrast adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Contrast adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Contrast adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0270 — Saturation adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Saturation adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Saturation adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0271 — Hue adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Hue adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Hue adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0272 — Temperature adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Temperature adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Temperature adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0273 — Tint adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Tint adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Tint adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0274 — Highlights adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Highlights adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Highlights adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0275 — Shadows adjustment
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Shadows adjustment` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Shadows adjustment” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0276 — Sharpening
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Sharpening` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Sharpening” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0277 — Blur
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Blur` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Blur” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0278 — Denoising
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Denoising` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Denoising” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0279 — Crop
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Crop` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Crop” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0280 — Rotate
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Rotate` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Rotate” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0281 — Flip
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Flip` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Flip” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0282 — Resize
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Resize` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Resize” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0283 — Straighten
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Straighten` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Straighten” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0284 — Perspective correction
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Perspective correction` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Perspective correction” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0285 — Canvas extension
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Canvas extension` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Canvas extension” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0286 — Background removal
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Background removal` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Background removal” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/04_DYNAMIC_ISLAND_BACKGROUND.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0287 — Background replacement
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Background replacement` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Background replacement” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/04_DYNAMIC_ISLAND_BACKGROUND.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
- `SOURCE_SPLIT/HEY_FINAL/00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0288 — Object removal
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Object removal` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Object removal” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0289 — Object replacement
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Object replacement` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Object replacement” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0290 — Recoloring
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Recoloring` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Recoloring” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0291 — Generative fill
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Generative fill` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Generative fill” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0292 — Outpainting
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Outpainting` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Outpainting” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0293 — Upscaling
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Upscaling` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Upscaling” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0294 — Restoration
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Restoration` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Restoration” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0295 — Text replacement in images
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Text replacement in images` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Text replacement in images” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0296 — Click-to-select
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Click-to-select` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Click-to-select” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0297 — Lasso selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Lasso selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Lasso selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0298 — Brush selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Brush selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Brush selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0299 — Natural-language selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Natural-language selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Natural-language selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0300 — Pointer selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Pointer selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Pointer selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0301 — Voice selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Voice selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Voice selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0302 — Object-list selection
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Object-list selection` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Object-list selection” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0303 — Non-destructive editing where possible
**Kind:** historical_capability_or_behavior; **Historical group:** Image editing
**Source-derived label:** `Non-destructive editing where possible` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User performs “Non-destructive editing where possible” on an existing scoped object; system targets only the requested state, preserves unrelated content, shows actual before/after diff, and supports undo when reversible.
**State, permission and integration check:** Preserve original asset, locked invariants and approved versions; validate actual editable/exported file.
**Positive verification:** Perform scoped edit, diff target and protected invariants, reload/reopen and verify no unauthorized collateral change.
**Negative/recovery verification:** render failure, format error, unintended collateral change, provider cost exhaustion
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
