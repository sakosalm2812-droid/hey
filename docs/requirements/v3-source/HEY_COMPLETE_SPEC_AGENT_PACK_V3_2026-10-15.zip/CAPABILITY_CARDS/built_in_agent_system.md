# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Built In Agent System

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-0843 — Agent orchestration
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Agent orchestration` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Agent orchestration” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0844 — Intent agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Intent agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Intent agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0845 — Context agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Context agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Context agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0846 — Planning agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Planning agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Planning agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0847 — Execution agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Execution agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Execution agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`
- `SOURCE_SPLIT/HEY_FINAL/05_EXECUTION/01_REPOSITORY_IMPLEMENTATION_ORDER.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0848 — Verification agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Verification agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Verification agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0849 — Recovery agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Recovery agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Recovery agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/15_COMPLETE_FAILURE_RECOVERY_CATALOG.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0850 — Task agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Task agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Task agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0851 — Workflow agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Workflow agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Workflow agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0852 — Capability agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Capability agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Capability agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/04_RUNTIME_CAPABILITY_SYNTHESIS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0853 — Permission agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Permission agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Permission agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0854 — Security-policy agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Security-policy agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Security-policy agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0855 — Quality agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Quality agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Quality agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0856 — Response agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Response agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Response agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0857 — Personality agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Personality agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Personality agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0858 — Mode agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Mode agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Mode agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0859 — Memory ingestion agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory ingestion agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory ingestion agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0860 — Memory retrieval agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory retrieval agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory retrieval agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0861 — Memory ranking agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory ranking agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory ranking agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0862 — Memory dedup agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory dedup agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory dedup agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0863 — Memory update agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory update agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory update agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/21_COMPLETE_PWA_INSTALL_UPDATE_SPEC.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0864 — Memory decay agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory decay agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory decay agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0865 — Memory deletion agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory deletion agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory deletion agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0866 — Memory privacy agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory privacy agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory privacy agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0867 — Memory provenance agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory provenance agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory provenance agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0868 — Memory graph agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory graph agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory graph agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0869 — Knowledge graph agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Knowledge graph agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Knowledge graph agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0870 — Memory summarization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Memory summarization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Memory summarization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0871 — Preference agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Preference agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Preference agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0872 — Pattern agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Pattern agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Pattern agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0873 — Project-memory agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Project-memory agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Project-memory agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/06_COMPLETE_PROJECT_SYSTEM.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0874 — Goal-memory agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Goal-memory agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Goal-memory agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0875 — Web research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Web research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Web research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0876 — Deep research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Deep research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Deep research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0877 — Source verification agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Source verification agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Source verification agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0878 — Fact-check agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Fact-check agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Fact-check agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0879 — News agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `News agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “News agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0880 — Academic agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Academic agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Academic agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0881 — Document research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Document research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Document research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0882 — PDF research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `PDF research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “PDF research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0883 — Image research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Image research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Image research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0884 — Competitive research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Competitive research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Competitive research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0885 — Customer research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Customer research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Customer research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0886 — Market research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Market research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Market research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0887 — Synthesis agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Synthesis agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Synthesis agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/04_RUNTIME_CAPABILITY_SYNTHESIS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0888 — Citation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Citation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Citation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0889 — Research planner
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Research planner` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Research planner” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0890 — Uncertainty agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Uncertainty agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Uncertainty agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0891 — Software architect agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Software architect agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Software architect agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0892 — Frontend agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Frontend agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Frontend agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0893 — Backend agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Backend agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Backend agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0894 — Full-stack agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Full-stack agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Full-stack agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0895 — Database agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Database agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Database agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0896 — Supabase agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Supabase agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Supabase agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0897 — API agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `API agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “API agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0898 — AI-integration agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `AI-integration agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “AI-integration agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0899 — Provider-routing agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Provider-routing agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Provider-routing agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0900 — Code-review agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Code-review agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Code-review agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0901 — Debugger agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Debugger agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Debugger agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0902 — Testing agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Testing agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Testing agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0903 — E2E agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `E2E agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “E2E agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0904 — Performance agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Performance agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Performance agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/16_COMPLETE_PERFORMANCE_BUDGETS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0905 — DevOps agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `DevOps agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “DevOps agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0906 — Release agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Release agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Release agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/RELEASE_GAP_AND_EXPECTATION_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0907 — Migration agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Migration agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Migration agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0908 — Dependency agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Dependency agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Dependency agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0909 — Documentation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Documentation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Documentation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0910 — Code-quality agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Code-quality agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Code-quality agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0911 — Refactor agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Refactor agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Refactor agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0912 — Build agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Build agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Build agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0913 — Native/Tauri agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Native/Tauri agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Native/Tauri agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/23_COMPLETE_NATIVE_DYNAMIC_ISLAND.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0914 — Security auditor
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Security auditor` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Security auditor” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0915 — Authentication agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Authentication agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Authentication agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0916 — Authorization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Authorization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Authorization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0917 — Secret agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Secret agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Secret agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0918 — Application-security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Application-security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Application-security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0919 — API-security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `API-security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “API-security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0920 — AI-security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `AI-security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “AI-security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0921 — Tool-security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Tool-security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Tool-security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0922 — Computer-control security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Computer-control security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Computer-control security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0923 — File-security agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `File-security agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “File-security agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0924 — Privacy agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Privacy agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Privacy agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0925 — Audit agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Audit agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Audit agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0926 — Abuse-prevention agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Abuse-prevention agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Abuse-prevention agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0927 — Incident-response agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Incident-response agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Incident-response agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0928 — Computer-use agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Computer-use agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Computer-use agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0929 — Desktop agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Desktop agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Desktop agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0930 — Keyboard agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Keyboard agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Keyboard agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0931 — Pointer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Pointer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Pointer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0932 — Window agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Window agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Window agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0933 — App-launcher agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `App-launcher agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “App-launcher agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0934 — Process agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Process agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Process agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0935 — Filesystem agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Filesystem agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Filesystem agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0936 — File-organization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `File-organization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “File-organization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0937 — Browser agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Browser agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Browser agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0938 — Web-form agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Web-form agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Web-form agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0939 — Download agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Download agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Download agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0940 — Clipboard agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Clipboard agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Clipboard agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0941 — Screenshot agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Screenshot agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Screenshot agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0942 — Terminal agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Terminal agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Terminal agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0943 — System-settings agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `System-settings agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “System-settings agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0944 — Voice agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Voice agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Voice agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0945 — STT agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `STT agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “STT agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0946 — TTS agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `TTS agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “TTS agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0947 — Wake-word agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Wake-word agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Wake-word agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0948 — VAD agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `VAD agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “VAD agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0949 — Interruption agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Interruption agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Interruption agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0950 — Voice-personality agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Voice-personality agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Voice-personality agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0951 — Language-detection agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Language-detection agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Language-detection agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0952 — Translation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Translation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Translation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0953 — Conversation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Conversation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Conversation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0954 — Voice-summary agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Voice-summary agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Voice-summary agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0955 — English agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `English agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “English agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0956 — Kurdish agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Kurdish agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Kurdish agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0957 — Arabic agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Arabic agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Arabic agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0958 — RTL agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `RTL agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “RTL agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0959 — Internationalization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Internationalization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Internationalization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0960 — Pronunciation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Pronunciation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Pronunciation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0961 — Product manager agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Product manager agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Product manager agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/00_AUTHORITATIVE_NEWEST_PRODUCT_FLOW_AMENDMENT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0962 — Product-strategy agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Product-strategy agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Product-strategy agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/00_AUTHORITATIVE_NEWEST_PRODUCT_FLOW_AMENDMENT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0963 — UX-research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `UX-research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “UX-research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0964 — UX-design agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `UX-design agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “UX-design agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0965 — UI-design agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `UI-design agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “UI-design agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0966 — Design-system agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Design-system agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Design-system agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0967 — Creative-director agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Creative-director agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Creative-director agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0968 — Branding agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Branding agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Branding agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0969 — Motion agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Motion agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Motion agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MOTION_AND_TUTORIAL_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0970 — Accessibility agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Accessibility agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Accessibility agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0971 — Responsive-design agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Responsive-design agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Responsive-design agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0972 — Empty-state agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Empty-state agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Empty-state agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0973 — Error-state agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Error-state agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Error-state agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0974 — Onboarding agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Onboarding agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Onboarding agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0975 — Design-QA agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Design-QA agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Design-QA agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0976 — Workspace agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Workspace agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Workspace agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0977 — Widget agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Widget agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Widget agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0978 — Layout agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Layout agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Layout agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0979 — State agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `State agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “State agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0980 — Dynamic-Island agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Dynamic-Island agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Dynamic-Island agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/04_DYNAMIC_ISLAND_BACKGROUND.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/23_COMPLETE_NATIVE_DYNAMIC_ISLAND.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0981 — Notification agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Notification agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Notification agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0982 — Timer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Timer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Timer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0983 — Media agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Media agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Media agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0984 — Calendar agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Calendar agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Calendar agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0985 — Reminder agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Reminder agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Reminder agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0986 — Taskboard agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Taskboard agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Taskboard agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0987 — Search agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Search agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Search agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0988 — Proactive agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Proactive agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Proactive agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0989 — Morning agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Morning agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Morning agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0990 — Routine agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Routine agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Routine agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0991 — Focus agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Focus agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Focus agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0992 — Time-management agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Time-management agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Time-management agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0993 — Weekly-review agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Weekly-review agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Weekly-review agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0994 — Goal-coach agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Goal-coach agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Goal-coach agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0995 — Productivity agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Productivity agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Productivity agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0996 — Personal-development agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Personal-development agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Personal-development agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0997 — Learning agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Learning agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Learning agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0998 — Study agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Study agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Study agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-0999 — Creator agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Creator agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Creator agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1000 — Writer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Writer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Writer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1001 — Editor agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Editor agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Editor agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1002 — Social agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Social agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Social agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1003 — Marketing agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Marketing agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Marketing agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1004 — Sales agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Sales agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Sales agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1005 — Startup agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Startup agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Startup agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1006 — Finance-planning agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Finance-planning agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Finance-planning agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1007 — Operations agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Operations agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Operations agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1008 — Customer-support agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Customer-support agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Customer-support agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1009 — Competitor agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Competitor agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Competitor agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1010 — Content-QA agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Content-QA agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Content-QA agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1011 — Vision agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Vision agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Vision agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1012 — Screen-understanding agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Screen-understanding agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Screen-understanding agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1013 — Document-vision agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Document-vision agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Document-vision agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1014 — Camera agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Camera agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Camera agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1015 — Phone agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Phone agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Phone agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1016 — Tablet agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Tablet agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Tablet agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1017 — Display agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Display agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Display agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1018 — TV agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `TV agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “TV agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1019 — Smart-home agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Smart-home agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Smart-home agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/02_COMPLETE_HOME_DASHBOARD_INTELLIGENCE.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1020 — Wearable agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Wearable agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Wearable agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1021 — Vehicle agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Vehicle agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Vehicle agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1022 — Cross-device agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Cross-device agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Cross-device agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1023 — Discovery agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Discovery agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Discovery agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/24_COMPLETE_TUTORIAL_DISCOVERY_SYSTEM.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1024 — Pairing agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Pairing agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Pairing agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1025 — Health agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Health agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Health agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1026 — Prayer-times agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Prayer-times agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Prayer-times agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1027 — Quran agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Quran agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Quran agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1028 — Hadith agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Hadith agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Hadith agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1029 — Islamic-calendar agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Islamic-calendar agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Islamic-calendar agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1030 — Religious-research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Religious-research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Religious-research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1031 — Health-information agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Health-information agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Health-information agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1032 — Medical-research agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Medical-research agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Medical-research agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1033 — Legal-information agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Legal-information agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Legal-information agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1034 — Education agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Education agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Education agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1035 — Science agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Science agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Science agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1036 — Engineering agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Engineering agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Engineering agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1037 — Data-analysis agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Data-analysis agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Data-analysis agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/13_COMPLETE_DATA_SCHEMA_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1038 — Statistics agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Statistics agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Statistics agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1039 — Visualization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Visualization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Visualization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1040 — Documentation/compliance agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Documentation/compliance agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Documentation/compliance agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1041 — Regression agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Regression agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Regression agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1042 — Integration-validation agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Integration-validation agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Integration-validation agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1043 — Contract-test agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Contract-test agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Contract-test agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/13_COMPLETE_DATA_SCHEMA_CONTRACT.md`
- `SOURCE_SPLIT/HEY_FINAL/00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1044 — Data-integrity agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Data-integrity agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Data-integrity agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/13_COMPLETE_DATA_SCHEMA_CONTRACT.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1045 — User-journey agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `User-journey agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “User-journey agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1046 — Trust agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Trust agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Trust agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1047 — Hallucination-detection agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Hallucination-detection agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Hallucination-detection agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1048 — Output-sanitization agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Output-sanitization agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Output-sanitization agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1049 — Audit-review agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Audit-review agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Audit-review agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1050 — Release-gate agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Release-gate agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Release-gate agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/RELEASE_GAP_AND_EXPECTATION_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1051 — Forge-planner agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Forge-planner agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Forge-planner agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1052 — Agent-designer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Agent-designer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Agent-designer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1053 — Forge-validator agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Forge-validator agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Forge-validator agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1054 — Test-generator agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Test-generator agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Test-generator agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1055 — Workflow-designer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Workflow-designer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Workflow-designer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1056 — Tool-designer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Tool-designer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Tool-designer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1057 — Capability-duplicate agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Capability-duplicate agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Capability-duplicate agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/04_RUNTIME_CAPABILITY_SYNTHESIS.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1058 — Forge-versioning agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Forge-versioning agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Forge-versioning agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1059 — Forge-health agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Forge-health agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Forge-health agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1060 — Forge-governance agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Forge-governance agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Forge-governance agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/01_OWNER_CONSOLE_AND_GOVERNANCE.md`
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1061 — Agent-router agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Agent-router agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Agent-router agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1062 — Scheduler agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Scheduler agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Scheduler agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1063 — Load-balancer agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Load-balancer agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Load-balancer agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1064 — Fallback agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Fallback agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Fallback agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1065 — Cost-controller agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Cost-controller agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Cost-controller agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1066 — Latency-controller agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Latency-controller agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Latency-controller agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1067 — Observability agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Observability agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Observability agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1068 — Dependency agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Dependency agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Dependency agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1069 — Retry-policy agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Retry-policy agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Retry-policy agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1070 — Lifecycle agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Lifecycle agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Lifecycle agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/08_COMPLETE_FIRST_RUN_ACCOUNT_LIFECYCLE.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1071 — Registry agent
**Kind:** historical_agent_role; **Historical group:** Built-in agent system
**Source-derived label:** `Registry agent` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The internal “Registry agent” specialist is selected only for suitable requests; receives bounded inputs/tools/permissions, returns typed result+evidence, and can be cancelled or replaced without a separate visible chatbot.
**State, permission and integration check:** Separate model proposal from runtime authorization and independent verification; constrain cost.
**Positive verification:** Route at least one real qualifying and one non-qualifying task; inspect bounded tool/cost choices and score actual result independently.
**Negative/recovery verification:** unsupported claim, stale evidence, prompt injection, model/provider 429 or 500
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
