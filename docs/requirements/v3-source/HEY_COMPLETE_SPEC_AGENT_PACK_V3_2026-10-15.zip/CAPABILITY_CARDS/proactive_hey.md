# HEY — ORIGINAL HISTORICAL REQUIREMENT CARDS: Proactive Hey

**Status:** source-title grounded; agent must reconcile with complete original source and newer amendments. These are not claims of tested implementation.

## BIBLE-1138 — Proactive suggestions
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Proactive suggestions` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Proactive suggestions” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1139 — Morning briefing
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Morning briefing` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Morning briefing” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1140 — Deadline awareness
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Deadline awareness` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Deadline awareness” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1141 — Calendar awareness
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Calendar awareness` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Calendar awareness” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1142 — Prayer-time awareness
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Prayer-time awareness` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Prayer-time awareness” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1143 — Weather awareness
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Weather awareness` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Weather awareness” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1144 — Routine awareness
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Routine awareness` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Routine awareness” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1145 — Broken-automation alerts
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Broken-automation alerts` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Broken-automation alerts” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1146 — Device alerts
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Device alerts` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Device alerts” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1147 — Research watchers
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Research watchers` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** User requests “Research watchers”; system returns the correct authorized object(s) or a truthful no-result, with source/freshness and access boundaries.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Query known authorized and unauthorized fixtures, compare returned IDs and provenance to ground truth.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1148 — Commitment reminders
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Commitment reminders` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Commitment reminders” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1149 — Cosmos-pattern suggestions
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Cosmos-pattern suggestions` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Cosmos-pattern suggestions” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1150 — Notification caps
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Notification caps` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Notification caps” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1151 — Quiet hours
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Quiet hours` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Quiet hours” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1152 — Cooldowns
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Cooldowns` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Cooldowns” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1153 — Per-category controls
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Per-category controls` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Per-category controls” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1154 — Delivery-device controls
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `Delivery-device controls` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “Delivery-device controls” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.

## BIBLE-1155 — No-nagging policy
**Kind:** historical_capability_or_behavior; **Historical group:** Proactive HEY
**Source-derived label:** `No-nagging policy` in `HEY-MASTER-PRODUCT-BIBLE.docx`. **Behavioral elaboration below is a proposed acceptance template, not a quoted user-approved specification.**
**Observable contract:** The user can discover and use “No-nagging policy” in an appropriate HEY surface; resulting state and returned feedback accurately reflect the actual system, with persistence where expected.
**State, permission and integration check:** Respect account/tenant scope, accessible UX, stable state and real outcome verification.
**Positive verification:** Run user-level journey through actual exposed HEY UI/API on declared supported platform; verify persisted postcondition.
**Negative/recovery verification:** permission revoked, network down, duplicate event, unsupported device
**Additional detailed sections to read and reconcile (automatically suggested; not independently confirmed authoritative matches):**
- `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**Remaining required work:** owner maps actual repo files, applies latest refinements, writes typed schema, integrates real UI/backend/native/provider as applicable, adds positive and negative tests, records independent evidence.
**Current implementation/evidence:** UNKNOWN / NOT EXECUTED.
