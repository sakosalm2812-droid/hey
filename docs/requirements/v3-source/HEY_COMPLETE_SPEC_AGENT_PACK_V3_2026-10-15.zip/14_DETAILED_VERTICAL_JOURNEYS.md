# HEY — FULL VERTICAL USER-JOURNEY CONTRACTS (ADDITIVE)

All journeys below are **NOT EXECUTED**. Actual route, service account, source SHA, OS and device must be filled by the owning agent after repository inspection. Each scenario requires user-visible completion evidence and an independent negative test.

## Journey A — New account becomes personalized but unrestricted

**Initial:** New email/account, no Cosmos consent or existing Space. **Steps:** sign up with actual Auth/email; verify email; login; default Chat/Voice view; onboarding multi-select Teacher+Developer+Create; create Space; pin teacher quiz and coder tool; sign out; sign in on second device; unpin and undo; revoke school access. **Expected:** state persists with adaptive layout; both categories accessible; revocation blocks teacher organization data even when tool remains pinned; deleting one Space leaves other Spaces and the canonical Brain intact. **Failures:** expired email, provider outage, RLS denial, stale cache/layout corruption, unavailable native tool. **Evidence:** provider/account logs, DB rows scoped to user, browser recording, before/after state, tester sign-off.

## Journey B — HEY One and Fusion under real cost limits

**Initial:** user chooses Auto/Balanced. **Steps:** ordinary question routed once to economical model; complex code/refactor task gets optional planner/coder/verifier topology if benefit exceeds budget; intentional first-provider failure triggers bounded fallback; create long response under concurrency; run quota boundary. **Expected:** actual model versions recorded, behavior meets task goals, no claims of running inaccessible weights, Edge action authorization uses Trust Kernel not model-generated booleans, user can stop work, hard budget stops paid requests. **Failures:** 429/500, invalid schema, empty answer, timeout, contradictory council, provider abuse. **Evidence:** real sanitized provider request IDs, quality rubric, token/cost ledger, independent factual/code checks.

## Journey C — Forge creates useful tool safely

**Initial:** no tool for desired bounded task. **Steps:** search registry; propose missing capability; synthesize minimal tool/adapter; review dependency license and permissions; sandbox, adversarial tests, demonstrate with test input; user installs version; tool appears in universal search and a custom Space; revoke and run again; rollback to previous version. **Expected:** user can inspect exactly what was built, deny its permissions, undo installation; no untrusted code obtains credentials or elevated action authority. **Failures:** malicious package, prompt injection, dependency CVE, network blocked, sandbox crash. **Evidence:** signed manifest, permission decision, execution trace, independent tests and rollback receipt.

## Journey D — Living Answers mini-app

**Initial:** user asks to forecast startup inference costs. **Steps:** HEY renders a calculator with model cost, prompt token count, queries/day, customer count and monthly estimate; user changes sliders/selects; output recalculates without roundtrip; save to Business Space; reopen mobile; optionally trigger a budget alert through an explicit authorize button. **Expected:** arithmetic accurate with tested boundary values, accessible text alternative, state persistence, no alert actually created without authorization, server validates persisted settings. **Failures:** malicious widget prop injection, nonexistent model price, unavailable web data, quota stale, offline. **Evidence:** UI calculations compared to deterministic Python arithmetic, save/reload logs, allowed/denied action audit.

## Journey E — Voice ↔ Chat ↔ Live ↔ Studio

**Initial:** ongoing project with attached file and Cosmos policy. **Steps:** chat requests presentation; embedded Presentation Studio loads editable slides; switch to Voice and request 'change slide three only'; real deck edit; switch Live and screen-share explicitly; close Live; return Chat; export PPTX; reopen. **Expected:** one conversation ID, only slide 3 changed except necessary metadata, voice model barge-in works, screen capture indicator stops, export opens with consistent content and Project DNA. **Failures:** permission denial, speech recognizer duplicate-start, lost network during export, selected slide ambiguity, assistant incorrect completion. **Evidence:** before/after XML/deck/render diff, media permissions, stored version receipts, independent slide open validation.

## Journey F — HEY Flow to external editor

**Initial:** native companion installed and authorized for text insertion into selected app. **Steps:** activate shortcut; dictate Sorani then English; punctuation; correction; selected text rewrite; pause; resume; stop; re-open app. **Expected:** text appears in intended window only; correct language, no duplicate insertion; safe clipboard fallback explicitly identified; transcript not retained beyond configured policy; mic indicator and stop work. **Failures:** focus changes mid-dictation, app rejects text, OS privacy dialog, microphone revoked, no local speech model. **Evidence:** screen recording (without secrets), clipboard/focus/permission audit, word error rate on consented evaluation set, stopwatch latency.

## Journey G — Android classroom presentation gestures

**Initial:** teacher uses authorized classroom smartboard or paired computer+camera. **Steps:** identify camera hardware; calibrate open palm/pinch/swipe; launch slide deck; swipe right/left; pinch zoom; pause gesture detection; test false positives while speaking; close session. **Expected:** actual slide movement, no unexpected high-impact actions, full-screen visible presentation, safe privacy state, offline/local gesture path where supported. **Failures:** no camera, two hands/conflicting gesture, low light, occlusion, background app, child walk-by, late activation. **Evidence:** hardware model, recorded before/after slide IDs, gesture confidence/hysteresis traces, school-approved test without student imagery.

## Journey H — Teacher resource generation and privacy

**Initial:** teacher joins synthetic Leaders-like organization, role-scoped test classes. **Steps:** generate lesson plan aligned to stated age/content; quiz with answer key; editable worksheet; slide presentation; export; teacher edits section; another unrelated teacher account tries to fetch resources; simulated student tries teacher-only resource. **Expected:** pedagogically coherent, editable, printable results; organization isolation survives direct API attempts; generated resources clearly distinguish factual sources and AI-created material. **Failures:** curriculum hallucination, copyrighted material copying, data leakage, wrong role, format failure, projector displaying personal data. **Evidence:** teacher rubric, export openability tests, RLS cross-tenant tests.

## Journey I — Native file action with scoped mandate

**Initial:** user names selected folder inside allowed scope. **Steps:** ask HEY to rename only a named file, display preview, approve scoped action, execute via Edge, verify on disk; change target in another user utterance; revoke permission; retry former mandate. **Expected:** actual correct file rename, atomic action receipt, target change invalidates approval, no access outside folder, original restored on reversible failure. **Failures:** file locked, filename conflict, symlink traversal, injected webpage instruction, laptop sleep; no claim of execution if device unreachable. **Evidence:** filesystem hashes/names, native process logs, mandate/refusal checks.

## Journey J — Durable scheduled work

**Initial:** permitted recurring task with local timezone Asia/Baghdad. **Steps:** schedule task; server restart before trigger; timezone DST edge synthetic test for zones with DST; duplicate event delivery; provider 500; user revocation. **Expected:** no double external side effects, future schedule survives restart, appropriate retry/checkpoint, cancelled jobs remain cancelled, exact actual outcome history. **Failures:** corrupt checkpoint, clock skew, queue poison message, concurrent worker race. **Evidence:** DB outbox transactions, mission trace and independently observed action count.

## Journey K — Project Integrity detects missing refinement

**Initial:** source decisions across several conversations (approved/brainstorm/rejected). **Steps:** ask agent to implement fixed 'Developer Mode'; introduce later approved customizable cross-category Spaces; intentionally provide a deficient implementation hiding teacher tools; ask Completion Guardian to assess it; revise feature; attempt same approved change on second session. **Expected:** latest requirement identified and traceable, unapproved suggestion remains tentative, false completion refused, source-backed changes applied once without discarding other accepted behavior. **Failures:** retrieval misses source, conflict between archived old/new, agents lack shared memory, unsafe cross-tenant retrieval. **Evidence:** decision graphs, source text pointers, mocked-omission red-team detection precision, human review and real UI tests.

## Journey L — Disaster recovery / incomplete action truth

**Initial:** live staging app with a queued generation mission, saved artifact and private school-test data. **Steps:** start generation; kill worker; restore queue; provider unavailable; restore isolated database backup; reopen from second device; inspect activity. **Expected:** safe resume/partial status with no invented finished artifact; no duplicate side effects; backups actually restorable; no old tenant data leaks. **Failures:** migration mismatch, missing R2 file, stale auth session, expired signed URL, provider billing overrun. **Evidence:** backup snapshot time, restore result, object diff, cross-org denial, regenerated signed links only after authorization.

## Journey M — Extreme small-detail intelligence without endless filler

**Initial:** user asks to deploy HEY for $25–50 monthly with Leaders pilot. **Steps:** produce feasible allocation separating fixed/proportional spending; identify student privacy, domain annual bill, vendor eligibility, GPU impossibility, model token caps, owner merchant authorization, 429 load, failover; adapt plan on budget change. **Expected:** factors surfaced when material, no provider fees invented, clear estimate vs verified fact, concrete execution plan rather than generic bureaucracy. **Failures:** hidden overspend, claims unsupported subscription payment country, bogus accuracy claims, cites stale data as current. **Evidence:** risk/assumption checklist, vendor source date, reproducible arithmetic, user acceptance.
