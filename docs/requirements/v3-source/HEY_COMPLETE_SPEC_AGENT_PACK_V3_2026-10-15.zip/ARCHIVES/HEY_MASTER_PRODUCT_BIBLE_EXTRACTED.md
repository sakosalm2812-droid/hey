HEY

MASTER PRODUCT BIBLE

The complete vision, capability map, experience model, system architecture, user possibilities, platform boundaries, and vNext expansion plan

S&A • HEY AI Life Operating System

Canonical feature inventory: 1–1460 • Built-in agents: exactly 229 (843–1071)

## How to read this document

HEY is intentionally broader than a normal application. To avoid confusing vision with implementation evidence, use these meanings:

## Product definition

HEY is conceived as an AI Life Operating System rather than a single chatbot. Its job is to unify conversation, memory, creation, research, automation, device control, projects, files and proactive assistance under one trusted identity and one consistent interface.

The design goal is not “an app with many buttons.” The goal is a coherent intelligence layer that can understand context, remember only what it is allowed to remember, act across supported systems, prove what it changed, and move between devices without forcing the user to rebuild context.

## The promise

HEY should reduce the distance between intent and outcome. A user should be able to say what they want, show what they mean, select the object or screen region involved, and let HEY assemble the right agents, providers, tools and devices while preserving permissions and verification.

Where an operating system or external service prevents a behavior, HEY should expose the limitation and use the strongest legitimate fallback rather than simulate success.

## Core product principles

Conversation-first: after sign-in, the default destination is the Chat/Voice Conversation Surface, not a dashboard.

One context, many surfaces: Chat, Voice, Live, Dynamic Island, widgets, notifications and device handoff should share the same conversation/task identity where appropriate.

Private by default: minimum context, explicit permissions, local-first routing for sensitive work, user-controlled memory and visible sensing state.

Act with proof: actions, automations and missions should distinguish requested, running, verified, partial, failed and cancelled states; a UI animation is never proof of execution.

Project consistency: Project DNA, locks and provenance protect brand, terminology, structure and identity across long-running work.

Platform honesty: web/PWA, Windows, Android and iOS share outcome goals but use different legitimate mechanisms where OS constraints require it.

Free-first launch: launch paths should prefer free, local or free-tier providers; paid adapters can exist but cannot silently become mandatory.

No clutter tax: HEY may contain enormous capability depth without exposing every capability as a permanent navigation item.

## What HEY should feel like

HEY should feel closer to a trusted operating layer than a collection of AI features. The user should not need to decide which model, agent, tool, screen or device to use for ordinary work; HEY should route intelligently while keeping the route inspectable.

The visual direction is premium, calm and minimal: near-black graphite surfaces, refined glass, realistic depth, restrained adaptive accents, strong typography, subtle motion and consistent rounded geometry. The UI should avoid flashy “AI hologram” clichés. Information density can increase in professional/developer contexts, but the base experience stays quiet and deliberate.

The primary relationship is conversational. Sidebars and secondary navigation collapse away when not needed. Mobile uses overlay drawers rather than permanent space-taking panels. Desktop supports compact/collapsible/resizable navigation. The dashboard is secondary; sign-in should land on Chat/Voice.

Voice should feel like a call with the same HEY—not a separate assistant. Spoken user turns and HEY responses belong to the same persisted conversation. Replies default to concise natural speech; interruption should stop speech quickly. The preferred identity is a deep British male voice, with configurable voice and wake phrase.

## The complete HEY system

The canonical specification contains 1,460 numbered capabilities. The following sections explain what each domain means in practice. The complete numbered inventory is reproduced later in this document so no approved capability is omitted.

### Core HEY identity and interaction

How the user talks to HEY and how HEY adapts. Text and voice remain one relationship, with response style, depth, mood, mode, time and personality adapting without losing continuity.

Representative capabilities: Text chat with HEY; Voice conversations with HEY; Switching between Chat and Voice without losing context; Continuous conversation history; Project-aware conversations; File-aware conversations.

### HEY Answer Engine

The answer-quality layer. It prioritizes answer-first structure, evidence, source quality, uncertainty, conflict handling, citations when needed, privacy-aware context and truthful failure/partial-success reporting.

Representative capabilities: Answer-first response structure; Dynamic response length; Evidence-backed answers; Citations where appropriate; Source-quality ranking; Freshness checking.

### Cosmos / memory / second brain

A user-controlled second brain made of raw timeline events plus distilled structured memory. Provenance, confidence, freshness, privacy, contradiction handling, deletion and scoped retrieval are first-class.

Representative capabilities: Persistent long-term memory; Preference memory; Project memory; Goal memory; Decision memory; Task memory.

### Projects and Project DNA

Persistent project-specific rules and identity: canonical sources, terminology, brand system, approved references, design tokens, privacy scope, decisions and consistency checks.

Representative capabilities: Create projects; Project switching; Project-specific memory; Project-specific files; Project-specific tasks; Project-specific agents.

### Pinpoint Precision

A change-control system for “change exactly this and nothing else.” It identifies invariants, locks protected state, compares intended vs actual delta, and repairs unintended changes.

Representative capabilities: “Change exactly this and nothing else” editing; Intended-change detection; Protected-state detection; Allowed-secondary-change detection; Explicit invariants; Implicit invariants.

### Artifact system and version history

Artifacts become versioned objects with provenance, snapshots, comparison, branch/merge concepts and object-level editing rather than disposable generated files.

Representative capabilities: Artifact creation; Artifact Inspector; Version history; Branched version history; Git-like visual version graph; Name versions.

### Image generation

A multi-provider creation layer for images, icons, logos, diagrams, UI mockups, product visuals and other formats with identity persistence, ranking and QA.

Representative capabilities: Text-to-image; Image-to-image; Voice-to-image; Multiple reference images; Image variations; Transparent-background images.

### Image editing

Selection-aware, non-destructive image editing where possible, covering conventional adjustments and generative/object-level modifications.

Representative capabilities: Brightness adjustment; Exposure adjustment; Contrast adjustment; Saturation adjustment; Hue adjustment; Temperature adjustment.

### Storyboard and frame system

A structured pre-production system translating scripts into scenes and shots, with continuity, metadata, locked approvals and selective regeneration.

Representative capabilities: Storyboard workspace; Script-to-scenes; Scenes-to-shots; Shot-card generation; Shot metadata; Camera angle control.

### Video generation and editing

Generation plus editing as one pipeline: shots, continuity, extensions, B-roll, captions, audio ducking, aspect conversion and export presets.

Representative capabilities: Text-to-video; Image-to-video; Frame-to-video; First/last-frame video generation; Storyboard-to-video; Video continuation.

### Motion graphics

Typography, logos, product/UI reveals, charts, callouts and explainers treated as editable motion systems rather than only pre-rendered videos.

Representative capabilities: Kinetic typography; Logo reveals; Product reveals; UI animation; HUD-style graphics when appropriate; Lower thirds.

### Audio and speech

Speech recognition, transcription, dubbing, TTS, voice control, cleanup, segmentation, translation and synchronization.

Representative capabilities: Speech-to-text; Transcription; Speaker diarization; Translation; Caption creation; Narration.

### Presentations

Narrative planning, writing, visual generation, diagrams/charts, speaker notes, citations, QA, Pinpoint editing and presenter runtime.

Representative capabilities: PPTX creation; Presentation outlining; Slide narrative planning; Slide writing; Slide design; Visual generation.

### Documents and books

Creation/redesign of DOCX, PDF, Markdown, reports, manuals, books, worksheets, exams, notes and educational materials with citation and consistency support.

Representative capabilities: DOCX creation; PDF creation; Markdown documents; Long-form writing; Book-page generation; Document redesign.

### Knowledge transformation

A universal “Turn this into…” engine that converts trusted source material into summaries, notes, presentations, worksheets, flashcards, quizzes, audio and visual explainers while preserving provenance.

Representative capabilities: Source → summary; Source → notes; Source → presentation; Source → worksheet; Source → flashcards; Source → quiz.

### HEY Live

A live multimodal session that can understand selected screens/cameras/windows, point to targets, guide or assist, and escalate to acting only within permission boundaries.

Representative capabilities: Live voice session; Live screen understanding; Live camera understanding; Screen + camera simultaneously; Active-window understanding; Selected-monitor understanding.

### Voice system

Hands-free natural conversation with wake word, VAD, interruption/barge-in, captions, voice language detection and short voice-optimized replies. Preferred launch behavior includes a deep British male voice direction and configurable wake phrase.

Representative capabilities: Wake word “HEY”; Voice activity detection; Speech interruption / barge-in; Listening state; Thinking state; Speaking state.

### Dynamic Island

A persistent compact status/action surface for voice, media, research, generation, timers, approvals, handoff and progress outside the main window where the platform allows it.

Representative capabilities: Persistent native Dynamic Island; Works outside main HEY window where supported; Idle mode; Listening mode; Thinking mode; Speaking mode.

### Background HEY

Timers, schedules, workflows, agents, notifications, research and handoff may continue when the main UI closes, subject to OS/background restrictions and user controls.

Representative capabilities: Tray/menu helper; HEY keeps running after main window closes; Background wake word; Background shortcuts; Background Dynamic Island; Background notifications.

### Computer control

A permissioned computer-use layer for pointer, keyboard, windows, apps, files, terminal and system operations, with risk classification, previews, verification and recovery.

Representative capabilities: Pointer movement; Click; Double-click; Right-click; Drag; Scroll.

### Browser control

Navigation, forms, page extraction, file transfer, monitoring and research with page-content prompt-injection defenses.

Representative capabilities: Open websites; Search web; Navigate pages; Tab control; Click web controls; Type into forms.

### Files

Search, read, summarize, organize, move, rename, duplicate, delete-with-safeguards, provenance and change verification for local or connected files.

Representative capabilities: File search; File reading; File summarization; File organization; File moving; File renaming.

### Workspace

A living canvas of movable/resizable/dockable widgets spanning chat, voice, files, code, research, media, calendar, devices, Cosmos and more.

Representative capabilities: Living workspace; Chat widget; Voice widget; Live widget; Image widget; Storyboard widget.

### Home / dashboard

A secondary command/status view for projects, missions, tasks, calendar, weather, prayer, usage, health, reminders and recommendations. It is not the mandatory startup destination.

Representative capabilities: Active project overview; Current mission; Tasks; Calendar; Weather; Prayer information.

### Navigation and discoverability

A small primary navigation plus Universal Search, Command Palette, contextual suggestions, pinned/recent capabilities and guided first-use discovery.

Representative capabilities: Conversation Surface as default sign-in destination; Chat/Voice switcher; Primary navigation; Create hub; Projects; Cosmos.

### Tutorials

Feature education embedded into the product, including replayable tutorials, practice mode and reduced-motion variants.

Representative capabilities: First-launch tutorial; Chat tutorial; Voice tutorial; HEY Live tutorial; Dynamic Island tutorial; Widgets tutorial.

### Gestures

Optional camera-based gesture control for HEY and, where permissions/native integration permit, device actions. Gestures are customizable and risk-classified.

Representative capabilities: Open-palm summon; Palm-to-fist grab; Fist move; Pinch click/select; Pinch drag; Two-hand spread enlarge.

### Automations

Recorded, scheduled, conditional and multi-step workflows with retry, approval, verification, history, versioning and rollback.

Representative capabilities: Workflow creation; Automation recorder; Teach-by-doing; Scheduled automations; Trigger-based automations; Conditional automations.

### Forge

The capability builder. It can design agents, teams, workflows, skills, commands, automations, widgets, dashboards, adapters and mini-app-like capabilities; every candidate should pass requirement, permission, contract, test, sandbox/simulation and validation gates before install.

Representative capabilities: Create agents; Create agent teams; Create workflows; Create skills; Create commands; Create automations.

### Built-in agent system

Exactly 229 built-in specialist roles (843–1071) form a routing/orchestration layer across reasoning, memory, research, development, security, device control, voice, design, productivity, domain knowledge, Forge and reliability.

This is a routing and specialization system, not 229 separate chatbots the user must manage. HEY should choose specialists automatically, show them when useful, and keep one shared authorization and capability boundary. The full roster appears in the agent appendix.

### Cross-device and Device Fabric

Trusted devices become roles in one fabric: workstation, companion, confirmation device, camera, presentation controller or compute node, with pairing, trust, LAN paths, file transfer and handoff.

Representative capabilities: Windows support; macOS support; Linux support; Android support; iOS support using legitimate APIs; Tablet support.

### Offline and local

Local wake word, reminders, file search, selected local models, cached memory, local computer control and LAN-only operation with explicit degradation when cloud features are unavailable.

Representative capabilities: Local Mode; Local wake word; Local reminders; Local file search; Selected local models; Local computer control.

### Provider system

A multi-provider router balancing capability, health, cost, latency, quality, privacy and manual preference; it includes fallback, circuit breakers, budgets and usage tracking.

Representative capabilities: Multi-provider AI routing; OpenRouter integration; OpenAI-class provider support; Anthropic-class provider support; Gemini-class provider support; Local-model support.

### Proactive HEY

Useful initiative without nagging: briefings, deadline/calendar/prayer/weather/routine awareness, broken automation alerts, research watchers and suggestion controls.

Representative capabilities: Proactive suggestions; Morning briefing; Deadline awareness; Calendar awareness; Prayer-time awareness; Weather awareness.

### Productivity

Tasks, success criteria, dependencies, verification, missions, scheduling, routines, Focus Mode, Weekly Review, Goal Coach, Smart Notes and commitment memory.

Representative capabilities: Tasks; Task priorities; Task dependencies; Task success criteria; Task verification; Task retries.

### Search

One semantic search surface spanning conversations, files, projects, artifacts, memory, tasks, agents, workflows, commands, settings, tutorials and devices.

Representative capabilities: Universal Search; Search conversations; Search files; Search projects; Search artifacts; Search Cosmos memory.

### Modes

Named context bundles such as Study, Creator, Coding, Research, Business, Focus, Meeting, Presentation, Travel, Morning, Late Night, Accessibility, Private, Offline and Execution, plus custom modes.

Representative capabilities: Study Mode; Creator Mode; Coding Mode; Research Mode; Business Mode; Focus Mode.

### Religious features

Prayer times/notifications, Quran and Hadith access/research, Islamic calendar and dua support with provenance. HEY must not present itself as a scholar.

Representative capabilities: Prayer times; Prayer notifications; Quran access; Quran search/research; Hadith access; Hadith research.

### Accessibility

Keyboard, screen reader, focus, high contrast, reduced motion, text scaling, captioning and device/RTL accessibility profiles.

Representative capabilities: Keyboard navigation; Screen-reader support; Focus states; High contrast; Reduced motion; Text scaling.

### Localization

Sorani Kurdish, Kurmanji where implemented, Arabic and English with RTL layouts, locale formatting, pronunciation adaptation, translation and multilingual voice/tutorials.

Representative capabilities: Kurdish Sorani support; Kurdish Kurmanji support where implemented; Arabic support; English support; RTL layout; Locale-aware formatting.

### Accounts and authentication

Sign-up/sign-in, verification, reset, refresh, logout, resume, export/deletion and server-authoritative plans/entitlements without client-side security bypasses.

Representative capabilities: Sign up; Sign in; Email verification; Password reset; Session refresh; Logout.

### Billing and usage

Free/Pro/Elite architecture, plan limits, subscription lifecycle, checkout/portal, cost controls and usage dashboard. Pricing should remain configurable until commercial policy is finalized.

Representative capabilities: Free plan; Pro plan; Elite plan; Usage accounting; Plan limits; Upgrade.

### Security and Trust Center

Fail-closed authorization, RLS, least privilege, confirmations, audit, secret isolation, prompt-injection resistance, minimum-context sharing, permission expiry/scopes, revoke-all and Emergency Stop.

Representative capabilities: Fail-closed permission model; Authentication security; Authorization security; Supabase RLS; Least privilege; Explicit high-risk confirmations.

### PWA and install

Manifest, service worker, offline shell, standalone mode, deep links, shortcuts, safe updates and clear distinction between PWA and native capabilities.

Representative capabilities: Install HEY PWA; Web App Manifest; Service worker; Offline shell; Standalone PWA experience; PWA icons.

### Developer platform

API/SDK concepts, webhooks, MCP-style integrations, local plugins, developer console, logs, routing/cost/event inspection, sandbox, simulation and staged workflows.

Representative capabilities: HEY API; Agent SDK; Tool SDK; Workflow SDK; Webhooks; MCP-style integrations.

### Diagnostics and reliability

Health surfaces and recovery for providers, database, auth, Cosmos, audio/camera, native bridges, devices, storage, agents and workflows, plus graceful degradation and performance/battery/thermal adaptation.

Representative capabilities: HEY Health; Provider diagnostics; Database diagnostics; Supabase diagnostics; Auth diagnostics; Cosmos diagnostics.

### Observability and quality

Structured errors, correlation IDs, action receipts, traces, tests, release gates and benchmarks for precision, long-project consistency, computer control, memory and creativity.

Representative capabilities: Structured error logging; Provider health visibility; API failure visibility; Cost visibility; Abuse visibility; Mission tracing.

### Collaboration

Shared projects/artifacts/agents/workflows with roles, scoped permissions, revocation and activity visibility; private memory remains separate unless intentionally shared.

Representative capabilities: Shared projects; Project members; Collaboration roles; Shared artifacts; Shared agents; Shared workflows.

### Business / marketing / productivity intelligence

Business command workspace, strategy, operations, marketing, sales, competitor/market research, customer feedback clustering, content QA, campaign consistency and Brand Memory.

Representative capabilities: Business Command workspace; Marketing support; Sales support; Startup strategy; Finance planning; Operations support.

### Education

Study Mode, adaptive lessons, mastery, teacher/student outputs, quizzes, flashcards, exams, answer keys, lesson plans and worksheets.

Representative capabilities: Study Mode; Adaptive lessons; Mastery graphs; Teacher workspace; Student outputs; Teacher outputs.

### Health / legal / science informational support

Information and research support in health, medical, legal, science, engineering, data, statistics and compliance domains, with appropriate high-stakes caution.

Representative capabilities: Health information; Medical research support; Legal information support; Science research; Engineering support; Data analysis.

### Customization

Appearance, motion, voice behavior, personality, workspace, widgets, gestures and permission preferences should be adjustable without fragmenting the product identity.

Representative capabilities: Themes; Accent colors; Backgrounds; Glass intensity; Transparency; Contrast.

## What HEY lets you do outside a normal phone app

HEY’s defining ambition is that intelligence does not stop at the chat box. It can extend into the computer, browser, files, displays, trusted devices and physical interaction surfaces—while remaining permissioned and visible.

Control supported computers with pointer, keyboard, windows, apps, files, clipboard, screenshots and terminal actions under explicit permissions.

Use HEY Live to understand a selected monitor, app window, screen region or camera and guide the user with overlays, labels, arrows and step markers.

Keep timers, schedules, workflows, notifications, research and trusted background helpers running after the main window closes when the OS allows it.

Use a native compact Dynamic Island-like surface on desktop and legitimate equivalents on mobile platforms for status, approvals, timers, voice and progress.

Move conversations, missions, files and artifacts between trusted devices through Device Fabric and handoff checkpoints.

Use another trusted phone/tablet as a camera, confirmation device, presentation remote or companion while a desktop acts as the workstation.

Run local file search, selected local models, local computer control and cached memory during limited or offline operation.

Use optional gestures to summon HEY, select, drag, navigate, confirm/reject and control media or supported system actions.

Turn research or files directly into documents, presentations, worksheets, flashcards, media and structured artifacts rather than copying between separate apps.

Allow long-running missions to use cloud continuation or another trusted device when the local machine sleeps, where infrastructure and platform policy permit it.

### Examples of end-to-end “outside the app” workflows

Fix something on the computer: The user says “the download is broken.” HEY inspects the active window, asks for any required permission, checks the download state, identifies the cause, guides or acts, verifies the resulting file and returns an action receipt.

Continue a mission on another device: A desktop research mission reaches a point where the user leaves. HEY checkpoints the task and hands supervision to a trusted phone; later the final artifact appears back on the desktop with the same mission timeline.

Use the tablet as a visual companion: The desktop remains the compute/work device while a tablet shows a reference, camera feed, presentation controls or confirmation prompt.

Ambient voice without a full window: On a supported native platform, HEY can remain available through a tray helper, wake phrase and compact island; the full app opens only when the task needs richer context.

Gesture-assisted control: With explicit camera permission and visible sensing, a user can summon HEY, move/select items, pause media, confirm/reject or navigate supported interfaces using learned gestures.

Project-aware creation across apps: A user selects source files, asks for a campaign, and HEY produces copy, visuals, a presentation and video storyboard using the same Project DNA and approved brand rules rather than re-prompting each tool.

## What becomes newly possible or dramatically easier with HEY

Many individual ingredients exist in separate products. HEY’s differentiation is the integration: shared context, governed memory, cross-device continuity, verified action, creation systems and a single trust model. The following are the workflows HEY is designed to make practical in one system.

One relationship instead of separate assistants — HEY unifies chat, voice, Live, compact UI, memory, projects and devices around the same user and task context.

Memory that behaves like governed infrastructure — Cosmos is not just a chat-history search. It models provenance, confidence, privacy, contradictions, expiry, graph relationships and user approval.

Project DNA as a consistency engine — Brand, terminology, identity, accepted/rejected examples and design rules can persist across months of work and across output formats.

Pinpoint editing across modalities — The same “change only this” philosophy applies to text, code, images, layouts, audio, video and structured artifacts.

Action with verifiable state — HEY is designed to separate an intended action from an actually verified result, reducing the common assistant failure of claiming success after only generating instructions.

AI that can exist outside its main window — Background helpers, Dynamic Island, notifications, device handoff and native adapters let HEY participate in the user’s workflow without demanding a full-screen chat.

Capability creation without unsafe self-authority — Forge can design and test new capabilities, but permissions and high-risk installation remain governed by the user/security model.

Cross-device roles rather than duplicate apps — Each device can contribute what it is good at: screen/keyboard, camera, portability, confirmation, presentation control or compute.

One creation system from source to final artifact — Research, image/video/audio creation, presentations, documents and motion graphics share Project DNA, provenance, versions and verification.

A personal operating policy — Modes, privacy routing, provider budgets, notification caps, quiet hours and permission preferences let HEY behave differently without forcing the user to micromanage every request.

## System architecture and execution model

### Canonical execution flow

1. User intent / trigger

2. Context assembly with privacy filters

3. Capability lookup

4. Platform/provider availability

5. Trusted identity and authorization

6. Confirmation gate when required

7. Agent/tool/workflow execution

8. Verification

9. Normalized result

10. Audit + provenance + memory update + UI receipt

### Non-negotiable security boundaries

Client-supplied role, plan, entitlement or permission data is never authoritative at a sensitive execution boundary.

Agents, workflows, Forge artifacts and automations cannot grant themselves permissions or bypass confirmation policy.

Secrets stay server-side or in appropriate secure native storage; service-role secrets are never shipped in browser-visible variables.

High-impact operations must expose scope, risk and expected effect before action when meaningful.

Unsupported capabilities fail closed instead of returning fake success.

Prompt/tool output is treated as untrusted input when it can influence browser/computer control or other external actions.

Minimum necessary context is sent to providers; sensitive projects may require local-only routing.

Emergency Stop should be able to halt autonomous/high-risk actions while preserving read-only diagnostics.

### Provider routing

The launch router is free-first: local, free or free-tier paths are preferred when they satisfy quality and privacy needs. Paid adapters may be ready but disabled until configured. Routing can consider modality, task class, model capability, health, latency, cost, privacy, plan and explicit user choice. Circuit breakers and fallback prevent one failing provider from freezing the whole product.

### Cross-platform model

Web/PWA, Windows/Tauri, Android and iOS share the same product core and outcome contracts. Platform adapters implement what the OS legally and technically allows. “Parity” means the best legitimate outcome, not pretending browser code can perform unrestricted native actions. iOS background work and system-wide control, for example, require Apple-supported mechanisms and cannot be treated like an unrestricted desktop runtime.

## User experience model

### Conversation Surface

Default authenticated home. Chat history can hide. Voice can be entered without losing context. New conversation, current project, attachments and compact status remain obvious.

### Dynamic Island

Persistent native compact surface where available. Shows state, progress, approvals, timers, voice, media, handoff and completion; expands only when needed.

### Workspace

A spatial work area for widgets and artifacts. Users can move, resize, overlap, snap, group, stack, pin, dock, minimize and use multi-display layouts.

### Command Palette

The fastest route to any capability, setting, file, agent, project, command, device or action. Search results should be directly actionable.

### Universal Search

Semantic search across the entire user-visible HEY universe, filtered by scope and privacy.

### Home / dashboard

Optional overview of active project, mission, tasks, calendar, weather, prayer, usage, system health and recommendations.

### Trust Center

The place to see and revoke mic/camera/screen/background/device/agent/workflow permissions, cloud/local routing, integrations and recent sensitive actions.

### Tutorial Center

Replayable feature education, teach-by-doing and practice mode so HEY can remain powerful without becoming undiscoverable.

## Personality, modes and communication

HEY can feel brother-like, mentor-like, teacher-like, strategic, creative, critical or execution-focused without changing core truthfulness. Users can control challenge, humor, formality, verbosity, teaching depth, proactive behavior and surprise frequency. Modes should adjust workspace, agent mix, notifications, provider routing and voice/personality together rather than being cosmetic themes.

## Voice: target final experience

Same conversation as text chat; every spoken turn can appear as text and persist.

Continuous hands-free conversation with VAD/turn detection where supported.

Barge-in: user speech interrupts HEY speech quickly and cleanly.

Mute, unmute, stop, end session, output-device selection and visible audio state.

Speech output is sanitized so HEY does not read Markdown syntax, raw URLs, code fences or formatting noise as if they were prose.

Short conversational responses by default, with longer spoken explanations only when useful or requested.

Wake phrase is configurable; the current product preference can ship as “Wake up” while retaining “HEY” as an optional recognizable phrase.

Browser/PWA voice works in the foreground; native apps use platform audio sessions/background mechanisms where browsers cannot provide reliable behavior.

Voice animation reacts to real audio state/levels rather than playing decorative loops unrelated to speech.

## Cosmos: memory and personal intelligence

Cosmos should maintain both a private chronological timeline and a distilled semantic graph. The timeline answers “what happened”; the graph answers “what matters and how is it related.” Neither should mean that the entire memory store is sent to every model call.

Every important memory can carry source/provenance, confidence, timestamps, scope and relationships.

Conflicting memories are detected and resolved or quarantined instead of silently overwriting one another.

Project-isolated memory keeps project context from leaking into unrelated work.

Memory Inbox gives the user a review surface for uncertain or sensitive candidates.

Private Session and local-only modes allow work that should not enter persistent cloud memory.

Time Machine shows how memories, preferences and decisions evolved and what superseded what.

“Never remember this category” and deletion/export controls make memory governance explicit.

## Agents and Forge

The 229 built-in agents are specialist roles selected by orchestration; they should not behave as 229 isolated personalities. The canonical registry drives routing, UI, diagnostics and Forge compatibility. Custom agents remain separate from the built-in count.

Forge is the safe capability expansion system. It can create agents, teams, workflows, skills, commands, automations, widget templates, dashboards, capability packs, adapters and mini-app-like internal capabilities. The lifecycle is requirements → permission design → I/O contract → tests → sandbox/simulation → validation → preview → approval/install → registration → health monitoring → versioning → rollback. Private is the default; sharing is explicit.

## Proposed vNext additions — new capabilities to make HEY better

Everything in this chapter is an extension proposed in this document. These items are not being represented as already implemented. They are designed to strengthen usability, trust, continuity, privacy, creation quality and cross-device behavior while fitting HEY’s existing architecture.

V1. Universal Action Graph — A single graph connecting people, files, apps, devices, projects, agents, permissions, automations and artifacts so HEY can reason about what can be done next without hard-coded navigation.

V2. Intent Layer — A temporary intent object for every meaningful request: goal, constraints, risk, expected proof, deadline, preferred device and privacy level.

V3. Action Rehearsal — For high-impact actions, HEY can simulate the intended sequence and show the exact side effects before execution.

V4. Universal Undo — A cross-feature undo ledger for reversible actions across files, settings, workflows, artifacts and supported app actions.

V5. Proof of Completion — Tasks and missions can define proof requirements such as a changed file hash, sent message ID, created artifact, screenshot, or verified external state.

V6. Consent Receipts — Every sensitive permission or external action can generate a compact receipt showing who/what requested it, why, scope, duration and revocation path.

V7. Data Route Map — A live privacy map showing which information stayed local, which provider saw what context, and why each external route was chosen.

V8. Context Budget — Per-project and per-request controls for how much memory, files, screen content and conversation history may be included.

V9. Zero-Context Share — A one-tap mode that strips personal memory and project context before an external model or shared workspace receives a request.

V10. Private Compute Enclave — When hardware permits, sensitive local processing can be isolated into a constrained local runtime with explicit data-export boundaries.

V11. Shadow Mode — HEY plans what it would do but performs nothing; useful for learning the user, testing automations and auditing risky workflows.

V12. Teach HEY by Correction — When the user corrects an action, HEY can convert the correction into a scoped rule, preference or workflow test instead of repeating the mistake.

V13. Semantic Clipboard — Clipboard history becomes searchable, private-by-default context that can be transformed, compared, cited or moved between trusted devices.

V14. Workspace Scenes — Named multi-widget arrangements such as Launch Day, Study Sprint, Creator Studio and Deep Research, restored per device or display configuration.

V15. Attention Budget — A user-defined daily interruption budget that proactive HEY must respect, with criticality scoring and deferred delivery.

V16. Focus Shield — During focus sessions HEY can suppress noncritical notifications, park incoming tasks, capture interruptions and deliver a structured recap later.

V17. Adaptive Meeting Cockpit — Combines agenda, live notes, action items, relevant project memory, files, participant context and post-meeting follow-up in one mode.

V18. Mission Journal — Long-running missions maintain a human-readable timeline of decisions, attempts, blockers, evidence and recovery points.

V19. What Changed Digest — For projects, files, connected services or devices, HEY can summarize meaningful changes since the user last checked.

V20. Relationship-Aware Memory — Cosmos can distinguish facts about the user, another person, a project, an organization and a device, avoiding accidental cross-contamination.

V21. Memory Counterfactuals — HEY can answer “what would this decision look like if we ignored X preference?” without rewriting stored memory.

V22. Memory Quarantine — Low-confidence or conflicting memories stay isolated until confirmed, instead of silently affecting answers.

V23. Artifact Lineage — Every generated asset can expose its source files, prompts, models/providers, edits, approvals and downstream derivatives.

V24. Design Consistency Compiler — Project DNA can compile brand constraints into machine-checkable rules used by image, document, presentation and UI generation.

V25. Character/Object Identity Vault — Approved references for recurring characters, products and objects can be stored as protected identities with change thresholds.

V26. Multi-Artifact Change Set — One user request can propose coordinated edits across a document, presentation, image set and campaign assets with a single review screen.

V27. Cross-Device Task Migration — A running task can checkpoint and move between desktop, phone, tablet and trusted compute node without restarting the mission.

V28. Proximity Handoff — With explicit opt-in, a task or media session can surface on the most appropriate trusted nearby device.

V29. Room Mode — On supported devices, HEY can operate as an ambient assistant with strong visible sensing indicators, local wake-word processing and strict no-retention defaults.

V30. Multi-Device Camera Director — A project can use multiple trusted camera devices as selectable visual inputs for demonstrations, scanning or guided work.

V31. Compute Pool — Trusted devices can advertise safe compute capabilities so local workloads can be routed based on performance, battery and privacy.

V32. Offline Emergency Pack — A compact local bundle for reminders, critical notes, selected memory, documents, maps/files and basic assistant functions during internet loss.

V33. Provider Arbitration — For high-value tasks, multiple models may independently propose answers and a verifier can select or synthesize using quality/cost/privacy policy.

V34. Provider Reputation Memory — HEY records task-specific provider quality over time rather than relying only on static rankings.

V35. Latency SLOs — Interactive features can declare latency targets; the router chooses a faster fallback when the preferred model is too slow.

V36. Budget Autopilot — Users can set daily/monthly AI budgets; routing automatically adapts quality and provider selection while protecting critical tasks.

V37. Local Model Warm Pool — Frequently used local models can be prewarmed only when power/thermal state permits, avoiding slow first responses without wasting battery.

V38. Trust-Aware Automation — Automations can have trust levels that grow only after successful verified runs and shrink after failures or changed dependencies.

V39. Automation Digital Twin — A workflow can run against mock data and simulated tools before being allowed to touch real systems.

V40. Dependency Watch — HEY monitors workflow/provider/tool dependencies and warns before scheduled missions fail due to expired auth, changed APIs or unavailable devices.

V41. Capability Contracts — Every capability exposes machine-readable inputs, outputs, permissions, risks, platform requirements, fallbacks and verification methods.

V42. Capability Health Map — Users can see Ready, Limited, Needs Setup, Offline or Unavailable states instead of discovering failures during execution.

V43. Safe Self-Expansion — When HEY encounters a missing low-risk capability, Forge can draft and test a candidate; installation still follows risk and approval policy.

V44. Personal Command Language — Users can define natural phrases that map to verified workflows without learning syntax.

V45. Selection Everywhere — Text, files, regions of the screen, browser elements, images or objects can become temporary HEY context through one selection model.

V46. Input Fusion — Voice, text, pointer, camera, screen, gestures and files can be combined in one request while preserving provenance for each input.

V47. Output Fusion — A single task can deliberately produce text, speech, visual overlays, files, widgets, notifications and device actions as one coordinated response.

V48. Live Explain-Why — During execution HEY can answer why a provider, agent, device, permission or action was selected without exposing hidden reasoning.

V49. Confidence Surface — Important factual outputs can display concise confidence/source freshness indicators without cluttering normal chat.

V50. Decision Ledger Plus — Major decisions store alternatives considered, assumptions, evidence, chosen option, review date and later outcome.

V51. Outcome Learning — HEY can ask whether a recommendation or automation actually worked and use that feedback as scoped preference/quality data.

V52. Project Health — Projects get a health layer covering stale decisions, broken links, overdue tasks, unresolved contradictions and unverified outputs.

V53. Research Watchlists — Persistent research questions can be monitored and only notify when a meaningful evidence change occurs.

V54. Source Diffing — For recurring research, HEY highlights what changed between source versions rather than re-summarizing everything.

V55. Evidence Packs — A research result can export a compact bundle containing claims, citations, source snapshots, confidence and unresolved disagreements.

V56. Creator Continuity — Campaigns share approved brand memory, character identity, typography, voice and visual constraints across images, video, motion and copy.

V57. Shot Memory — Video projects remember approved framing, lenses, lighting, movement and continuity rules across generations.

V58. Motion System Memory — Motion timing, easing, transition grammar and typography behavior become reusable Project DNA rather than one-off prompts.

V59. Presentation Runtime — Slides can become live interactive surfaces connected to HEY, notes, timers, audience questions and supporting source material.

V60. Document Live Blocks — Documents can contain refreshable HEY blocks for data, summaries or status sections with explicit provenance and update controls.

V61. Accessibility Autopilot — HEY can proactively detect contrast, focus, captioning, motion and text-size issues in artifacts before export.

V62. Language Identity — Projects can define terminology, tone and translation rules per language rather than treating translation as word substitution.

V63. Religious Source Guard — Religious answers can require explicit source classes/provenance and clearly separate scripture, commentary and uncertain interpretation.

V64. Family / Shared Spaces Firewall — Shared spaces can expose only intentionally shared memory and artifacts while preserving each member’s private Cosmos.

V65. Guest Device Session — A temporary trusted-device session can expire automatically and leave no persistent private memory on the guest device.

V66. Lost Device Kill Switch — Trusted devices can be revoked from the Trust Center, invalidating tokens, handoff keys and background privileges.

V67. Incident Freeze — Emergency Stop can freeze automations, remote control and Forge installs while keeping read-only access to diagnostics and evidence.

V68. Privacy Replay — Users can review a timeline of when mic, camera, screen, local files or external providers were used during a mission.

V69. Release Truth Dashboard — Before launch, public claims are automatically compared against verified evidence so marketing cannot accidentally promise unverified features.

V70. Canary Capability Rollout — New capabilities can ship to a small opt-in group with health gates and automatic rollback conditions.

V71. Self-Test Center — HEY can periodically run non-destructive diagnostics for providers, mic, speakers, camera, notifications, storage, native bridges and database access.

V72. Golden Journeys — Critical user flows such as sign-in → chat → voice → persistence → task execution are continuously tested as release gates.

V73. Session Recovery Capsule — Before risky app upgrades or crashes, HEY can checkpoint open conversations, workspace layout, mission state and unsaved artifact context.

V74. Universal Import — HEY can ingest supported exports from other assistants, notes apps, task managers and file systems into scoped projects without silently merging private data.

V75. Universal Export — Users can export projects, memory, workflows, agents and artifacts into documented open formats to avoid lock-in.

V76. Personal AI Constitution — A user-controlled policy file defines boundaries such as privacy, spending, tone, high-risk actions, proactive behavior and forbidden categories.

V77. Explainable Personalization — HEY can show which explicit preference or project rule changed a response, with one-click correction or disable.

V78. Friction Detector — HEY notices repeated multi-step patterns and suggests an automation only after enough evidence, rather than nagging after one repetition.

V79. Capability Inbox — Newly installed or discovered capabilities appear in a review queue with permissions, examples and suggested placement before cluttering navigation.

V80. Adaptive Navigation — Frequently used capabilities can surface contextually while the primary navigation stays intentionally small and stable.

V81. Command Palette Actions — Search results are actionable: open, summarize, move, share, run, compare, continue, schedule, pin, inspect or ask HEY.

V82. Cross-Surface Continuity — The same object can move from chat to widget to Dynamic Island to notification to device handoff without losing task identity.

V83. Ambient Status Language — Listening, thinking, acting, waiting for approval, offline, degraded and failed states share one consistent visual/audio language everywhere.

V84. Proactive Silence — HEY can decide not to notify when information is low-value, redundant, stale or already handled.

V85. Personal SLA — Users can set expectations such as “never interrupt meetings,” “finish research by morning,” or “prefer privacy over speed,” which become routing policy.

V86. Human Override First — Every autonomous surface keeps a clear stop, pause, cancel, revoke or take-over path appropriate to its risk level.

## Implementation reality snapshot

This section deliberately separates product vision from evidence. It records only facts that have direct evidence from the current project/recent verification, not a blanket “everything works” claim.

Module 00 upgrade foundation: Verified locally. The transactional upgrader supports baseline hashes, backups, conflict detection, redacted logs, resumable state, rollback and local verification gates. Its recorded successful run had 43 tests passing, lint passing, web build passing and Rust cargo check passing.

Chat/auth/persistence: User testing previously confirmed sign-in, normal AI chat, provider response, conversation creation, message persistence, refresh persistence and switching chats. This evidence should not be generalized to unrelated subsystems.

Canonical capability registry: Current source includes a platform-aware registry with supported/unsupported/permission-required/restricted states and adapter-based execution.

Provider registry: Current source includes provider registration plus model/capability listing. Full production multi-provider routing/failover behavior still requires subsystem-specific verification.

Tauri/native desktop: The project contains a Tauri app and native-island window architecture. Successful cargo check verifies compilation in the tested local environment, not every native runtime feature.

Mobile/native verification: Android device behavior, iOS/macOS builds, signed installers and all platform permission flows require their actual environments. These must remain “not tested” until directly verified.

Forge validation: Source architecture includes Forge concepts and validation. “Static validation passed” must not be conflated with executing a generated capability safely in a real sandbox.

## Rules that protect HEY from becoming fake or fragile

Source exists ≠ implemented end-to-end.

Implemented ≠ automated-tested.

Automated-tested ≠ verified working in every platform/environment.

Verified locally ≠ production deployed.

A displayed capability or clickable button must never imply the external action succeeded.

Every public claim should be backed by a current evidence matrix.

Platform constraints should be documented as product behavior, not hidden as bugs or marketing exceptions.

New AI providers and native APIs should be adapters behind stable contracts so HEY does not become coupled to one vendor.

Destructive restructuring must preserve a recoverable backup and rollback path.

## Appendix A — Complete canonical capability inventory (1–1460)

The following list reproduces every numbered capability from the canonical 105-page HEY specification. Minor extraction typos in headings were normalized; capability meaning was not expanded or silently changed here.

### Core HEY identity and interaction (1–50)

1. Text chat with HEY

2. Voice conversations with HEY

3. Switching between Chat and Voice without losing context

4. Continuous conversation history

5. Project-aware conversations

6. File-aware conversations

7. Screen-aware conversations

8. Camera-aware conversations

9. Browser-aware conversations

10. Context-aware answers

11. Memory-aware answers

12. Device-aware answers

13. Mode-aware answers

14. Time-aware answers

15. Mood/context-sensitive response style

16. Brother-like HEY personality

17. Mentor behavior

18. Sensei/teacher behavior

19. Strategist behavior

20. Creative-partner behavior

21. Critical feedback when useful

22. Intelligent disagreement

23. Adaptive challenge level

24. Adjustable humor level

25. Adjustable formality

26. Adjustable verbosity

27. Adjustable teaching depth

28. “Surprise me intelligently” suggestions

29. No-nagging behavior

30. Behavioral continuity across sessions

31. Different response styles for simple vs complex questions

32. Quick answers

33. Deep-dive answers

34. Exhaustive research answers

35. Debate mode

36. Teacher mode

37. Strategist mode

38. Creative mode

39. Execution mode

40. Research mode

41. Late-night behavior

42. Morning behavior

43. Focused/silent behavior when less speech is better

44. Natural correction behavior

45. Natural uncertainty handling

46. Assumption extraction

47. Counterfactual reasoning

48. Decision support

49. Decision ledger

50. Opposing-view generation

### HEY Answer Engine (51–84)

51. Answer-first response structure

52. Dynamic response length

53. Evidence-backed answers

54. Citations where appropriate

55. Source-quality ranking

56. Freshness checking

57. Conflicting-source handling

58. Fact verification

59. Research synthesis

60. Hallucination reduction

61. Uncertainty detection

62. Output quality gate

63. Anti-sycophancy

64. Anti-filler behavior

65. Clarifying questions only when materially necessary

66. Research debate between agents

67. Answer consistency with Project DNA

68. Memory relevance filtering

69. Context firewalling

70. Privacy-aware answering

71. Translation-aware answering

72. Kurdish support

73. Arabic support

74. English support

75. RTL-aware responses

76. Voice-optimized responses

77. Live-mode short responses

78. Dynamic Island ultra-compact responses

79. Notification-sized summaries

80. Action-result summaries

81. Partial-success reporting

82. Failure explanations

83. Action receipts

84. Developer-mode detailed traces

### Cosmos / memory / second brain (85–132)

85. Persistent long-term memory

86. Preference memory

87. Project memory

88. Goal memory

89. Decision memory

90. Task memory

91. People memory

92. Device memory

93. File memory

94. Artifact memory

95. Conversation memory

96. Place memory

97. Routine memory

98. Command memory

99. Workflow memory

100. Agent memory

101. Memory provenance

102. Memory confidence

103. Memory freshness

104. Memory last-used tracking

105. Memory privacy scope

106. Memory relationships

107. Memory supersession

108. Memory expiration

109. Memory deduplication

110. Memory updates

111. Contradiction detection

112. Contradiction resolution

113. Memory deletion

114. Memory export

115. Memory sync

116. Memory decay

117. Memory Inbox

118. Approve memory candidate

119. Edit memory candidate

120. Reject memory candidate

121. Pin memory

122. “Never remember this category” control

123. Project-isolated memory

124. Private Session

125. Guest mode

126. Sensitive-screen mode

127. Local-only memory mode

128. Visual Cosmos graph

129. Memory graph relationships

130. Personal Intelligence Graph

131. Time-based memory history

132. Memory Time Machine

### Projects and Project DNA (133–172)

133. Create projects

134. Project switching

135. Project-specific memory

136. Project-specific files

137. Project-specific tasks

138. Project-specific agents

139. Project-specific workflows

140. Project-specific artifacts

141. Project goals

142. Project canonical sources

143. Project terminology

144. Project banned terminology

145. Brand guidelines

146. Color-system memory

147. Typography memory

148. Spacing/grid memory

149. Illustration-style memory

150. Photo-style memory

151. UI-style memory

152. Design tokens

153. Character identity memory

154. Object identity memory

155. Layout templates

156. Output dimensions

157. Output-format rules

158. Voice/tone rules

159. Naming rules

160. Citation rules

161. Approved examples

162. Rejected examples

163. Accepted generations as references

164. Project locks

165. Decision history

166. Project dependencies

167. Privacy scope

168. Style-drift detection

169. Terminology-drift detection

170. Layout-drift detection

171. Character-consistency checking

172. Canonical-source checking

### Pinpoint Precision (173–210)

173. “Change exactly this and nothing else” editing

174. Intended-change detection

175. Protected-state detection

176. Allowed-secondary-change detection

177. Explicit invariants

178. Implicit invariants

179. Automatic restore points

180. Actual-vs-intended delta comparison

181. Unintended-change detection

182. Automatic repair

183. Content locks

184. Layout locks

185. Style locks

186. Character locks

187. Object locks

188. Typography locks

189. Palette locks

190. Camera locks

191. Lighting locks

192. Timing locks

193. Audio locks

194. Voice locks

195. Structure locks

196. Code API locks

197. Data-schema locks

198. File-structure locks

199. Naming locks

200. Source/reference locks

201. Project DNA locks

202. Before/After inspector

203. Split comparison

204. Overlay comparison

205. Blink comparison

206. Text diff

207. Code diff

208. Layout diff

209. Object diff

210. Change metadata

### Artifact system and version history (211–231)

211. Artifact creation

212. Artifact Inspector

213. Version history

214. Branched version history

215. Git-like visual version graph

216. Name versions

217. Approve versions

218. Finalize versions

219. Duplicate versions

220. Restore versions

221. Compare versions

222. Merge compatible changes

223. Artifact provenance

224. Automatic snapshots

225. Destructive-edit restore points

226. Object-level edits

227. Layer-level edits

228. Paragraph-level edits

229. Shot-level edits

230. Component-level edits

231. Region-level edits

### Image generation (232–266)

232. Text-to-image

233. Image-to-image

234. Voice-to-image

235. Multiple reference images

236. Image variations

237. Transparent-background images

238. Vector-like outputs where supported

239. Icon generation

240. Logo generation

241. Poster generation

242. Diagram generation

243. UI mockup generation

244. Product visual generation

245. Educational illustration generation

246. Photographic generation

247. Illustration generation

248. Background generation

249. Texture generation

250. Social-media creative generation

251. Thumbnail generation

252. Marketing visual generation

253. Custom dimensions

254. Custom aspect ratios

255. Batch generation

256. Automatic provider choice

257. Manual provider override

258. Object identity persistence

259. Character identity persistence

260. Project identity persistence

261. Variant count control

262. Output ranking

263. Preference learning

264. Generation QA

265. Automatic retry

266. Automatic repair

### Image editing (267–303)

267. Brightness adjustment

268. Exposure adjustment

269. Contrast adjustment

270. Saturation adjustment

271. Hue adjustment

272. Temperature adjustment

273. Tint adjustment

274. Highlights adjustment

275. Shadows adjustment

276. Sharpening

277. Blur

278. Denoising

279. Crop

280. Rotate

281. Flip

282. Resize

283. Straighten

284. Perspective correction

285. Canvas extension

286. Background removal

287. Background replacement

288. Object removal

289. Object replacement

290. Recoloring

291. Generative fill

292. Outpainting

293. Upscaling

294. Restoration

295. Text replacement in images

296. Click-to-select

297. Lasso selection

298. Brush selection

299. Natural-language selection

300. Pointer selection

301. Voice selection

302. Object-list selection

303. Non-destructive editing where possible

### Storyboard and frame system (304–333)

304. Storyboard workspace

305. Script-to-scenes

306. Scenes-to-shots

307. Shot-card generation

308. Shot metadata

309. Camera angle control

310. Lens-feel control

311. Shot-size control

312. Composition control

313. Subject control

314. Pose/action control

315. Environment control

316. Lighting control

317. Palette control

318. Depth control

319. Motion-intent control

320. First-frame definition

321. End-frame definition

322. Shot duration

323. Shot transitions

324. Dialogue field

325. Voiceover field

326. Sound field

327. Continuity checking

328. Reordering shots

329. Regenerating one shot only

330. Locking approved shots

331. Shot variants

332. Character continuity

333. Object continuity

### Video generation and editing (334–367)

334. Text-to-video

335. Image-to-video

336. Frame-to-video

337. First/last-frame video generation

338. Storyboard-to-video

339. Video continuation

340. B-roll generation

341. Product video generation

342. UI-demo video generation

343. Educational video generation

344. Cinematic video generation

345. Marketing video generation

346. Shot extension

347. Camera control

348. Subject consistency

349. Long-video shot decomposition

350. Regenerate only failed shot

351. Trim

352. Split

353. Reorder clips

354. Crop

355. Resize

356. Aspect-ratio conversion

357. Speed adjustment

358. Silence removal

359. Captions

360. Subtitle translation

361. Titles

362. B-roll insertion

363. Voiceover insertion

364. Audio ducking

365. Color adjustments

366. Highlight extraction

367. Export presets

### Motion graphics (368–381)

368. Kinetic typography

369. Logo reveals

370. Product reveals

371. UI animation

372. HUD-style graphics when appropriate

373. Lower thirds

374. Animated graphs

375. Callouts

376. Infographics

377. Title sequences

378. Transitions

379. Explainer sequences

380. Editable motion outputs where possible

381. Motion-graphics instruction generation

### Audio and speech (382–404)

382. Speech-to-text

383. Transcription

384. Speaker diarization

385. Translation

386. Caption creation

387. Narration

388. Voiceover

389. Text-to-speech

390. Voice selection

391. Pronunciation control

392. Speech speed control

393. Pitch control

394. Expressiveness control

395. Noise reduction

396. Silence cleanup

397. Audio normalization

398. Segmentation

399. Dubbing

400. Alignment/sync

401. Sound-effect generation where provider supports it

402. Ambient audio generation where provider supports it

403. Region-specific audio editing

404. Track-specific audio editing

### Presentations (405–423)

405. PPTX creation

406. Presentation outlining

407. Slide narrative planning

408. Slide writing

409. Slide design

410. Visual generation

411. Diagram creation

412. Chart creation

413. Speaker notes

414. Citations

415. Theme system

416. Typography system

417. Animation/transitions

418. Presentation QA

419. Slide consistency checking

420. Slide-level Pinpoint editing

421. Presentation Director

422. Interactive presentations

423. Presenter mode

### Documents and books (424–447)

424. DOCX creation

425. PDF creation

426. Markdown documents

427. Long-form writing

428. Book-page generation

429. Document redesign

430. Document consistency

431. Citation support

432. Structured reports

433. Manuals

434. Guides

435. Worksheets

436. Teacher editions

437. Student editions

438. Exams

439. Answer keys

440. Notes

441. Flashcards

442. Mind maps

443. Lessons

444. Quizzes

445. Activities

446. Source-to-document transformation

447. Cross-format stale-content detection

### Knowledge transformation (448–462)

448. Source → summary

449. Source → notes

450. Source → presentation

451. Source → worksheet

452. Source → flashcards

453. Source → quiz

454. Source → audio explanation

455. Source → visual explainer

456. Source → mind map

457. Source → teacher edition

458. Source → student edition

459. Source → exam

460. Source → answer key

461. Universal “Turn this into…” workflow

462. Transformation provenance

### HEY Live (463–489)

463. Live voice session

464. Live screen understanding

465. Live camera understanding

466. Screen + camera simultaneously

467. Active-window understanding

468. Selected-monitor understanding

469. Selected-region understanding

470. File/project context during Live

471. Pointer context

472. Live source switching

473. Multiple-monitor support

474. Live pointer overlay

475. Highlight targets

476. Outline targets

477. Point at targets

478. Label targets

479. Dim unrelated areas

480. Draw arrows

481. Step markers

482. Guide Mode

483. Assist Mode

484. Act Mode

485. Visible sensing indicator

486. Pause sensing

487. App exclusions

488. Sensitive mode

489. No raw-feed retention by default

### Voice system (490–507)

490. Wake word “HEY”

491. Voice activity detection

492. Speech interruption / barge-in

493. Listening state

494. Thinking state

495. Speaking state

496. Deep British male voice direction

497. Voice-language detection

498. Voice translation

499. Voice summarization

500. Voice personality adaptation

501. Voice command execution

502. Background wake-word support where platform allows

503. Mute/unmute

504. Captions

505. Audio-output selection

506. Voice session duration

507. Voice-call style UI

### Dynamic Island (508–542)

508. Persistent native Dynamic Island

509. Works outside main HEY window where supported

510. Idle mode

511. Listening mode

512. Thinking mode

513. Speaking mode

514. Voice-call mode

515. Music/media mode

516. Generation mode

517. Research mode

518. Mission mode

519. Timer mode

520. Reminder mode

521. Upload mode

522. Download mode

523. Approval mode

524. Error mode

525. Recovery mode

526. Completion mode

527. Cross-device handoff mode

528. Expand/collapse

529. Mini chat

530. Quick actions

531. Progress display

532. Pause

533. Cancel

534. Approve

535. Reject

536. Open full HEY

537. Multi-monitor behavior

538. Custom position

539. Custom size

540. Custom transparency

541. Auto-hide

542. Always-on-top options

### Background HEY (543–561)

543. Tray/menu helper

544. HEY keeps running after main window closes

545. Background wake word

546. Background shortcuts

547. Background Dynamic Island

548. Background notifications

549. Background timers

550. Background schedules

551. Background workflows

552. Background Cosmos sync

553. Background agents

554. Background downloads/uploads

555. Background generation

556. Background research

557. Background media

558. Background handoffs

559. Close-preference settings

560. Full quit

561. Cloud task continuation during local sleep where supported

### Computer control (562–590)

562. Pointer movement

563. Click

564. Double-click

565. Right-click

566. Drag

567. Scroll

568. Keyboard typing

569. Keyboard shortcuts

570. App launching

571. Window management

572. Multi-monitor control

573. Process control

574. File operations

575. Clipboard actions

576. Screenshots

577. Downloads

578. Uploads

579. Terminal actions

580. System settings

581. Printer access where supported

582. Scanner access where supported

583. Bluetooth control where supported

584. External-drive handling

585. Network settings where allowed

586. Guide/Assist/Act levels

587. High-impact action preview

588. Action verification

589. Undo/recovery where possible

590. Prompt-injection shielding

### Browser control (591–608)

591. Open websites

592. Search web

593. Navigate pages

594. Tab control

595. Click web controls

596. Type into forms

597. Select menu items

598. Scroll pages

599. Upload files

600. Download files

601. Extract data

602. Summarize pages

603. Compare pages

604. Research from pages

605. Screenshot pages

606. Monitor pages

607. Browser selection → Ask HEY

608. Page-content injection defense

### Files (609–624)

609. File search

610. File reading

611. File summarization

612. File organization

613. File moving

614. File renaming

615. File duplication

616. File deletion with safeguards

617. Folder creation

618. Folder organization

619. Local-file intelligence

620. File-context awareness

621. Drag files into HEY

622. File-to-artifact conversion

623. File provenance

624. File-change verification

### Workspace (625–668)

625. Living workspace

626. Chat widget

627. Voice widget

628. Live widget

629. Image widget

630. Storyboard widget

631. Video widget

632. Audio widget

633. Presentation widget

634. Document widget

635. Browser widget

636. Research widget

637. Notes widget

638. Files widget

639. Code widget

640. Terminal widget

641. Calendar widget

642. Tasks widget

643. Timers widget

644. Media widget

645. Camera widget

646. Cosmos widget

647. Agents widget

648. Missions widget

649. Devices widget

650. Weather widget

651. Prayer widget

652. Usage widget

653. Notifications widget

654. Move widgets

655. Resize widgets

656. Overlap widgets

657. Snap widgets

658. Group widgets

659. Stack widgets

660. Pin widgets

661. Minimize widgets

662. Maximize widgets

663. Close widgets

664. Dock widgets

665. Multi-display layouts

666. Workspace templates

667. Semantic drag-and-drop

668. Adaptive workspace layouts

### Home / dashboard (669–684)

669. Active project overview

670. Current mission

671. Tasks

672. Calendar

673. Weather

674. Prayer information

675. Usage

676. System health

677. Reminders

678. Quick actions

679. Recent files/artifacts

680. Recommendations

681. Add Widget

682. Personalized layout

683. Mode-specific layout

684. Home not forced as default startup

### Navigation and discoverability (685–706)

685. Conversation Surface as default sign-in destination

686. Chat/Voice switcher

687. Primary navigation

688. Create hub

689. Projects

690. Cosmos

691. Research

692. Files

693. Tasks/Missions

694. Automations

695. Widgets

696. Explore More

697. Add capability

698. Pin capability

699. Reorder capability

700. Recent capabilities

701. Recommended capabilities

702. Universal Search

703. Command Palette

704. Contextual suggestions

705. First-use discovery

706. Feature tutorial discovery

### Tutorials (707–768)

707. First-launch tutorial

708. Chat tutorial

709. Voice tutorial

710. HEY Live tutorial

711. Dynamic Island tutorial

712. Widgets tutorial

713. Workspace tutorial

714. Projects tutorial

715. Project DNA tutorial

716. Cosmos tutorial

717. Memory Inbox tutorial

718. Image generation tutorial

719. Pinpoint tutorial

720. Image editing tutorial

721. Storyboard tutorial

722. Video tutorial

723. Motion graphics tutorial

724. Audio tutorial

725. Presentation tutorial

726. Document tutorial

727. Research tutorial

728. Browser tutorial

729. Files tutorial

730. Code tutorial

731. Tasks tutorial

732. Calendar tutorial

733. Mission tutorial

734. Automation tutorial

735. Teach-by-doing tutorial

736. Forge tutorial

737. Skills tutorial

738. Agents advanced tutorial

739. Modes tutorial

740. Focus Mode tutorial

741. Meeting Mode tutorial

742. Morning Mode tutorial

743. Devices tutorial

744. Cross-device tutorial

745. Gesture basics tutorial

746. Custom gesture tutorial

747. Permissions tutorial

748. Trust Center tutorial

749. Private Mode tutorial

750. Offline Mode tutorial

751. Notifications tutorial

752. Appearance tutorial

753. Voice-settings tutorial

754. Personality-settings tutorial

755. Provider-routing tutorial

756. Developer Console tutorial

757. Diagnostics tutorial

758. Time Machine tutorial

759. Command Palette tutorial

760. Universal Search tutorial

761. Collaboration tutorial

762. Billing/usage tutorial

763. Accessibility tutorial

764. Language/RTL tutorial

765. Tutorial Center

766. Replay tutorials

767. Practice mode

768. Reduced-motion tutorials

### Gestures (769–795)

769. Open-palm summon

770. Palm-to-fist grab

771. Fist move

772. Pinch click/select

773. Pinch drag

774. Two-hand spread enlarge

775. Two-hand shrink

776. Swipe-left back

777. Swipe-right forward

778. Swipe-down minimize

779. Swipe-up restore/maximize

780. Two-finger play/pause

781. Stop-palm interrupt

782. Point + pinch activate

783. Thumbs-up confirmation

784. Thumbs-down rejection

785. Both-palms overview

786. Horizontal rotation control

787. Vertical air-scroll

788. Custom gestures

789. Gesture recording

790. Gesture conflict detection

791. Gesture practice/test

792. Per-app gesture bindings

793. Per-device gestures

794. Gesture-risk classification

795. Local pose inference where possible

### Automations (796–815)

796. Workflow creation

797. Automation recorder

798. Teach-by-doing

799. Scheduled automations

800. Trigger-based automations

801. Conditional automations

802. Multi-step workflows

803. Tool actions in workflows

804. Approval gates

805. Retry logic

806. Verification steps

807. Pause/resume

808. Workflow history

809. Workflow versioning

810. Workflow rollback

811. Custom commands

812. Voice-triggered commands

813. Text commands

814. Gesture-triggered commands

815. Scheduled commands

### Forge (816–842)

816. Create agents

817. Create agent teams

818. Create workflows

819. Create skills

820. Create commands

821. Create automations

822. Create widget templates

823. Create dashboards

824. Create capability packs

825. Create adapters

826. Create internal mini-app-style capabilities

827. Duplicate-capability checking

828. Requirements gathering

829. Permission design

830. Input/output contract design

831. Test generation

832. Sandbox testing

833. Simulation

834. Validation

835. Preview

836. Approve/install

837. Register capability

838. Health monitoring

839. Versioning

840. Rollback

841. Private-by-default Forge output

842. Optional sharing/public publishing

### Built-in agent system (843–1071)

843. Agent orchestration

844. Intent agent

845. Context agent

846. Planning agent

847. Execution agent

848. Verification agent

849. Recovery agent

850. Task agent

851. Workflow agent

852. Capability agent

853. Permission agent

854. Security-policy agent

855. Quality agent

856. Response agent

857. Personality agent

858. Mode agent

859. Memory ingestion agent

860. Memory retrieval agent

861. Memory ranking agent

862. Memory dedup agent

863. Memory update agent

864. Memory decay agent

865. Memory deletion agent

866. Memory privacy agent

867. Memory provenance agent

868. Memory graph agent

869. Knowledge graph agent

870. Memory summarization agent

871. Preference agent

872. Pattern agent

873. Project-memory agent

874. Goal-memory agent

875. Web research agent

876. Deep research agent

877. Source verification agent

878. Fact-check agent

879. News agent

880. Academic agent

881. Document research agent

882. PDF research agent

883. Image research agent

884. Competitive research agent

885. Customer research agent

886. Market research agent

887. Synthesis agent

888. Citation agent

889. Research planner

890. Uncertainty agent

891. Software architect agent

892. Frontend agent

893. Backend agent

894. Full-stack agent

895. Database agent

896. Supabase agent

897. API agent

898. AI-integration agent

899. Provider-routing agent

900. Code-review agent

901. Debugger agent

902. Testing agent

903. E2E agent

904. Performance agent

905. DevOps agent

906. Release agent

907. Migration agent

908. Dependency agent

909. Documentation agent

910. Code-quality agent

911. Refactor agent

912. Build agent

913. Native/Tauri agent

914. Security auditor

915. Authentication agent

916. Authorization agent

917. Secret agent

918. Application-security agent

919. API-security agent

920. AI-security agent

921. Tool-security agent

922. Computer-control security agent

923. File-security agent

924. Privacy agent

925. Audit agent

926. Abuse-prevention agent

927. Incident-response agent

928. Computer-use agent

929. Desktop agent

930. Keyboard agent

931. Pointer agent

932. Window agent

933. App-launcher agent

934. Process agent

935. Filesystem agent

936. File-organization agent

937. Browser agent

938. Web-form agent

939. Download agent

940. Clipboard agent

941. Screenshot agent

942. Terminal agent

943. System-settings agent

944. Voice agent

945. STT agent

946. TTS agent

947. Wake-word agent

948. VAD agent

949. Interruption agent

950. Voice-personality agent

951. Language-detection agent

952. Translation agent

953. Conversation agent

954. Voice-summary agent

955. English agent

956. Kurdish agent

957. Arabic agent

958. RTL agent

959. Internationalization agent

960. Pronunciation agent

961. Product manager agent

962. Product-strategy agent

963. UX-research agent

964. UX-design agent

965. UI-design agent

966. Design-system agent

967. Creative-director agent

968. Branding agent

969. Motion agent

970. Accessibility agent

971. Responsive-design agent

972. Empty-state agent

973. Error-state agent

974. Onboarding agent

975. Design-QA agent

976. Workspace agent

977. Widget agent

978. Layout agent

979. State agent

980. Dynamic-Island agent

981. Notification agent

982. Timer agent

983. Media agent

984. Calendar agent

985. Reminder agent

986. Taskboard agent

987. Search agent

988. Proactive agent

989. Morning agent

990. Routine agent

991. Focus agent

992. Time-management agent

993. Weekly-review agent

994. Goal-coach agent

995. Productivity agent

996. Personal-development agent

997. Learning agent

998. Study agent

999. Creator agent

1000. Writer agent

1001. Editor agent

1002. Social agent

1003. Marketing agent

1004. Sales agent

1005. Startup agent

1006. Finance-planning agent

1007. Operations agent

1008. Customer-support agent

1009. Competitor agent

1010. Content-QA agent

1011. Vision agent

1012. Screen-understanding agent

1013. Document-vision agent

1014. Camera agent

1015. Phone agent

1016. Tablet agent

1017. Display agent

1018. TV agent

1019. Smart-home agent

1020. Wearable agent

1021. Vehicle agent

1022. Cross-device agent

1023. Discovery agent

1024. Pairing agent

1025. Health agent

1026. Prayer-times agent

1027. Quran agent

1028. Hadith agent

1029. Islamic-calendar agent

1030. Religious-research agent

1031. Health-information agent

1032. Medical-research agent

1033. Legal-information agent

1034. Education agent

1035. Science agent

1036. Engineering agent

1037. Data-analysis agent

1038. Statistics agent

1039. Visualization agent

1040. Documentation/compliance agent

1041. Regression agent

1042. Integration-validation agent

1043. Contract-test agent

1044. Data-integrity agent

1045. User-journey agent

1046. Trust agent

1047. Hallucination-detection agent

1048. Output-sanitization agent

1049. Audit-review agent

1050. Release-gate agent

1051. Forge-planner agent

1052. Agent-designer agent

1053. Forge-validator agent

1054. Test-generator agent

1055. Workflow-designer agent

1056. Tool-designer agent

1057. Capability-duplicate agent

1058. Forge-versioning agent

1059. Forge-health agent

1060. Forge-governance agent

1061. Agent-router agent

1062. Scheduler agent

1063. Load-balancer agent

1064. Fallback agent

1065. Cost-controller agent

1066. Latency-controller agent

1067. Observability agent

1068. Dependency agent

1069. Retry-policy agent

1070. Lifecycle agent

1071. Registry agent

### Cross-device and Device Fabric (1072–1101)

1072. Windows support

1073. macOS support

1074. Linux support

1075. Android support

1076. iOS support using legitimate APIs

1077. Tablet support

1078. TV/projector support

1079. Wearable support where integrated

1080. Vehicle support where integrated

1081. Smart-home integrations

1082. Device discovery

1083. Device pairing

1084. Device trust

1085. Device roles

1086. Desktop workstation role

1087. Mobile companion role

1088. Private-confirmation device role

1089. Camera device role

1090. Presentation controller role

1091. Compute node role

1092. LAN direct communication

1093. LAN compute

1094. Cross-device file transfer

1095. Cross-device conversation continuity

1096. Cross-device mission continuation

1097. Cross-device artifact continuation

1098. Follow Me

1099. Proximity routing

1100. Shared memory controls

1101. Device handoff

### Offline and local (1102–1117)

1102. Local Mode

1103. Local wake word

1104. Local reminders

1105. Local file search

1106. Selected local models

1107. Local computer control

1108. Cached memory

1109. LAN-only operation

1110. Offline degradation

1111. Cloud-action queueing

1112. Local/cloud indicator

1113. Local-only project policy

1114. Privacy-based routing

1115. Hardware-adaptive routing

1116. Battery-aware routing

1117. Thermal-aware routing

### Provider system (1118–1137)

1118. Multi-provider AI routing

1119. OpenRouter integration

1120. OpenAI-class provider support

1121. Anthropic-class provider support

1122. Gemini-class provider support

1123. Local-model support

1124. Image-provider adapters

1125. Video-provider adapters

1126. Audio-provider adapters

1127. Provider health monitoring

1128. Provider benchmarking

1129. Provider fallback

1130. Provider circuit breaker

1131. Cost-aware routing

1132. Latency-aware routing

1133. Quality-aware routing

1134. Privacy-aware routing

1135. Manual provider override

1136. Provider budgets

1137. Provider usage tracking

### Proactive HEY (1138–1155)

1138. Proactive suggestions

1139. Morning briefing

1140. Deadline awareness

1141. Calendar awareness

1142. Prayer-time awareness

1143. Weather awareness

1144. Routine awareness

1145. Broken-automation alerts

1146. Device alerts

1147. Research watchers

1148. Commitment reminders

1149. Cosmos-pattern suggestions

1150. Notification caps

1151. Quiet hours

1152. Cooldowns

1153. Per-category controls

1154. Delivery-device controls

1155. No-nagging policy

### Productivity (1156–1177)

1156. Tasks

1157. Task priorities

1158. Task dependencies

1159. Task success criteria

1160. Task verification

1161. Task retries

1162. Mission Center

1163. Long-running missions

1164. Pause/resume missions

1165. Mission replay

1166. Mission provenance

1167. Mission blockers

1168. Duration learning

1169. Calendar intelligence

1170. Scheduling proposals

1171. Routines

1172. Focus Mode

1173. Weekly Review

1174. Goal Coach

1175. Smart Notes

1176. Remember-later

1177. Commitment memory

### Search (1178–1193)

1178. Universal Search

1179. Search conversations

1180. Search files

1181. Search projects

1182. Search artifacts

1183. Search Cosmos memory

1184. Search tasks

1185. Search agents

1186. Search workflows

1187. Search commands

1188. Search settings

1189. Search tutorials

1190. Search devices

1191. Semantic search

1192. Filters

1193. Recent searches

### Modes (1194–1214)

1194. Study Mode

1195. Creator Mode

1196. Coding Mode

1197. Research Mode

1198. Business Mode

1199. Focus Mode

1200. Meeting Mode

1201. Presentation Mode

1202. Travel Mode

1203. Morning Mode

1204. Late Night Mode

1205. Accessibility Mode

1206. Private Mode

1207. Offline Mode

1208. Execution Mode

1209. Mode-specific workspace

1210. Mode-specific agents

1211. Mode-specific notifications

1212. Mode-specific provider routing

1213. Mode-specific voice/personality

1214. Custom modes

### Religious features (1215–1225)

1215. Prayer times

1216. Prayer notifications

1217. Quran access

1218. Quran search/research

1219. Hadith access

1220. Hadith research

1221. Islamic calendar

1222. Dua support

1223. Source provenance

1224. Scholar-reference connector concept

1225. HEY does not present itself as a scholar

### Accessibility (1226–1237)

1226. Keyboard navigation

1227. Screen-reader support

1228. Focus states

1229. High contrast

1230. Reduced motion

1231. Text scaling

1232. Accessible color choices

1233. Captioning

1234. Voice alternatives

1235. Accessibility profiles

1236. Device-specific accessibility

1237. RTL accessibility

### Localization (1238–1247)

1238. Kurdish Sorani support

1239. Kurdish Kurmanji support where implemented

1240. Arabic support

1241. English support

1242. RTL layout

1243. Locale-aware formatting

1244. Pronunciation adaptation

1245. Translation

1246. Multilingual voice

1247. Multilingual tutorials

### Accounts and authentication (1248–1261)

1248. Sign up

1249. Sign in

1250. Email verification

1251. Password reset

1252. Session refresh

1253. Logout

1254. Returning-user resume

1255. Account deletion

1256. Data export

1257. Server-side plan enforcement

1258. Server-side entitlements

1259. Founder/cofounder role without bypassing security

1260. Admin-granted plans

1261. Session security

### Billing and usage (1262–1276)

1262. Free plan

1263. Pro plan

1264. Elite plan

1265. Usage accounting

1266. Plan limits

1267. Upgrade

1268. Downgrade

1269. Cancellation

1270. Payment-failure handling

1271. Subscription-state syncing

1272. Checkout

1273. Billing portal

1274. Server-side entitlement checks

1275. Cost controls

1276. User usage dashboard

### Security and Trust Center (1277–1316)

1277. Fail-closed permission model

1278. Authentication security

1279. Authorization security

1280. Supabase RLS

1281. Least privilege

1282. Explicit high-risk confirmations

1283. Audit logs

1284. Secret isolation

1285. Prompt-injection resistance

1286. Minimum-context sharing

1287. Agent self-authorization prevention

1288. Trust Center

1289. Mic-status control

1290. Camera-status control

1291. Screen-status control

1292. Background-state control

1293. Account/integration control

1294. Device-trust control

1295. Agent permission control

1296. Workflow permission control

1297. Cosmos privacy control

1298. Cloud/local routing control

1299. Permission expiry

1300. Once-only permissions

1301. Session permissions

1302. Timed permissions

1303. Mission permissions

1304. Persistent permissions

1305. Revoke All

1306. Emergency Stop

1307. Rate limiting

1308. Abuse prevention

1309. Input validation

1310. Output sanitization

1311. File-upload validation

1312. CSRF/CORS handling where relevant

1313. XSS protection

1314. Webhook security

1315. Session/token protection

1316. Sensitive-log protection

### PWA and install (1317–1332)

1317. Install HEY PWA

1318. Web App Manifest

1319. Service worker

1320. Offline shell

1321. Standalone PWA experience

1322. PWA icons

1323. Maskable icons

1324. beforeinstallprompt flow where supported

1325. Manual-install guidance where needed

1326. Deep linking

1327. App shortcuts

1328. Safe update flow

1329. Update notifications

1330. Download page

1331. Native vs PWA install distinction

1332. Installed PWA launches to Chat/Voice Conversation Surface

### Developer platform (1333–1352)

1333. HEY API

1334. Agent SDK

1335. Tool SDK

1336. Workflow SDK

1337. Webhooks

1338. MCP-style integrations

1339. Local plugins

1340. Developer Console

1341. Logs

1342. Routing inspection

1343. Cost inspection

1344. Event inspection

1345. Tests

1346. Sandbox

1347. Feature flags

1348. Capability manifests

1349. Developer Mode

1350. Simulation Mode

1351. Workflow staging

1352. Release rollback

### Diagnostics and reliability (1353–1381)

1353. HEY Health

1354. Provider diagnostics

1355. Database diagnostics

1356. Supabase diagnostics

1357. Auth diagnostics

1358. Cosmos diagnostics

1359. Microphone diagnostics

1360. Speaker diagnostics

1361. Camera diagnostics

1362. Wake-word diagnostics

1363. Notification diagnostics

1364. Tauri/native diagnostics

1365. OS diagnostics

1366. Browser diagnostics

1367. Integration diagnostics

1368. Device diagnostics

1369. Storage diagnostics

1370. Agent diagnostics

1371. Workflow diagnostics

1372. Retry

1373. Fallback

1374. Reconnect

1375. Resume

1376. Restore

1377. Crash recovery

1378. Graceful degradation

1379. Performance adaptation

1380. Battery adaptation

1381. Thermal adaptation

### Observability and quality (1382–1404)

1382. Structured error logging

1383. Provider health visibility

1384. API failure visibility

1385. Cost visibility

1386. Abuse visibility

1387. Mission tracing

1388. Tool tracing

1389. Correlation IDs

1390. Action receipts

1391. Regression tests

1392. Integration tests

1393. Contract tests

1394. E2E tests

1395. Visual regression

1396. Data integrity checks

1397. User-journey tests

1398. Release gates

1399. HEY benchmarks

1400. Precision benchmark

1401. Long-project consistency benchmark

1402. Computer-control benchmark

1403. Memory benchmark

1404. Creativity benchmark

### Collaboration (1405–1414)

1405. Shared projects

1406. Project members

1407. Collaboration roles

1408. Shared artifacts

1409. Shared agents

1410. Shared workflows

1411. Family/shared spaces concept

1412. Permission-scoped sharing

1413. Controlled revoke access

1414. Collaboration activity

### Business / marketing / productivity intelligence (1415–1428)

1415. Business Command workspace

1416. Marketing support

1417. Sales support

1418. Startup strategy

1419. Finance planning

1420. Operations support

1421. Competitor analysis

1422. Market research

1423. Customer-feedback clustering

1424. Content QA

1425. Campaign consistency

1426. Brand Memory

1427. Experiment tracking

1428. Creator Workspace

### Education (1429–1441)

1429. Study Mode

1430. Adaptive lessons

1431. Mastery graphs

1432. Teacher workspace

1433. Student outputs

1434. Teacher outputs

1435. Quiz generation

1436. Flashcards

1437. Exam generation

1438. Answer keys

1439. Lesson planning

1440. Worksheets

1441. Learning-profile adaptation

### Health / legal / science informational support (1442–1450)

1442. Health information

1443. Medical research support

1444. Legal information support

1445. Science research

1446. Engineering support

1447. Data analysis

1448. Statistics

1449. Visualization

1450. Documentation/compliance support

### Customization (1451–1460)

1451. Themes

1452. Accent colors

1453. Backgrounds

1454. Glass intensity

1455. Transparency

1456. Contrast

1457. Text size

1458. Density

1459. Corner radius

1460. Shadows

## Appendix B — Exact 229 built-in agent roster

The built-in registry spans 843 through 1071 inclusive: exactly 229 roles. Custom user-created/Forge agents are additional and must not alter this built-in count unless the canonical registry itself is intentionally revised.

843. Agent orchestration

844. Intent agent

845. Context agent

846. Planning agent

847. Execution agent

848. Verification agent

849. Recovery agent

850. Task agent

851. Workflow agent

852. Capability agent

853. Permission agent

854. Security-policy agent

855. Quality agent

856. Response agent

857. Personality agent

858. Mode agent

859. Memory ingestion agent

860. Memory retrieval agent

861. Memory ranking agent

862. Memory dedup agent

863. Memory update agent

864. Memory decay agent

865. Memory deletion agent

866. Memory privacy agent

867. Memory provenance agent

868. Memory graph agent

869. Knowledge graph agent

870. Memory summarization agent

871. Preference agent

872. Pattern agent

873. Project-memory agent

874. Goal-memory agent

875. Web research agent

876. Deep research agent

877. Source verification agent

878. Fact-check agent

879. News agent

880. Academic agent

881. Document research agent

882. PDF research agent

883. Image research agent

884. Competitive research agent

885. Customer research agent

886. Market research agent

887. Synthesis agent

888. Citation agent

889. Research planner

890. Uncertainty agent

891. Software architect agent

892. Frontend agent

893. Backend agent

894. Full-stack agent

895. Database agent

896. Supabase agent

897. API agent

898. AI-integration agent

899. Provider-routing agent

900. Code-review agent

901. Debugger agent

902. Testing agent

903. E2E agent

904. Performance agent

905. DevOps agent

906. Release agent

907. Migration agent

908. Dependency agent

909. Documentation agent

910. Code-quality agent

911. Refactor agent

912. Build agent

913. Native/Tauri agent

914. Security auditor

915. Authentication agent

916. Authorization agent

917. Secret agent

918. Application-security agent

919. API-security agent

920. AI-security agent

921. Tool-security agent

922. Computer-control security agent

923. File-security agent

924. Privacy agent

925. Audit agent

926. Abuse-prevention agent

927. Incident-response agent

928. Computer-use agent

929. Desktop agent

930. Keyboard agent

931. Pointer agent

932. Window agent

933. App-launcher agent

934. Process agent

935. Filesystem agent

936. File-organization agent

937. Browser agent

938. Web-form agent

939. Download agent

940. Clipboard agent

941. Screenshot agent

942. Terminal agent

943. System-settings agent

944. Voice agent

945. STT agent

946. TTS agent

947. Wake-word agent

948. VAD agent

949. Interruption agent

950. Voice-personality agent

951. Language-detection agent

952. Translation agent

953. Conversation agent

954. Voice-summary agent

955. English agent

956. Kurdish agent

957. Arabic agent

958. RTL agent

959. Internationalization agent

960. Pronunciation agent

961. Product manager agent

962. Product-strategy agent

963. UX-research agent

964. UX-design agent

965. UI-design agent

966. Design-system agent

967. Creative-director agent

968. Branding agent

969. Motion agent

970. Accessibility agent

971. Responsive-design agent

972. Empty-state agent

973. Error-state agent

974. Onboarding agent

975. Design-QA agent

976. Workspace agent

977. Widget agent

978. Layout agent

979. State agent

980. Dynamic-Island agent

981. Notification agent

982. Timer agent

983. Media agent

984. Calendar agent

985. Reminder agent

986. Taskboard agent

987. Search agent

988. Proactive agent

989. Morning agent

990. Routine agent

991. Focus agent

992. Time-management agent

993. Weekly-review agent

994. Goal-coach agent

995. Productivity agent

996. Personal-development agent

997. Learning agent

998. Study agent

999. Creator agent

1000. Writer agent

1001. Editor agent

1002. Social agent

1003. Marketing agent

1004. Sales agent

1005. Startup agent

1006. Finance-planning agent

1007. Operations agent

1008. Customer-support agent

1009. Competitor agent

1010. Content-QA agent

1011. Vision agent

1012. Screen-understanding agent

1013. Document-vision agent

1014. Camera agent

1015. Phone agent

1016. Tablet agent

1017. Display agent

1018. TV agent

1019. Smart-home agent

1020. Wearable agent

1021. Vehicle agent

1022. Cross-device agent

1023. Discovery agent

1024. Pairing agent

1025. Health agent

1026. Prayer-times agent

1027. Quran agent

1028. Hadith agent

1029. Islamic-calendar agent

1030. Religious-research agent

1031. Health-information agent

1032. Medical-research agent

1033. Legal-information agent

1034. Education agent

1035. Science agent

1036. Engineering agent

1037. Data-analysis agent

1038. Statistics agent

1039. Visualization agent

1040. Documentation/compliance agent

1041. Regression agent

1042. Integration-validation agent

1043. Contract-test agent

1044. Data-integrity agent

1045. User-journey agent

1046. Trust agent

1047. Hallucination-detection agent

1048. Output-sanitization agent

1049. Audit-review agent

1050. Release-gate agent

1051. Forge-planner agent

1052. Agent-designer agent

1053. Forge-validator agent

1054. Test-generator agent

1055. Workflow-designer agent

1056. Tool-designer agent

1057. Capability-duplicate agent

1058. Forge-versioning agent

1059. Forge-health agent

1060. Forge-governance agent

1061. Agent-router agent

1062. Scheduler agent

1063. Load-balancer agent

1064. Fallback agent

1065. Cost-controller agent

1066. Latency-controller agent

1067. Observability agent

1068. Dependency agent

1069. Retry-policy agent

1070. Lifecycle agent

1071. Registry agent

## Appendix C — Canonical capabilities following item 1460

The source specification continues after item 1460 with additional approved customization, selection-intelligence and release-system concepts that were not assigned individual numbers. They are included here so they are not lost.

Animation intensity

Voice visualizer style

Cursor settings

Interface sounds

Dynamic Island settings

Mode-specific appearance

Voice speed

Voice pitch

Voice expressiveness

Wake phrase customization

Challenge level

Humor level

Formality

Verbosity

Proactivity

Teaching style

Surprise frequency

Workspace layout

Dock settings

Widget defaults

Gesture customization

Permission preferences

Import/export customization presets

Command Palette

Global shortcuts

Selection-based HEY

Browser selection → HEY

File selection → HEY

Optional clipboard context

Drag-anything into HEY

Mobile share-to-HEY

Camera-to-action

Screen-to-action

Input Fusion

Output Fusion

Feature flags

Staged rollout

Release rollback

Production diagnostics

Backup system

Database migrations

Migration rollback

Crash recovery

Deployment checks

Launch acceptance matrix

Public claims truth matrix

Incident severity system

Known issues

Support process

Bug-report flow

Post-launch hotfix flow

Launch war room

## Appendix D — Source basis and reconciliation notes

Primary product basis: the canonical 105-page HEY specification provided by the project owner, containing the complete numbered capability map and agent roster. Additional product decisions in this document reconcile later project directions: Conversation Surface as default home, premium graphite/glass design, one canonical 229-agent registry, free-first launch routing, shared core with native adapters, strong permission boundaries, and evidence-based verification semantics.

Where older directions conflicted, this document favors the newest explicit direction while preserving configurability where possible. Examples: the wake phrase becomes configurable; “Wake up” can be the preferred launch phrase while “HEY” remains an option. Free/Pro/Elite remain architectural plan tiers, while exact commercial pricing is intentionally not hard-coded here. Unreal Engine is not a required product dependency; Dream World or other interactive systems should choose the runtime that best fits the technical requirements.

## Final product statement

HEY should ultimately be the place where the user can think, ask, create, remember, research, decide, automate and act—across files, projects, software and trusted devices—without giving up control over privacy, permissions, proof, reversibility or product quality.


[Table extracted from original Product Bible]

IMPORTANT SCOPE NOTE; This document is a product bible and target specification, not a claim that every capability is already verified in production. “Where supported” means the strongest legitimate implementation permitted by the operating system, connected service, device permissions, provider availability and user authorization. Proposed vNext additions are labeled separately.


[Table extracted from original Product Bible]

Term | Meaning

Canonical / approved | Part of the HEY product specification.

Architected / source exists | The codebase contains an implementation or foundation; this alone is not proof of end-to-end behavior.

Automated-tested | A specific test contract has passed.

Verified working | Direct evidence shows the intended behavior works in the tested environment.

Platform-constrained | The exact behavior depends on OS/API permissions; HEY must use legitimate platform mechanisms or degrade honestly.

Proposed vNext | A new addition in this document intended to make HEY stronger; not represented as already built.
