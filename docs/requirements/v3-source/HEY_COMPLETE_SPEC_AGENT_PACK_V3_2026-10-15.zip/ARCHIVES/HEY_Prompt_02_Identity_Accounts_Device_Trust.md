You are the principal production engineer responsible for HEY’s canonical Identity, Accounts, Sessions, Authentication, Workspace Identity Boundaries, and Device Trust system.

This is Prompt 02 of the HEY-NEXT production program.

The existing newest HEY codebase is currently unavailable.

Do NOT invent or assume its architecture.

Build this subsystem as a production-grade, interface-stable, integration-ready package that can later be reconciled with the real HEY codebase by Claude Code.

Create:

`HEY-NEXT/02-identity-accounts-device-trust/`

This package must use and conform to the canonical contracts established by:

`HEY-NEXT/01-global-foundation/`

If Prompt 01 files are not physically available in this task environment, reproduce only the minimum shared type assumptions necessary for this package and mark them clearly as:

`TEMPORARY CONTRACT MIRRORS — MUST BE RECONCILED WITH PROMPT 01`

Do NOT create competing global contracts.

==================================================
ABSOLUTE FINAL PRODUCT CONTRACT
==================================================

This is FINAL-PRODUCT engineering.

Forbidden:

- MVPs
- prototypes presented as finished
- demo-only authentication
- fake login flows
- hard-coded users
- hard-coded organizations
- placeholder session logic
- frontend-only auth
- backend-only auth
- localStorage-only trust for consequential security state
- insecure “remember me”
- boolean authorization shortcuts
- fake device registration
- fake biometric support
- fake passkey support
- fake MFA
- silently deferred security work
- TODO-driven completion claims
- mocks presented as production behavior
- “works on my machine” as completion evidence
- creating duplicate identity or session systems
- security-by-obscurity
- trusting client-supplied identity claims
- trusting device names as device identity
- trusting model output as authentication or authorization
- assuming code exists means security is complete

For everything applicable, completion requires:

research →
architecture →
implementation →
data models →
authentication →
session security →
account lifecycle →
workspace/org boundaries →
device enrollment →
device trust →
revocation →
recovery →
security →
privacy →
failure handling →
offline/degraded behavior →
weak-device behavior →
observability →
auditability →
accessibility readiness →
localization readiness →
tests →
adversarial tests →
integration tests →
recovery tests →
evidence.

If you find a fixable defect within this package, fix it.

Discovery creates work.

Do not claim PRODUCTION_READY without evidence.

==================================================
PACKAGE RESPONSIBILITY
==================================================

Own exactly these concerns:

1. User identity
2. Account identity
3. Authentication
4. Sign-up
5. Sign-in
6. Sign-out
7. Session creation
8. Session renewal
9. Session expiry
10. Session revocation
11. Multi-device sessions
12. Device registration
13. Device identity
14. Device enrollment
15. Device trust
16. Device naming
17. Device metadata
18. Device capability identity linkage
19. Lost-device handling
20. Device revocation
21. Suspicious-session handling
22. Reauthentication
23. Step-up authentication
24. Passkey architecture
25. Password fallback if supported
26. MFA architecture
27. Recovery architecture
28. Account recovery
29. Recovery codes/keys where justified
30. Trusted recovery contacts where appropriate
31. Workspace membership identity
32. Organization membership identity
33. Personal/work/family account separation
34. Role identity
35. Service identities
36. Agent identities
37. Extension identities
38. External-agent identities
39. Machine/service accounts
40. Session scopes
41. Temporary delegated sessions
42. Guest/shared-device sessions
43. Public-display/session privacy
44. Owner/internal operator identity
45. Authentication audit trail
46. Identity security events
47. Identity export/migration contracts
48. Account deletion lifecycle
49. Identity-data retention
50. Cross-device identity continuity

Do NOT build the full authorization/permission engine here.

Prompt 01 owns the canonical authorization foundation.

This package authenticates WHO/WHAT something is.

The Trust Kernel later decides WHAT it may do.

==================================================
CORE ARCHITECTURAL RULE
==================================================

Authentication answers:

`Who are you?`

Session management answers:

`Is this authenticated context still valid?`

Device trust answers:

`Which physical/logical device is participating, and how much should HEY trust it?`

Authorization answers:

`What are you allowed to do?`

Do not merge these concepts into one boolean.

==================================================
IDENTITY MODEL
==================================================

Create typed identities for at least:

- HumanUserIdentity
- AccountIdentity
- WorkspaceIdentity
- OrganizationIdentity
- DeviceIdentity
- SessionIdentity
- ServiceIdentity
- AgentIdentity
- ExtensionIdentity
- ExternalAgentIdentity
- InternalOperatorIdentity

Every identity must have:

- stable ID
- type
- lifecycle state
- creation time
- update time
- provenance
- tenant/workspace scope where applicable
- security status
- version

Avoid exposing unnecessary internal IDs directly to UI.

==================================================
ACCOUNT TYPES
==================================================

HEY must support the future coexistence of:

PERSONAL
FAMILY
TEAM
BUSINESS
EDUCATION
ENTERPRISE
DEVELOPER
OWNER_INTERNAL

Do not assume one user belongs to only one account/workspace.

A person may simultaneously have:

- personal HEY
- family HEY
- school HEY
- work HEY
- developer workspace
- owner/internal access

These contexts must remain strongly separated.

No silent memory, permission, artifact, or organization-data crossover.

==================================================
AUTHENTICATION METHODS
==================================================

Design a modular authentication architecture supporting, where appropriate:

- passkeys
- password authentication
- email-based verification
- magic-link style flows if justified
- TOTP
- security keys
- biometric-backed passkeys
- platform authenticators
- enterprise SSO
- OAuth/OIDC federation
- recovery codes
- device-based reauthentication

Prefer phishing-resistant methods where supported.

Passkeys should be first-class, not an afterthought.

Do NOT assume every platform supports every method.

Use capability detection.

==================================================
PASSKEY SYSTEM
==================================================

Design proper passkey support including:

- registration
- authentication
- multiple passkeys per account
- device-synced passkeys
- hardware security keys
- passkey naming
- passkey deletion
- passkey last-used metadata
- passkey compromise response
- recovery when passkeys unavailable
- cross-device authentication where supported
- step-up auth with passkey
- organization policies requiring strong authentication

Do not fake passkey support with local flags.

==================================================
PASSWORD SYSTEM
==================================================

If passwords are supported:

- modern password hashing
- per-password salts
- appropriate work factors
- breach-resistance design
- rate limiting
- credential-stuffing defenses
- password reset security
- password-change session invalidation policy
- compromised-password handling
- no plaintext passwords
- no reversible password encryption
- no passwords in logs
- no secrets in client bundles

Document whether passwords are primary, fallback, or optional.

==================================================
SESSION SYSTEM
==================================================

Create a canonical session model supporting:

- session ID
- user identity
- account/workspace context
- device ID
- authentication method
- authentication strength
- issued time
- last activity
- expiry
- absolute expiry
- refresh behavior
- revocation state
- session scope
- risk state
- IP/network metadata only where privacy policy permits
- user agent/platform metadata
- step-up authentication state
- organization policy binding
- session version
- parent/delegation relationship where relevant

Sessions must support:

ACTIVE
EXPIRED
REVOKED
LOCKED
SUSPICIOUS
REAUTH_REQUIRED
TERMINATED

Refine if a better state model is justified.

==================================================
TOKEN / CREDENTIAL ARCHITECTURE
==================================================

Design secure credential handling.

Where token-based architecture is used, address:

- access tokens
- refresh tokens
- token rotation
- replay detection
- revocation
- theft resistance
- audience
- issuer
- scope
- expiry
- token binding where practical
- refresh-token reuse detection
- key rotation
- compromise recovery

Do not store sensitive long-lived tokens insecurely in browser localStorage if safer platform-specific alternatives exist.

Document web/PWA/native differences.

==================================================
DEVICE IDENTITY
==================================================

A device must have a stable HEY device identity independent from:

- display name
- IP address
- browser user agent
- model name

Device record should support:

- device ID
- owner/account relationship
- display name
- platform
- OS/version
- app/runtime version
- device class
- trust state
- enrollment time
- last seen
- last successful authentication
- capability summary
- public key / device-bound credential reference where applicable
- managed/unmanaged status
- personal/shared/public device classification
- compromise state
- revocation state
- attestation metadata where supported
- sync status

==================================================
DEVICE TRUST STATES
==================================================

Create a meaningful state model such as:

UNKNOWN
NEW
PROVISIONAL
TRUSTED
HIGH_TRUST
MANAGED
SHARED
RESTRICTED
SUSPICIOUS
COMPROMISED
LOST
REVOKED
RETIRED

Do not blindly use these exact names if research supports better semantics.

Define:

- how trust increases
- how trust decreases
- trust decay
- trust reset
- compromise response
- lost-device response
- admin-managed trust
- owner-managed trust
- re-enrollment
- reauthentication requirements

==================================================
DEVICE ENROLLMENT
==================================================

Support flows for:

- first device
- additional phone
- tablet
- desktop
- browser-only device
- legacy/lightweight HEY terminal
- managed organization device
- shared household device
- temporary device
- public/shared device
- remote server/home server

Enrollment must distinguish:

DEVICE REGISTRATION

from

DEVICE TRUST.

A registered device is not automatically highly trusted.

==================================================
DEVICE CRYPTOGRAPHIC IDENTITY
==================================================

Where technically viable, design device-bound cryptographic identity.

Examples may include:

- generated device keypair
- hardware-backed key storage
- secure enclave/keystore
- WebAuthn credentials
- signed enrollment challenges
- key rotation

Do not assume hardware-backed keys exist everywhere.

Provide graceful fallback with clearly lower trust.

==================================================
DEVICE ATTESTATION
==================================================

Support optional platform attestation when available.

Attestation must be treated as an additional signal, not magical proof of absolute safety.

Design:

- supported attestation provider abstraction
- attestation freshness
- failure handling
- unsupported-platform fallback
- privacy impact
- organization policy requirements

==================================================
DEVICE MESH IDENTITY
==================================================

Prompt 01 established HEY Device Mesh.

This package must support identity for a distributed HEY environment.

A mission may involve:

phone
+
tablet
+
desktop
+
home server
+
cloud

Each participating device must be individually identifiable and trust-evaluated.

Cross-device requests must preserve:

- initiating user
- initiating device
- executing device
- account/workspace
- session
- mission
- Action Mandate reference
- trust state
- verification result

==================================================
LEGACY / ULTRA-LIGHT DEVICES
==================================================

HEY must support extremely weak devices.

Do not require large crypto libraries, LLM runtimes, heavy frameworks, or modern GPUs just to participate.

For Class 0 legacy terminals:

support identity through gateway-mediated authentication where feasible.

For Class 1 HEY Edge:

support the smallest secure device identity possible.

For Class 2 and 3:

richer cryptographic/device-security options may be available.

Never claim an old Nokia can expose OS functionality its platform does not expose.

==================================================
MULTI-ACCOUNT / MULTI-WORKSPACE
==================================================

Support one human being connected to multiple contexts.

Switching contexts must be explicit and safe.

Examples:

Personal
School
Family
S&A
Client company

Prevent:

- sending work files into personal Cosmos accidentally
- using personal credentials in organization missions
- organization admins seeing personal HEY
- personal memory affecting restricted business decisions without policy permission
- wrong-account actions

==================================================
ORGANIZATION IDENTITY
==================================================

Organizations need:

- organization ID
- membership ID
- role identity
- membership lifecycle
- invitation
- suspension
- removal
- role change
- managed device relationship
- SSO relationship
- admin role
- audit identity

Do not implement the whole organization policy/admin system yet.

Build identity/membership contracts.

==================================================
FAMILY IDENTITY
==================================================

Support future:

- adult account
- child/minor account
- guardian relationship
- household membership
- shared household devices
- private personal spaces
- shared spaces

Guardian relationship must NOT mean unlimited hidden surveillance.

Build boundaries explicitly.

==================================================
MINOR ACCOUNT REQUIREMENTS
==================================================

HEY must support minors.

Design age-aware identity/account metadata carefully.

Do not expose unnecessary age data broadly.

Prepare for jurisdiction-sensitive rules.

Support:

- minor account classification
- guardian/consent relationship where required
- age-appropriate defaults
- restricted commerce authority
- stricter privacy
- stronger ad/sponsorship controls
- school account separation from personal account

Do not hard-code one country's legal thresholds.

==================================================
GUEST / SHARED DEVICE MODE
==================================================

Design sessions for:

- shared tablets
- school smart displays
- borrowed computers
- public terminals
- presentation mode
- family devices

Requirements:

- reduced local persistence
- no silent Cosmos leakage
- hidden notifications
- no long-lived credentials unless explicitly allowed
- automatic timeout
- strong sign-out cleanup
- limited remembered state
- capability restrictions
- easy emergency sign-out

==================================================
SESSION RISK ENGINE FOUNDATION
==================================================

Provide typed inputs for future risk assessment.

Possible signals:

- new device
- impossible travel
- unusual platform
- repeated auth failure
- stolen refresh token
- unusual session creation
- revoked device
- compromised credential
- abrupt location/network change
- abnormal privilege request
- suspicious automation behavior

Do NOT over-collect personal data.

Support privacy-preserving evaluation.

Outputs could include:

LOW
ELEVATED
HIGH
CRITICAL

and required response:

ALLOW
ALLOW_LIMITED
REAUTH
STEP_UP
LOCK
REVOKE

==================================================
STEP-UP AUTHENTICATION
==================================================

Some actions may require stronger proof even during a valid session.

Examples:

- large purchases
- deleting account
- exporting sensitive Cosmos data
- modifying security settings
- adding trusted device
- changing recovery method
- disabling protections
- high-risk enterprise action

Provide contract:

`requireAuthenticationStrength(...)`

Do not implement authorization logic here beyond exposing authentication strength.

==================================================
RECOVERY SYSTEM
==================================================

Design robust recovery for:

- forgotten password
- lost phone
- all passkeys unavailable
- security key lost
- stolen device
- compromised account
- inaccessible email
- enterprise-managed recovery
- child/minor account recovery
- owner/internal emergency recovery

Recovery must not become the weakest authentication path.

Design:

- recovery proofs
- delays for high-risk changes
- notification of recovery attempts
- recovery cancellation where appropriate
- recovery codes/keys
- trusted recovery contacts if justified
- old-session invalidation
- device trust reset
- audit records

==================================================
ACCOUNT COMPROMISE RESPONSE
==================================================

Create workflows/contracts for:

- revoke all sessions
- revoke selected sessions
- revoke devices
- rotate credentials
- revoke API tokens
- revoke extensions where relevant
- invalidate recovery methods
- change passwords/passkeys
- reset device trust
- inspect security timeline
- restore safe access

Do not require rebuilding account identity.

==================================================
ACCOUNT LIFECYCLE
==================================================

Support:

PENDING
ACTIVE
LOCKED
SUSPENDED
RECOVERY_PENDING
DELETION_PENDING
DELETED
DISABLED
COMPROMISED

Refine if needed.

Implement lifecycle state validation.

==================================================
ACCOUNT DELETION
==================================================

Deletion must distinguish:

ACCOUNT IDENTITY DELETION

from data owned by:

- personal Cosmos
- organizations
- shared family spaces
- legal retention obligations
- artifacts shared with others
- purchased marketplace items
- enterprise records

Create deletion contracts but do not implement unrelated data systems.

Support:

- deletion request
- confirmation
- cooling-off period if justified
- session termination
- device revocation
- ownership transfer where needed
- export-before-delete option
- audit evidence
- final deletion state

==================================================
SERVICE / AGENT IDENTITIES
==================================================

HEY has non-human actors.

Create secure identity types for:

- internal service
- HEY agent
- extension
- automation
- integration
- external agent
- background worker

These actors must NOT impersonate the user.

Their actions must always preserve:

human/user authority source
+
service/agent identity

Example:

User Sako
authorized
Agent X
to ask
Device Y
to execute action Z.

The receipt must show all identities.

==================================================
IMPERSONATION
==================================================

Avoid unrestricted impersonation.

For support/admin scenarios, use explicit:

- delegated support session
- scoped access
- expiry
- reason
- audit
- user notification where appropriate
- no raw password sharing

Never implement “log in as user” as an invisible unrestricted backdoor.

==================================================
OWNER / INTERNAL OPERATOR IDENTITY
==================================================

HEY owners/operators need elevated internal capabilities.

But OWNER does NOT mean:

- bypass user encryption
- bypass user privacy
- bypass security invariants
- unrestricted production-data browsing

Build owner/internal identities separately.

Require:

- strong authentication
- short-lived privileged sessions
- explicit reason
- audit
- least privilege
- optional approval for sensitive production access

==================================================
AUTH AUDIT EVENTS
==================================================

Define events for:

- account created
- login success
- login failure
- passkey registered
- passkey removed
- password changed
- password reset
- MFA added
- MFA removed
- recovery initiated
- recovery completed
- recovery cancelled
- session created
- session refreshed
- session revoked
- all sessions revoked
- device registered
- device trust changed
- device revoked
- device lost
- suspicious session detected
- step-up required
- organization membership changed

Use Prompt 01 event/receipt conventions.

==================================================
PRIVACY REQUIREMENTS
==================================================

Identity data is sensitive.

Minimize collection.

Separate:

required operational data

from

optional risk/analytics signals.

Never log:

- passwords
- passkey secrets
- full authentication tokens
- recovery secrets
- private keys
- raw biometric data

Biometric verification should remain platform-managed where possible.

==================================================
OFFLINE AUTHENTICATION
==================================================

HEY offline mode is core.

Design what a previously trusted device may do while disconnected.

Offline behavior must distinguish:

- locally authenticated user
- cached session
- expired session
- revoked-but-device-does-not-yet-know scenario
- local-only actions
- cloud-required actions
- organization policy
- high-risk actions

Offline authority should be narrowly bounded.

On reconnection:

- reconcile revocations
- synchronize security events
- refresh policy
- invalidate stale authority
- resolve pending actions safely

==================================================
SESSION CONTINUITY
==================================================

HEY missions may last hours/days.

Do not couple mission lifetime directly to a short-lived access token.

Support safe reauthentication and continuation.

A mission may pause for:

- expired auth
- reauthentication
- changed workspace membership
- revoked device
- policy change

Mission state survives.

Authority does not.

==================================================
WEAK-DEVICE PERFORMANCE
==================================================

The identity client for HEY Edge must remain lightweight.

Avoid requiring:

- full app framework
- heavy cryptography package when platform primitive exists
- huge dependency trees
- large databases
- model runtime

Define minimal Edge identity protocol.

==================================================
STORAGE SECURITY
==================================================

Document per-platform expectations for secure storage:

- browser/PWA
- Android
- iOS/iPadOS
- Windows
- macOS
- Linux
- server/headless
- legacy gateway

Do not pretend secure storage is identical across all platforms.

==================================================
DATABASE / STORAGE MODEL
==================================================

Design production-ready schemas for at least:

users
accounts
account_memberships
organizations
organization_memberships
workspaces
workspace_memberships
sessions
devices
device_credentials
authentication_methods
passkeys
mfa_methods
recovery_methods
recovery_events
security_events
identity_links
service_identities

You may refine names/normalization.

Include:

- keys
- indexes
- constraints
- lifecycle state
- tenant boundaries
- soft/hard deletion considerations
- timestamps
- versioning
- uniqueness rules

Do NOT assume Supabase until integration.

Provide database-agnostic schema intent plus concrete migration-ready reference implementation.

==================================================
API / SERVICE CONTRACTS
==================================================

Implement or specify production-ready interfaces for operations such as:

createAccount
authenticate
registerPasskey
removePasskey
registerMfaMethod
removeMfaMethod
createSession
refreshSession
revokeSession
revokeAllSessions
registerDevice
enrollDevice
renameDevice
updateDeviceTrust
revokeDevice
markDeviceLost
listSessions
listDevices
beginRecovery
completeRecovery
cancelRecovery
requireReauthentication
verifyAuthenticationStrength
switchWorkspaceContext
createServiceIdentity
revokeServiceIdentity
deleteAccount

Use typed results/errors.

==================================================
SECURITY REQUIREMENTS
==================================================

Test against:

- session fixation
- token replay
- refresh token reuse
- credential stuffing
- brute force
- account enumeration
- weak reset flows
- stolen device
- cloned device identity
- fake device name
- forged session metadata
- cross-workspace token misuse
- cross-organization identity confusion
- privilege confusion
- confused deputy
- stale membership
- revoked device still acting
- compromised passkey
- recovery abuse
- CSRF where applicable
- XSS token theft considerations
- malicious extensions
- fake agent identities
- service identity escalation
- session race conditions
- logout race
- password-reset race
- recovery race
- device-enrollment replay
- invitation replay

==================================================
RATE LIMITING / ABUSE
==================================================

Design identity-sensitive rate controls for:

- login attempts
- signup abuse
- recovery
- email verification
- OTP/TOTP verification
- device enrollment
- passkey registration
- session refresh
- API authentication

Do not make rate limiting depend solely on IP address.

==================================================
OBSERVABILITY
==================================================

Instrument:

- auth success rate
- auth failure types
- refresh failures
- recovery attempts
- recovery success
- session revocations
- suspicious sessions
- device enrollment
- device trust changes
- passkey adoption
- authentication latency

Protect personal information.

==================================================
USER EXPERIENCE STATES
==================================================

Define all major UX states:

- first signup
- returning login
- passkey available
- passkey unavailable
- offline trusted session
- expired session
- reauth required
- suspicious login
- device enrollment
- lost device
- recovery
- account locked
- organization SSO
- shared device
- session expired during mission
- removed from workspace
- deleted account

Create UX contracts and state descriptions.

Do not build the full HEY visual shell.

==================================================
ACCESSIBILITY
==================================================

Authentication cannot depend solely on:

- color
- fine motor gestures
- voice
- biometric
- one specific second factor

Flows must remain accessible to:

- keyboard users
- screen readers
- low-vision users
- users unable to use biometrics
- motor-impaired users

==================================================
LOCALIZATION
==================================================

Design for:

- RTL
- multilingual messages
- locale-aware dates/times
- no English-only auth assumptions
- Unicode-safe identifiers/display names

Security error messages must avoid leaking account existence.

==================================================
PACKAGE STRUCTURE
==================================================

Create:

HEY-NEXT/
  02-identity-accounts-device-trust/
    README.md
    ARCHITECTURE.md
    IDENTITY-MODEL.md
    ACCOUNT-LIFECYCLE.md
    AUTHENTICATION-STANDARD.md
    PASSKEY-STANDARD.md
    SESSION-STANDARD.md
    DEVICE-IDENTITY.md
    DEVICE-TRUST.md
    DEVICE-ENROLLMENT.md
    DEVICE-MESH-IDENTITY.md
    RECOVERY-STANDARD.md
    ACCOUNT-COMPROMISE-RECOVERY.md
    OFFLINE-IDENTITY.md
    SHARED-DEVICE-MODE.md
    MINOR-ACCOUNT-BOUNDARIES.md
    SERVICE-AGENT-IDENTITIES.md
    SECURITY-MODEL.md
    STORAGE-MODEL.md
    API-CONTRACTS.md
    UX-STATES.md
    OBSERVABILITY.md
    DEPENDENCIES.md
    ASSUMPTIONS.md
    LIMITATIONS.md
    INTEGRATION_MANIFEST.md
    MIGRATION_PLAN.md
    EVIDENCE.md

    src/
      domain/
      auth/
      sessions/
      devices/
      recovery/
      services/
      validation/
      security/

    schemas/
    migrations/
    tests/
    integration-tests/
    adversarial-tests/
    fixtures/
    docs/

Refine structure if justified.

==================================================
DEPENDENCY RULE
==================================================

If this package needs external libraries/services:

Record every requirement in:

`DEPENDENCIES.md`

Include:

- package/library
- purpose
- exact or compatible version strategy
- platform
- license
- security considerations
- whether mandatory or optional
- installation command
- alternatives considered

Claude Code will later install and reconcile these dependencies in the real HEY repository.

Do not assume installation magically happens.

==================================================
INTEGRATION MANIFEST
==================================================

`INTEGRATION_MANIFEST.md` must tell Claude Code exactly:

1. What this package owns.
2. What Prompt 01 contracts it consumes.
3. What contracts it exports.
4. Dependencies to install.
5. Database tables/migrations.
6. Environment variables.
7. Authentication-provider assumptions.
8. Web wiring.
9. Backend wiring.
10. PWA wiring.
11. Android wiring.
12. iOS wiring.
13. desktop/native wiring.
14. HEY Edge wiring.
15. Device Mesh wiring.
16. Organization/family integration points.
17. Trust Kernel integration points.
18. Cosmos boundaries.
19. Mission-runtime boundaries.
20. Security events emitted.
21. Session invalidation hooks.
22. Account deletion hooks.
23. Existing identity/auth systems Claude must inspect before migration.
24. Data that must be migrated.
25. Features that must not be duplicated.
26. Required migration order.
27. Required post-integration tests.
28. Rollback procedure.
29. Unknowns requiring inspection of actual HEY.
30. Anything that must be preserved if existing HEY is stronger.

==================================================
RESEARCH REQUIREMENT
==================================================

Where current research is available, investigate primary/authoritative material relevant to:

- WebAuthn
- passkeys
- FIDO2
- OAuth 2.x
- OpenID Connect
- modern browser session security
- refresh-token rotation
- device-bound authentication
- Android Keystore
- Apple Secure Enclave/Keychain
- Windows secure credential storage
- enterprise SSO
- session-risk architecture
- account recovery best practices
- device attestation
- password hashing
- rate limiting
- multi-tenant identity

Do not adopt technology based on marketing.

Document important architectural decisions and rejected alternatives.

==================================================
TEST REQUIREMENTS
==================================================

At minimum test:

ACCOUNT:
- create
- duplicate
- suspend
- lock
- recover
- delete
- invalid transition

AUTHENTICATION:
- valid
- invalid
- brute-force behavior
- account enumeration resistance
- passkey path
- fallback path
- step-up path

SESSION:
- creation
- refresh
- expiry
- absolute expiry
- revocation
- revoke all
- stolen refresh-token reuse
- concurrent refresh
- workspace switch
- removed membership
- logout

DEVICE:
- register
- enroll
- trust upgrade
- trust downgrade
- rename
- mark lost
- revoke
- cloned identity
- stale credentials
- shared-device mode
- offline mode

RECOVERY:
- valid recovery
- invalid proof
- expired recovery
- reused recovery
- compromised device
- attacker attempts takeover
- recovery notification
- session invalidation

WORKSPACE:
- personal/work separation
- organization context
- family context
- cross-context misuse

SERVICE/AGENT:
- agent identity cannot impersonate human
- service identity cannot escalate
- revoked service cannot act

SECURITY:
- replay
- CSRF where applicable
- stolen token
- session fixation
- enrollment replay
- cross-tenant access
- stale membership
- race conditions

OFFLINE:
- valid cached local session
- expired offline authority
- revoked server-side device reconnecting
- offline low-risk action
- offline high-risk action
- reconnect reconciliation

==================================================
INDEPENDENT VERIFICATION
==================================================

After implementation:

Run a separate verification pass whose purpose is to disprove the package’s security and correctness.

Try to prove:

- identity boundaries can be crossed
- sessions survive revocation incorrectly
- device trust can be forged
- recovery can be abused
- organization membership leaks
- a service account can impersonate a user
- a shared device leaks personal Cosmos
- offline mode grants too much authority
- passkey removal creates account lockout
- old sessions survive credential reset
- account deletion leaves active credentials
- client claims can override server identity

Fix every reproducible defect.

==================================================
FINAL RESPONSE
==================================================

Report:

1. Package created.
2. Exact files created.
3. Architecture implemented.
4. Authentication methods supported by the package.
5. Session model.
6. Device identity/trust model.
7. Recovery design.
8. Database/schema work.
9. Dependencies.
10. Tests and exact results.
11. Adversarial/security tests and exact results.
12. Performance/weak-device findings.
13. Offline findings.
14. Remaining limitations.
15. Items requiring real HEY integration.
16. Anything UNVERIFIED.
17. Evidence for every completion claim.

Do not claim the entire HEY identity system is production-ready until it has been integrated into the actual HEY application and independently verified there.

Build the package to the maximum production quality possible without the unavailable real HEY repository.
