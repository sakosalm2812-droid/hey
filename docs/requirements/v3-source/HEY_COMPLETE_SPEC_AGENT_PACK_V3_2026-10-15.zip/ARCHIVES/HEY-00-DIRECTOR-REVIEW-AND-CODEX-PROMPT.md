# 00 — HEY Director: code-grounded review and Codex prompt

Review dates: 2026-10-02–03. Phase: review and implementation planning only. No application implementation, deployment, migrations, or source edits performed.

## A. Workstream summary

**The current coordination records cannot establish whole-product readiness.** The inspected implementation has useful registries, execution guards, transactional upgrade machinery, tests and honest native-release limits. Its reporting layer nevertheless promotes names, catalog entries, source presence and test-file references into verification claims. It does not provide the required traceability from all approved source requirements to one owner, repository binding, acceptance conditions, candidate-specific evidence and production disposition.

Director outcome: establish one authoritative requirement/ownership/dependency/evidence coordination record and derive product status from it. Do not implement every product domain in this workstream. Other workstreams own functionality; Director owns source resolution, assignment, priorities, dependencies, conflicts and truthful product state.

### Authority applied

1. Current user instructions authorize this review and final tailored prompt, superseding initialization-only waiting and the refined document's earlier instruction to defer a prompt until the user says done.
2. `HEY_REFINED_ENGINEERING_DOCUMENT.md`, embedded `00_START_HERE.md`, explicitly elevates canonical resolution files, domain contracts and new amendments above original decisions for covered conflicts. Its `01_GOVERNANCE/01_AUTHORITY_AND_COMPLETION.md` and `02_REFINEMENT_APPLICATION.md` retain all non-conflicting original requirements. The 215 cards are additions/refinements, **not the total product scope**.
3. Original `HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`: embedded foundation, intelligence, interaction, governance and execution files govern over conflicting old detailed/reference material. Preserve the specific newest product-flow amendment where refined authority says it controls navigation/composition.
4. Repository `AGENTS.md` describes the prior September 30 authority and `E:\hey`; do not treat an uploaded snapshot as proof of the Windows working tree or remote HEAD. Its old 229-agent baseline is a seed requirement, not a limit on the Unlimited Agent Foundry. Older V1/V2 and free-only/free-first launch assumptions cannot narrow newer approved scope.
5. Maturity: `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Record blockers and evidence categories separately. UNKNOWN, MOCK_ONLY, IMPLEMENTED_UNVERIFIED, BLOCKED_EXTERNAL and WAIVED are not PASS. A waiver never fulfills a requirement.

### Review boundary and evidence

The cleaned archive was extracted for read-only review, without displaying `.env` values. Sources and coordination files were read directly. Structure was mapped across frontend, core, legacy TS routes, edge functions, SQL, native adapters, service worker, config and tests. Director-owned ledgers/generators/orchestrator/status/release documents were inspected deeply; functional domains were inspected as dependencies, not exhaustively audited.

This is **not** a complete semantic certification of 52,123 specification lines or every product capability. Original source sections and all 215 refined cards are indexed below; cards without domain review remain explicitly UNREVIEWED. The original 8,560 clause candidates and 14,248 occurrence records are described in the refined document, but their referenced JSON ledgers are not supplied as separate files here. Do not pretend to have read them. Combined documents are sufficient to start traceability; full occurrence disposition remains open.

## B. Current implementation map

Paths below are repository-relative to extracted `hey/`; supplied source documents are external review inputs.

| System | Actual paths/objects | Static finding |
|---|---|---|
| Build/runtime entry | `package.json`, `index.html`, `vite.config.js`, `src/main.jsx`, `src/App.jsx` | Active build is Vite React SPA; HTML loads `src/main.jsx`. No Next build script. |
| Routing/UI/state | `src/App.jsx`, `src/ChatPage.jsx`, `src/pages/VoicePage.jsx`, `src/components/layout/AppLayout.jsx`, `src/AuthContext.jsx`, `src/context/ThemeContext.jsx`, `src/i18n/LocaleContext.jsx` | Protected/public routes; chat, voice, studios, owner access, tasks, Cosmos and other pages. Presence is not working behavior. |
| Runtime boot and decision/execution | `src/main.jsx`, `src/core/completionRuntime.js`, `src/core/heyBrain.js`, `src/core/executionController.js`, `src/core/executionEngine.js`, `src/core/eventBus.js`, `src/core/infinity/infinityRuntime.js` | Shared runtime plus Infinity installed; event/permission/result boundaries need Architecture and Integration ownership. |
| Registry/provider/tools | `src/core/capabilityRegistry.js`, `src/core/toolRegistry.js`, `src/core/providerRegistry.js`, `src/core/providerRouter.js`, `src/core/infinity/providerRouter.js`, `agents/v1AgentCatalog.js`, `src/core/agentEngine.js` | Runtime availability and catalog status must remain distinct from verification. Multiple provider layers require caller-level disposition. |
| Chat transport/backend | `src/lib/heyAI.js`, `src/lib/requestTransport.js`, `src/lib/supabase.js`, `supabase/functions/hey/index.ts`, `_shared/requestAdmission.js`, `_shared/providerTransport.js` | Client uses configured HEY endpoint or Supabase edge URL; fallback `/api/hey` requires actual host binding. Do not infer Vite serves legacy Next routes. |
| Edge functions | `supabase/functions/{hey,hey-studio,hey-push,admin-entitlements,delete-account}/index.ts` | Five current edge entry points, not the four described in older status notes. |
| Auth/data/SQL | `supabase/migrations/` (19 files), `prisma/`, `supabase/functions/admin-entitlements/{ownerPolicy.js,ownerService.js}` | SQL objects include profiles, conversations/messages, memory/graph, records, permissions/devices/routines, suggestions, audit, action/quality/Forge runs, entitlements, generation jobs, push subscriptions, request buckets and owner receipts. Migration files do not prove deployed schema or RLS behavior. |
| Native/device | `src-tauri/src/main.rs`, `src-tauri/tauri.conf.json`, `src-tauri/capabilities/default.json`, `src/lib/tauriAdapter.js`, `native/android/app/src/main/java/com/hey/app/MainActivity.kt`, `native/ios/HeyCommandBridge.swift`, `native/external-control/android/ExternalHeyAccessibilityService.kt` | Platform code/scaffolds present; signed installs, actual board compatibility and real-device behavior unverified. |
| PWA | `public/sw.js`, `public/site.webmanifest`, `scripts/generate-service-worker.mjs`, `src/components/PWAUpdatePrompt.jsx`, `tests/pwa-offline.test.js` | Separate Release/PWA ownership; no production offline/install claim from source alone. |
| Legacy/quarantined surfaces | `src/app/**`, including API routes; `src/lib/agents/registry.ts`; TS support libraries; `prisma/` | Existing alongside SPA. Quarantine is claimed by release docs; inspect import/serving topology before removal. |
| Director coordination | `docs/upgrade/MASTER-STATUS.json`, `HEY-CAPABILITY-LEDGER.json`, `HEY-VERIFICATION-MATRIX.md`; `docs/release/HEY-CAPABILITY-MATRIX.json`, `RELEASE_GATE.md`, `HEY-RELEASE-EVIDENCE.md` | Several status vocabularies and hand-maintained/generated reports; no demonstrated full refined requirement wiring. |
| Coordination generators | `scripts/generate-capability-ledger.mjs`, `scripts/hey-upgrade/generate-module-plans.ps1`, `generate-module-reports.ps1`, `modules/*.json`, `verify-module.mjs` | 34 historical upgrade module plans; these IDs are not the 19 specialist workstream IDs. |
| Upgrade executor | `HEY-UPGRADE.ps1`, `scripts/hey-upgrade/HeyUpgrade.psm1`, `Test-HeyUpgrade.ps1`, `tests/upgrade-orchestrator.test.js` | Baseline conflict checks, backups, command timeouts/redaction, rollback and verification states exist. Product evidence semantics need repair. |
| Test topology | `tests/` (37 files), `e2e/landing.spec.ts`, `src/lib/__tests__/`, `playwright.config.ts`, stored `test-results/` | `npm test` runs `tests/*.test.js`; TS tests and browser tests are not automatically included. Stored reports are historical artifacts, not this session's evidence. |

Inventory counts excluding filenames containing `.backup`: 106 files under `src/core`, 43 under `src/pages`, 249 under `src/components`, 19 SQL migrations, one Rust source file, six files under `native`. Counts are inventories, not capability totals.

## C. Requirement coverage within Director ownership

Every row requires product-domain evidence from its primary implementation owner. No domain is declared production-ready here.

| Requirement and precise source section | Existing implementation/binding | Conservative maturity | Evidence / missing work |
|---|---|---|---|
| Source precedence and preservation: refined `00_START_HERE`, governance 01/02; original foundation 00/01 | `AGENTS.md`; old docs and module titles | DESIGNED | Authority documented, but repo guidance predates refinement. Add source hashes, explicit conflict resolution and preserved-source disposition. |
| One primary owner per requirement: governance 01; user's ownership index | Historical `modules/*.json` domains | MISSING for required specialist ownership map | 34 upgrade modules exist; not a unique 00–18 owner map for full requirements. Preserve distinction. |
| Full spec↔code binding: refinement application; original execution 01 | Capability generator and ledgers | IMPLEMENTING | Inventory-like records exist, but no exact binding and acceptance coverage for all refined cards plus retained original semantics. |
| Honest maturity/evidence: foundation replacement contract; refined governance 01; evaluation domain | `generate-capability-ledger.mjs`, status JSON, verification docs | IMPLEMENTING | Evidence inferred from words/catalog flags/references; must become run- and candidate-bound. |
| Dependency and execution order: original execution 01; refined execution pipeline | `modules/*.json`, `Get-HeyModulePlans`, `Invoke-HeyAllUpgrade` | IMPLEMENTING | Dependency declarations present; traversal sorts filenames and skips states. Need validated DAG, cycle/missing owner checks, blocked downstream behavior and evidence freshness. |
| Conflict/duplication resolution: original replacement contract; refinement consolidation instructions | Status notes document candidate duplicate engines | DESIGNED | Need durable decision queue with requester, primary owner, affected requirements, evidence, decision and migration/removal prerequisites. |
| Product-wide production state: original final whole-product gate; refined test/release matrix | `RELEASE_GATE.md`, capability matrix, platform matrix | IMPLEMENTING | Historical conditional-go and source-verified labels cannot certify current full approved product. Need derived per-platform candidate verdicts. |
| Explicit external blockers and continued independent work: refined execution 01/preflight | BLOCKED/limits/setup docs | IMPLEMENTING | Existing honesty useful; blockers not fully requirement-bound. Native hardware, live backend and signing remain unverified. |
| Recovery/checkpoint/rollback: original completion contract; refined execution checkpoint; sync/recovery | PowerShell transactional backups and state | IMPLEMENTING | No fresh PowerShell execution here. Bind rollback/checkpoint/evidence to source candidate; preserve later work and never auto-apply as a status repair. |
| Independent review/user-device testing: refined review protocol/pipeline; original final gate | Test/release narratives | DESIGNED | No independent reviewer/device test performed here. New review authorization does not constitute device verification. |
| Governance/owner decision record: original governance owner console; refined governance 01 | Owner service/policy and receipt migration | IMPLEMENTING at coordination boundary | Static owner enforcement and tests exist; Director consumes authenticated decisions, never creates identities or an admin bypass. |
| Bounded improvement prioritization: refined authority/refinement application | Ad hoc upgrade reports | DESIGNED | Need benefit/risk/dependencies/before-after rubric; no infinite improvement loop or feature-count target. |

Full product-domain maturity is UNASSESSED by Director pending specialist evidence. Appendix indexes all 215 cards without pretending its domain classifications establish implementation coverage.

## D. Strengths to preserve

- Existing runtime capability registry starts unavailable and separates platform support/permission/restriction. This is a useful fail-closed boundary, not a completion ledger.
- `tests/release-surfaces.test.js` explicitly tests missing provider, unverified result, and absent Forge/automation runner failures. Keep these negative cases; mocked provider success is only contract-test evidence.
- PowerShell upgrade code refuses baseline conflicts even with Force, backs up files, captures exit status and supports rollback. Strengthen it rather than creating another upgrade runner.
- `src/core/platformMatrix.js` explicitly identifies unbuilt desktop/mobile releases. Preserve honest platform limits while correcting the meaning of release verification.
- Existing SQL admission/owner/Forge changes and tests are useful evidence anchors; leave migrations and domain logic to their owners.

## E. Problems found

### D00-01 — Evidence fabrication by heuristics (high; confirmed static)

`scripts/generate-capability-ledger.mjs`: `evidenceForV1Name()` returns VERIFIED WORKING for names containing words such as chat, voice, agent or memory. Agent mapping assigns VERIFIED WORKING unconditionally. Feature status `implemented` becomes AUTOMATED TESTED. `testsReferencing()` uses substring matches and never executes or reads a run result. The engine stub heuristic only checks short files and narrow text patterns; absent matches do not establish correctness. Impact: generated claims can certify unimplemented/unexecuted behavior. Remove these promotion rules, retaining heuristic inventory only as non-evidence metadata.

### D00-02 — Historical complete-looking rollup contradicts its notes (high; confirmed static)

`docs/upgrade/MASTER-STATUS.json` summary says total=34, verified=34, pending=0, failed=0. Module notes disclose no dedicated mode-transition test, no performance-budget test and native scaffolds/external setup. `HEY-CAPABILITY-LEDGER.json` records 2,040 entries, 238 verified-working, zero partial and zero blocked. These are stale inventory/status claims, not full production coverage; duplicates and catalog entries inflate the denominator. Preserve history with its original scope; never convert it to current pass evidence.

### D00-03 — Stale evidence can suppress work (high; confirmed static)

`Invoke-HeyAllUpgrade` skips `verified-local`, `verified-backend`, `verified-native` in Apply/Resume without checking candidate/source/plan/environment fingerprint. `VerifyOnly` writes verified-local when probes complete. `verify-module.mjs` can succeed on existence/import checks and can succeed with zero requested probes; it is not a full product validator. Impact: changed code or requirements can retain old completion status. Add applicability and freshness validation; probe success is one evidence kind, not maturity promotion.

### D00-04 — Declared dependencies are not a validated scheduling DAG (high; confirmed inspected traversal)

`Get-HeyModulePlans` sorts filenames; `Invoke-HeyAllUpgrade` iterates that order. Example: `02-UI-DESIGN-SYSTEM` precedes `20-AUTH-SECURITY`, while newest product order puts shared authorization/contracts first. Android/iOS plans depend on Windows rather than expressing shared adapter/platform prerequisites. Do not mechanically replace these with the 19 workstream IDs: upgrade modules and ownership are separate dimensions. Derive scheduling from explicit task dependencies, detect cycles and missing prerequisites, and let independent work proceed around blockers.

### D00-05 — Release verdicts exceed their evidence (high; confirmed static)

`docs/release/RELEASE_GATE.md` is dated September 20 and says CONDITIONAL GO, includes catalog presence as QA-agent evidence, reports secret-scan/build/test results without a current candidate, and defers duplicate-registry disposition post-launch. Newer authority requires candidate-specific integration, independent/device and release evidence. `src/core/platformMatrix.js:isReleaseVerified()` returns true for the web's `verifiedSource`; source verification is not production release verification. Workstream 10 owns release behavior; Director requests contract correction and prevents stale public readiness claims.

### D00-06 — No demonstrated comprehensive requirement ownership/wiring (high; bounded search finding)

Searches in `scripts`, `docs/upgrade` and `tests` for refined HEY-CAP IDs, requirement/source/primary-owner fields did not establish the required ledger. Generator imports old V1, Infinity, feature, agent and mode catalogs, not the authoritative refined occurrence/cards. Mapping source meaning is a semantic task; name matching is insufficient. No numeric catalog count is a substitute for complete source disposition.

### D00-07 — Broader architecture overlaps need explicit handoffs (medium; review candidates)

Active Vite SPA coexists with `src/app` TS/Next routes and Prisma. Provider routers exist at `src/core/providerRouter.js` and `src/core/infinity/providerRouter.js`; computer/workspace/memory layers also overlap in names. These are candidates for caller-level reconciliation by 01/13, not proven interchangeable implementations. Keep unique behavior until replacement wiring and tests demonstrate safe retirement.

### D00-08 — Reproduction and archive hygiene gaps (medium; confirmed inventory)

The archive contains `.env` and `.env.local` plus stored reports/logs and backups. Values were not read or copied into this report; no assertion that they contain live credentials. 09 should assess and rotate only if actual exposure warrants it, and 10 should define a redacted source bundle. Archived reports lack demonstrated relevance to the current candidate. `E:\hey` current dirty/unpushed state remains unknown.

### Fresh test evidence and limitations

Executed in extracted snapshot: `node --test tests/*.test.js`, Node v24.19.0. Exit 1; runner reported 117 tests, 107 pass, 10 fail, 0 skipped/cancelled/todo; 1,767.235309 ms reported test duration. Nine test files fail loading missing packages (`react`, `@tauri-apps/api`, or `@supabase/supabase-js`), and upgrade-orchestrator fails because PowerShell is absent. These are review-environment blockers; no product logic failure is established by those load failures. No dependencies installed and no source modified to make checks green.

No lint/build, live Supabase/RLS, browser E2E, native build/install, device flows, paid calls, deployment or independent review executed. Missing dependencies also block a meaningful full build/lint baseline. Passing deterministic/contract checks do not verify providers, external side effects, production databases or devices. Stored Playwright results were inventoried, not replayed or adopted as current evidence.

## F. Improvements

**MUST FIX:** remove heuristic verification promotion; create full source/owner/binding/evidence traceability; invalidate stale evidence; validate dependencies; distinguish module transactions from feature maturity; replace current-product readiness claims with candidate/platform-scoped evidence; record independent/device/production gates honestly.

**SHOULD IMPROVE:** generate all status projections from canonical coordination records; add scoped resumable checkpoints and decision/handoff records; preserve source occurrence context and explicit synonym disposition; expose blocked downstream work and available independent work; redact source bundles; reconcile documentation authority and archived labels.

**OPTIONAL HIGH-VALUE:** show the critical path and compare measured improvement proposals using identical tasks/rubrics. Adopt only if it materially improves scheduling or evidence review. No new user-facing Director dashboard is required by this task.

## G. Dependencies and handoffs

These are prepared handoffs, not messages sent to other chats.

| Workstream | Director dependency / shared contract |
|---|---|
| 01 Architecture | Canonical command/response/event/state and domain bindings; adjudicate overlaps; shared-contract impact graph. |
| 02 UI / UX / Brand | Visual support/acceptance and RTL composition; consumes status truth. |
| 03 Core Intelligence | Decision/context/provider quality evidence; consumes 15 memory contracts. |
| 04 Agents + Computer Use | Executable agent/tool contracts, actual action receipts and sandbox outcome evidence. |
| 05 Forge + Creation | Artifact identity/version/selectors/export/Pinpoint evidence; consumes design and verification. |
| 06 Voice | Voice execution and session evidence consuming 03/07/09/14; permission policy remains 09. |
| 07 Native Platforms + Devices | Build/OS/hardware capability support and adapter evidence; native smartboard control primary owner. |
| 08 QA / Red Team | Evidence format/test-run integration and failure-case coverage; owns verification infrastructure. |
| 09 Security / Privacy / Permissions | RLS/authz/approvals/revocation/owner identity evidence, redaction; archived env assessment. |
| 10 Release Engineering | Candidate/release gates, deployment evidence, upgrade executor operational changes, backups/rollback. |
| 11 Product Polish | Honest status/error/help/recovery presentation and localization evidence. |
| 12 Research Lab | Evidence-backed bounded improvement proposals and dependency freshness. |
| 13 Integration + Merge Review | Binding validation, duplicate disposition and impacted shared-flow evidence. |
| 14 Performance + Local Runtime | Measured cohort/resource/local-cloud/cost evidence; proposed targets distinct from measurements. |
| 15 Memory + Cosmos | Memory/project/account isolation, deletion/retrieval/sync evidence. |
| 16 Proactive HEY | Mission/background scheduling/checkpoint/product recovery evidence. Product scheduler is not Director task scheduling. |
| 17 Enterprise + Schools | Institution/teacher workflow/shared-display evidence; consumes 07 board control and 09 policy. |
| 18 Final Product Audit | Independent evidence sufficiency and final whole-product acceptance; Director cannot self-sign this gate. |

Recommended coordination data: stable requirement ID/source occurrence/hash, one primary owner, consumer owners, platform applicability, bound files/symbols/API/SQL/event contracts, acceptance-case IDs, dependency IDs, maturity, blocker, evidence references, decision/waiver records and candidate fingerprint. This is a **proposed** schema, not an existing table/API. Keep 01 runtime schemas and 08/10 evidence records canonical; coordination references them.

## H. Acceptance criteria

1. Every approved source requirement has a preserved occurrence/disposition and unique primary owner; all 215 cards and retained originals are included without feature-count narrowing.
2. No name/catalog/import/test-reference alone promotes maturity. Missing, failed, stale, mock-only or waived evidence cannot become PASS.
3. Evidence is bound to candidate/source/plan/environment/platform; impacted edits reopen gates. Unaffected evidence reuse requires an explicit validated dependency basis.
4. Every dependency resolves; cycles reject; blocked prerequisites prevent dependent promotion while independent tasks remain schedulable.
5. Legacy upgrade module IDs and specialist IDs remain distinct and mapped. No historical applied/verified transaction is rewritten as product readiness.
6. All generated projections agree with the canonical ledger; historical verdicts retain dated scope and cannot certify a newer candidate.
7. Prepared handoffs identify exact dependency/owner/blocker; transmission is recorded only when it occurred.
8. 08/13/18 verification and 10 release evidence remain separate; real device outcomes identify actual tester, date, build, OS/device and result.
9. Current source edits, especially unpushed Windows work, are preserved through preflight/merge/rollback. No secrets or raw private user context in reports.
10. Tests exercise false-promotion, stale evidence, dependencies, conflicting source dispositions, failed/skipped checks, blockers, recovery and projection consistency. Report unexecuted checks as unexecuted.

## I. Codex implementation plan

1. Establish actual repository/branch/HEAD/dirty-state and source hashes; record baseline and current unresolved environments.
2. Extract authoritative section locators in planning space and record semantic conflict decisions; retain original source bytes and unresolved coverage.
3. Extend existing coordination ledger/report generation with requirement IDs, owner/workstream mapping and exact repository bindings. Import historical catalog/status data as inventory/history only.
4. Introduce validated evidence references with candidate/environment/applicability and conservative maturity rules; wire to 08/10 evidence producers.
5. Add dependency validation, impact invalidation and decision/blocker/handoff/checkpoint views. Have 10 own transactional executor changes; do not redesign the product scheduler.
6. Generate historical/current status projections; correct documentation authority and readiness interpretation through reviewed 10/13 edits.
7. Add/run scoped regression checks, review source coverage, obtain required independent review, and leave remaining external/domain/device gates open.

## J. Final Codex prompt

Copy the complete block below. Paths are discovered repository-relative paths; the review extraction location is not presumed to be the live repository.

```text
HEY CODEX WORKSTREAM IMPLEMENTATION
WORKSTREAM: 00 — HEY Director

MISSION:
Establish trustworthy product-wide coordination: preserve the full approved scope; bind requirements to exactly one implementation owner, actual code/contracts, dependencies, acceptance cases and candidate-specific evidence; resolve conflicts and derive honest priorities/progress/readiness. Do not become a giant feature implementation workstream.

AUTHORITATIVE SOURCES:
Read the supplied HEY_REFINED_ENGINEERING_DOCUMENT.md: 00_START_HERE.md; 01_GOVERNANCE/01_AUTHORITY_AND_COMPLETION.md and 02_REFINEMENT_APPLICATION.md; 02_EXECUTION/01_IMPLEMENTATION_PIPELINE.md, 02_REPOSITORY_AND_TABLET_PREFLIGHT.md and SESSION_CHECKPOINT_TEMPLATE.md; 03_CONTRACTS canonical resolution/dispatch/semantic/sync contracts and evaluation/operations domains; 05_VERIFICATION/01_TEST_AND_RELEASE_MATRIX.md and REVIEW_PROTOCOL.md; review-scope/contextual-review sections; all 215 requirement cards and their acceptance anchors.
Read HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md: foundation 00/01; 05_EXECUTION implementation order/final gate; relevant intelligence/interaction/governance; retained detailed originals, specifically product-flow amendment and public-claims/completeness/launch contracts. The refined canonical files override covered conflicts; all non-conflicting originals remain mandatory. 215 is not total scope. No invented MVP/V1/V2 split. Current user instructions supersede archived prompt timing. Read live AGENTS.md and reconcile its older authority statements without discarding valid safety/verification constraints.

CURRENT IMPLEMENTATION FINDINGS:
Static review of uploaded snapshot confirms Vite SPA entry index.html→src/main.jsx→src/App.jsx, shared runtime plus Infinity boot, five Supabase edge functions and 19 migration files. Live Windows E:\hey/remote currentness is unknown.
scripts/generate-capability-ledger.mjs promotes names containing chat/voice/agent/etc to VERIFIED WORKING; agents unconditionally verified; implemented catalog flags and substring test references become AUTOMATED TESTED without run results. These are not valid evidence.
docs/upgrade/MASTER-STATUS.json says 34/34 verified despite notes disclosing untested behavior/native external setup. HEY-CAPABILITY-LEDGER.json contains 2040 inventory entries, not full canonical requirements.
Get-HeyModulePlans sorts filenames. Invoke-HeyAllUpgrade skips historical verified states without freshness validation. verify-module.mjs proves requested imports/existence/test exit results, not production completeness; zero requested probes can pass.
RELEASE_GATE.md's September 20 CONDITIONAL GO and platformMatrix.js web source verification cannot certify the current full approved product. Multiple legacy TS/Next and shared-core candidates need 01/13 caller-level disposition, not blanket removal.
Fresh review test run: Node v24.19.0, node --test tests/*.test.js, exit 1, 107 pass/10 fail of 117 runner tests; failures were missing react/Tauri/Supabase dependencies and missing PowerShell. No build/lint/live backend/native/device flow executed. Treat historical reports separately and reproduce baseline on actual worker.

FILES AND SYSTEMS TO INSPECT FIRST:
AGENTS.md; package.json; index.html; src/main.jsx; src/App.jsx; vite.config.js; eslint.config.js;
scripts/generate-capability-ledger.mjs;
docs/upgrade/MASTER-STATUS.json, HEY-CAPABILITY-LEDGER.json, HEY-VERIFICATION-MATRIX.md;
docs/release/HEY-CAPABILITY-MATRIX.json, RELEASE_GATE.md, HEY-RELEASE-EVIDENCE.md, BLOCKED.md, HEY-KNOWN-LIMITS.md;
HEY-UPGRADE.ps1; scripts/hey-upgrade/HeyUpgrade.psm1, verify-module.mjs, generate-module-plans.ps1, generate-module-reports.ps1, Test-HeyUpgrade.ps1, modules/*.json;
tests/upgrade-orchestrator.test.js, release-surfaces.test.js, owner-governance.test.js;
src/core/platformMatrix.js, capabilityRegistry.js, v1CapabilityManifest.js, featureCatalog.js, infinity/infinityManifest.js; agents/v1AgentCatalog.js.
Inspect nearby execution/event/provider/state dependencies and existing source documents before edits; do not assume another path or table exists.

SCOPE:
Authority/source disposition; unique primary ownership across 00–18; requirement↔repository binding; dependency/priority/conflict/decision/blocker/handoff/checkpoint records; evidence references; derived product status and coordination reports. Prefer existing ledger/report infrastructure. New planning/schema/test files may be added when justified; name them only after repository inspection.

OUT OF SCOPE:
Independent redesign of Brain/providers/agents/tools/Forge/voice/native/memory/product schedulers/UI/school workflows/RLS/release infrastructure. 08 owns test/evidence infrastructure, 10 executor/release operations, 13 integration, 18 final audit. Make minimal necessary shared coordination-boundary edits only with explicit owner/impact record; unresolved dependency work becomes a precise handoff.

REQUIRED CHANGES:
1. Preflight: verify actual repo identity, branch, HEAD, dirty/untracked user work, lockfile, runtimes and tests; preserve unpushed Windows changes. Hash supplied authoritative documents and inspected snapshot. No assumed GitHub freshness; no secret values in output. Keep source extraction in planning space and original bytes intact.
2. Authority/source ledger: record stable locators and occurrence context, source precedence, semantic disposition, retained acceptance conditions and unresolved conflicts. Explicitly resolve contradictions without silently dropping requirements. Missing referenced refined JSON files remain declared missing; combined Markdown supports initial mapping but is not proof of full atomic disposition.
3. Ownership/binding: exactly one primary specialist 00–18 per requirement; consumers explicit. Map 34 historical upgrade modules separately. Bind actual files/symbols/routes/edge functions/SQL/events/native adapters/tests only after inspection. A logical specification operation is not an existing endpoint. Persist acceptance-case associations, platform applicability and coverage gaps. Preserve 215 cards plus retained original meaning, with no arbitrary feature-count target.
4. Evidence/maturity: replace heuristic promotions with evidence references. Inventory hints never certify behavior. Store candidate/dirty-tree or content fingerprint, requirement/spec version, testcase/runner version, environment/platform/device, timestamp, expected/observed outcome, execution result, evidence location and verifier independence. Missing/failed/skipped/stale/mock-only/waived/external-blocked items cannot PASS. Require applicable integration, independent/device and release conditions for PRODUCTION_READY. Keep runtime availability, transaction status and product maturity distinct.
5. Scheduling/invalidation: validated dependency DAG, missing-reference/cycle rejection, blocked downstream gates, independent-work continuation, shared-file ownership and impacted-evidence invalidation. Coordinate with 10 so resume cannot skip stale evidence and probes cannot masquerade as full verification. Preserve upgrade safety/rollback; do not execute apply/rollback to repair status. Test ordering using dependencies rather than filename labels.
6. Conflicts/improvements/handoffs: persistent decision queue with impacted requirements, owner, evidence, alternatives, rationale, deadlines/blockers and resolution. Improvement proposals carry measured benefit/risk/cost/dependencies and retained acceptance. Handoffs remain prepared until actual supported transmission is logged; no invented chat notifications. Persist resumable checkpoint with last successful step, open evidence and next exact action.
7. Projections/readiness: derive coordination views from the canonical ledger rather than independent claims. Preserve historical reports with dates/scope; never adopt old conditional-go or source-verified as current release readiness. Work with 10/13 on platformMatrix consumers and release documents. Keep unsupported platforms/external setup/waivers explicit and forbid misleading whole-product completion.
Each change must document persistence, permissions, failure/recovery and verification. A file-backed coordination record is acceptable if existing workflow supports it; do not invent a server service/database migration without a real authorized need.

PRESERVE:
Vite route/build topology, current chat/auth/persistence behavior; fail-closed capability/tool/agent/Forge paths; original acceptance conditions; transactional baseline conflict refusal, secret redaction, timed commands, backups and safe rollback; honest native/platform limits; unique behavior in overlapping engines until safe owner-led consolidation.

REMOVE / REPLACE:
Remove name/catalog/source/test-reference-based evidence promotion. Replace stale current-status projections with derived evidence-aware status while retaining history. Do not delete runtime registries or legacy engine behavior just to reduce counts. Retire duplicate coordination sources only after consumer migration, regression checks and rollback evidence.

SHARED CONTRACTS:
Proposed coordination fields: requirement ID/source locator/hash/disposition, primary owner/consumers, platform applicability, repository/API/schema/event/native/test bindings, acceptance IDs, dependency IDs, maturity/blocker, evidence refs, candidate fingerprint and decision records.
Consume canonical 01 command/response/event state, 09 policy/owner decisions, 08 evidence producers and 10 release records. Never let a client/local status, agent or report self-authorize an action. Full coverage/ownership does not prove domain implementation.

PERFORMANCE REQUIREMENTS:
No measured coordination latency/RAM baseline exists. Avoid importing/executing all runtime engines merely to build an inventory. Use deterministic incremental hashing/indexing and bounded scans, reuse unchanged evidence only through validated impact rules, and support resumable mapping on weak-worker environments. Have 14 supply measured budgets/cohorts; proposed targets remain proposals. Ordinary checks make no paid/provider/live side-effect calls.

SECURITY / PRIVACY REQUIREMENTS:
Redact credentials and private context; inspect env names only unless securely necessary. No service secrets in reports/client bundles. Account/tenant scope and authenticated owner decisions for shared records; no admin bypass or fake approvals. Reports cannot authorize deployment/actions. Preserve exactly-three-owner policy with configured identities; ordinary approval and unanimous extension publication follow authoritative governance. Emergency labels cannot bypass release controls. Keep audit evidence tamper-aware and separate reviewer independence from model agreement.

UX REQUIREMENTS:
Coordination output shows pending/unreviewed/in-progress/blocked/failed/stale/conflict/cancelled/recovered/verified states with specific reasons and next actions. Unknown results cannot look completed. Preserve checkpoint/input on errors. Use existing surfaces only where warranted; no unrequested dashboard build. Product status copy/recovery presentation changes consume 11/02.

ACCESSIBILITY / LOCALIZATION:
Readable structured Markdown/JSON reports and unambiguous state labels. If an existing UI consumes status, preserve keyboard/focus/touch/screen-reader/reduced-motion/contrast/RTL behavior and localization; obtain 02/11 acceptance evidence. No new UI solely to satisfy the Director task.

FAILURE CASES:
Conflicting source amendments; preserved original clause missing from mapping; duplicate owner; unresolved binding; cycle/missing dependency; stale candidate/spec/test/adapter; successful HTTP without observed outcome; test file exists but never ran; failing/skipped/flaky check; mocked provider receipt; partial save; interrupted report write; corrupted ledger; missing PowerShell/dependency/device; cross-platform evidence reuse; forged waiver/owner signature; changed dirty tree; offline checkpoint recovery; active transaction with later user edits. Preserve data, refuse promotion and emit exact blockers.

TESTS TO ADD OR UPDATE:
Scoped deterministic tests for false-positive keyword/agent/catalog promotion; presence/reference vs executed evidence; absent probes; per-platform maturity; failed/skipped/mock/waived/stale evidence; full source-card and retained-source coverage; unique ownership; cycle/missing prerequisite/topological order; blocked downstream with independent progress; evidence invalidation; corrupted/interrupted ledger recovery; consistent projections; truthful checkpoint/handoff; secret redaction. Extend existing tests/upgrade-orchestrator.test.js via 10 for transactional changes, not a second executor. 08/18 review sufficiency; 13 checks bindings. Full domain E2E tests are owner dependencies, not Director's feature implementation.

CODEX EXECUTION RULES:
Inspect real code and current source authority. Preserve strong behavior; extend canonical systems; no duplicate registries/services, placeholders or simulated completion. Stay in scope and report minimal dependency edits. Preserve required compatibility; safe additive migration only if justified, with rehearsal/backup/rollback. Keep HEY runnable. Do not stop after code: run relevant checks and real flows where technically possible, investigate failures and fix introduced regressions. Never weaken requirements/tests to turn green; distinguish environment blockers from defects. Do not claim tests/device/independent review not executed. Deployment is a separate authorized task. No commits unless requested. Continue independent coordination work around exact external blockers; leave unavailable behavior unverified.

ACCEPTANCE CRITERIA:
1. Full source disposition includes all 215 refined cards and retained original requirements, with open coverage explicit.
2. Exactly one primary 00–18 owner per requirement; upgrade modules mapped separately; consumers explicit.
3. Every claimed implementation binding exists and matches semantics; unreviewed bindings stay unreviewed.
4. No heuristic/source/mock/waiver/stale/failed evidence promotes PASS or PRODUCTION_READY.
5. Candidate/platform/environment-specific evidence and impact invalidation work; legacy status cannot skip stale gates.
6. Dependency graph rejects cycles/missing references and correctly schedules available work around blockers.
7. All current projections agree; dated historic records cannot certify new candidates.
8. Conflict/decision/blocker/handoff/checkpoint records preserve context and actual transmission truth.
9. Regression checks run or have precise honest blockers; no unrelated behavior regression or secret exposure.
10. Independent 08/13/18 and 10 release gates remain required; unsupported/device-unverified behavior remains explicit.

DEFINITION OF DONE:
Director coordination is complete only when source preservation, unique ownership, actual bindings, dependency/conflict handling, durable recovery, truthful evidence/maturity, consistent status and scoped tests are verified against the candidate. Applicable auth/security/accessibility/localization/persistence and failure cases must pass. This does not mark the whole product complete. Missing domain/integration/user-device/independent/release evidence remains an open gate; no simulated path is represented as real.

RETURN FORMAT:
Return: 1 Summary of changes; 2 Files created; 3 Files modified; 4 Files removed; 5 Architecture decisions; 6 Migrations/schema changes; 7 Tests added; 8 Tests executed; 9 Test results; 10 Manual flows exercised; 11 Performance observations; 12 Security/privacy observations; 13 Remaining limitations; 14 Dependencies needing another workstream; 15 Acceptance-criteria evidence; 16 Anything not honestly verified.
```

## Appendix: source inventory and unreviewed capability tracking

The following inventory preserves embedded source section names and every refined capability card. Domain names are read from the cards, not invented endpoints. Implementation maturity for these domain cards is **UNASSESSED** in this Director review; primary specialist mapping must be semantically validated. Director-owned governance coverage is recorded in C. No card is silently treated as complete.

### Coordination update — 2026-10-03

All 19 existing specialist chats have received their review-only briefs, per the user’s coordination report. Implementation remains unauthorized. The project Sources tab lists Yoyoyo.zip and both authoritative Markdown documents, per the user’s direct inspection. Some specialists cannot inspect archive contents in their context. Track each affected workstream as BLOCKED_SOURCE_ACCESS, with report basis SPEC_ONLY/PARTIAL until actual code inspection occurs. This means unavailable inspection capability, not missing source code. Such reports cannot be accepted as code-grounded implementation plans or completed audits. Specialist-by-specialist access and review completion remain unconfirmed; no cross-chat notification is claimed.

Director access was rechecked through Python zipfile: 1,087 file entries; hey/package.json, hey/AGENTS.md and hey/src/App.jsx were read directly. Director’s access does not establish access in another chat. Archive filename is exactly Yoyoyo.zip; the local numeric prefix is transport naming only.

### Source fingerprints

- `01-Yoyoyo.zip` — SHA-256 `238f4c79ff6685fa8d04772a36966a3e1625063d819d31240fb0c434b072ccb8`
- `02-HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md` — SHA-256 `e617dfe4ca2e9c1dd753b53d3002c9e694bbb1582728d1aef725d92f11e2b82d`
- `03-HEY_REFINED_ENGINEERING_DOCUMENT.md` — SHA-256 `d39a85b0bd79174b3c8b4caa2c33d4706e0620a71b355542b6218458847b88e9`

### Original embedded source sections (indexed, not full semantic certification)

- `00_FOUNDATION/00_READ_ME_FIRST.md`
- `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`
- `02_INTELLIGENCE_EVOLUTION/01_COGNITIVE_FABRIC_AND_INTELLIGENCE_COUNCIL.md`
- `02_INTELLIGENCE_EVOLUTION/02_DECISION_FABRIC_BEYOND_TOKENS.md`
- `02_INTELLIGENCE_EVOLUTION/03_UNLIMITED_AGENT_FOUNDRY.md`
- `02_INTELLIGENCE_EVOLUTION/04_RUNTIME_CAPABILITY_SYNTHESIS.md`
- `02_INTELLIGENCE_EVOLUTION/05_RISK_TWIN_SOLUTION_TWIN.md`
- `02_INTELLIGENCE_EVOLUTION/06_EVOLUTION_ENGINE_WHOLE_INTERNET.md`
- `03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`
- `03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`
- `03_INTERACTION_PLATFORM/03_PLATFORM_OUTCOME_PARITY.md`
- `03_INTERACTION_PLATFORM/04_DYNAMIC_ISLAND_BACKGROUND.md`
- `04_SECURITY_GOVERNANCE/01_OWNER_CONSOLE_AND_GOVERNANCE.md`
- `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`
- `04_SECURITY_GOVERNANCE/03_RATE_LIMITS_COMPUTE_ALLOWANCES_CONTINUITY.md`
- `04_SECURITY_GOVERNANCE/04_CLOSED_SOURCE_API_LOCAL_MODELS_EXTENSIONS.md`
- `05_EXECUTION/01_REPOSITORY_IMPLEMENTATION_ORDER.md`
- `05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`
- `06_PROMPTS/00_MASTER_IMPLEMENTATION_PROMPT.md`
- `01_DETAILED_SYSTEM_SPECS/00_AUTHORITATIVE_NEWEST_PRODUCT_FLOW_AMENDMENT.md`
- `01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`
- `01_DETAILED_SYSTEM_SPECS/02_COMPLETE_HOME_DASHBOARD_INTELLIGENCE.md`
- `01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`
- `01_DETAILED_SYSTEM_SPECS/04_COMPLETE_NOTIFICATIONS_ATTENTION_SYSTEM.md`
- `01_DETAILED_SYSTEM_SPECS/05_COMPLETE_MODES_SYSTEM.md`
- `01_DETAILED_SYSTEM_SPECS/06_COMPLETE_PROJECT_SYSTEM.md`
- `01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`
- `01_DETAILED_SYSTEM_SPECS/08_COMPLETE_FIRST_RUN_ACCOUNT_LIFECYCLE.md`
- `01_DETAILED_SYSTEM_SPECS/09_COMPLETE_PLATFORM_CAPABILITY_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/10_COMPLETE_PERMISSIONS_RISK_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`
- `01_DETAILED_SYSTEM_SPECS/13_COMPLETE_DATA_SCHEMA_CONTRACT.md`
- `01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/15_COMPLETE_FAILURE_RECOVERY_CATALOG.md`
- `01_DETAILED_SYSTEM_SPECS/16_COMPLETE_PERFORMANCE_BUDGETS.md`
- `01_DETAILED_SYSTEM_SPECS/17_COMPLETE_ANALYTICS_EVENT_TAXONOMY.md`
- `01_DETAILED_SYSTEM_SPECS/18_COMPLETE_SUPPORT_INCIDENT_SEVERITY.md`
- `01_DETAILED_SYSTEM_SPECS/19_COMPLETE_PUBLIC_CLAIMS_TRUTH_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/20_COMPLETE_LAUNCH_ACCEPTANCE_MATRIX.md`
- `01_DETAILED_SYSTEM_SPECS/21_COMPLETE_PWA_INSTALL_UPDATE_SPEC.md`
- `01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`
- `01_DETAILED_SYSTEM_SPECS/23_COMPLETE_NATIVE_DYNAMIC_ISLAND.md`
- `01_DETAILED_SYSTEM_SPECS/24_COMPLETE_TUTORIAL_DISCOVERY_SYSTEM.md`
- `01_DETAILED_SYSTEM_SPECS/25_COMPLETENESS_INVENTORY.md`
- `01_DETAILED_SYSTEM_SPECS/ANSWER_ENGINE_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/COMPLETE_CAPABILITY_CATALOG_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/MOTION_AND_TUTORIAL_SYSTEM_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/RELEASE_GAP_AND_EXPECTATION_DETAIL.md`
- `01_DETAILED_SYSTEM_SPECS/VISUAL_REFERENCE_MASTER.md`

### Refined cards: domain audit pending

| Requirement | Title | Specification runtime domain | Director domain-review status |
|---|---|---|---|
| HEY-CAP-001 | Proof before done | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-002 | Personal acceptance checklist | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-003 | Learn from corrections | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-004 | Interruption recovery | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-005 | Consequence preview | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-006 | Weak-result detection | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-007 | Cross-device missions | device | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-008 | Private quality benchmark | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-009 | Teach by demonstration | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-010 | Verified skill library | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-011 | Interface-change repair | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-012 | Practice environments | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-013 | Cross-task skill transfer | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-014 | Prompt experiments | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-015 | Evidence-based method routing | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-016 | Skill retirement | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-017 | Memory provenance | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-018 | Memory conflict resolution | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-019 | Memory expiration | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-020 | Memory boundaries | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-021 | Editable memory map | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-022 | Decision history | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-023 | Selective forgetting | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-024 | Task-focused context | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-025 | Claim evidence map | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-026 | Decision-changing research | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-027 | Evidence-weighted dissent | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-028 | Source lineage | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-029 | Freshness monitoring | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-030 | Research-to-action handoff | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-031 | Reproducible research | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-032 | Coverage reporting | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-033 | Dependency-aware missions | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-034 | Shared-file coordination | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-035 | Duplicate-action protection | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-036 | Verified handoffs | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-037 | Bottleneck detection | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-038 | Outcome-based progress | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-039 | Acceptance-based delegation | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-040 | Recovery rehearsals | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-041 | Mission-scoped permissions | identity | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-042 | Action receipts | control | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-043 | Protected areas | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-044 | Supported undo | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-045 | Assumption checkpoints | identity | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-046 | Private presentation mode | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-047 | Sensitive-data routing | identity | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-048 | Emergency stop | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-049 | Lesson-to-classroom workflow | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-050 | Misconception-aware tutoring | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-051 | Teacher-reviewed differentiation | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-052 | Curriculum traceability | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-053 | Consistent creative projects | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-054 | Constraint-aware generation | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-055 | Targeted regeneration | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-056 | Delivery inspection | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-057 | Decision rehearsal | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-058 | Structured project model | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-059 | Safe shadow mode | control | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-060 | Personal operating rules | memory | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-061 | Disagreement experiments | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-062 | Friction-driven improvements | research | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-063 | Task-suited quality checks | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-064 | Capability growth loop | skills | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-065 | Draft preservation | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-066 | Stable scrolling | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-067 | Intent-preserving interruption | voice | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-068 | Quiet notification grouping | notifications | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-069 | Contextual recovery actions | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-070 | Respectful defaults | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-071 | Honest save indicators | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-072 | Undoable low-risk UI actions | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-073 | Progressive disclosure | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-074 | Accessible status updates | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-075 | Reduced-motion continuity | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-076 | Touch and keyboard parity | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-077 | RTL and mixed-language stability | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-078 | Large classroom readability | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-079 | Safe shared-device logout | education | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-080 | Attachment readiness checks | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-081 | Duplicate upload detection | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-082 | Natural-language correction scope | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-083 | Coherent terminology | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-084 | Time-zone correctness | notifications | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-085 | Offline capability disclosure | device | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-086 | Battery-aware work | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-087 | Adaptive asset loading | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-088 | Virtualized long histories | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-089 | Local deterministic fast path | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-090 | Minimal routing hop | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-091 | Progressive useful answers | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-092 | Quality-aware escalation | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-093 | Scoped response caching | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-094 | Cancellation propagation | missions | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-095 | Provider health adaptation | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-096 | Fair scheduling | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-097 | Latency tracing | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-098 | Adaptive voice endpointing | voice | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-099 | Audio feedback prevention | voice | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-100 | Grounded screen assistance | voice | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-101 | Environment preflight | device | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-102 | Dependency impact preview | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-103 | Backup restoration drills | operations | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-104 | Privacy-preserving diagnostics | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-105 | Accessibility regression checks | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-106 | Quality-versus-cost controls | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-107 | Bounded proactive assistance | notifications | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-108 | Portable project export | artifacts | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-109 | User-visible uncertainty | evaluation | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-110 | Compatibility lifecycle | performance | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-111 | Dead-end prevention | ux | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-112 | Exact selectors | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-113 | Exact edit payloads | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-114 | Complete response schemas | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-115 | Cross-feature journeys | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-116 | Forbidden-state tests | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-117 | Version compatibility rules | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-118 | Migration interruption handling | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-119 | Deletion dependency maps | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-120 | Configuration validation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-121 | Support boundaries | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-122 | Working-context strip | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-123 | Explain included context | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-124 | Temporary context exclusion | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-125 | Conversation branches | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-126 | Branch comparison | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-127 | Pinned requirements | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-128 | Task-scoped corrections | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-129 | Deliverables tray | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-130 | Source-to-output navigation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-131 | Decision queue | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-132 | Keyboard-safe tablet layout | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-133 | Orientation continuity | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-134 | Resumable uploads | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-135 | Bandwidth controls | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-136 | Safe gesture boundaries | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-137 | Stylus selection | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-138 | One-handed controls | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-139 | Background-return reconciliation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-140 | Storage management | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-141 | Lightweight preview fallback | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-142 | Consequential name clarification | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-143 | Command versus dictation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-144 | Recognition corrections | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-145 | Mixed-language speech | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-146 | Output-device recovery | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-147 | Voice-session ownership | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-148 | Interrupt intent choices | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-149 | Classroom microphone calibration | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-150 | Pronunciation preferences | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-151 | Private spoken responses | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-152 | Version-bound approvals | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-153 | Anchored review comments | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-154 | Design-token locking | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-155 | Compatibility profiles | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-156 | Missing-source detection | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-157 | Source-change impact | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-158 | Structural and visual comparison | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-159 | Real-content previews | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-160 | Release bundles | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-161 | Export round-trip checks | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-162 | Connection preflight | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-163 | Account-switch detection | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-164 | Destination previews | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-165 | Revocation propagation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-166 | Reconnection without repeats | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-167 | Webhook reconciliation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-168 | Credential rotation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-169 | Integration health history | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-170 | Data portability checks | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-171 | Service-removal plans | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-172 | Task-class latency | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-173 | Tail-latency control | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-174 | Backpressure | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-175 | Coalesced permitted reads | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-176 | Coordinated retries | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-177 | Interactive/background separation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-178 | Safe useful streaming | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-179 | End-to-end completion timing | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-180 | Latency regression gates | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-181 | Trace-led optimization | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-182 | Verified deliverable loop | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-183 | Living project brief | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-184 | Correction-to-test loop | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-185 | Classroom session bundle | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-186 | Cross-device review loop | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-187 | Decision experiment workspace | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-188 | Dependency-aware change assistant | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-189 | Failure reproduction package | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-190 | Confidence-to-action boundary | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-191 | Release rehearsal | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-192 | Account-bound local vault | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-193 | Storage-pressure recovery | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-194 | Multi-tab leader election | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-195 | Clock-skew-safe leases | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-196 | Human approval anti-replay | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-197 | Atomic context switching | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-198 | Input-method composition safety | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-199 | Focus restoration after overlays | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-200 | Non-drag workspace controls | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-201 | Archive extraction safeguards | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-202 | Document active-content isolation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-203 | Structured data correctness | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-204 | Encrypted resumable checkpoints | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-205 | Artifact lineage attestations | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-206 | Bounded dependency expansion | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-207 | Reproducible randomized evaluations | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-208 | Canary rollback triggers | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-209 | Dependency vulnerability triage | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-210 | Trace propagation allowlist | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-211 | Data-retention control center | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-212 | Semantic deduplication review | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-213 | Read-only safe operation mode | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-214 | Quality budget negotiation | UNBOUND | UNREVIEWED; maturity UNASSESSED |
| HEY-CAP-215 | Cross-language evidence alignment | UNBOUND | UNREVIEWED; maturity UNASSESSED |
