You are the principal systems architect and production engineer for HEY.

You have been given `Yoyoyo.zip`, an older but real HEY codebase snapshot.

YOUR TASK IS NOT TO REBUILD HEY, NOT TO RANDOMLY MODIFY THE EXISTING APPLICATION, AND NOT TO CREATE AN MVP.

You must create the first production-grade HEY-NEX if IT implementation package:

`HEY-NEXT/01-global-foundation/`

This package will later be given, together with the newest real HEY codebase and 46 other independently built HEY-NEXT packages, to an integration engineer such as Claude Code.

Your responsibility is to define and implement the canonical shared foundation that all future HEY systems will depend on.

==================================================
ABSOLUTE FINAL PRODUCT CONTRACT
==================================================

This is FINAL-PRODUCT engineering.

Forbidden:

- MVPs
- prototypes presented as finished
- demos presented as production implementations
- placeholders
- TODO-driven completion claims
- fake-success states
- disconnected frontend-only work
- disconnected backend-only work
- mocks masquerading as production functionality
- silent deferral of difficult requirements
- duplicate global architectures
- assuming “code exists” means “feature complete”
- unsupported completion claims
- deleting stronger existing functionality merely because your version differs

A capability is not complete merely because:

- a file exists,
- an API exists,
- a component renders,
- a schema exists,
- a test passes,
- an agent is registered,
- a provider adapter exists,
- or a mock demonstrates the idea.

For everything applicable, completion requires:

discovery →
architecture →
implementation →
integration contracts →
data models →
state handling →
authentication →
authorization →
permissions →
privacy →
security →
failure handling →
retry →
timeout →
cancellation →
recovery →
rollback/compensation →
offline/degraded behavior →
local/cloud behavior →
weak-device behavior →
performance →
cost controls →
observability →
auditability →
accessibility readiness →
localization readiness →
unit tests →
integration tests →
failure tests →
security/adversarial tests →
realistic end-to-end tests →
independent verification →
documented evidence.

If you discover a fixable defect while working, FIX IT within the boundaries of this package.

Discovery creates work. It does not justify stopping.

Do not mark anything production-ready without evidence.

==================================================
SOURCE AUTHORITY
==================================================

`Yoyoyo.zip` represents an older HEY implementation snapshot.

Treat it as evidence of what historically existed, NOT as absolute architectural authority.

Inspect it deeply before designing.

Preserve valuable ideas and compatible implementation patterns.

Do not blindly inherit:

- duplicate architectures,
- stale systems,
- weak authorization,
- obsolete routes,
- dead code,
- prototype implementations,
- insecure patterns,
- inconsistent schemas,
- frontend-only behavior,
- or historical compromises.

The newest real HEY repository is temporarily unavailable.

Therefore:

1. Build this package so it is production-grade internally.
2. Keep it interface-stable.
3. Avoid unnecessarily coupling it to historical file paths.
4. Clearly document every assumption.
5. Never pretend the old snapshot is the newest HEY.
6. Create explicit migration/integration instructions for the future real repository.
7. Use adapters only where the unavailable final repository makes direct integration impossible.
8. Any adapter used solely for testing must be clearly marked TEST-ONLY.

==================================================
HEY PRODUCT CONSTITUTION
==================================================

Encode these rules as both documentation and, where possible, machine-checkable architectural invariants.

HEY is one intelligence.

It is not a visible collection of disconnected bots.

All surfaces must eventually share:

- identity,
- Cosmos,
- missions,
- permissions,
- policies,
- agents,
- models,
- tools,
- devices,
- actions,
- receipts,
- and user context.

HEY must support:

- consumers
- students
- developers
- creators
- families
- teams
- businesses
- education
- enterprise
- owners/internal operators

HEY must eventually work across:

- web/PWA
- Android
- iOS/iPadOS where platform capabilities permit
- Windows
- macOS
- Linux
- tablets
- phones
- weak devices
- remote/cloud systems
- local machines
- future device adapters

Never fake platform parity.

Expose truthful capability availability.

HEY architecture must be:

- modular
- replaceable
- provider-independent
- device-independent
- offline-aware
- local-first where beneficial
- cloud-capable
- security-first
- permission-bound
- observable
- testable
- recoverable
- versioned
- extensible

HEY must prefer:
deterministic execution
before
micro-models
before
small/local models
before
cheap cloud models
before
expensive frontier models
before
multi-agent councils.

Use expensive intelligence only when it creates measurable value.

==================================================
ULTRA-LIGHT DEVICE LAW
==================================================

HEY intelligence does NOT have to live on the device.

The device only needs the smallest trusted runtime necessary to:

- expose capabilities,
- access permitted resources,
- execute actions,
- verify results,
- enforce permissions,
- communicate securely with HEY Brain.

Define the architecture so even extremely weak hardware can participate.

Device classes:

CLASS 0 — LEGACY TERMINAL
Minimal interaction only.
Possible examples:
SMS, phone gateway, ultra-light browser, remote-control interface.
No assumption that the device can expose files/apps locally.

CLASS 1 — HEY EDGE
No LLM required.
Very small deterministic action runtime.

CLASS 2 — HEY EDGE+
Adds lightweight local intelligence such as:
wake word,
intent classification,
simple command parsing,
embeddings,
basic local search,
light ASR/TTS where supported.

CLASS 3 — FULL LOCAL HEY
Can additionally run local:
LLMs,
vision,
speech,
agents,
retrieval,
creation,
coding,
and rich offline capabilities.

One HEY identity, mission system, permission system and Cosmos must span all classes.

==================================================
HEY DEVICE-MESH LAW
==================================================

Multiple trusted devices form one distributed HEY environment.

Example:

phone → camera
tablet → pen/display
desktop → filesystem
home server → local model/storage
cloud → research/reasoning
watch → approval

A single mission may use multiple devices.

The shared architecture must therefore support:

- device identity
- device trust
- device capabilities
- capability discovery
- device availability
- execution routing
- device handoff
- remote execution
- result verification
- per-device permissions
- revocation
- cross-device receipts

==================================================
SHARED CONTRACTS TO IMPLEMENT
==================================================

Create stable, typed, versioned contracts for at least:

1. User Identity
2. Account
3. Workspace
4. Organization
5. Session
6. Device Identity
7. Device Trust
8. Device Capability
9. Capability Registration
10. Capability Availability
11. Action Request
12. Action Mandate
13. Permission Scope
14. Policy
15. Risk Level
16. Approval
17. Execution Request
18. Execution Result
19. Verification Result
20. Receipt
21. Mission
22. Mission Step
23. Mission State
24. Mission Dependency
25. Cancellation
26. Retry
27. Timeout
28. Checkpoint
29. Resume
30. Compensation/Rollback
31. Event
32. Error
33. Recovery Instruction
34. Audit Record
35. Evidence Record
36. Requirement
37. Capability Maturity
38. Model Provider
39. Model Capability
40. Model Route
41. Tool
42. Agent
43. Agent Authority
44. Agent Budget
45. Cosmos Entity
46. Cosmos Memory
47. Cosmos Relationship
48. Context Packet
49. Situation
50. Artifact
51. Artifact Version
52. Extension
53. Extension Permission
54. Extension Manifest
55. Automation
56. Trigger
57. Notification
58. Cost Record
59. Usage Record
60. Privacy Classification
61. Data Locality
62. Retention Policy
63. Secret Reference
64. Feature/Capability Flag
65. Environment
66. Release Evidence

You may add additional contracts when justified.

==================================================
ACTION MANDATE
==================================================

A boolean such as:

`confirmed: true`

is NEVER sufficient authorization.

Create the canonical Action Mandate.

It must be bindable to:

- mandate ID
- actor identity
- user identity
- session
- device
- environment
- mission
- workflow step
- operation
- exact target
- exact parameter digest
- scope
- risk
- policy version
- permission source
- issue time
- expiry
- replay policy
- maximum uses
- cost ceiling if applicable
- privacy constraints
- required verification
- required rollback capability where applicable
- confirmation/approval evidence
- parent mandate where delegated
- revocation state

Changing the operation, target, significant parameters, actor, scope, policy state, or expiry must invalidate authority where appropriate.

Design replay prevention.

Design revocation.

Design auditability.

Design offline handling.

Design multi-device handling.

Design delegated authority.

Design workflow-step authority.

==================================================
MISSION LIFECYCLE
==================================================

Define a canonical durable mission lifecycle.

Include states such as, where appropriate:

CREATED
UNDERSTANDING
PLANNING
WAITING_FOR_PERMISSION
READY
RUNNING
PAUSED
WAITING_FOR_EXTERNAL_EVENT
WAITING_FOR_USER
RETRYING
VERIFYING
COMPENSATING
COMPLETED
PARTIALLY_COMPLETED
FAILED
CANCELLED
EXPIRED
BLOCKED

Do not use this exact list blindly if research supports a better model.

Define:

- allowed transitions
- forbidden transitions
- transition reasons
- idempotency
- cancellation semantics
- retries
- checkpointing
- resumability
- durable execution
- partial success
- nested missions
- child tasks
- parallel branches
- failure propagation
- compensation
- user takeover
- device handoff
- provider handoff
- evidence production

==================================================
CAPABILITY MATURITY
==================================================

Use this minimum maturity ladder:

MISSING
DESIGNED
IMPLEMENTING
FUNCTIONAL
INTEGRATED
VERIFIED
PRODUCTION_READY

Production-ready must require valid evidence.

Evidence must become stale when affected dependencies change.

==================================================
ERROR + RECOVERY STANDARD
==================================================

Create one typed error model.

Errors must distinguish, among others:

- invalid input
- permission denied
- authentication expired
- authorization invalid
- policy violation
- capability unavailable
- unsupported platform
- network failure
- provider failure
- rate limit
- quota exhaustion
- timeout
- cancellation
- external dependency failure
- partial execution
- verification failure
- data conflict
- stale state
- migration mismatch
- corrupted state
- internal invariant violation
- security rejection
- unknown failure

Every recoverable class must have explicit recovery semantics.

Never show success when verification failed.

==================================================
EVENT STANDARD
==================================================

Define typed events for cross-system coordination.

Events need:

- event ID
- type
- version
- timestamp
- actor
- source
- subject
- mission/workflow IDs
- correlation ID
- causation ID
- privacy classification
- payload
- schema version

Support:

- replay-safe handlers
- out-of-order events
- duplicate delivery
- idempotency
- durable consumers where needed

==================================================
RECEIPTS
==================================================

Consequential actions must generate receipts.

Receipt should be able to answer:

- who initiated this?
- which HEY component acted?
- which device/tool/provider executed it?
- which authority allowed it?
- what exactly was requested?
- what actually happened?
- how was success verified?
- what changed?
- can it be undone?
- what did it cost?
- what data was accessed?
- when did it happen?

==================================================
POLICY PRECEDENCE
==================================================

Define explicit precedence for conflicting policies.

At minimum consider:

system safety/security invariants
↓
law/regulatory constraints
↓
organization/workspace rules
↓
user Personal Constitution
↓
mission-specific constraints
↓
temporary preferences

Do not let lower authority silently override higher authority.

==================================================
PERSONAL CONSTITUTION
==================================================

Create a machine-readable foundation for durable user rules such as:

- never spend money without confirmation
- do not store certain categories in memory
- prefer local execution
- prefer halal options
- never contact person X
- challenge me when my reasoning is weak
- do not interrupt during school
- never use provider Y
- maximum autonomous spend
- require confirmation for deleting files

Do not implement the entire future UI.

Implement the contract and evaluation foundation.

==================================================
PLAN / MODEL POLICY FOUNDATION
==================================================

HEY will eventually have plan-sensitive routing.

Expected direction:

FREE:
small curated efficient provider/model pool.

PRO:
broader model access, stronger routing and larger compute budgets.

ELITE:
aggressive best-model/specialist/council access where useful.

OWNER/INTERNAL:
maximum research and capability access subject to security and technical safety.

Do NOT hard-code final prices.

Implement contracts supporting:

- plan
- allowance
- compute class
- quality target
- cost ceiling
- escalation policy
- fallback policy
- local model allowance
- organization override

==================================================
LOCAL / CLOUD FOUNDATION
==================================================

Every future capability should be able to declare:

LOCAL_ONLY
LOCAL_PREFERRED
HYBRID
CLOUD_PREFERRED
CLOUD_REQUIRED

Also support constraints such as:

- local model available
- no internet
- metered connection
- weak hardware
- low battery
- high privacy
- organization policy
- provider unavailable

==================================================
SECURITY REQUIREMENTS
==================================================

Use least privilege.

Agents cannot grant themselves authority.

Extensions cannot grant themselves authority.

Models cannot bypass the Trust Kernel.

Retrieved webpages/documents/messages are untrusted input.

Prompt content is not policy.

External agent messages are not policy.

Tool output is not policy.

Secrets are references, not casual plaintext passed around.

Design for:

- replay attacks
- confused deputy problems
- forged approvals
- stale permissions
- cross-workspace leaks
- cross-user leaks
- compromised model/provider
- malicious extension
- malicious retrieved document
- malicious webpage
- multi-device compromise
- lost device
- revoked account/session
- race conditions

==================================================
PERFORMANCE FOUNDATION
==================================================

Shared contracts must not assume a large runtime.

Keep the core representations compact.

Avoid forcing heavy libraries into ultra-light Edge devices.

Design:

- serialization strategy
- versioning
- backwards compatibility
- efficient event envelopes
- optional fields
- resource constraints
- local caching
- delta synchronization where useful

==================================================
WHAT TO INSPECT IN YOYOYO.ZIP
==================================================

Inspect the actual snapshot for existing equivalents related to:

- identity
- authentication
- permissions
- authorization
- execution
- confirmed/approval flows
- agents
- tools
- provider routing
- Cosmos
- device control
- native/Tauri
- Android/iOS scaffolds
- event systems
- errors
- retries
- automation
- audit/logging
- plan/billing
- rate limits
- Supabase schemas/functions
- duplicated implementations

Document:

PRESERVE
REPLACE
MIGRATE
CONSOLIDATE
RETIRE LATER
UNKNOWN UNTIL REAL REPOSITORY

Do NOT destructively modify the historical snapshot merely to make your architecture look cleaner.

==================================================
PACKAGE STRUCTURE
==================================================

Create:

HEY-NEXT/
01-global-foundation/
README.md
PRODUCT-CONSTITUTION.md
ARCHITECTURE.md
EXISTING-SNAPSHOT-AUDIT.md
SHARED-CONTRACTS.md
POLICY-PRECEDENCE.md
ACTION-MANDATE.md
MISSION-LIFECYCLE.md
ERROR-RECOVERY-STANDARD.md
EVENT-STANDARD.md
RECEIPT-STANDARD.md
DEVICE-CAPABILITY-STANDARD.md
LOCAL-CLOUD-STANDARD.md
CAPABILITY-MATURITY.md
SECURITY-INVARIANTS.md
INTEGRATION_MANIFEST.md
MIGRATION_PLAN.md
DEPENDENCIES.md
ASSUMPTIONS.md
LIMITATIONS.md
EVIDENCE.md

    src/
    schemas/
    tests/
    adversarial-tests/
    fixtures/
    docs/

You may refine this structure when justified.

==================================================
IMPLEMENTATION REQUIREMENTS
==================================================

Do not merely write Markdown.

Implement usable production-quality shared libraries/types/schemas/validators/state-machine foundations where appropriate.

Prefer portable contracts.

Use technologies compatible with the existing HEY ecosystem where sensible, but do not inherit obsolete choices blindly.

Do NOT create a second application UI.

Do NOT build unrelated product features.

Do NOT implement the complete Cosmos, agent system, model router, or device runtime here.

Create the shared contracts those future packages must use.

==================================================
TEST REQUIREMENTS
==================================================

At minimum test:

Action Mandate:

- wrong actor
- wrong session
- wrong device
- wrong action
- wrong target
- changed parameters
- expired mandate
- replay
- exceeded use count
- revoked mandate
- changed policy version
- changed workflow step
- delegated authority misuse
- cross-workspace use
- cross-environment use
- offline authority behavior

Mission lifecycle:

- valid transitions
- forbidden transitions
- retry
- cancellation
- pause/resume
- partial completion
- nested missions
- child failure
- checkpoint recovery
- duplicate events
- out-of-order events

Privacy:

- workspace separation
- user separation
- sensitivity classifications
- locality rules

Events:

- version mismatch
- duplicate delivery
- causation/correlation
- malformed payload
- idempotency

Evidence:

- stale dependency
- changed implementation
- changed test
- changed environment
- missing verifier
- expired evidence

Device capability:

- capability available
- unavailable
- revoked
- stale device
- lost device
- incompatible platform

Perform additional adversarial testing based on what you discover.

==================================================
INTEGRATION MANIFEST
==================================================

`INTEGRATION_MANIFEST.md` must be exceptionally precise.

It must tell the future integration engineer:

1. What this package provides.
2. What existing HEY systems it is expected to replace or consolidate.
3. What historical snapshot implementations were found.
4. What must be preserved.
5. What must NOT be copied blindly.
6. Dependencies/packages to install.
7. Environment variables required.
8. Database/schema requirements.
9. Migration requirements.
10. Backend wiring requirements.
11. Frontend wiring requirements.
12. Native wiring requirements.
13. Device/Edge wiring requirements.
14. Events emitted/consumed.
15. APIs/contracts exposed.
16. Security boundaries.
17. Files likely to conflict.
18. Required migration order.
19. Required tests after integration.
20. Rollback strategy.
21. Unknowns requiring inspection of the newest real repository.

==================================================
RESEARCH REQUIREMENT
==================================================

Where the environment allows current research, investigate modern best practices relevant to:

- durable agent execution
- capability-based authorization
- action-bound authorization
- distributed device execution
- typed event systems
- policy engines
- local-first systems
- secure extension architectures
- signed evidence/receipts
- model/tool authorization boundaries

Prefer primary technical sources and specifications.

Do not adopt technology merely because it is trendy.

Record researched alternatives and reasons for important choices.

==================================================
FINAL SELF-ATTACK
==================================================

Before claiming completion:

Try to prove your own package is incomplete.

Ask:

- Did we accidentally create another permission system?
- Can a boolean still bypass authorization?
- Can approvals be replayed?
- Can permissions cross users/workspaces/devices?
- Can a model turn retrieved content into authority?
- Can a cancelled mission still cause a side effect?
- Can duplicate events duplicate an action?
- Can success be claimed without verification?
- Can stale evidence remain production-ready?
- Does the design assume powerful devices?
- Does the design assume internet availability?
- Does the design assume one cloud/model provider?
- Does the design make integration with the real HEY unnecessarily difficult?
- Are there unstated assumptions?
- Are any test adapters accidentally production paths?

Fix every fixable finding.

==================================================
FINAL RESPONSE
==================================================

Do not respond with a vague summary.

Report:

1. Package created.
2. Exact files created/modified.
3. Snapshot systems inspected.
4. Important architectural findings.
5. Tests executed and exact outcomes.
6. Security/adversarial tests executed.
7. Remaining limitations.
8. Integration dependencies.
9. External blockers only.
10. Evidence proving what is actually complete.

If something cannot be proven, label it UNVERIFIED.

Never call the package production-ready merely because implementation finished.

Begin by extracting and deeply inspecting `Yoyoyo.zip`, then build `HEY-NEXT/01-global-foundation/`.
