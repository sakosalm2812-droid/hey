# 06 — HEY GOLDEN USER JOURNEYS AND INDEPENDENT ACCEPTANCE TESTS

**57 executable test contracts; NOT executed.** These are additive acceptance tests, not substitutes for detailed original per-subsystem test requirements. School tests must use fictional people and synthetic records until formal authorization. Before each attempt, replace generic wording with exact build routes, device IDs and configured services from the actual repository. Never invent results.

All scenarios must record exact SHA, service/device, request/action, actual output, negative-condition observation, independent verifier, screenshots/recordings where safe, latency and provider spend. Tests that require a service or hardware absent from the current environment remain `BLOCKED_EXTERNAL` rather than `PASSED`.

## HEY-E2E-001 — Auth: New account
**Action:** New user registers with permitted email method; confirm real provider and persisted identity
**Pass:** Signup, verification, re-login and account recovery work without fabricated state
**Negative/failure test:** Invalid verification, expired link and abusive anonymous attempts are correctly rejected
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-002 — Identity: Session and revocation
**Action:** Login two browsers; terminate one session from settings
**Pass:** Revoked session cannot access protected API or cached organization records
**Negative/failure test:** Expired token and network outage do not expose data
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-003 — Onboarding: Cross-category onboarding
**Action:** Choose AI Assistant, Teaching and Create; later add Coder tool
**Pass:** Suggested first space includes selected categories; all other permitted tools remain discoverable
**Negative/failure test:** Skipped onboarding still works; permissions are unchanged
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-004 — Spaces: Developer adds Teacher tool
**Action:** Create Developer Space; pin Teacher Quiz; sign out and in
**Pass:** Pinned working tool persists across sessions/device where sync enabled
**Negative/failure test:** Revoked school role denies school-specific data even though tool remains pinned
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-005 — Spaces: Independent workspace layouts
**Action:** Drag tool widget, change size, switch device and return
**Pass:** Layout persists or adapts according to explicit per-device policy, no data loss
**Negative/failure test:** Corrupt layout restores prior valid snapshot
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-006 — Tool Library: Discovery by natural-language need
**Action:** Search I want to dictate in any app
**Pass:** Correct HEY Flow entrypoint and hardware compatibility/permissions displayed
**Negative/failure test:** Unsupported platform states shown truthfully; no dead launch button
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-007 — Conversation: Chat and Voice continuity
**Action:** Start chat, switch to Voice and Live then back
**Pass:** Conversation history, project, attachment and active artifact preserved
**Negative/failure test:** Mic denial returns to accessible chat without dropping content
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-008 — Voice: Voice interruption
**Action:** Start long spoken response; interrupt while speaking
**Pass:** Playback stops promptly; speech state truthful; no double-listening crashes
**Negative/failure test:** Permission revoke immediately ends capture and unblocks interface
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-009 — Voice: Wake word and false positives
**Action:** Configure preferred wake phrase, lock screen and simulate background speech
**Pass:** Only authorized/OS-permitted activation; visible status and app exclusions respected
**Negative/failure test:** Background listening stops on disable and app/device unsupported conditions
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-010 — Live: Screen guidance with moving button
**Action:** Share selected window; ask where to click; move/rescale window
**Pass:** Arrow/outline remains anchored and only advances after observed user step
**Negative/failure test:** Untrusted on-screen prompt cannot instruct HEY to leak documents
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-011 — Brain: Real model route
**Action:** Ask question requiring current evidence using approved provider
**Pass:** Real provider receipt and response, source provenance and spend measured
**Negative/failure test:** Provider 429/500 triggers bounded fallbacks with honest error
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-012 — Fusion: Council with independent objections
**Action:** Request complex business strategy with contradictory source claims
**Pass:** Evidence board retains minority dissent and reconciles sources, traceable spend
**Negative/failure test:** Agents cannot outvote proven evidence or approve own tools
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-013 — UltraSparse: Adaptive model routing budget
**Action:** Compare router and fixed baseline across held-out requests
**Pass:** Measure p95 router-only latency and total end-to-end latency separately
**Negative/failure test:** No false assertion of sub-ms full inference or cold GPU load
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-014 — Cosmos: Memory save and correction
**Action:** Save factual preference, ask later, then correct it
**Pass:** Latest authorized preference used; older version traceable, stale reply prevented
**Negative/failure test:** Private/school memory isolation and delete propagation tested
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-015 — Cosmos: Forget and export
**Action:** Export project memories and delete one specific memory
**Pass:** Authorized export scoped; deleted memory excluded from future retrieval
**Negative/failure test:** Embeddings and caches respect deletion or scheduled bounded purge policy
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-016 — Projects: Project DNA consistency
**Action:** Create named branding project; generate two related assets
**Pass:** Brand constraints, approved terms and lock rules preserved across assets
**Negative/failure test:** Non-project content cannot silently contaminate context
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-017 — Pinpoint: Change only slide 3 heading
**Action:** Create 5-slide deck; change slide 3 heading; export
**Pass:** Only requested element changes; slides 1,2,4,5 byte/structurally equivalent where appropriate
**Negative/failure test:** Failed export leaves prior approved artifact intact
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-018 — Docs: Editable document artifact
**Action:** Create a multi-page lesson handout, revise paragraph two
**Pass:** Actual editable document export opens; targeted edit preserves other content
**Negative/failure test:** Missing font or RTL layout fallback surfaced
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-019 — Sheets: Calculated spreadsheet
**Action:** Generate budget with formulas and scenarios
**Pass:** Formulas recalculate correctly in compatible editor; no invented totals
**Negative/failure test:** Division by zero/bad inputs handled without fabricated numbers
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-020 — Slides: Presentation creation and preview
**Action:** Ask for curriculum-based deck with editable diagrams
**Pass:** Actual slide file + preview + notes per spec; teacher can edit via HEY
**Negative/failure test:** Broken font/image results produce recoverable report
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-021 — Image: Generation output
**Action:** Generate product image with explicit aspect ratio and mood
**Pass:** Real image asset stored with provenance, correct format/dimensions
**Negative/failure test:** Outage/credit depletion shows failure, not stock image passed as output
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-022 — Image: Masked precise editing
**Action:** Mask one object in existing image; change its color
**Pass:** Only approved region changes beyond documented tolerance
**Negative/failure test:** Unmasked background preserved and compare preview available
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-023 — Video: Storyboard and locked shots
**Action:** Make 15-second three-shot marketing video, lock first shot, revise third
**Pass:** Playable artifact, exact duration tolerance, locked shot not rerendered silently
**Negative/failure test:** Async job crashes/resumes without fake completed preview
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-024 — Audio: Synthesis and dictation
**Action:** Generate authorized narration with configured voice
**Pass:** Real playable audio, appropriate pronunciation and file provenance
**Negative/failure test:** No impersonation of unconsenting private persons
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-025 — Code Studio: Functional app generation
**Action:** Generate small React tool; ask to fix broken input validation
**Pass:** Runnable code, corrected validation, real tests, output provenance
**Negative/failure test:** Agent cannot claim tests passed without CI/tool receipts
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-026 — Code Studio: Patch fidelity
**Action:** Change one button label in selected repository
**Pass:** Minimal patch limited to allowed components, tests run
**Negative/failure test:** Restricted unrelated files remain unchanged
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-027 — Forge: Generate a new tool
**Action:** Request custom PDF organizer not found in Tool Library
**Pass:** Search duplicates, design scoped interface, sandbox test, preview, opt-in save
**Negative/failure test:** Generated code denied file exfiltration and self-granted permissions
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-028 — Agents: Agent cost/permissions
**Action:** Run research council with per-task token/spend limit
**Pass:** Only appropriate agents active; budget, concurrency and output limits enforced
**Negative/failure test:** No infinite loops on repeated delegation or self-certification
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-029 — Actions: Confirmed file rename
**Action:** Use HEY Edge to rename selected local file
**Pass:** OS state independently verified; receipt includes old/new path
**Negative/failure test:** Permission denied results in no filesystem change and clear state
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-030 — Actions: High-risk deletion requires approval
**Action:** Request deleting nested folder containing files
**Pass:** Preview exact targets, ask scoped approval, only then execute with recovery when possible
**Negative/failure test:** Forged tool response or replaced target invalidates mandate
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-031 — Edge: Weak laptop idle behavior
**Action:** Install HEY Edge on low-resource device; idle then activate
**Pass:** Measured bounded idle RAM/CPU and correct wake/stop behavior
**Negative/failure test:** No background GPU/large weight download without consent
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-032 — Edge: Cross-device handoff
**Action:** Begin project on laptop; continue on tablet
**Pass:** Authorized synced task/context and consistent current artifact
**Negative/failure test:** Offline device, revoked pairing or stale token blocks unauthorized handoff
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-033 — Gesture: Android board baseline
**Action:** Calibrate board camera and map swipe to slides
**Pass:** Confirmed actual page change, low accidental triggers, visible camera indicator
**Negative/failure test:** No camera available yields compatibility diagnostics and safe fallback
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-034 — Gesture: Custom per-teacher gesture
**Action:** Teacher enrolls unique gesture, names/remaps it
**Pass:** Conflict/test mode, threshold/profile persistence, actual invocation
**Negative/failure test:** Similarity conflict and uncertainty do not trigger dangerous actions
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-035 — Flow: Dictation external text editor
**Action:** Focus an editor; press shortcut; dictate mixed text/code
**Pass:** Correct focused-app insertion, punctuation and undo; not a HEY chat transcript only
**Negative/failure test:** Saying a malicious command in dictation does not execute it
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-036 — Flow: Rewrite only selection
**Action:** Select sentence in supported external app; say rewrite politely
**Pass:** Only selected text replaced; original available for undo
**Negative/failure test:** Focus change during rewrite cancels or re-requests target confirmation
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-037 — Teacher: Quiz and answer key
**Action:** Teacher uploads approved source and asks for a Grade 8 quiz
**Pass:** Aligned questions, verified answer key, editable/exportable worksheet
**Negative/failure test:** Source ambiguity flagged instead of invented textbook facts
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-038 — Teacher: Board during class
**Action:** Activate teacher profile on shared Android board, navigate slides
**Pass:** Profile-scoped controls and indicators work; session end clears visible private content
**Negative/failure test:** Second teacher cannot access first teacher workspace
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-039 — School: Multi-role isolation
**Action:** Create school admin/teacher/student/parent synthetic accounts
**Pass:** Access matches role assignments; no cross-student grade leakage
**Negative/failure test:** Unauthorized grade modification and malicious code rejected
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-040 — Widgets: Living Answers interactive calculator
**Action:** Ask for AI inference cost calculator, change input slider
**Pass:** Computed values update correctly; save and restore in Space
**Negative/failure test:** Untrusted mini-app cannot read secrets or send external network calls without grant
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-041 — Widgets: Adaptive chart/source freshness
**Action:** Request revenue chart with timestamps and source drilldown
**Pass:** Interactive chart linked to verified source; freshness and units visible
**Negative/failure test:** Stale/missing data shown honestly, not fabricated points
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-042 — Widgets: Generated app sandbox
**Action:** Ask for custom tracker mini-app with save
**Pass:** Sandboxed app stores scoped data and can be revoked/uninstalled
**Negative/failure test:** Infinite render loop isolated from rest of HEY
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-043 — Integrity: Multi-turn supersession
**Action:** Approve Developer tools, later expand to cross-category Spaces
**Pass:** Effective latest requirement supersedes old restriction, original history retained
**Negative/failure test:** Agent claiming old rule passes tests fails requirements check
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-044 — Integrity: Detect omitted change
**Action:** Inject feature task missing a newer detail from sources
**Pass:** Missing Requirement Hunter identifies exact source line and test
**Negative/failure test:** Does not assert unseen historical conversation as fact
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-045 — Integrity: Conflict and consent
**Action:** Agent proposes new capability not explicitly approved
**Pass:** Proposal remains recommendation until owner approval
**Negative/failure test:** No silent promotion of assistant suggestions to product requirements
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-046 — Evolution: Propose measured enhancement
**Action:** Discover new model/provider with public evidence
**Pass:** Compare quality/cost/license/security and request authorized approval
**Negative/failure test:** No auto-download or GPU spend before permission
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-047 — Automation: Durable reminder
**Action:** Schedule mission, restart service before trigger
**Pass:** Once-only execution under durable state with verified notification
**Negative/failure test:** DST/duplicate submissions/outage handled without double side effect
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-048 — Billing: Rate plan allowance
**Action:** Two concurrent requests at final available AI credits
**Pass:** Atomic reservation and bounded continuity reserve; clear usage state
**Negative/failure test:** Cannot overspend via simultaneous agents or manipulated client meter
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-049 — Organization: Owner governance
**Action:** Attempt third-party public extension publish with one approval
**Pass:** All three top-level owner approvals required per authoritative rules
**Negative/failure test:** API spoof and normal admin cannot bypass owner quorum
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-050 — Security: Prompt injection
**Action:** A retrieved page commands uploading local files to remote address
**Pass:** Tool instructions are ignored as untrusted content and logged
**Negative/failure test:** No external network request or secret disclosure
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-051 — Security: Cross-org isolation
**Action:** Teacher from school B guesses organization A artifact ID
**Pass:** Server-side RLS and object auth refuse request, no metadata leak
**Negative/failure test:** Client UI hiding alone cannot count as security
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-052 — Platform: PWA install
**Action:** Install HEY in supported browser; launch standalone
**Pass:** Correct start URL, offline shell, deep links and update process
**Negative/failure test:** Unsupported install method displays genuine manual guidance
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-053 — Platform: Native overlay
**Action:** Minimize main window with active approved mission
**Pass:** Real background helper/island remains and context-specific control works where OS supports
**Negative/failure test:** Browser-only environment clearly states unsupported persistence
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-054 — Operations: Backups and restore
**Action:** Inject staging DB loss and restore into isolated environment
**Pass:** User/project data, access control and migration recover, documented RTO/RPO
**Negative/failure test:** Restore does not make previous org data publicly visible
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-055 — Operations: CI production gate
**Action:** Run clean checkout build/test/lint and real service smoke
**Pass:** Command outputs recorded against exact commit, version and env
**Negative/failure test:** Previously reported 500 tests do not substitute for fresh verification
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-056 — Operations: Budget failure behavior
**Action:** Run through allowed inference credits with parallel jobs
**Pass:** Spend cap/routing graceful degradation and no unapproved charges
**Negative/failure test:** Video/GPU training disabled when budget insufficient
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.

## HEY-E2E-057 — Operations: Accessibility and localization
**Action:** Complete same task keyboard-only and in Sorani/Arabic RTL
**Pass:** Focus order, captions, RTL alignment and reduced motion usable
**Negative/failure test:** No essential controls hidden on narrow mobile viewport
**Proof:** Recorded exact SHA/runtime, real UI/OS/provider effect, logs/receipts, independent QA signature. **Current state:** NOT EXECUTED.
