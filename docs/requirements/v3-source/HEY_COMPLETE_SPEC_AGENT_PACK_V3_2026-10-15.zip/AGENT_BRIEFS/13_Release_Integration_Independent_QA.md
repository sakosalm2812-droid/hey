# HEY SPECIALIST BRIEF — 13 Release Integration Independent QA

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** One canonical release branch, real staging URL, real provider/DB/native E2E journeys, adversarial tests, rollback, budget and authorization proof; never invent status.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Operations, Auth, Security, Platform. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R20. Deployment and operating budget — approved current constraint

Initial HEY monthly cloud operating ceiling: **$25–$50**. Proposed cost envelope: Supabase Pro $25 for one paid Postgres/Auth project; Cloudflare Workers Paid $5 for web/API; model inference $12 prepaid, no auto-recharge; domain annual reserve ~$2/month; uncommitted reserve $5. These are planning allocations, not guaranteed enforceable all-vendor bill caps or approval to purchase. Prefer Cloudflare R2 within free allowances for private object storage; managed auth/DB and lightweight API, legitimate queue/workflow for long tasks, SMTP mail free tier while eligible, GitHub CI, basic monitoring. Separate stage and production secrets/data; staging use synthetic info and a free DB project where suitable; never grant staging service role in prod. Real runtime data stores authorization/revocation, durable jobs, memory, budget holds and audited receipts; mocks/in-memory state don't qualify. Reject arbitrary “everything runs inside Workers” design for long/CPU/GPU jobs. Paid hosted inference rather than dedicated GPU initially; actual GPU training/serving requires separate approved compute. Rate limits and provider spend controls must handle concurrency and irreversible costs. Use spend/failure/latency alerts, backups plus real restore drill, incident stop/rollback. Benchmark actual users in Kurdistan and classroom networks where possible.

School pilot: isolate one approved Leaders organization with 5–10 initial teacher accounts and fictional student records, small $3 portion of initial $12 inference allowance; no assumption of unlimited teacher generation. Teacher questionnaire, IT coordination, compatibility and printed forms are not fully paid for by cloud envelope. HEY public rollout and school pilot are separate release audiences, with transparent readiness and support.

## R21. Continuous engineering execution and reality check

The real codebase must be inventoried by SHA before claims. Coordinator-reported 500/500 tests and 73/73 Fusion/Edge tests are historical code-level evidence but NOT proof of live DB, deployed Deno functions, native device, real model provider or browser end-to-end validation. Do not restart 11 specialists merely to rename tasks. Make tasks vertical: actual user journey → UI/backend/provider/db/native → auth/privacy → error/recovery → independent verification. Maintain one canonical integration/release branch; isolate parallel work in distinct worktrees; frontend has sole shared UI ownership while backend owners export contracts; integration owner resolves compatibility and QA owner independently retests. Never create one gigantic same-file merge conflict across agents.

Use status chain MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY; also distinguish external credentials/hardware blockers. An entire 47-step item is NOT “done” based on one green test. Every feature entry must link source, final requirement, real entrypoint, commits, live provider evidence, auth/security, cross-account tests, failure injection, weak-device tests and rollback. When external services unavailable, build independently testable code and state honestly what remains; neither fake a deployment nor idle all workers. Recover or replace unavailable requirement inventories only with visible provenance. Independent full-product QA covers new and returning users, permission denial/revoke, provider timeout/429, network drop, stale/missing data, multiple concurrent calls, retries/idempotency, native helper crash, corrupted state, backup restore, school-user isolation, device-specific restrictions, a11y/RTL and low-resource behavior.

## R22. Known product-version conflict decisions (prevent old agents from reverting)

- Historical fixed mode catalogs / non-customizable modes → superseded by fully customizable Spaces, cross-category tools and personalized onboarding. Preserve useful original modes as templates/behaviors.
- Old dashboards as default → superseded; signed-in landing is unified Chat/Voice unless user changes.
- Historical fixed 229 agents → legacy seed; no arbitrary system limit; lazy loaded, not displayed as apps.
- “4,210 features” → engineering inventory items, NOT number of separate HEY apps or widgets.
- Local full supermodel on 8-GB laptop → superseded by remote HEY One + compact HEY Edge / optional small local models.
- All-billing-free imperative → updated to $25–50 approved monthly envelope, but no unapproved purchases.
- Gesture control only inside chat or web window → wrong; native/Android helper as supported, teacher-presentations first-class and independent use.
- Teacher Mode as only presentation builder → wrong; teacher workflow suite plus distinct future school management platform.
- UI “structured paragraphs” alone → wrong; Living Answers includes live functional widgets, maps, artifacts and sandboxed mini-apps.
- Current 11 specialists know all older chats → false; explicit source-bound per-task briefs are mandatory.
- Repeated audits without functioning release → unacceptable; final-product build must stay active with independent in-app E2E validation.
- “No gaps because an agent said so” → prohibited: evidence must be attached and rechecked.

## R23. Acceptance journeys from customer point of view

For each scenario run a real staged cross-account/device path, record timestamp, build SHA, actual backend/provider, input, output, artifacts, cost and failure/recovery:

1. New user signs up, verifies email, signs in, recovers account, revokes session.
2. User chooses Create & Build + Teaching; all other categories still discoverable; change preferences after onboarding.
3. Create Developer Space; add Teacher quiz and VoiceOS; reorder, rename, refresh browser/second device; layout persists.
4. Ask simple fact -> concise answer; complex task -> cited sources and actionable table; missing source -> no invented citation.
5. Ask for interactive calculator -> working controls, save to Space, refresh and restore, permission revoke behavior.
6. Start Voice, interrupt speaking, toggle Chat without losing active artifact/context, deny mic and continue text.
7. Use Flow dictation into authorized external text field with punctuation; switch focus/private field -> no unwanted insertion.
8. Say “open app” -> native companion acts with scoped mandate; real process/window verified.
9. Ask rename/move file -> correct file changed, receipt linked, safe undo available; denied folder doesn't change.
10. Webcam gesture Next/Previous slides -> correct presentations state, false positive protection, disconnected camera stop.
11. Teacher creates lesson, worksheet, quiz answer key and editable presentation from supplied source, exports and reloads.
12. Live screen guidance highlights actual element; stop capture revokes sensing and indicators disappear.
13. Create image with actual licensed provider; edit only selected region; check unchanged parts.
14. Storyboard-to-video job produces actual playable video where enabled, not synthetic receipt; export and resume.
15. Create/edit spreadsheet cells with formulas; reload and export with correct formula results.
16. Cosmos stores a consensual fact, recalls correct latest version, corrects/deletes and respects privacy/organization scope.
17. Automation scheduled in Baghdad timezone survives a server restart/DST where applicable, runs once, actual effect verified.
18. Model routing: cheap->strong escalation under task quality threshold, Fusion only when justified, show spend and rationale.
19. Native device handoff on trusted devices resumes task without duplicated side effects.
20. User revokes access during mission -> calls stop and UI reports partial exact status.
21. Cross-school/private account isolation including files, tools, memory, widgets and logs.
22. Load concurrent model requests against $12 prepaid allotment, ensure reservation/limiter and graceful exhausted-state.
23. Weak laptop UI and HEY Edge idle usage meet measured performance budget.
24. Owner Console escalation requires high-security login; extension publication follows required multi-owner policy.
25. Recovery drill: backup restore, schema rollback, killed worker, poison job, expired auth, provider outage and interrupted output.
26. Accessibility: screen reader, keyboard, touch, RTL Sorani/Arabic, screen magnification, reduced motion and captions.
27. Product Integrity detects requirement contradiction across multiple simulated contexts, warns of missing final behavior, rejects fake completion.
28. Install PWA in compatible browser, standalone startup, offline shell, upgrade, deep link; unsupported install explains limitations.
29. School smartboard teacher profiles independent wake phrases, default fallback, principal health view, End-of-Class privacy cleanup.
30. Full regression: none of the above is broken by the next merged specialist branch.

## R24. No open-ended self-improvement loop

The requirement to improve every system means achieving testable capabilities, not endless speculative optimization. Feature review must propose measurable refinements and implement approved refinements; unapproved new major concepts remain proposals. Freeze acceptance criteria for a version until clear new user approval; defects and regressions still must be fixed. Source amendments and version tags are distributed automatically to assigned agents and their tests updated. Nothing called “maximum performance” without hardware/cost/workload-specific benchmarks.

---

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/20_COMPLETE_LAUNCH_ACCEPTANCE_MATRIX.md`

# Complete Release Acceptance Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Create one release gate mapping every HEY V1 capability to evidence, tests, owner and status.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Feature inventory, owner, dependency, platform, discovery path, happy-path test, failure test, privacy/security test, performance test, tutorial, docs, public claim.
- Release blockers and waivers.

# 2. User experience contract
- Release Commander sees one truth table instead of verbal 'done'.
- PASS requires evidence; UNKNOWN is not PASS.
- Waivers are explicit, time-limited and user-impact assessed.

# 3. Architecture / runtime contract
- Generate matrix from capability registry + test results where possible.
- Link CI/E2E evidence, screenshots only as supplemental.
- Critical capabilities require fresh production smoke test.

# 4. Required state model
- not-started
- implemented-unverified
- testing
- pass
- fail
- waived
- disabled

# 5. Failure and recovery catalog
- Test unavailable → remains unverified.
- Flaky test → cannot count as reliable pass.
- Production differs from staging → production smoke blocks launch.

# 6. Security / privacy / trust requirements
- Security blockers cannot be waived casually.
- Data-loss/authz failures are launch blockers.

# 7. Data model / persistence
- release_gates
- capability_status
- test_evidence
- waivers
- release_candidates

# 8. Events / telemetry contracts
- release.gate.updated
- release.blocked
- waiver.created
- candidate.promoted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh account E2E.
- Returning account.
- Free/paid.
- PWA.
- Native helper.
- Provider failover.
- Database backup/restore.
- Rollback.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/19_COMPLETE_PUBLIC_CLAIMS_TRUTH_MATRIX.md`

# Complete Public Claims & Truth Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Ensure every website/social/pricing claim corresponds to a verified production capability.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Feature claims, platform claims, pricing, privacy, performance, 'works in background', device control, generation, memory, integrations.
- Claim evidence and owner.

# 2. User experience contract
- Marketing may be bold but cannot imply unsupported access or reliability.
- Platform limitations are clear where material.
- Demo footage must match real achievable product behavior.

# 3. Architecture / runtime contract
- Claims registry maps public sentence → capability ID → supported platforms → test evidence → last verified release.
- Release process revalidates high-risk claims.

# 4. Required state model
- verified
- verified-with-limitations
- temporarily-disabled
- unverified
- retired

# 5. Failure and recovery catalog
- Capability disabled → website copy/feature flag update.
- Test fails → claim blocked.
- Platform changed → matrix update.

# 6. Security / privacy / trust requirements
- Privacy/security claims require security review.
- No deceptive pricing/limits.

# 7. Data model / persistence
- public_claims
- claim_evidence
- claim_platforms
- claim_reviews

# 8. Events / telemetry contracts
- claim.created
- claim.verified
- claim.blocked
- claim.retired

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Background-island claim verified native.
- PWA install claim verified.
- Computer-control claim per platform.
- Pricing limits match entitlements.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/15_COMPLETE_FAILURE_RECOVERY_CATALOG.md`

# Complete Failure, Recovery & Graceful-Degradation Catalog
## HEY V1 — Full-depth implementation specification

**Mission:** Ensure HEY fails visibly, safely and recoverably instead of becoming stuck or pretending success.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Network, auth, provider, database, filesystem, device, permission, native helper, browser, generation, memory, sync, billing, migration, notification and UI failures.
- Retry, fallback, checkpoint, undo, partial success.

# 2. User experience contract
- Error message says what failed, what remains safe, what HEY tried, and best next action.
- Partial success is not reported as complete.
- User work/drafts preserved wherever possible.
- Advanced detail available without dumping stack traces at normal users.

# 3. Architecture / runtime contract
- Central error taxonomy with retryability, severity, user-safe message, diagnostic code and owner.
- Recovery coordinator avoids retry storms.
- Checkpoints for long-running work.
- Action receipts include failures and verification.

# 4. Required state model
- transient
- persistent
- user-action-required
- permission-blocked
- degraded
- partial-success
- recovering
- unrecoverable

# 5. Failure and recovery catalog
- Network drop
- 401/403
- 429
- 5xx
- disk full
- database unavailable
- provider timeout
- helper crash
- sync conflict
- corrupt artifact
- billing webhook delay
- migration failure

# 6. Security / privacy / trust requirements
- Fail closed for security failures.
- Never expose secrets in error detail.
- No destructive auto-recovery without snapshot/approval.

# 7. Data model / persistence
- error_events
- recovery_attempts
- checkpoints
- incident_links
- action_receipts

# 8. Events / telemetry contracts
- error.raised
- recovery.started
- recovery.succeeded
- recovery.failed
- partial.success
- circuit.breaker

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Every major subsystem has injected failure tests.
- Retry caps.
- Offline recovery.
- Crash restart.
- Partial result preservation.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `05_EXECUTION/01_REPOSITORY_IMPLEMENTATION_ORDER.md`

# Repository Implementation Order

The coding agent starts from the current HEY codebase, not from a greenfield rewrite assumption.

1. Inventory routes/components/APIs/edge functions/database/migrations/RLS/auth/providers/agents/tools/workflows/native commands/service worker/config/tests.
2. Search contextually for TODO/FIXME/HACK/TEMP/MOCK/STUB/PLACEHOLDER/coming soon/dummy/localhost/dead flags/duplicate implementations.
3. Build spec↔code map.
4. Fix shared contracts/data/events/auth/security/permissions/rate limits first.
5. Provider/decision/cognitive runtime.
6. Agent registry/verifier/recovery.
7. Cosmos/projects/Pinpoint/artifacts.
8. Chat/Voice/Live/screen-camera guidance/Island/background.
9. Studios/generation.
10. computer/browser/files/device/platform adapters.
11. automations/Forge/capability synthesis/Evolution Engine.
12. plans/billing/API/Education/owner console.
13. discoverability/tutorial/accessibility/localization.
14. whole-system failure/security/performance/production gates.

Every subsystem is audited, improved/replaced, migrated, tested, independently verified and only then marked production-ready.


---



### SOURCE FILE: `05_EXECUTION/02_FINAL_WHOLE_PRODUCT_GATE.md`

# Final Whole-Product Gate

Before HEY is called finished, a fresh independent verifier runs realistic journeys with no developer cache, plus returning-user projects/memory/artifacts/integrations.

Required stress cases include provider 429/500, selected model disappearance, network drop, offline, expired auth, denied/revoked permission, database outage, duplicate submission, simultaneous requests, tab/window close, native helper restart, corrupted local state, allowance boundary, migration rollback, backup restore, malicious page prompt injection, generated-capability adversarial test, third-party package rejection, cross-project privacy, public-display privacy, mobile/tablet/desktop, RTL/reduced motion and weak hardware.

The final question is:

> If HEY went live to thousands of users right now, what could fail, leak data, waste money, confuse users, falsely claim success, corrupt work, become unrecoverable or make the product feel unfinished?

Every discovered issue is fixed or explicitly accepted/documented by the owners before release.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
