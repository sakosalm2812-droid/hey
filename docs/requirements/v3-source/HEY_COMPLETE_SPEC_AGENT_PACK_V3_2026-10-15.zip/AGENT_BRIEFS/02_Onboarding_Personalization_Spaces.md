# HEY SPECIALIST BRIEF — 02 Onboarding Personalization Spaces

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Implement Why do you want to use HEY multi-select; persist across sessions; user can add cross-category tools; Spaces create/rename/duplicate/archive, pin/reorder/resize, undo and authorized contextual memory.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Auth, Identity, Onboarding, Spaces, Tool Library. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R02. Global UX, navigation, brand, themes and motion

**Default after authentication is the Chat/Voice Conversation Surface.** The user's recent conversation, project, artifact and current mission are restored when safe; user-configured startup override wins. Persistent prominent destinations Home (conversational entry + contextual personal view), Tools, Spaces, Activity, Settings; dedicated Create/Projects/Cosmos/Live routes and advanced inspectors may be reachable from navigation, search and quick actions without cluttering the default. “Home” must not become a mandatory generic dashboard before HEY can be used.

Desktop: compact/collapsible/resizable sidebar, command palette, global shortcuts, split/overlay artifact workspaces, window management. Tablet: adaptive rails/panels, rotation, touch. Mobile: bottom nav + context drawers, voice-first affordances, safe-area, virtual keyboard and offline views. Large displays/smartboards: readable distance type, privacy-aware public display, multi-user handoff where legitimate. Keyboard navigation, screen readers, focus management, touch targets, RTL (Kurdish/Arabic), localization, reduced-motion and high contrast must be tested. Theme direction is premium near-black graphite glass, real depth, tactile interactive states, muted nature accents; avoid cyan hologram clichés and performance-heavy effects on weak hardware. Adjustable themes/accents, visual density, typography and motion; user can choose a brighter variant without losing contrast.

Every major feature requires discoverable, contextual, animated or stepwise tutorial, replayable/skippable with a text fallback. Tutorial must use real product UI state and not demo a nonexistent action. Empty/error/offline/pending/no-permission/expired-token/recovery states are designed, not generic spinners. Startup, install/updates and PWA vs native must be clearly differentiated. Dynamic Island is genuinely native/persistent where supported: survives main app minimize/close while authorized helper remains active, exposes task-relevant controls (Voice call, media, jobs, timers, approvals, errors, handoffs); never masquerade a React card as a system-wide overlay.

## R03. First-run onboarding and adaptive preference setup

First major question **“Why do you want to use HEY?”** with multi-select: `AI Assistant`, `AI Models`, `Control & Automation`, `Create & Build`, `Teaching & Learning`, `Life & Work`, `Custom`, `Skip`. Each choice shows plain-language examples, not unexplained model/provider acronyms. Multiple options allowed; the selection initializes recommendations, pins, suggested Spaces and the right onboarding tutorial. No choice permanently hides other tools. Custom accepts user's own goal in natural language; Skip yields excellent default Chat/Voice access. Permissions for mic/camera/screen/devices are asked contextually rather than all at once. Users can later change role interests, tool pins, language, model preferences, voice, theme and startup location; all persist across permitted devices. School organization membership is a separate access grant and never inferred from selecting Teaching.

Acceptance: first-run select Developer + Teacher, create default mixed Space, launch tools in both categories, restart and verify all preferences retained; account B cannot read A's onboarding state; skip works; denied mic still allows chat.

## R04. Modes, personalities, adaptive answer depth

Use original full mode/personality source. Recognize Quick, Standard, Deep Dive, Mentor, Strategist, Research, Creative, Emotional Support, Crisis, Teacher, Debate, Execution, custom combinations and earlier user-favored Hey Brother/Explorer style as product options where appropriately defined. Modes guide voice/style/tool/routing, never strip baseline capabilities or alter permission policy. Auto adapts to complexity, user preferences and task. Voice default concise natural with expandable full transcript/artifacts; Chat can be detailed, structured and citations-backed. Brand personality may use a calm deep British male voice option; voice library, legitimate user-authorized custom voice and wake-word preferences. Avoid implying medically or legally regulated professional advice is certified.

## R05. Tools Library + universal discovery + command palette

One canonical capability registry supports installed/available/experimental/platform-constrained entries, per-person/account/organization permissions, costs, dependency health, entitlements and discoverability. Search semantic natural-language requests e.g. “write by speaking everywhere”, “control this slide with my hand”, “edit slide three only”, “run an agent over my code”, “teach chemistry using a quiz” and return actual launchable tools and a truthful support explanation. Each tool provides name/category/description, examples, launch/stop, configure, permissions, status, platform matrix, model/provider dependencies, usage/allowance display, errors/help/version. Provide Favorites, Recently Used, popular/recommended, pin/reorder/add shortcuts, context-aware suggestion and advanced mode. Do not list internal agents as ordinary apps. Tool availability must be evaluated server/runtime side, not only with hidden UI flags.

Tool launch lifecycle: DISCOVERED → PERMISSION_REQUIRED/READY → STARTING → RUNNING → PAUSED/DEGRADED/FAILED → STOPPED, with durable mission linkage when needed. Missing plugin or disconnected provider launches a concrete connection/permissions flow, not fake success.

## R06. Custom Spaces — the user's own operating environment

A Space is a persistently named user- or organization-scoped environment containing selected tools, widgets, project contexts, layouts, shortcuts, saved Living Answers, models, language/theme tweaks and filtered activity. Provide create/rename/duplicate/archive/delete, import/export if safe, default templates, blank canvas, natural-language Space setup with preview, pinned catalog selection, drag/reorder/resize/snap/stack/minimize/dock, multiple view layouts, task/project tabs, undo/redo/snapshots. A Developer may add Teacher tools; a Teacher may add Software Studio and Model Lab. Spaces do not create authorization: access depends on the underlying user/org permission for every item. Organization-managed spaces inherit policy but cannot silently overwrite personal Spaces. Context switch cannot lose draft or active tasks; preserve safe mission continuity. User controls startup Space and workspace defaults. Load only active widgets and refresh them within resource budgets.

Workspace widgets: clock/date/timezone, weather, calendar, task list, routines, notes, project status, music/media, timer, notifications, news, quote, prayer/Quran/Hadith if enabled, HEY/S&A stats where authorized, device battery/health, research, terminal, code, audio, image, video, saved art, agent monitors. Sensitivity is location/time dependent: user controls location and religious widgets; public-display mode conceals private content. Weather/prayer info has source and freshness. Broken widget cannot crash full workspace; stale data explicitly labeled.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/08_COMPLETE_FIRST_RUN_ACCOUNT_LIFECYCLE.md`

# Complete First-Run, Sign-In & Account Lifecycle
## HEY V1 — Full-depth implementation specification

**Mission:** Make entry into HEY immediate, premium and safe from account creation through deletion.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Sign up, verification, sign in, recovery, first run, onboarding, returning user, sign out, account switch, deletion/export.
- Startup destination and install prompts.

# 2. User experience contract
- Successful sign-in defaults to Chat/Voice Conversation Surface.
- Onboarding requests permissions just-in-time, not all at once.
- First real task teaches HEY by doing.
- Returning users skip onboarding and resume safely.
- PWA/native install suggestion occurs after demonstrated value.

# 3. Architecture / runtime contract
- Auth session managed server-side/securely.
- Startup resolver checks onboarding state, last safe conversation, active mission, explicit preference.
- Account deletion/export is durable and auditable.
- Plan/entitlement state cannot be forged client-side.

# 4. Required state model
- anonymous
- signing-up
- verification-pending
- onboarding
- active
- session-expired
- locked
- deletion-pending
- deleted

# 5. Failure and recovery catalog
- Expired session → reauth preserving local draft.
- Verification email failure → resend.
- Account deletion partial failure → retry/report.
- Entitlement mismatch → server truth wins.

# 6. Security / privacy / trust requirements
- Secure tokens, no secrets in local storage where avoidable.
- Rate-limit recovery/login abuse.
- Reauthentication for sensitive account actions.

# 7. Data model / persistence
- users
- profiles
- sessions
- onboarding_progress
- account_exports
- deletion_jobs
- startup_preferences

# 8. Events / telemetry contracts
- auth.signed_in
- onboarding.step
- startup.route
- session.expired
- account.exported
- account.deleted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in → Conversation Surface.
- Returning sign-in → safe resume.
- Session expiry preserves draft.
- Delete/export test.
- PWA install prompt timing test.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`

# Complete Navigation & Information Architecture
## HEY V1 — Full-depth implementation specification

**Mission:** Make every important HEY capability discoverable without exposing internal complexity.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Conversation Surface (Chat/Voice) is the default signed-in destination.
- Primary global navigation, contextual navigation, Create hierarchy, Explore More, + Add, Universal Search, Command Palette, recent/favorites, mobile bottom nav.
- Information scent, labels, hierarchy, advanced-mode disclosure, role/device/mode adaptations.
- Deep-link routing and return-to-previous-context behavior.

# 2. User experience contract
- Primary normal-user nav: Chat/Voice entry, Live, Projects, Create, Cosmos, Tasks/Missions, Widgets/Workspace, Search, Notifications, Settings.
- Important Create actions visible before Explore More: Image, Video, Presentation, Document, Audio.
- `+ Add` lets users pin additional capabilities without seeing raw agents.
- Advanced tools are discoverable through Advanced Mode, Search, Forge, Developer—not cluttering normal nav.
- Navigation never loses active project/conversation/artifact state.
- Breadcrumbs appear only where hierarchy is genuinely useful.
- Mobile uses bottom nav + More; desktop uses collapsible rail; tablet uses adaptive split shell.

# 3. Architecture / runtime contract
- Central route registry with capability metadata, permissions, feature flags, platform support and discovery rank.
- Navigation state is distinct from task/artifact state.
- Deep links restore intended resource with permission checks.
- Startup route resolver respects newest rule: default Conversation Surface, then explicit user override, then safe resume.
- Explore More reads from capability registry but filters by audience/platform/entitlements.

# 4. Required state model
- anonymous
- authenticating
- signed-in-first-run
- signed-in-returning
- conversation-active
- immersive-live
- embedded-studio
- full-studio
- modal
- offline
- unsupported-platform
- advanced-mode

# 5. Failure and recovery catalog
- Unknown/deprecated route → safe redirect with explanation.
- Feature flag off → remove dead nav and provide fallback if linked.
- Unauthorized deep link → permission/entitlement explanation.
- Stale project/artifact link → recovery and search, not blank page.
- Navigation state corruption → restore last valid route.

# 6. Security / privacy / trust requirements
- Never use client-only nav hiding as authorization.
- Sensitive routes require server/runtime enforcement.
- Do not leak advanced/debug routes to normal users.
- External URLs opened safely and clearly distinguished.

# 7. Data model / persistence
- navigation_preferences
- pinned_capabilities
- recent_capabilities
- startup_destination
- feature_flags
- entitlements
- capability_manifest
- workspace_route_state

# 8. Events / telemetry contracts
- nav.opened
- nav.pinned
- nav.unpinned
- search.opened
- capability.discovered
- capability.launched
- route.failed
- startup.resolved

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in lands Chat/Voice.
- Returning user resumes safe conversation state.
- Normal user finds Image/Video/Live/Cosmos without Explore More.
- + Add persists pinned tool.
- Deep link to project artifact restores context.
- Advanced Mode reveals developer areas without changing normal nav.

# 12. Non-goals / prohibited shortcuts
- Do not put all 229 agents in navigation.
- Do not make Explore More the only discovery path.
- Do not route sign-in to generic dashboard by default.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/02_COMPLETE_HOME_DASHBOARD_INTELLIGENCE.md`

# Complete Home / Workspace Intelligence
## HEY V1 — Full-depth implementation specification

**Mission:** Make Home useful as a living workspace without making it the forced landing page.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Widget composition, contextual recommendations, active work, tasks/calendar, projects, weather, prayer where enabled, usage/system state, routines.
- User-controlled layouts and adaptive suggestions.
- Multiple workspace layouts and per-mode layouts.

# 2. User experience contract
- Home is available from navigation but is not default post-sign-in.
- Default shows one focal item plus 2–4 supporting modules, not a 12-card admin grid.
- Active mission/current project gets highest priority.
- `+ Add Widget` is obvious.
- HEY may suggest layout changes, but persistent changes require user acceptance unless explicitly enabled.
- Widgets can move/resize/stack/minimize/maximize.

# 3. Architecture / runtime contract
- Workspace state persisted per user/device/mode.
- Widget registry declares size variants, refresh policy, permissions, privacy and offline behavior.
- Contextual ranking uses real signals but does not reorder constantly.
- Workspace mutations are undoable and snapshot important layout changes.

# 4. Required state model
- first-run
- normal
- active-mission
- focus-mode
- morning-mode
- offline
- weak-hardware
- empty-calendar
- no-projects
- customized

# 5. Failure and recovery catalog
- Widget data source failure → local error tile without collapsing workspace.
- Slow widget → skeleton and timeout.
- Layout corruption → restore last good snapshot.
- Missing capability after update → placeholder with remove/replace choice.

# 6. Security / privacy / trust requirements
- Private widgets must respect project/user privacy.
- Sensitive data is hidden on TV/projector/public-display modes.
- Widgets cannot silently escalate permissions.

# 7. Data model / persistence
- workspace_layouts
- widget_instances
- widget_preferences
- mode_layouts
- layout_snapshots
- widget_registry

# 8. Events / telemetry contracts
- workspace.opened
- widget.added
- widget.moved
- widget.resized
- widget.failed
- layout.restored
- layout.suggestion.accepted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh user sees calm default.
- Add widget and restart → persists.
- Switch Focus Mode → correct layout.
- Weak laptop uses lightweight effects.
- Broken widget does not break Home.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/05_COMPLETE_MODES_SYSTEM.md`

# Complete HEY Modes System
## HEY V1 — Full-depth implementation specification

**Mission:** Make modes coherent environment presets rather than cosmetic labels.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Study, Creator, Coding, Research, Business, Focus, Meeting, Presentation, Travel, Morning, Late Night, Accessibility, Private, Offline, Execution.
- Per-mode workspace, notifications, agents, provider policy, voice/personality, gestures, privacy.

# 2. User experience contract
- Mode switch visibly explains what changes.
- Same HEY identity remains; modes tune behavior.
- Mode can be temporary, scheduled, context-triggered or manually selected.
- User can create/customize mode and restore defaults.

# 3. Architecture / runtime contract
- Mode manifest with overrides and inheritance from global settings.
- Mode resolver prevents contradictory settings.
- Transition is atomic: workspace + policy + notifications + routing update coherently.
- Private/Offline modes enforce hard privacy/routing rules, not merely theme changes.

# 4. Required state model
- inactive
- activating
- active
- temporarily-overridden
- scheduled
- deactivating
- conflict

# 5. Failure and recovery catalog
- Mode config invalid → fall back to safe global defaults.
- Provider unavailable → mode degrades visibly.
- Private Mode cloud conflict → block cloud action.

# 6. Security / privacy / trust requirements
- Private and Offline modes have hard enforcement.
- Mode cannot grant permissions not already authorized.
- Meeting mode must show sensing/recording state.

# 7. Data model / persistence
- modes
- mode_overrides
- mode_schedules
- mode_history
- mode_layouts

# 8. Events / telemetry contracts
- mode.activated
- mode.deactivated
- mode.override
- mode.conflict
- mode.schedule.triggered

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Study mode changes workspace/notifications.
- Private Mode prevents long-term memory write as configured.
- Offline Mode prevents cloud routing.
- Mode exit restores previous state.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`

# Complete Widget Platform
## HEY V1 — Full-depth implementation specification

**Mission:** Turn widgets into a coherent internal app surface with safe extensibility.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Built-in widgets, app/service widgets, custom widgets, Forge-generated widgets, size variants, interaction contracts, refresh, privacy.
- Widget library, customization, drag/drop, stacking, dock, fullscreen.

# 2. User experience contract
- Every widget has compact/standard/expanded behavior when meaningful.
- Widget has clear title, primary information and contextual actions.
- Normal users see product concepts, not provider/internal IDs.
- Widgets can be embedded in Chat/Voice/Workspace where relevant.
- One widget never hijacks the page.

# 3. Architecture / runtime contract
- Widget manifest: id/version/title/category/sizes/data sources/permissions/actions/offline/cache/privacy/render contract.
- Sandbox external/custom widgets where possible.
- Shared lifecycle: mount, load, ready, stale, degraded, error, suspended, unmount.
- Background refresh is budgeted and pauseable.

# 4. Required state model
- loading
- ready
- stale
- refreshing
- degraded
- permission-required
- offline
- error
- suspended
- hidden

# 5. Failure and recovery catalog
- API failure → stale cached state + retry.
- Permission revoked → permission-required state.
- Malformed custom widget → sandbox crash boundary.
- Refresh loop → circuit breaker.

# 6. Security / privacy / trust requirements
- Least privilege per widget.
- No raw secrets in widget code.
- Sensitive widgets can be excluded from screenshots/public modes.
- Third-party content cannot issue HEY commands as authority.

# 7. Data model / persistence
- widget_manifests
- widget_instances
- widget_cache
- widget_permissions
- widget_versions
- widget_health

# 8. Events / telemetry contracts
- widget.loaded
- widget.action
- widget.refresh
- widget.degraded
- widget.crash
- widget.permission.requested

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Add/remove/reorder survives restart.
- Widget error isolated.
- Offline cached widget shows freshness.
- Custom widget permission revoke works.
- RTL and mobile variants work.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
