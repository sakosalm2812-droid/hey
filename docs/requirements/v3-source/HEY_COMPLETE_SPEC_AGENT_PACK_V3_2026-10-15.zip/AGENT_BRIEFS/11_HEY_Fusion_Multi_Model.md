# HEY SPECIALIST BRIEF — 11 HEY Fusion Multi Model

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Bounded model council with cheap/strong, parallel, critic/verifier, evidence synthesis, rigorous Edge Trust Kernel scopes, latency/cost gates and fallback; recover Edge authorization mismatch.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Fusion, Brain, Agents. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R01. Global product definition and experience

HEY is one AI Life Operating System and personal intelligence environment: assistant, operating layer, second brain, research and creative system, planning and business companion, developer studio, teacher experience, device bridge and extensible intelligent platform. Users ask for outcomes, not which of hundreds of hidden agents to call. The same Brain, Cosmos, security/trust, mission, tool and artifact infrastructure serves every mode. Never implement duplicate teacher/developer/voice-specific brains as shortcuts. Expose expert controls only if wanted. Subsystems must communicate through versioned typed contracts, capability manifests and data/event schema migrations.

Primary promise: user expresses intention by text/voice/screen/selection/camera; HEY selects tools/agents/models/devices, requests authorization when necessary, executes, verifies actual state and reports what really happened. A response must never claim an external file was edited, a lesson exported, a message sent, or a device action completed without a real success receipt and independent target-state check where feasible. Preserve undo, version history, progress, pause, resume, cancellation and diagnostics.

## R16. Personal memory / Cosmos, research and situation

Cosmos uses event timeline + structured profile/project/fact graph + embeddings/search index as needed. Facts include source, confidence, timestamps, subject, consent scope, owner and supersession. Do not “save every single piece of info” indiscriminately; support user-selectable privacy scopes, private/no-memory modes, memory inbox and explicit deletion/corrections. Query current relevant memory without dumping all context into every prompt; retrieve evidence; explain when data is stale. Context compiler uses consented real-time situation/time/location/device/current document, not covert data harvesting. Cross-org/private data must never leak to shared school project. Universal search uses local docs/connectors/web with freshness, citations and injection defense; distinguish search results from instructions. Project DNA and Pinpoint Precision enforce consistent branding/approved assets and surgical edits across outputs.

## R17. Agents, Intelligence Council, Forge, Evolution, automations and proactivity

Model and agents are separate axes. A 229-specialist historical catalog is neither an engine limit nor 229 always-running expensive models. Agent registry supports families → specialists → temporary specialists, lazy retrieval, typed contracts, scope, permissions, health/cost/timeout/retry/evaluation/retirement. Evidence Board and council select only helpful participants (Architect, Builder, Verifier, Contrarian, Flaw Hunter, Opportunity Hunter, Missing-Requirement Hunter, UX/Business/Teacher etc.); preserve minority evidence and stop debate when marginal gain is low. Deterministic policies, math, schedulers, validators and classifiers should not waste large-model tokens. Forge safely synthesizes tools/workflows/agents/actions if existing tools do not suffice, with source/dependency analysis, sandbox/dry run, Risk Twin + Solution Twin, tests, preview, opt-in save, versioning and revocation. Evolution observes useful advancements and makes evidence-backed proposals; ordinary owners approve new internal product evolution, critical security emergency procedure may permit fast fixes with transparent rollback and notifications. Never let an AI self-approve privileged change.

Automations are durable event/time schedules, with timezone/DST, idempotency, atomic outbox, retry with backoff, poison queue, pause/resume/recovery/revoke, visible next-run and last-run receipts. Morning/Focus/Review modes and proactive nudges use consent and configurable quiet hours; no spam or repetitive suggestions. Real scheduled work must outlive browser tab closure where legitimate and report unavoidable external blocks.

## R21. Continuous engineering execution and reality check

The real codebase must be inventoried by SHA before claims. Coordinator-reported 500/500 tests and 73/73 Fusion/Edge tests are historical code-level evidence but NOT proof of live DB, deployed Deno functions, native device, real model provider or browser end-to-end validation. Do not restart 11 specialists merely to rename tasks. Make tasks vertical: actual user journey → UI/backend/provider/db/native → auth/privacy → error/recovery → independent verification. Maintain one canonical integration/release branch; isolate parallel work in distinct worktrees; frontend has sole shared UI ownership while backend owners export contracts; integration owner resolves compatibility and QA owner independently retests. Never create one gigantic same-file merge conflict across agents.

Use status chain MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY; also distinguish external credentials/hardware blockers. An entire 47-step item is NOT “done” based on one green test. Every feature entry must link source, final requirement, real entrypoint, commits, live provider evidence, auth/security, cross-account tests, failure injection, weak-device tests and rollback. When external services unavailable, build independently testable code and state honestly what remains; neither fake a deployment nor idle all workers. Recover or replace unavailable requirement inventories only with visible provenance. Independent full-product QA covers new and returning users, permission denial/revoke, provider timeout/429, network drop, stale/missing data, multiple concurrent calls, retries/idempotency, native helper crash, corrupted state, backup restore, school-user isolation, device-specific restrictions, a11y/RTL and low-resource behavior.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/14_COMPLETE_PROVIDER_FALLBACK_ROUTING_MATRIX.md`

# Complete Provider, Model & Fallback Routing
## HEY V1 — Full-depth implementation specification

**Mission:** Select the best real provider/tool path by quality, latency, cost, privacy, modality, health and user policy.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- LLM, image, video, audio, speech, embedding, OCR/vision, local models, specialized tools.
- Auto routing, manual advanced override, fallback, budgets, privacy constraints, health.

# 2. User experience contract
- Normal users see HEY, not provider complexity.
- Advanced users can inspect why a route was selected.
- Manual provider pinning gives clear failure/fallback policy.
- Local-only project never routes cloud.

# 3. Architecture / runtime contract
- Provider adapter contract: capabilities, auth, request, streaming, cancellation, usage, errors, health, retry semantics.
- Router scores quality/latency/cost/privacy/health and requirement constraints.
- Circuit breakers remove unhealthy providers temporarily.
- Fallback does not silently change a materially important capability without notice.

# 4. Required state model
- healthy
- degraded
- rate-limited
- auth-failed
- unavailable
- circuit-open
- recovering

# 5. Failure and recovery catalog
- 429 → backoff/fallback.
- Auth failure → disable provider and alert admin/user where relevant.
- Timeout → cancel and fallback if safe.
- Partial generation → preserve result and retry missing part.

# 6. Security / privacy / trust requirements
- Keys server-side/native secure storage.
- No cross-project data leakage.
- Provider privacy policies represented in routing constraints.

# 7. Data model / persistence
- providers
- provider_models
- provider_health
- provider_routes
- provider_usage
- provider_budgets
- routing_policies

# 8. Events / telemetry contracts
- provider.selected
- provider.failed
- fallback.started
- route.explained
- budget.blocked
- circuit.opened

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Primary failure fallback.
- Local-only blocks cloud.
- Budget threshold.
- Manual pin.
- Provider recovery.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `02_INTELLIGENCE_EVOLUTION/01_COGNITIVE_FABRIC_AND_INTELLIGENCE_COUNCIL.md`

# Cognitive Fabric & Intelligence Council

HEY does not treat one LLM response as the definition of intelligence. It composes the best topology for the task: one fast model, deterministic engine, cheap→strong cascade, planner/executor/verifier, parallel experts, critic/reviser, tournament, simulation, or a full **Intelligence Council**.

## Meeting-room architecture
For difficult decisions, relevant specialists enter one shared deliberation room. They see the same Evidence Board containing facts, primary sources, constraints, assumptions, calculations, proposals, objections and unresolved questions. They can challenge one another, revise proposals and introduce ideas missed by the original prompt.

Consensus is **evidence-weighted**, not vote-counted. A strong minority objection cannot be erased merely because many agents agree. A Dissent Guardian preserves material disagreement. A Contrarian and Flaw Hunter deliberately attack the emerging consensus. A Deliberation Budgeter stops extra rounds once marginal improvement no longer justifies latency/cost.

## Example topologies
- Simple question: one fast low-cost model.
- Complex factual answer: researcher + source verifier + synthesis + fact checker.
- Coding: architect + implementers + test + security + reviewer + independent verifier.
- Company strategy: product, market, finance, technology, operations, customer, risk, contrarian, opportunity, long-term and synthesis specialists in debate rounds.
- High-assurance security: multiple independent threat models + exploit simulation + mitigation design + verifier.

## Required components
Expert Selector; Council Chair; Evidence Board; Dissent Guardian; Contrarian; Flaw Hunter; Assumption Breaker; Missing-Requirement Hunter; Opportunity Hunter; Second-Order Effects Agent; Consensus Synthesizer; Independent Verifier; Deliberation Budgeter; provenance/cost/latency tracing.

## Goal
Use orchestration, tools, memory, retrieval, specialization, verification and parallelism to outperform the underlying individual model whenever these mechanisms create a real task-level advantage. Measure the result rather than claiming universal superiority.


---



### SOURCE FILE: `02_INTELLIGENCE_EVOLUTION/02_DECISION_FABRIC_BEYOND_TOKENS.md`

# Decision Fabric — Intelligence Beyond Token Generation

Tokens are only one mechanism used by generative language models. HEY must avoid spending generative-model tokens on work that can be solved faster or more reliably by other mechanisms.

## HEY decision stack
1. Deterministic code/rules/state machines for exact policy and workflow transitions.
2. Caches and memoized validated results.
3. Traditional algorithms for parsing, diffing, scheduling, hashing, graphs, compression, ranking and math.
4. Embeddings/vector retrieval for similarity and memory/search retrieval.
5. Rerankers/classifiers for relevance, spam, risk, intent and candidate ordering.
6. Typed decision models for bounded choices/scores/probabilities.
7. Small/local models for narrow uncertain tasks.
8. Strong generative models for open-ended reasoning/generation.
9. Intelligence Council for high-value/high-uncertainty tasks.

Jev-class systems are useful inspiration: a typed decision model can return probabilities over allowed decisions rather than generating prose token-by-token. HEY should support such engines through adapters for routing, ranking, policy, risk, approvals, relevance and other bounded decisions. They do not replace generative models; they remove unnecessary generative work.

## Speed techniques HEY should use where supported
KV/prefix caching, speculative decoding, batching, parallel tool/model execution, quantization for local models, sparse/MoE inference where provider/runtime supports it, streaming, prefetching, request coalescing, compiled prompts/contracts, context retrieval instead of giant prompts, deterministic fast paths, local heuristics, concurrency controls and latency-aware provider routing.

## Invention mandate
HEY may build its own **MicroDecision Fabric**: task-specific calibrated classifiers and deterministic policies trained/evaluated on HEY's own labelled outcomes. Uncertain cases escalate to stronger intelligence. Every decision engine is calibrated and benchmarked per task.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
