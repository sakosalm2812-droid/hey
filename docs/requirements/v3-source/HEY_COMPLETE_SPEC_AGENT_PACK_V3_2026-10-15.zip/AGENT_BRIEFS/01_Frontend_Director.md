# HEY SPECIALIST BRIEF — 01 Frontend Director

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Own the shared premium visual system, Chat/Voice default shell, navigation, conversation-studio coexistence, responsive/RTL/a11y, Living Answers widget host. Never claim frontend mock is a working feature; coordinate backend contract owners.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Conversation, Spaces, Widgets, Platform, Operations. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R02. Global UX, navigation, brand, themes and motion

**Default after authentication is the Chat/Voice Conversation Surface.** The user's recent conversation, project, artifact and current mission are restored when safe; user-configured startup override wins. Persistent prominent destinations Home (conversational entry + contextual personal view), Tools, Spaces, Activity, Settings; dedicated Create/Projects/Cosmos/Live routes and advanced inspectors may be reachable from navigation, search and quick actions without cluttering the default. “Home” must not become a mandatory generic dashboard before HEY can be used.

Desktop: compact/collapsible/resizable sidebar, command palette, global shortcuts, split/overlay artifact workspaces, window management. Tablet: adaptive rails/panels, rotation, touch. Mobile: bottom nav + context drawers, voice-first affordances, safe-area, virtual keyboard and offline views. Large displays/smartboards: readable distance type, privacy-aware public display, multi-user handoff where legitimate. Keyboard navigation, screen readers, focus management, touch targets, RTL (Kurdish/Arabic), localization, reduced-motion and high contrast must be tested. Theme direction is premium near-black graphite glass, real depth, tactile interactive states, muted nature accents; avoid cyan hologram clichés and performance-heavy effects on weak hardware. Adjustable themes/accents, visual density, typography and motion; user can choose a brighter variant without losing contrast.

Every major feature requires discoverable, contextual, animated or stepwise tutorial, replayable/skippable with a text fallback. Tutorial must use real product UI state and not demo a nonexistent action. Empty/error/offline/pending/no-permission/expired-token/recovery states are designed, not generic spinners. Startup, install/updates and PWA vs native must be clearly differentiated. Dynamic Island is genuinely native/persistent where supported: survives main app minimize/close while authorized helper remains active, exposes task-relevant controls (Voice call, media, jobs, timers, approvals, errors, handoffs); never masquerade a React card as a system-wide overlay.

## R03. First-run onboarding and adaptive preference setup

First major question **“Why do you want to use HEY?”** with multi-select: `AI Assistant`, `AI Models`, `Control & Automation`, `Create & Build`, `Teaching & Learning`, `Life & Work`, `Custom`, `Skip`. Each choice shows plain-language examples, not unexplained model/provider acronyms. Multiple options allowed; the selection initializes recommendations, pins, suggested Spaces and the right onboarding tutorial. No choice permanently hides other tools. Custom accepts user's own goal in natural language; Skip yields excellent default Chat/Voice access. Permissions for mic/camera/screen/devices are asked contextually rather than all at once. Users can later change role interests, tool pins, language, model preferences, voice, theme and startup location; all persist across permitted devices. School organization membership is a separate access grant and never inferred from selecting Teaching.

Acceptance: first-run select Developer + Teacher, create default mixed Space, launch tools in both categories, restart and verify all preferences retained; account B cannot read A's onboarding state; skip works; denied mic still allows chat.

## R04. Modes, personalities, adaptive answer depth

Use original full mode/personality source. Recognize Quick, Standard, Deep Dive, Mentor, Strategist, Research, Creative, Emotional Support, Crisis, Teacher, Debate, Execution, custom combinations and earlier user-favored Hey Brother/Explorer style as product options where appropriately defined. Modes guide voice/style/tool/routing, never strip baseline capabilities or alter permission policy. Auto adapts to complexity, user preferences and task. Voice default concise natural with expandable full transcript/artifacts; Chat can be detailed, structured and citations-backed. Brand personality may use a calm deep British male voice option; voice library, legitimate user-authorized custom voice and wake-word preferences. Avoid implying medically or legally regulated professional advice is certified.

## R05. Tools Library + universal discovery + command palette

One canonical capability registry supports installed/available/experimental/platform-constrained entries, per-person/account/organization permissions, costs, dependency health, entitlements and discoverability. Search semantic natural-language requests e.g. “write by speaking everywhere”, “control this slide with my hand”, “edit slide three only”, “run an agent over my code”, “teach chemistry using a quiz” and return actual launchable tools and a truthful support explanation. Each tool provides name/category/description, examples, launch/stop, configure, permissions, status, platform matrix, model/provider dependencies, usage/allowance display, errors/help/version. Provide Favorites, Recently Used, popular/recommended, pin/reorder/add shortcuts, context-aware suggestion and advanced mode. Do not list internal agents as ordinary apps. Tool availability must be evaluated server/runtime side, not only with hidden UI flags.

Tool launch lifecycle: DISCOVERED → PERMISSION_REQUIRED/READY → STARTING → RUNNING → PAUSED/DEGRADED/FAILED → STOPPED, with durable mission linkage when needed. Missing plugin or disconnected provider launches a concrete connection/permissions flow, not fake success.

## R06. Custom Spaces — the user's own operating environment

A Space is a persistently named user- or organization-scoped environment containing selected tools, widgets, project contexts, layouts, shortcuts, saved Living Answers, models, language/theme tweaks and filtered activity. Provide create/rename/duplicate/archive/delete, import/export if safe, default templates, blank canvas, natural-language Space setup with preview, pinned catalog selection, drag/reorder/resize/snap/stack/minimize/dock, multiple view layouts, task/project tabs, undo/redo/snapshots. A Developer may add Teacher tools; a Teacher may add Software Studio and Model Lab. Spaces do not create authorization: access depends on the underlying user/org permission for every item. Organization-managed spaces inherit policy but cannot silently overwrite personal Spaces. Context switch cannot lose draft or active tasks; preserve safe mission continuity. User controls startup Space and workspace defaults. Load only active widgets and refresh them within resource budgets.

Workspace widgets: clock/date/timezone, weather, calendar, task list, routines, notes, project status, music/media, timer, notifications, news, quote, prayer/Quran/Hadith if enabled, HEY/S&A stats where authorized, device battery/health, research, terminal, code, audio, image, video, saved art, agent monitors. Sensitivity is location/time dependent: user controls location and religious widgets; public-display mode conceals private content. Weather/prayer info has source and freshness. Broken widget cannot crash full workspace; stale data explicitly labeled.

## R07. HEY Living Answers — full Generative UI engine

User intent determines output form. A short fact uses concise text; a numerical comparison uses a chart/table; navigating a city uses a real map; editing a file uses an editable artifact; building a calculator can generate a sandboxed working mini-app. Rich component vocabulary includes:

- Editorial: headings, block quotes, inline equations, citations, references and verified source links, collapsible details, comparison tables, badges limited to real statuses.
- Data: sortable/filterable virtual tables, graph/bar/line/pie/scatter/time series, trend lines, uncertainty bands, KPI tiles, export, unit and currency calculations using trusted math code.
- Controls: sliders, switches, segmented selections, radio/checkbox, dates, time ranges, file pickers, editable field/form validation, play/pause, progress, optimistic state with rollback where safe.
- Places: geocoded maps, multi-stop routes, travel time/ETA when backed by actual provider, nearby business data, opening hours with data freshness and verified reservation availability.
- Media: images, before/after, gallery/carousel, 3D/AR previews where supported, audio waveform/player, video/tracks, rich captions/transcripts, camera/screen previews with visible permission states.
- Work: editable doc/spreadsheet/presentation, source-code diff, interactive terminal/test output, calendar event, task board, milestone timeline, agents/delegations, mission logs, approval cards, file/result previews, provenance.
- Learning: flashcards, quizzes, interactive science/simulation diagrams, step-by-step visual math, hint/reveal, progress and teacher feedback.
- Generated app: calculator/planner/dashboard/custom workflow, bounded local state, save/export/reopen, declared data connectors and actions, versioned sandbox.

**Rendering contract:** model outputs a validated, versioned declarative scene/AST describing allowed components, data schema, trust level, source/citation IDs, event handlers by server-known action ID, state persistence scope, permissions and streaming/lifecycle states. Never trust raw model-produced HTML/JS/CSS as privileged app code. The renderer checks schema/size/depth/URL/safe markup, encodes text, enforces resource limits, a11y and content security, and denies unauthorized actions. Rich components using untrusted user-supplied code run in isolated iframe/webview/worker sandboxes (depending on platform) with explicit capability channel and bounded network/file access; clean fallback to static content on unsupported devices. Do not expose keys in component props. All host write actions go through Trust Kernel authorization, actual result receipt and optional undo. Data binds to real scoped services; stale/failed and unavailable states visible, without made-up numbers. A control never advertises a feature it cannot perform.

**Persistence:** Save widget to Space/project/conversation; versions, source data, interaction state and permissions persist only as authorized. On reconnect, restore from safe snapshot; if data source revoked show explanation and enable repair, never silently reuse stale privileged data. External links sourced from actual provider/reference records. User can copy/export where type permits. Voice can narrate widget changes, and screen reader/touch interaction must remain possible. Generated widgets have a resource/cost allowance and suspend when hidden as appropriate.

**Acceptance examples:** user asks for AI-cost calculator → functional sliders recalculate totals (server-backed pricing must show date); saves to Business Space → reload persists; switch account → unauthorized view fails; revoke price data → stale/disabled state; inject malicious model-output component → blocked; keyboard-only interaction passes; small-phone layout works; graph with missing data never invents data; click Deploy requires explicit real mandate and returns actual deployment receipt.

## R10. Chat, Voice, Live, HEY Brother and invocation

The complete conversation is one canonical timeline across text/voice/live, with attachments, sources, mission references, project context, widget state and artifacts. Voice should feel like a real call: living visualizer, listening/thinking/speaking states, mute, end, captions, interrupt/barge-in, audio output/voice choice, camera/screen controls, inline active task. Deep calm polished British male voice as preferred default option subject to an appropriate licensed TTS voice; custom voices only with authorization and consent. Wake word configurable, with brand `HEY` preferred and historical `Wake up` an allowed custom value; activation via wake word, push-to-talk, manual action and user-controlled background listening. Per-device visibility and low-power behavior, mic/privacy indicator, wake-word false-positive tests, noisy classroom adaptation, echo cancellation, VAD, timeouts, recovery if speech recognition double-starts. Do not retain raw audio by default beyond processing needs. Detect English, Sorani Kurdish, Kurmanji and Arabic where models genuinely support accuracy, fallback gracefully and expose corrections. User can turn off voice entirely and use quiet text.

Live may combine chosen screen/window/monitor/region, camera, file and audio sources. Guide overlays target controls, Assist proposes steps, Act follows scoped authorization and verifies. Stop/pause/revoke available instantly; external page/document content is untrusted and cannot command HEY as authority. Selection “Ask HEY about this” uses scoped capture only, never full-device hidden harvesting. Common mission can continue between modalities without spawning duplicate actions.

## R18. Full studios and pinpoint output

Image: text-to-image, image editing, variations, masks/object-level selection, reference styles and locked subject consistency; edit exactly requested region. Video: prompt/image/storyboard/first-last-frame → clips, multi-shot assembly, script, scene planning, continuity, camera motion, retime/split/trim/crop, titles, subtitles, voiceover, audio ducking, source/project provenance, long-form via scenes and actual export. Audio/music/speech: transcription, enhancement, narration, TTS, licensed sound/music generation, dubbing, translation, diarization if supported. Motion: kinetic typography, charts, transitions, product/UI demos and editable scene graphs. Documents/books/PDF/presentations/spreadsheets: editable layouts, graphs, speaker/content synchronization, formulas, pagination, language, print/export and revision/undo. Code/software/websites: repo editing, semantic diff, build/run/tests, previews, dependency/license checks and secure file/secret controls.

Embedded studio: user requests creation inside Chat/Voice → a synchronized Studio opens in same conversation with current project/context; user can keep talking, change only page/slide/shot three, collapse/expand full Studio without losing history, see structured progress and a real generated artifact. Dedicated Studio route opens same state, not a duplicate. Do not fabricate “video generated” when only an image/storyboard exists. Creation providers may be usage-priced; plan allowances and capability fallback. Media output must respect relevant content licensing and rights and should never imply an external provider has been called when not.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md`
**FULL original required, 167,626 characters. Read the full file in bounded sections from `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/FRONTEND_DESIGN_SYSTEM_DETAIL.md` before touching related components.** This file is deliberately not abbreviated or silently treated as read.

### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/00_AUTHORITATIVE_NEWEST_PRODUCT_FLOW_AMENDMENT.md`

# HEY V1 — AUTHORITATIVE FRONT-END / PRODUCT-FLOW AMENDMENT
## Newest decisions override conflicting older wording

This amendment is authoritative over older navigation/front-end wording wherever conflicts exist.

## A. SIGN-IN DESTINATION

After a successful sign-in, HEY must **not** take the user to a generic dashboard.

Default destination:
**The HEY Conversation Surface** — the primary page where the user can switch directly between **Chat** and **Voice**.

The product should immediately feel like the user has arrived at HEY itself, not at an admin dashboard.

### Required first signed-in view
- HEY wordmark / identity;
- Chat / Voice switcher;
- current project/context indicator when relevant;
- main conversation surface;
- prompt / microphone controls;
- compact access to Live;
- important contextual quick actions;
- Dynamic Island if supported;
- unobtrusive route to Home/Workspace, Projects, Cosmos, Create, etc.

### Returning user behavior
By default:
- return to the most recent Chat/Voice conversation state when safe;
- preserve current project/context;
- if a mission is active, show a compact resumable mission state;
- if user explicitly set a different startup destination, respect it.

### Do not
- dump users onto a generic grid of widgets;
- force users through a dashboard before speaking to HEY;
- make Chat and Voice look like unrelated products.

---

## B. CHAT + VOICE ARE ONE PRIMARY HEY SURFACE

Chat and Voice are two modalities of the same HEY Brain.

They should exist inside one coherent Conversation Surface.

### Desktop layout
Top/center modality selector:
- Chat
- Voice
- optionally Live as a nearby third action, not necessarily equal tab if Live uses immersive layout.

Switching Chat ↔ Voice:
- preserves conversation;
- preserves attachments/context;
- preserves project;
- preserves active artifact/studio;
- preserves mission;
- does not restart HEY.

### Chat mode
- editorial conversation;
- attachments;
- context/project chips;
- artifact cards;
- inline studio surfaces;
- action receipts;
- citations where relevant.

### Voice mode
The current generic voice page is not sufficient.

Required direction:
- use the premium call-like visual language previously designed;
- large HEY living visualizer;
- listening / thinking / speaking states;
- compact transcript;
- mute;
- end;
- captions;
- camera;
- screen;
- device/output;
- optional active task/artifact card;
- same conversation context as Chat.

Voice must feel like a live session with HEY, not a static microphone page.

---

## C. STUDIOS ARE MARRIED TO CHAT + VOICE

Dedicated Studio pages may remain for power users and direct navigation.

But creation must also work naturally **inside Chat and Voice**.

Example:
User in Chat:
“HEY, create me a 15-second video about X.”

Expected flow:
1. HEY understands request.
2. HEY may ask only materially necessary clarification.
3. Creation mission starts.
4. A Video Studio surface opens **inside the current HEY conversation/workspace**.
5. Chat remains available.
6. User can continue issuing edits conversationally.
7. Video Studio receives those edits directly.
8. Pinpoint Precision preserves locked/approved shots.
9. User can expand Studio to full workspace if desired.
10. User can collapse it back into conversation.
11. Dedicated Studio route can open the same artifact/state.

Same principle applies to:
- image;
- storyboard/frame;
- video;
- motion graphics;
- audio;
- presentation;
- document/book;
- code;
- research.

### Voice example
User in Voice:
“HEY, make a presentation about renewable energy.”

Expected:
- HEY verbally acknowledges;
- Presentation Studio appears as an embedded/side/full workspace while Voice remains active;
- user can say “change slide three only”;
- HEY edits slide three;
- conversation and studio remain synchronized.

Studios must never behave like unrelated apps launched from HEY.

---

## D. DYNAMIC ISLAND MUST LIVE OUTSIDE HEY

The Dynamic Island is a native persistent surface on supported platforms.

It must survive:
- unfocus;
- minimize;
- main-window close while helper remains running.

It must not depend on a browser tab or main React/Vite DOM remaining alive.

When clicked, it must show a **contextual control surface**, not merely an Activity list.

Context examples:
- Voice call;
- media;
- generation;
- research;
- mission;
- timer;
- download/upload;
- approval;
- handoff;
- result;
- error/recovery.

---

## E. PWA DOWNLOAD / INSTALL IS MISSING AND REQUIRED

HEY must expose a clear **Install HEY** / **Download HEY** path for the PWA/web-installable version.

### Required surfaces
Public website:
- primary or secondary “Install HEY” CTA where browser/platform supports PWA install;
- Download page with platform choices.

Inside HEY:
- Settings → Apps / Install / Device or equivalent;
- contextual install suggestion after meaningful use, not immediately on first page load;
- Help/Tutorial Center → Install HEY.

### Required PWA implementation
- valid Web App Manifest;
- app name and short_name;
- start_url;
- display mode appropriate for standalone experience;
- theme/background colors;
- icons including maskable icons;
- service worker;
- offline shell;
- installability criteria;
- correct scope;
- screenshots where platform supports richer install UI;
- shortcuts where useful;
- share target/file handling only if truly supported and tested.

### Install UX
If `beforeinstallprompt` is supported:
- capture event;
- show HEY-branded Install button;
- prompt only after user action;
- handle accepted/dismissed outcome;
- do not repeatedly nag after dismissal.

If browser does not expose programmatic prompt:
- show platform-specific manual steps;
- never display a fake “download” button that cannot install.

### Installed PWA behavior
- standalone shell;
- HEY icon;
- startup routes to Conversation Surface, not generic dashboard;
- session persists appropriately;
- deep links work;
- offline/local-capable parts degrade gracefully;
- updates are detected and applied safely;
- user is informed when restart/update is needed.

### Native download distinction
Do not confuse:
- PWA install;
- native Tauri desktop installer;
- mobile platform install.

The Download page should identify what the user is installing.

---

## F. HOME/DASHBOARD STILL EXISTS — BUT IS NOT THE DEFAULT POST-SIGN-IN DESTINATION

Home/Workspace remains useful for:
- widgets;
- tasks;
- calendar;
- active projects;
- missions;
- routines;
- weather;
- prayer where enabled;
- device/system state.

It is accessed from navigation and can be user-selected as startup destination.

But the default “enter HEY” experience is Chat/Voice.

---

## G. ACCEPTANCE TESTS FOR THIS AMENDMENT

1. Fresh sign-in → lands on Chat/Voice Conversation Surface.
2. Switch Chat → Voice → same conversation/context remains.
3. Voice visually matches call-like premium HEY direction.
4. In Chat, ask for video → embedded Studio appears without leaving HEY.
5. In Voice, ask for presentation → Studio appears while session continues.
6. Expand embedded Studio → dedicated/full workspace.
7. Collapse → returns to conversation without state loss.
8. Close main window during active mission → native Dynamic Island remains.
9. Click island during Voice → call controls.
10. Click island during generation → generation controls.
11. Supported browser → Install HEY CTA works.
12. Installed PWA opens standalone and lands on Conversation Surface.
13. Unsupported install browser → correct manual instructions, not fake prompt.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`

# Complete Navigation & Information Architecture
## HEY V1 — Full-depth implementation specification

**Mission:** Make every important HEY capability discoverable without exposing internal complexity.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Conversation Surface (Chat/Voice) is the default signed-in destination.
- Primary global navigation, contextual navigation, Create hierarchy, Explore More, + Add, Universal Search, Command Palette, recent/favorites, mobile bottom nav.
- Information scent, labels, hierarchy, advanced-mode disclosure, role/device/mode adaptations.
- Deep-link routing and return-to-previous-context behavior.

# 2. User experience contract
- Primary normal-user nav: Chat/Voice entry, Live, Projects, Create, Cosmos, Tasks/Missions, Widgets/Workspace, Search, Notifications, Settings.
- Important Create actions visible before Explore More: Image, Video, Presentation, Document, Audio.
- `+ Add` lets users pin additional capabilities without seeing raw agents.
- Advanced tools are discoverable through Advanced Mode, Search, Forge, Developer—not cluttering normal nav.
- Navigation never loses active project/conversation/artifact state.
- Breadcrumbs appear only where hierarchy is genuinely useful.
- Mobile uses bottom nav + More; desktop uses collapsible rail; tablet uses adaptive split shell.

# 3. Architecture / runtime contract
- Central route registry with capability metadata, permissions, feature flags, platform support and discovery rank.
- Navigation state is distinct from task/artifact state.
- Deep links restore intended resource with permission checks.
- Startup route resolver respects newest rule: default Conversation Surface, then explicit user override, then safe resume.
- Explore More reads from capability registry but filters by audience/platform/entitlements.

# 4. Required state model
- anonymous
- authenticating
- signed-in-first-run
- signed-in-returning
- conversation-active
- immersive-live
- embedded-studio
- full-studio
- modal
- offline
- unsupported-platform
- advanced-mode

# 5. Failure and recovery catalog
- Unknown/deprecated route → safe redirect with explanation.
- Feature flag off → remove dead nav and provide fallback if linked.
- Unauthorized deep link → permission/entitlement explanation.
- Stale project/artifact link → recovery and search, not blank page.
- Navigation state corruption → restore last valid route.

# 6. Security / privacy / trust requirements
- Never use client-only nav hiding as authorization.
- Sensitive routes require server/runtime enforcement.
- Do not leak advanced/debug routes to normal users.
- External URLs opened safely and clearly distinguished.

# 7. Data model / persistence
- navigation_preferences
- pinned_capabilities
- recent_capabilities
- startup_destination
- feature_flags
- entitlements
- capability_manifest
- workspace_route_state

# 8. Events / telemetry contracts
- nav.opened
- nav.pinned
- nav.unpinned
- search.opened
- capability.discovered
- capability.launched
- route.failed
- startup.resolved

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in lands Chat/Voice.
- Returning user resumes safe conversation state.
- Normal user finds Image/Video/Live/Cosmos without Explore More.
- + Add persists pinned tool.
- Deep link to project artifact restores context.
- Advanced Mode reveals developer areas without changing normal nav.

# 12. Non-goals / prohibited shortcuts
- Do not put all 229 agents in navigation.
- Do not make Explore More the only discovery path.
- Do not route sign-in to generic dashboard by default.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`

# Complete Widget Platform
## HEY V1 — Full-depth implementation specification

**Mission:** Turn widgets into a coherent internal app surface with safe extensibility.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Built-in widgets, app/service widgets, custom widgets, Forge-generated widgets, size variants, interaction contracts, refresh, privacy.
- Widget library, customization, drag/drop, stacking, dock, fullscreen.

# 2. User experience contract
- Every widget has compact/standard/expanded behavior when meaningful.
- Widget has clear title, primary information and contextual actions.
- Normal users see product concepts, not provider/internal IDs.
- Widgets can be embedded in Chat/Voice/Workspace where relevant.
- One widget never hijacks the page.

# 3. Architecture / runtime contract
- Widget manifest: id/version/title/category/sizes/data sources/permissions/actions/offline/cache/privacy/render contract.
- Sandbox external/custom widgets where possible.
- Shared lifecycle: mount, load, ready, stale, degraded, error, suspended, unmount.
- Background refresh is budgeted and pauseable.

# 4. Required state model
- loading
- ready
- stale
- refreshing
- degraded
- permission-required
- offline
- error
- suspended
- hidden

# 5. Failure and recovery catalog
- API failure → stale cached state + retry.
- Permission revoked → permission-required state.
- Malformed custom widget → sandbox crash boundary.
- Refresh loop → circuit breaker.

# 6. Security / privacy / trust requirements
- Least privilege per widget.
- No raw secrets in widget code.
- Sensitive widgets can be excluded from screenshots/public modes.
- Third-party content cannot issue HEY commands as authority.

# 7. Data model / persistence
- widget_manifests
- widget_instances
- widget_cache
- widget_permissions
- widget_versions
- widget_health

# 8. Events / telemetry contracts
- widget.loaded
- widget.action
- widget.refresh
- widget.degraded
- widget.crash
- widget.permission.requested

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Add/remove/reorder survives restart.
- Widget error isolated.
- Offline cached widget shows freshness.
- Custom widget permission revoke works.
- RTL and mobile variants work.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`

# Complete Conversation Surface + Embedded Studios
## HEY V1 — Full-depth implementation specification

**Mission:** Make Chat, Voice and creation/editing feel like one continuous HEY experience.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat/Voice modality switching, embedded studios, artifact cards, context persistence, voice-call UI, studio full-screen expansion, conversational edits.
- Image/video/audio/presentation/document/storyboard/code/research composition.

# 2. User experience contract
- Sign-in lands here.
- Chat and Voice share the exact same conversation and project context.
- Voice is call-like and premium, not generic mic page.
- Creation requests spawn embedded Studio within conversation/workspace.
- Dedicated Studio route opens same artifact/state; not separate duplicate state.
- Chat/Voice commands can manipulate current studio using Pinpoint locks.

# 3. Architecture / runtime contract
- Conversation session owns references to active project, artifact, studio session and Live session.
- Studio session has canonical artifact ID/version and is rendered in embedded/full modes.
- Voice and text inputs feed same HEY Brain/orchestration.
- UI event bus/state store synchronizes studio changes back to conversation.

# 4. Required state model
- chat
- voice-idle
- voice-listening
- voice-thinking
- voice-speaking
- studio-embedded
- studio-expanded
- studio-minimized
- generation-running
- waiting-user
- error

# 5. Failure and recovery catalog
- Studio component crash → conversation remains alive.
- Voice disconnect → fallback to Chat without context loss.
- Provider failure → studio retains prompt/assets.
- Route change → persist unsaved studio draft.

# 6. Security / privacy / trust requirements
- Mic/screen/camera visible indicators.
- Studio file access scoped.
- Voice transcript privacy settings respected.

# 7. Data model / persistence
- conversations
- conversation_turns
- studio_sessions
- active_artifact_refs
- voice_sessions
- drafts

# 8. Events / telemetry contracts
- conversation.mode.changed
- studio.opened
- studio.expanded
- artifact.changed
- voice.started
- voice.interrupted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Chat→Voice same context.
- Voice→Chat same context.
- Chat request video opens embedded studio.
- Voice slide-three-only edit modifies only slide three.
- Reload restores studio draft.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/ANSWER_ENGINE_DETAIL.md`
**FULL original required, 30,954 characters. Read the full file in bounded sections from `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/ANSWER_ENGINE_DETAIL.md` before touching related components.** This file is deliberately not abbreviated or silently treated as read.

### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/24_COMPLETE_TUTORIAL_DISCOVERY_SYSTEM.md`

# Complete Tutorial, Onboarding & Feature Discovery System
## HEY V1 — Full-depth implementation specification

**Mission:** Teach every major HEY capability through real UI practice, not static help pages.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- First-use tutorials, Tutorial Center, contextual Show Me, animated demos, practice mode, tutorial versioning, completion, discovery nudges.
- 63+ major tutorials and replay.

# 2. User experience contract
- Tutorial appears on first meaningful use, not as startup spam.
- User can say 'show me how to use X'.
- Tutorial spotlights real controls and lets user practice.
- Skip/replay/reduced-motion always available.
- Changed UI increments tutorial version and can offer What's New.

# 3. Architecture / runtime contract
- Tutorial registry maps capability IDs to steps, selectors/anchors, voice copy, fallback static frames and version.
- Runtime validates target exists before starting.
- Analytics records completion without recording sensitive content.
- Tutorial overlay never blocks critical security flow.

# 4. Required state model
- not-started
- offered
- in-progress
- skipped
- completed
- outdated
- practice

# 5. Failure and recovery catalog
- Target missing → fallback explanation and report stale tutorial.
- User navigates away → pause.
- Reduced motion → still-step version.
- Feature unavailable → platform-specific tutorial.

# 6. Security / privacy / trust requirements
- Tutorials must not grant permissions automatically.
- Privacy-sensitive feature tutorial explains sensing indicators.

# 7. Data model / persistence
- tutorials
- tutorial_steps
- tutorial_progress
- tutorial_versions

# 8. Events / telemetry contracts
- tutorial.offered
- tutorial.started
- tutorial.step
- tutorial.skipped
- tutorial.completed
- tutorial.stale

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Voice tutorial by voice command.
- Live first-use tutorial.
- Replay.
- UI selector stale detection.
- Reduced-motion tutorial.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/16_COMPLETE_PERFORMANCE_BUDGETS.md`

# Complete Performance, Battery & Thermal Budgets
## HEY V1 — Full-depth implementation specification

**Mission:** Keep HEY responsive on weak laptops and scalable on stronger hardware.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Startup, input latency, animation FPS, memory, CPU, GPU, bundle size, background usage, network, generation orchestration, battery/thermal adaptation.
- Performance tiers and instrumentation.

# 2. User experience contract
- Typing, scrolling and core navigation remain responsive while background work runs.
- Heavy studios lazy-load.
- Weak hardware automatically reduces nonessential glass/parallax/ambient effects.
- Performance degradation is not confused with feature failure.

# 3. Architecture / runtime contract
- Performance tier detector based on measured capability, not only hardware name.
- Task scheduler budgets background work.
- Virtualize large lists, defer offscreen rendering, cache carefully.
- Native and web telemetry measure actual latency.

# 4. Required state model
- full
- balanced
- lightweight
- battery-saver
- thermal-throttled
- background

# 5. Failure and recovery catalog
- Memory pressure → release caches.
- GPU jank → lower visual tier.
- CPU saturation → throttle background agents.
- Slow network → progressive/streamed UI.

# 6. Security / privacy / trust requirements
- Performance telemetry excludes sensitive content.
- User can disable diagnostics telemetry per policy.

# 7. Data model / persistence
- performance_profiles
- perf_samples
- resource_budgets
- thermal_state
- battery_state

# 8. Events / telemetry contracts
- perf.long_task
- perf.jank
- perf.memory_pressure
- tier.changed
- battery.saver

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Old Toshiba-class weak device smoke test.
- 60Hz/120Hz UI.
- Long chat virtualization.
- Large project.
- Background mission while typing.
- Battery saver.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
