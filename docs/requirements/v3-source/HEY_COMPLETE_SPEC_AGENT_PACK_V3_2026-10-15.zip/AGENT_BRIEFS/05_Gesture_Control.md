# HEY SPECIALIST BRIEF — 05 Gesture Control

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Full camera calibration and hand-landmark tracking; default/custom gesture vocabulary, profiles by teacher/device/app, false-trigger rejection, presentation state proof, immediate stop and offline limits.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Gesture, Teacher. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R11. HEY Flow dictation, native VoiceOS and gestures are separable products

**HEY Flow:** global shortcut/toolbar/compact overlay, start/stop, microphone state, speech recognition, auto punctuation, capitalization, filler cleanup, custom vocabulary, snippets, rewrite selected text, translation if requested, dictation into actual focused application where permitted, per-app settings and offline/local/cloud selection. Make text insertion atomic or undoable and safe: preserve cursor/selection, detect focus switches and private fields, avoid sending sensitive text to wrong app, show targeted preview on ambiguous actions. If an app blocks global injection, offer clipboard/authorized share fallback. Distinguish transcription from commands (“open file” spoken while dictating should not launch a file without explicit mode/intent).

**VoiceOS:** “open VS Code”, “locate this file”, “rename it”, “organize my desktop”, “change slide” uses shared actual computer-use action engine; scoped approvals, confirmation where appropriate, postcondition and action logs. Controlled by Voice, keyboard/command palette or screen selection; no action falsely reports success because OS adapter returned an optimistic result. Guide/Assist/Act levels. **Gesture mode** can be launched alone by a user who never talks to HEY. Gesture controls function on Android smartboards or attached cameras subject to hardware realities; users can map gestures per app, workspace, device and teacher profile.

## R12. Complete gesture vocabulary and calibration

Default proposed-to-test gesture mapping (may be adjusted per real hardware/use case): open palm → show HEY/overview; open palm→fist → grab; held fist motion → move widget; pinch → select/click; pinch-and-move → precision drag; spread both hands → enlarge/zoom; bring together → reduce; swipe left/right → previous/next slide or page depending on context; swipe up → restore; swipe down → minimize; two fingers → pause/resume; point+pinch → target+activate; raised hand → stop HEY speech; thumbs up/down → low-risk confirm/dismiss only; both palms → leave manipulation. Provide presentation-focused profiles with reverse slide mapping if requested. All mappings customizable; none grants payment/data-deletion authorization.

Calibration: available camera enumeration + explicit permission, device orientation, distance/light evaluation, handedness, threshold/hold/cooldown, confidence feedback, conflict and accidental detection, gesture preview with dry-run, custom-gesture recording and versioning, pause/hide/stop, on-device pose where practical, frame budget and frame-rate throttling on weak hardware, webcam/device disconnect auto-stop. Target disambiguation via focus/pointer/voice context; don't click random targets. Recorded raw video not saved by default. Custom gesture enrollment requires clear data deletion. No student-face identification for class operation unless a separate authorized consent-sensitive use case is explicitly approved; camera is for hand tracking.

## R13. HEY Board — Leaders smartboard-specific details

Distinct teacher smartboard helper/experience, not merely a separate presentation generator. For Android boards with uncertain camera/API support: investigate physical camera, supported Android version, external USB webcam, system microphone, OEM lockdown, accessibility APIs, local network, screen/control integration. Provide a real compatibility diagnostic report. Device management should not assume unsupported device-owner/kiosk provisioning; user previously rejected default kiosk/device-owner mode and teacher proximity confirmation. Enable teacher-created/deletable profiles with own wake word and a safe default/no-profile fallback. Teacher access may use school/S&A-approved codes; proper codes must be revocable and tied to organization policy, not universal backdoor. Principal dashboard/PIN/role only if securely designed. Offline core gesture controls and presentation profiles should remain available where hardware permits; local encrypted profiles, predictable background lifecycle and restart recovery; clear wake/active indicators, noise adaptation, camera/mic controls, per-board keys, health monitor/self-healing with loop prevention and user stop. Real teacher verification, no unapproved student face recognition, and public-display privacy. Substitutes can use safe generic profile when permitted. End-of-Class button/task ends class-relevant temporary permissions, clears sensitive on-screen content, saves/exports teacher work as configured and releases board sessions without deleting teacher artifacts. Do not advertise capability if Android hardware/OS cannot support it.

## R14. Teacher Mode and full school platform, distinguished

**HEY Teacher Mode** is one configurable HEY Space/tool collection with teacher identity/grade/subject/preferences, lesson outlines, concept explanations, differentiated difficulty, teacher-guided tutoring, PDF/textbook imports, worksheets, question banks, quizzes, exams, answer keys, activities, presentations, classroom visualizations, homework, rubrics, editable/exportable documents, printable materials, re-use, version history and smartboard integration. Teachers should request “change only question 4” or “simplify slide 3 without touching the others” with Pinpoint fidelity. Edits happen inside conversation-linked Studio. Teacher code grants school-specific mode only after server-side validation; code itself is not unrestricted administrative access. Kurdish/English/Arabic layout and print correctness tested. User remains free to add coding/model/creator tools from other categories.

**Full school management platform** is a separate ambitious integration surface with teacher/student/parent/admin roles, timetable, assignments/submission, grades, attendance, transport/bus reporting, announcements, end-of-class workflows, student progress, resource portals, permissions, audit and school policy; avoid copying or conflicting with existing principal-facing buses/attendance/grades system without integration agreements. Principal/IT requirements precede real data onboarding. Do not confuse “school platform planned” with something already sold/approved for use. HEY stays one common intelligence. School pilot can use teacher content and synthetic pupils before written school authorization for real student data. Child data, parent visibility, data retention, role isolation, audit, school contractual status and age-appropriate security require explicit governance.

**Teacher needs discovery:** a bilingual Sorani+English double-sided A4 form for all teachers asks (1) time-consuming/difficult tasks, (2) classroom/smartboard/equipment/systems problems, (3) tasks to simplify and desired tools, (4) anything teachers would improve at school; optional teacher name/subject/grade and priority field. Two questions per page, large writing areas, school-first branding; `S&A × Leaders` only if school authorizes co-brand. Completed feedback must become a needs register, with user-approved priorities, measurable acceptance criteria and feature owner; teacher requests are user research, not automatically all approved development scope.

## R15. HEY Edge: tiny trusted native companion + Device Mesh

Cloud/hosted HEY Brain need not run on user laptop. Edge has minimal idle footprint; real OS adapters for file/window/process/screen/clipboard/shortcuts/notifications, per-app automation, mic/wake, local gesture inference and verified device actions; no fake platform parity. Windows: UI Automation, window/process/filesystem/input APIs; macOS: Accessibility, ScreenCaptureKit, Shortcuts/AppleScript where legitimate; Linux: xdg portals, Wayland/X11, DBus; Android: intents, foreground-service notifications, user-enabled accessibility where appropriate, MediaProjection, camera, share flows; iOS/iPadOS: App Intents/Shortcuts/share extensions/Live Activities, no privileged unrestricted background terminal for ordinary apps; Web/PWA: constrained browser APIs. Enforce signed scoped mandates, device registration/pairing, nonce/replay/expiry and audit, revocation on target change, local policy; immediate stop and least-privilege. Device Mesh can handoff projects/mission state by authorized encrypted channel and choose device based on active capabilities, not invent access to an offline device. Conserve RAM/CPU/battery on older hardware; disable fancy effects as appropriate. No raw screen/audio retention without user's explicit settings.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/09_COMPLETE_PLATFORM_CAPABILITY_MATRIX.md`

# Complete Platform Capability Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Define truthful, strongest-possible behavior for web, PWA, Windows, macOS, Linux, Android and iOS.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat, Voice, Live, screen/camera, computer control, background helper, Dynamic Island, notifications, files, gestures, local models, device handoff, install/update.
- Per-platform fallback behavior.

# 2. User experience contract
- UI labels unavailable capabilities honestly.
- Same conceptual feature can have platform-specific implementation.
- User sees the strongest supported fallback rather than a dead button.

# 3. Architecture / runtime contract
- Capability registry includes platform support: native/full, supported-with-limits, guided-only, unavailable.
- Runtime capability detection, not user-agent assumptions alone.
- Native helper interfaces are abstracted behind capability contracts.

# 4. Required state model
- supported
- supported-limited
- permission-required
- unsupported
- temporarily-unavailable
- degraded

# 5. Failure and recovery catalog
- OS API unavailable → fallback.
- Permission denied → guide.
- Browser restrictions → native/PWA suggestion.
- Background suspension → cloud/server durable task fallback.

# 6. Security / privacy / trust requirements
- No fake arbitrary iOS control.
- No security bypass.
- Platform permissions explicit.

# 7. Data model / persistence
- platform_capabilities
- device_capabilities
- capability_health
- permission_grants

# 8. Events / telemetry contracts
- capability.detected
- capability.unavailable
- fallback.selected
- native.helper.connected

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Windows closed-window island.
- PWA install.
- Android assistant integration where supported.
- iOS fallback contracts.
- Linux/macOS background tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/16_COMPLETE_PERFORMANCE_BUDGETS.md`

# Complete Performance, Battery & Thermal Budgets
## HEY V1 — Full-depth implementation specification

**Mission:** Keep HEY responsive on weak laptops and scalable on stronger hardware.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Startup, input latency, animation FPS, memory, CPU, GPU, bundle size, background usage, network, generation orchestration, battery/thermal adaptation.
- Performance tiers and instrumentation.

# 2. User experience contract
- Typing, scrolling and core navigation remain responsive while background work runs.
- Heavy studios lazy-load.
- Weak hardware automatically reduces nonessential glass/parallax/ambient effects.
- Performance degradation is not confused with feature failure.

# 3. Architecture / runtime contract
- Performance tier detector based on measured capability, not only hardware name.
- Task scheduler budgets background work.
- Virtualize large lists, defer offscreen rendering, cache carefully.
- Native and web telemetry measure actual latency.

# 4. Required state model
- full
- balanced
- lightweight
- battery-saver
- thermal-throttled
- background

# 5. Failure and recovery catalog
- Memory pressure → release caches.
- GPU jank → lower visual tier.
- CPU saturation → throttle background agents.
- Slow network → progressive/streamed UI.

# 6. Security / privacy / trust requirements
- Performance telemetry excludes sensitive content.
- User can disable diagnostics telemetry per policy.

# 7. Data model / persistence
- performance_profiles
- perf_samples
- resource_budgets
- thermal_state
- battery_state

# 8. Events / telemetry contracts
- perf.long_task
- perf.jank
- perf.memory_pressure
- tier.changed
- battery.saver

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Old Toshiba-class weak device smoke test.
- 60Hz/120Hz UI.
- Long chat virtualization.
- Large project.
- Background mission while typing.
- Battery saver.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`

# Screen & Camera Guidance / Overlay System

HEY can use the screen or camera (with visible permission) to guide users through digital or physical tasks.

## Screen guidance
HEY understands UI elements, highlights the exact control, draws arrows/outlines/callouts, dims unrelated regions, numbers steps, follows moving UI targets, watches whether the step succeeded and advances only after verification. It can guide settings changes, software workflows, forms, troubleshooting and accessibility tasks.

## Camera guidance
HEY understands the live scene, identifies relevant objects, anchors arrows/labels/step markers to them, tracks them across frames and tells the user what to do next. It can assist with setup, assembly, troubleshooting and other appropriate real-world procedures.

## Spatial Guidance Graph
Both screen and camera guidance share a graph of targets, anchors, instructions, confidence and verification state. Voice can say “the button I mean is here” while the overlay highlights it.

## Privacy/security
Visible sensing indicator, instant pause/stop, selected-source controls, app exclusions, sensitive mode, raw-feed non-retention by default, prompt-injection defense for on-screen text, local vision/pose inference where viable.

## Agents
Screen Understanding, Camera Understanding, Object Detection, Object Tracking, Spatial Anchor, Guidance Planner, Overlay Renderer, Procedure Verification, Accessibility Guide, Prompt-Injection Guard, Safety/Risk.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
