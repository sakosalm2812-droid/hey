# HEY SPECIALIST BRIEF — 07 VoiceOS Live Computer Control

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Shared Chat/Voice/Live conversation; deep British voice choice, configurable wake word, screen guide/assist/act, device commands and independently verified outcomes, OS limitations.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Voice, Live, Actions, Platform. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R10. Chat, Voice, Live, HEY Brother and invocation

The complete conversation is one canonical timeline across text/voice/live, with attachments, sources, mission references, project context, widget state and artifacts. Voice should feel like a real call: living visualizer, listening/thinking/speaking states, mute, end, captions, interrupt/barge-in, audio output/voice choice, camera/screen controls, inline active task. Deep calm polished British male voice as preferred default option subject to an appropriate licensed TTS voice; custom voices only with authorization and consent. Wake word configurable, with brand `HEY` preferred and historical `Wake up` an allowed custom value; activation via wake word, push-to-talk, manual action and user-controlled background listening. Per-device visibility and low-power behavior, mic/privacy indicator, wake-word false-positive tests, noisy classroom adaptation, echo cancellation, VAD, timeouts, recovery if speech recognition double-starts. Do not retain raw audio by default beyond processing needs. Detect English, Sorani Kurdish, Kurmanji and Arabic where models genuinely support accuracy, fallback gracefully and expose corrections. User can turn off voice entirely and use quiet text.

Live may combine chosen screen/window/monitor/region, camera, file and audio sources. Guide overlays target controls, Assist proposes steps, Act follows scoped authorization and verifies. Stop/pause/revoke available instantly; external page/document content is untrusted and cannot command HEY as authority. Selection “Ask HEY about this” uses scoped capture only, never full-device hidden harvesting. Common mission can continue between modalities without spawning duplicate actions.

## R11. HEY Flow dictation, native VoiceOS and gestures are separable products

**HEY Flow:** global shortcut/toolbar/compact overlay, start/stop, microphone state, speech recognition, auto punctuation, capitalization, filler cleanup, custom vocabulary, snippets, rewrite selected text, translation if requested, dictation into actual focused application where permitted, per-app settings and offline/local/cloud selection. Make text insertion atomic or undoable and safe: preserve cursor/selection, detect focus switches and private fields, avoid sending sensitive text to wrong app, show targeted preview on ambiguous actions. If an app blocks global injection, offer clipboard/authorized share fallback. Distinguish transcription from commands (“open file” spoken while dictating should not launch a file without explicit mode/intent).

**VoiceOS:** “open VS Code”, “locate this file”, “rename it”, “organize my desktop”, “change slide” uses shared actual computer-use action engine; scoped approvals, confirmation where appropriate, postcondition and action logs. Controlled by Voice, keyboard/command palette or screen selection; no action falsely reports success because OS adapter returned an optimistic result. Guide/Assist/Act levels. **Gesture mode** can be launched alone by a user who never talks to HEY. Gesture controls function on Android smartboards or attached cameras subject to hardware realities; users can map gestures per app, workspace, device and teacher profile.

## R12. Complete gesture vocabulary and calibration

Default proposed-to-test gesture mapping (may be adjusted per real hardware/use case): open palm → show HEY/overview; open palm→fist → grab; held fist motion → move widget; pinch → select/click; pinch-and-move → precision drag; spread both hands → enlarge/zoom; bring together → reduce; swipe left/right → previous/next slide or page depending on context; swipe up → restore; swipe down → minimize; two fingers → pause/resume; point+pinch → target+activate; raised hand → stop HEY speech; thumbs up/down → low-risk confirm/dismiss only; both palms → leave manipulation. Provide presentation-focused profiles with reverse slide mapping if requested. All mappings customizable; none grants payment/data-deletion authorization.

Calibration: available camera enumeration + explicit permission, device orientation, distance/light evaluation, handedness, threshold/hold/cooldown, confidence feedback, conflict and accidental detection, gesture preview with dry-run, custom-gesture recording and versioning, pause/hide/stop, on-device pose where practical, frame budget and frame-rate throttling on weak hardware, webcam/device disconnect auto-stop. Target disambiguation via focus/pointer/voice context; don't click random targets. Recorded raw video not saved by default. Custom gesture enrollment requires clear data deletion. No student-face identification for class operation unless a separate authorized consent-sensitive use case is explicitly approved; camera is for hand tracking.

## R15. HEY Edge: tiny trusted native companion + Device Mesh

Cloud/hosted HEY Brain need not run on user laptop. Edge has minimal idle footprint; real OS adapters for file/window/process/screen/clipboard/shortcuts/notifications, per-app automation, mic/wake, local gesture inference and verified device actions; no fake platform parity. Windows: UI Automation, window/process/filesystem/input APIs; macOS: Accessibility, ScreenCaptureKit, Shortcuts/AppleScript where legitimate; Linux: xdg portals, Wayland/X11, DBus; Android: intents, foreground-service notifications, user-enabled accessibility where appropriate, MediaProjection, camera, share flows; iOS/iPadOS: App Intents/Shortcuts/share extensions/Live Activities, no privileged unrestricted background terminal for ordinary apps; Web/PWA: constrained browser APIs. Enforce signed scoped mandates, device registration/pairing, nonce/replay/expiry and audit, revocation on target change, local policy; immediate stop and least-privilege. Device Mesh can handoff projects/mission state by authorized encrypted channel and choose device based on active capabilities, not invent access to an offline device. Conserve RAM/CPU/battery on older hardware; disable fancy effects as appropriate. No raw screen/audio retention without user's explicit settings.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`

# Complete Conversation Surface + Embedded Studios
## HEY V1 — Full-depth implementation specification

**Mission:** Make Chat, Voice and creation/editing feel like one continuous HEY experience.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat/Voice modality switching, embedded studios, artifact cards, context persistence, voice-call UI, studio full-screen expansion, conversational edits.
- Image/video/audio/presentation/document/storyboard/code/research composition.

# 2. User experience contract
- Sign-in lands here.
- Chat and Voice share the exact same conversation and project context.
- Voice is call-like and premium, not generic mic page.
- Creation requests spawn embedded Studio within conversation/workspace.
- Dedicated Studio route opens same artifact/state; not separate duplicate state.
- Chat/Voice commands can manipulate current studio using Pinpoint locks.

# 3. Architecture / runtime contract
- Conversation session owns references to active project, artifact, studio session and Live session.
- Studio session has canonical artifact ID/version and is rendered in embedded/full modes.
- Voice and text inputs feed same HEY Brain/orchestration.
- UI event bus/state store synchronizes studio changes back to conversation.

# 4. Required state model
- chat
- voice-idle
- voice-listening
- voice-thinking
- voice-speaking
- studio-embedded
- studio-expanded
- studio-minimized
- generation-running
- waiting-user
- error

# 5. Failure and recovery catalog
- Studio component crash → conversation remains alive.
- Voice disconnect → fallback to Chat without context loss.
- Provider failure → studio retains prompt/assets.
- Route change → persist unsaved studio draft.

# 6. Security / privacy / trust requirements
- Mic/screen/camera visible indicators.
- Studio file access scoped.
- Voice transcript privacy settings respected.

# 7. Data model / persistence
- conversations
- conversation_turns
- studio_sessions
- active_artifact_refs
- voice_sessions
- drafts

# 8. Events / telemetry contracts
- conversation.mode.changed
- studio.opened
- studio.expanded
- artifact.changed
- voice.started
- voice.interrupted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Chat→Voice same context.
- Voice→Chat same context.
- Chat request video opens embedded studio.
- Voice slide-three-only edit modifies only slide three.
- Reload restores studio draft.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/23_COMPLETE_NATIVE_DYNAMIC_ISLAND.md`

# Complete Native Dynamic Island & Persistent Surface
## HEY V1 — Full-depth implementation specification

**Mission:** Make the Dynamic Island a real contextual HEY surface outside the main app on supported desktop platforms.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Native window/helper, always-on-top behavior, monitor selection, positioning, idle/listening/thinking/media/mission/generation/research/download/timer/approval/handoff/error/completion modes.
- Click/hover/voice/gesture expansion and full-app handoff.

# 2. User experience contract
- Island persists after main window closes while HEY helper remains.
- Click shows context-specific controls, not Activity-only.
- User can reposition/customize size/transparency/monitor/auto-hide.
- Island never blocks important OS UI and respects fullscreen apps per preference.
- Multiple concurrent activities resolve to one primary state + compact secondary indicators.

# 3. Architecture / runtime contract
- Native host window controlled by helper process; web UI rendered inside or native equivalent.
- Canonical activity selector ranks current states.
- IPC bridges task/media/voice/generation state from runtime to island.
- Island reconnects after UI/native helper restart.

# 4. Required state model
- idle
- listening
- thinking
- speaking
- media
- mission
- generation
- research
- transfer
- timer
- approval
- handoff
- error
- complete
- hidden

# 5. Failure and recovery catalog
- Helper crash → restart.
- IPC lost → degraded status + reconnect.
- Multiple activities → priority resolution.
- Monitor removed → move to primary display.

# 6. Security / privacy / trust requirements
- Always-visible sensing indicators.
- Lock-screen/private-screen redaction.
- Island cannot approve high-risk action without required confirmation details.

# 7. Data model / persistence
- island_preferences
- island_state
- active_surfaces
- native_helper_state

# 8. Events / telemetry contracts
- island.mode.changed
- island.expanded
- island.action
- helper.connected
- helper.disconnected

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Close main window persistence.
- Voice controls.
- Media controls.
- Generation controls.
- Monitor unplug.
- Full quit removes island.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `03_INTERACTION_PLATFORM/01_CHAT_VOICE_LIVE_UNIFIED.md`

# Unified Chat, Voice & Live

Chat and Voice are the same canonical conversation. Voice is not a separate history. A voice turn becomes part of chat history; text and voice share project, files, active artifacts, missions and Cosmos context.

## Different answer styles, same intelligence
Chat can be structured, detailed, source-rich and artifact-heavy. Voice is shorter, more natural, interruption-friendly and spoken in smaller turns. A full transcript/result can still appear in the shared conversation. Raw microphone audio is not retained by default after processing unless the user explicitly saves it. Private Mode can avoid durable transcript/memory according to settings.

Switching `Chat → Voice → Live → Chat` must preserve context.

## Live
HEY Live can combine voice with the user's chosen screen/window/monitor/region, camera, files and project context. Guide mode explains; Assist mode helps with bounded actions; Act mode performs authorized actions and verifies results.


---



### SOURCE FILE: `03_INTERACTION_PLATFORM/02_SCREEN_CAMERA_GUIDANCE_OVERLAYS.md`

# Screen & Camera Guidance / Overlay System

HEY can use the screen or camera (with visible permission) to guide users through digital or physical tasks.

## Screen guidance
HEY understands UI elements, highlights the exact control, draws arrows/outlines/callouts, dims unrelated regions, numbers steps, follows moving UI targets, watches whether the step succeeded and advances only after verification. It can guide settings changes, software workflows, forms, troubleshooting and accessibility tasks.

## Camera guidance
HEY understands the live scene, identifies relevant objects, anchors arrows/labels/step markers to them, tracks them across frames and tells the user what to do next. It can assist with setup, assembly, troubleshooting and other appropriate real-world procedures.

## Spatial Guidance Graph
Both screen and camera guidance share a graph of targets, anchors, instructions, confidence and verification state. Voice can say “the button I mean is here” while the overlay highlights it.

## Privacy/security
Visible sensing indicator, instant pause/stop, selected-source controls, app exclusions, sensitive mode, raw-feed non-retention by default, prompt-injection defense for on-screen text, local vision/pose inference where viable.

## Agents
Screen Understanding, Camera Understanding, Object Detection, Object Tracking, Spatial Anchor, Guidance Planner, Overlay Renderer, Procedure Verification, Accessibility Guide, Prompt-Injection Guard, Safety/Risk.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
