# HEY SPECIALIST BRIEF — 12 Product Integrity Living Answers

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Versioned requirements graph, decision supersession, source-aware E2E proof, rich declarative interactive response renderer, safe mini-app sandbox, persistent widget state and revocation.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Widgets, Integrity, Cosmos. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R04. Modes, personalities, adaptive answer depth

Use original full mode/personality source. Recognize Quick, Standard, Deep Dive, Mentor, Strategist, Research, Creative, Emotional Support, Crisis, Teacher, Debate, Execution, custom combinations and earlier user-favored Hey Brother/Explorer style as product options where appropriately defined. Modes guide voice/style/tool/routing, never strip baseline capabilities or alter permission policy. Auto adapts to complexity, user preferences and task. Voice default concise natural with expandable full transcript/artifacts; Chat can be detailed, structured and citations-backed. Brand personality may use a calm deep British male voice option; voice library, legitimate user-authorized custom voice and wake-word preferences. Avoid implying medically or legally regulated professional advice is certified.

## R07. HEY Living Answers — full Generative UI engine

User intent determines output form. A short fact uses concise text; a numerical comparison uses a chart/table; navigating a city uses a real map; editing a file uses an editable artifact; building a calculator can generate a sandboxed working mini-app. Rich component vocabulary includes:

- Editorial: headings, block quotes, inline equations, citations, references and verified source links, collapsible details, comparison tables, badges limited to real statuses.
- Data: sortable/filterable virtual tables, graph/bar/line/pie/scatter/time series, trend lines, uncertainty bands, KPI tiles, export, unit and currency calculations using trusted math code.
- Controls: sliders, switches, segmented selections, radio/checkbox, dates, time ranges, file pickers, editable field/form validation, play/pause, progress, optimistic state with rollback where safe.
- Places: geocoded maps, multi-stop routes, travel time/ETA when backed by actual provider, nearby business data, opening hours with data freshness and verified reservation availability.
- Media: images, before/after, gallery/carousel, 3D/AR previews where supported, audio waveform/player, video/tracks, rich captions/transcripts, camera/screen previews with visible permission states.
- Work: editable doc/spreadsheet/presentation, source-code diff, interactive terminal/test output, calendar event, task board, milestone timeline, agents/delegations, mission logs, approval cards, file/result previews, provenance.
- Learning: flashcards, quizzes, interactive science/simulation diagrams, step-by-step visual math, hint/reveal, progress and teacher feedback.
- Generated app: calculator/planner/dashboard/custom workflow, bounded local state, save/export/reopen, declared data connectors and actions, versioned sandbox.

**Rendering contract:** model outputs a validated, versioned declarative scene/AST describing allowed components, data schema, trust level, source/citation IDs, event handlers by server-known action ID, state persistence scope, permissions and streaming/lifecycle states. Never trust raw model-produced HTML/JS/CSS as privileged app code. The renderer checks schema/size/depth/URL/safe markup, encodes text, enforces resource limits, a11y and content security, and denies unauthorized actions. Rich components using untrusted user-supplied code run in isolated iframe/webview/worker sandboxes (depending on platform) with explicit capability channel and bounded network/file access; clean fallback to static content on unsupported devices. Do not expose keys in component props. All host write actions go through Trust Kernel authorization, actual result receipt and optional undo. Data binds to real scoped services; stale/failed and unavailable states visible, without made-up numbers. A control never advertises a feature it cannot perform.

**Persistence:** Save widget to Space/project/conversation; versions, source data, interaction state and permissions persist only as authorized. On reconnect, restore from safe snapshot; if data source revoked show explanation and enable repair, never silently reuse stale privileged data. External links sourced from actual provider/reference records. User can copy/export where type permits. Voice can narrate widget changes, and screen reader/touch interaction must remain possible. Generated widgets have a resource/cost allowance and suspend when hidden as appropriate.

**Acceptance examples:** user asks for AI-cost calculator → functional sliders recalculate totals (server-backed pricing must show date); saves to Business Space → reload persists; switch account → unauthorized view fails; revoke price data → stale/disabled state; inject malicious model-output component → blocked; keyboard-only interaction passes; small-phone layout works; graph with missing data never invents data; click Deploy requires explicit real mandate and returns actual deployment receipt.

## R08. Detail Intelligence — owner-level attention to small important details

HEY analyzes high-stakes tasks for missing requirements, assumptions, scope gaps, dependencies, failure modes, ongoing costs, security, permissions, maintenance and user experience. Example for a business launch: payment-provider eligibility in the owner's country, bank/age/contract requirements, taxes, refund and support workflow, capacity, billing ceilings, backups, vendor outages, licensing, legal/privacy notices, signup/account recovery, measured performance, cancellation and accessibility. For software: exact build/runtime versions, contract matching, migrations, resource exhaustion, secret handling, rollback, edge cases, realistic tests, platform permission differences. For school: real teacher pain points, smartboard hardware/model/camera presence, offline internet, student data policy, localized materials, printable/exportable formats, substitutes, training and maintenance.

Present **explicit requirements**, **approved changes**, **inferred risks**, **recommended additions** separately. Ask approval before implementing materially new product direction or spending money. Avoid bloat or one generic disclaimer repeated every time. The attention engine may use deterministic domain checklists + model critique + source checks on valuable tasks; it may not claim certainty it does not have. Surface one highest-value overlooked item in brief mode, a fuller risk/dependency map in company-owner/advanced mode. Store rejected suggestions to avoid repetition. Measure precision of valid reminders vs nuisance rate; require user override and adjustable proactivity.

## R09. Product Integrity Engine — requirements that survive agent/context turnover

Every project/change has append-only auditable events (`proposed`, `clarified`, `approved`, `rejected`, `superseded`, `implemented`, `integrated`, `verified`, `released`, `regressed`). Canonical requirement record: stable ID, source conversation/document, exact excerpt/hash, author, created/changed time, privacy scope, approval status, priority, version, semantic summary, acceptance criteria, dependencies, affected systems, owner, implementation links, commits, tests, evidence artifacts, risk, rollout and rollback; sensitive texts ACL-scoped. Distinguish direct user commands vs speculation, quoted data, assistant ideas and tool outputs. Revisions are typed `adds`, `narrows`, `replaces`, `contradicts`, `clarifies`. Superseded versions remain readable to authorized owners. Never infer approval from silence.

On new requested work: retrieve relevant approved state and conflicting history, propose resolved behavior, diff old/new, show what will be preserved, and create/refine acceptance tests. Before claiming feature completion, trace each applicable requirement to UI/backend/db/provider/native tests and independent evidence; flag omissions, unverified claims, broken integrations, unavailable sources and regression to an old design. Avoid just “all requirements read”: verify actual agent got relevant text plus stable source references. Cross-chat personal memory requires user permission; school/org records cannot leak between tenants. Deletion must remove user-governed data according to retention policy without silently compromising legally required audit logs. Reconcile concurrent updates transactionally; conflict UI and rollback. Product Integrity must not hallucinate recovered history.

**Proof scenario:** A→Developer mode; B→Developer includes Teacher tools; C→all Modes customizable Spaces. After context reset, HEY returns final C design and records A/B lineage, identifies an implementation with a hard-coded Developer-only tools list as erroneous, finds code owner, generates failing test, verifies fix in application. Another example: prototype says successfully generated PDF but returned empty object → completion rejected.

## R16. Personal memory / Cosmos, research and situation

Cosmos uses event timeline + structured profile/project/fact graph + embeddings/search index as needed. Facts include source, confidence, timestamps, subject, consent scope, owner and supersession. Do not “save every single piece of info” indiscriminately; support user-selectable privacy scopes, private/no-memory modes, memory inbox and explicit deletion/corrections. Query current relevant memory without dumping all context into every prompt; retrieve evidence; explain when data is stale. Context compiler uses consented real-time situation/time/location/device/current document, not covert data harvesting. Cross-org/private data must never leak to shared school project. Universal search uses local docs/connectors/web with freshness, citations and injection defense; distinguish search results from instructions. Project DNA and Pinpoint Precision enforce consistent branding/approved assets and surgical edits across outputs.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/ANSWER_ENGINE_DETAIL.md`
**FULL original required, 30,954 characters. Read the full file in bounded sections from `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/ANSWER_ENGINE_DETAIL.md` before touching related components.** This file is deliberately not abbreviated or silently treated as read.

### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`

# Complete Widget Platform
## HEY V1 — Full-depth implementation specification

**Mission:** Turn widgets into a coherent internal app surface with safe extensibility.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Built-in widgets, app/service widgets, custom widgets, Forge-generated widgets, size variants, interaction contracts, refresh, privacy.
- Widget library, customization, drag/drop, stacking, dock, fullscreen.

# 2. User experience contract
- Every widget has compact/standard/expanded behavior when meaningful.
- Widget has clear title, primary information and contextual actions.
- Normal users see product concepts, not provider/internal IDs.
- Widgets can be embedded in Chat/Voice/Workspace where relevant.
- One widget never hijacks the page.

# 3. Architecture / runtime contract
- Widget manifest: id/version/title/category/sizes/data sources/permissions/actions/offline/cache/privacy/render contract.
- Sandbox external/custom widgets where possible.
- Shared lifecycle: mount, load, ready, stale, degraded, error, suspended, unmount.
- Background refresh is budgeted and pauseable.

# 4. Required state model
- loading
- ready
- stale
- refreshing
- degraded
- permission-required
- offline
- error
- suspended
- hidden

# 5. Failure and recovery catalog
- API failure → stale cached state + retry.
- Permission revoked → permission-required state.
- Malformed custom widget → sandbox crash boundary.
- Refresh loop → circuit breaker.

# 6. Security / privacy / trust requirements
- Least privilege per widget.
- No raw secrets in widget code.
- Sensitive widgets can be excluded from screenshots/public modes.
- Third-party content cannot issue HEY commands as authority.

# 7. Data model / persistence
- widget_manifests
- widget_instances
- widget_cache
- widget_permissions
- widget_versions
- widget_health

# 8. Events / telemetry contracts
- widget.loaded
- widget.action
- widget.refresh
- widget.degraded
- widget.crash
- widget.permission.requested

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Add/remove/reorder survives restart.
- Widget error isolated.
- Offline cached widget shows freshness.
- Custom widget permission revoke works.
- RTL and mobile variants work.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/12_COMPLETE_EVENT_STATE_MACHINE_CONTRACTS.md`

# Complete Event & State-Machine Contracts
## HEY V1 — Full-depth implementation specification

**Mission:** Give HEY deterministic lifecycle semantics across missions, generations, Live, permissions, Forge and artifacts.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Event naming/versioning, correlation IDs, idempotency, ordering, replay safety, state transitions.
- Mission, Task, Workflow, Generation, Artifact, Live, Permission, Forge, Device Handoff state machines.

# 2. User experience contract
- UI state must derive from canonical lifecycle, not ad-hoc booleans.
- Progress labels correspond to real states.
- Cancel/pause/resume behavior is consistent.

# 3. Architecture / runtime contract
- Events include schema version, actor, timestamp, correlation/causation IDs, project/user scope.
- State transitions validated server/runtime-side.
- Idempotent handlers for retries.
- Dead-letter/failed-event visibility in diagnostics.

# 4. Required state model
- created
- queued
- running
- waiting-user
- waiting-resource
- paused
- verifying
- completed
- partially-completed
- failed
- cancelled
- recovering

# 5. Failure and recovery catalog
- Duplicate event → idempotent no-op.
- Out-of-order event → reject/defer.
- Crash mid-transition → recover from durable state.
- Invalid transition → diagnostics alert.

# 6. Security / privacy / trust requirements
- Events must not contain secrets/raw sensitive context unnecessarily.
- Audit security-relevant transitions.

# 7. Data model / persistence
- events
- state_snapshots
- transition_history
- correlation_context
- dead_letters

# 8. Events / telemetry contracts
- hey.input.received
- intent.resolved
- mission.*
- task.*
- workflow.*
- tool.*
- permission.*
- artifact.*
- generation.*
- memory.*
- device.*
- live.*
- provider.*
- security.alert

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Retry duplicate command.
- Crash/restart during generation.
- Cancel during verify.
- Permission wait/resume.
- Event schema backward compatibility.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`

# Complete Artifact / Pinpoint / Versioning System
## HEY V1 — Full-depth implementation specification

**Mission:** Guarantee exact-change editing, protected-state preservation, branches, comparison and recovery.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Artifacts across images, video, audio, slides, docs, UI, code, workflows, agents, data transforms.
- Locks, intended delta, protected state, actual delta, QA, repair, snapshots, branches, merge.

# 2. User experience contract
- User can say 'change only X' and HEY visibly understands what is protected.
- Before/After/Changes inspector available when useful.
- Approved versions can be named/finalized.
- Destructive edits create restore points automatically.

# 3. Architecture / runtime contract
- ChangeSet contains request, intended changes, invariants, allowed side effects, source version, output version, verification.
- Artifact graph supports branch/compare/restore/merge.
- Type-specific differ compares pixels/objects/text/code/layout/schema as appropriate.
- Verifier detects unintended changes before completion.

# 4. Required state model
- draft
- generating
- verifying
- needs-repair
- approved
- final
- branched
- merged
- restored
- failed

# 5. Failure and recovery catalog
- Diff unavailable → warn and require conservative verification.
- Merge conflict → explicit resolution.
- Provider regenerated too broadly → reject/repair.
- Corrupt version → restore parent.

# 6. Security / privacy / trust requirements
- Artifact permissions inherit project scope.
- Version history immutable audit where required.
- No cross-project reference leakage.

# 7. Data model / persistence
- artifacts
- artifact_versions
- change_sets
- locks
- diffs
- approvals
- snapshots
- branches
- merge_records

# 8. Events / telemetry contracts
- artifact.created
- change.requested
- change.verified
- change.rejected
- lock.added
- version.approved
- branch.created
- restore.completed

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Single-object image edit preserves rest.
- Slide-three-only edit preserves other slides.
- Code API lock regression.
- Data schema lock regression.
- Branch/restore/merge tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
