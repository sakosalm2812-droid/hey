# HEY SPECIALIST BRIEF — 08 Complete Teacher Experience

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Teacher-mode lessons/worksheets/quizzes/answer keys/presentations, school-issued codes, smartboard bridge, multilingual printable/exportable materials; future school platform separate; real student privacy isolation.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Teacher, School, Gesture, Docs, Slides. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R13. HEY Board — Leaders smartboard-specific details

Distinct teacher smartboard helper/experience, not merely a separate presentation generator. For Android boards with uncertain camera/API support: investigate physical camera, supported Android version, external USB webcam, system microphone, OEM lockdown, accessibility APIs, local network, screen/control integration. Provide a real compatibility diagnostic report. Device management should not assume unsupported device-owner/kiosk provisioning; user previously rejected default kiosk/device-owner mode and teacher proximity confirmation. Enable teacher-created/deletable profiles with own wake word and a safe default/no-profile fallback. Teacher access may use school/S&A-approved codes; proper codes must be revocable and tied to organization policy, not universal backdoor. Principal dashboard/PIN/role only if securely designed. Offline core gesture controls and presentation profiles should remain available where hardware permits; local encrypted profiles, predictable background lifecycle and restart recovery; clear wake/active indicators, noise adaptation, camera/mic controls, per-board keys, health monitor/self-healing with loop prevention and user stop. Real teacher verification, no unapproved student face recognition, and public-display privacy. Substitutes can use safe generic profile when permitted. End-of-Class button/task ends class-relevant temporary permissions, clears sensitive on-screen content, saves/exports teacher work as configured and releases board sessions without deleting teacher artifacts. Do not advertise capability if Android hardware/OS cannot support it.

## R14. Teacher Mode and full school platform, distinguished

**HEY Teacher Mode** is one configurable HEY Space/tool collection with teacher identity/grade/subject/preferences, lesson outlines, concept explanations, differentiated difficulty, teacher-guided tutoring, PDF/textbook imports, worksheets, question banks, quizzes, exams, answer keys, activities, presentations, classroom visualizations, homework, rubrics, editable/exportable documents, printable materials, re-use, version history and smartboard integration. Teachers should request “change only question 4” or “simplify slide 3 without touching the others” with Pinpoint fidelity. Edits happen inside conversation-linked Studio. Teacher code grants school-specific mode only after server-side validation; code itself is not unrestricted administrative access. Kurdish/English/Arabic layout and print correctness tested. User remains free to add coding/model/creator tools from other categories.

**Full school management platform** is a separate ambitious integration surface with teacher/student/parent/admin roles, timetable, assignments/submission, grades, attendance, transport/bus reporting, announcements, end-of-class workflows, student progress, resource portals, permissions, audit and school policy; avoid copying or conflicting with existing principal-facing buses/attendance/grades system without integration agreements. Principal/IT requirements precede real data onboarding. Do not confuse “school platform planned” with something already sold/approved for use. HEY stays one common intelligence. School pilot can use teacher content and synthetic pupils before written school authorization for real student data. Child data, parent visibility, data retention, role isolation, audit, school contractual status and age-appropriate security require explicit governance.

**Teacher needs discovery:** a bilingual Sorani+English double-sided A4 form for all teachers asks (1) time-consuming/difficult tasks, (2) classroom/smartboard/equipment/systems problems, (3) tasks to simplify and desired tools, (4) anything teachers would improve at school; optional teacher name/subject/grade and priority field. Two questions per page, large writing areas, school-first branding; `S&A × Leaders` only if school authorizes co-brand. Completed feedback must become a needs register, with user-approved priorities, measurable acceptance criteria and feature owner; teacher requests are user research, not automatically all approved development scope.

## R18. Full studios and pinpoint output

Image: text-to-image, image editing, variations, masks/object-level selection, reference styles and locked subject consistency; edit exactly requested region. Video: prompt/image/storyboard/first-last-frame → clips, multi-shot assembly, script, scene planning, continuity, camera motion, retime/split/trim/crop, titles, subtitles, voiceover, audio ducking, source/project provenance, long-form via scenes and actual export. Audio/music/speech: transcription, enhancement, narration, TTS, licensed sound/music generation, dubbing, translation, diarization if supported. Motion: kinetic typography, charts, transitions, product/UI demos and editable scene graphs. Documents/books/PDF/presentations/spreadsheets: editable layouts, graphs, speaker/content synchronization, formulas, pagination, language, print/export and revision/undo. Code/software/websites: repo editing, semantic diff, build/run/tests, previews, dependency/license checks and secure file/secret controls.

Embedded studio: user requests creation inside Chat/Voice → a synchronized Studio opens in same conversation with current project/context; user can keep talking, change only page/slide/shot three, collapse/expand full Studio without losing history, see structured progress and a real generated artifact. Dedicated Studio route opens same state, not a duplicate. Do not fabricate “video generated” when only an image/storyboard exists. Creation providers may be usage-priced; plan allowances and capability fallback. Media output must respect relevant content licensing and rights and should never imply an external provider has been called when not.

## R19. Organizations, family, marketplace, API, billing

Three top-level S&A founders/owners govern HEY according to original source; audit owner commands and use strong MFA/re-auth; no fourth top-level owner via normal API flow; public extension publication requires all three owner's authorization if that original rule remains approved; critical proven security fixes have monitored emergency process/notification. Organizations use role-based membership, separate data, entitlements, audit and policy. If HEY supports parent/child/family accounts, implement careful privacy, permissions and age restrictions; do not silently expose a child's conversation to unrelated guardians. Marketplace extensions have signed manifest, trust review, dependency scanning, versions, sandbox, publication and quarantine/revocation. Public developer APIs must be versioned and explicit about quota/permissions and avoid exposing internal secrets.

Subscription layers may include Free, Pro, Elite and institution licensing; plan entitlements are independent of payment provider; metering includes tokens, tool calls, expensive media, GPU minutes, storage and concurrent agents. Do not promise unlimited costly usage under a flat plan. Payment providers must be legal/available for S&A's actual jurisdiction and merchant eligibility (Iraq cannot be assumed supported by Stripe/Paddle); use approved adult/business representative for provider and school contracts as appropriate. Refund/support/failed payment/webhook dedup and transactional ledger are production requirements. Avoid storing card data directly.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/07_COMPLETE_ARTIFACT_PINPOINT_VERSIONING.md`

# Complete Artifact / Pinpoint / Versioning System
## HEY V1 — Full-depth implementation specification

**Mission:** Guarantee exact-change editing, protected-state preservation, branches, comparison and recovery.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Artifacts across images, video, audio, slides, docs, UI, code, workflows, agents, data transforms.
- Locks, intended delta, protected state, actual delta, QA, repair, snapshots, branches, merge.

# 2. User experience contract
- User can say 'change only X' and HEY visibly understands what is protected.
- Before/After/Changes inspector available when useful.
- Approved versions can be named/finalized.
- Destructive edits create restore points automatically.

# 3. Architecture / runtime contract
- ChangeSet contains request, intended changes, invariants, allowed side effects, source version, output version, verification.
- Artifact graph supports branch/compare/restore/merge.
- Type-specific differ compares pixels/objects/text/code/layout/schema as appropriate.
- Verifier detects unintended changes before completion.

# 4. Required state model
- draft
- generating
- verifying
- needs-repair
- approved
- final
- branched
- merged
- restored
- failed

# 5. Failure and recovery catalog
- Diff unavailable → warn and require conservative verification.
- Merge conflict → explicit resolution.
- Provider regenerated too broadly → reject/repair.
- Corrupt version → restore parent.

# 6. Security / privacy / trust requirements
- Artifact permissions inherit project scope.
- Version history immutable audit where required.
- No cross-project reference leakage.

# 7. Data model / persistence
- artifacts
- artifact_versions
- change_sets
- locks
- diffs
- approvals
- snapshots
- branches
- merge_records

# 8. Events / telemetry contracts
- artifact.created
- change.requested
- change.verified
- change.rejected
- lock.added
- version.approved
- branch.created
- restore.completed

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Single-object image edit preserves rest.
- Slide-three-only edit preserves other slides.
- Code API lock regression.
- Data schema lock regression.
- Branch/restore/merge tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**FULL original required, 254,934 characters. Read the full file in bounded sections from `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md` before touching related components.** This file is deliberately not abbreviated or silently treated as read.

### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/22_COMPLETE_CHAT_VOICE_STUDIO_COMPOSITION.md`

# Complete Conversation Surface + Embedded Studios
## HEY V1 — Full-depth implementation specification

**Mission:** Make Chat, Voice and creation/editing feel like one continuous HEY experience.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat/Voice modality switching, embedded studios, artifact cards, context persistence, voice-call UI, studio full-screen expansion, conversational edits.
- Image/video/audio/presentation/document/storyboard/code/research composition.

# 2. User experience contract
- Sign-in lands here.
- Chat and Voice share the exact same conversation and project context.
- Voice is call-like and premium, not generic mic page.
- Creation requests spawn embedded Studio within conversation/workspace.
- Dedicated Studio route opens same artifact/state; not separate duplicate state.
- Chat/Voice commands can manipulate current studio using Pinpoint locks.

# 3. Architecture / runtime contract
- Conversation session owns references to active project, artifact, studio session and Live session.
- Studio session has canonical artifact ID/version and is rendered in embedded/full modes.
- Voice and text inputs feed same HEY Brain/orchestration.
- UI event bus/state store synchronizes studio changes back to conversation.

# 4. Required state model
- chat
- voice-idle
- voice-listening
- voice-thinking
- voice-speaking
- studio-embedded
- studio-expanded
- studio-minimized
- generation-running
- waiting-user
- error

# 5. Failure and recovery catalog
- Studio component crash → conversation remains alive.
- Voice disconnect → fallback to Chat without context loss.
- Provider failure → studio retains prompt/assets.
- Route change → persist unsaved studio draft.

# 6. Security / privacy / trust requirements
- Mic/screen/camera visible indicators.
- Studio file access scoped.
- Voice transcript privacy settings respected.

# 7. Data model / persistence
- conversations
- conversation_turns
- studio_sessions
- active_artifact_refs
- voice_sessions
- drafts

# 8. Events / telemetry contracts
- conversation.mode.changed
- studio.opened
- studio.expanded
- artifact.changed
- voice.started
- voice.interrupted

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Chat→Voice same context.
- Voice→Chat same context.
- Chat request video opens embedded studio.
- Voice slide-three-only edit modifies only slide three.
- Reload restores studio draft.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
