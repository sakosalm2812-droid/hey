# HEY SPECIALIST BRIEF — 04 Lightweight Edge Device Mesh

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** Lightweight native helpers, accurate platform capability matrix, user-approved OS action adapters, signed mandates, pairing/trust, resource budgets, recovery and device handoff; no giant local AI required.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Edge, Actions, Platform, Security. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R11. HEY Flow dictation, native VoiceOS and gestures are separable products

**HEY Flow:** global shortcut/toolbar/compact overlay, start/stop, microphone state, speech recognition, auto punctuation, capitalization, filler cleanup, custom vocabulary, snippets, rewrite selected text, translation if requested, dictation into actual focused application where permitted, per-app settings and offline/local/cloud selection. Make text insertion atomic or undoable and safe: preserve cursor/selection, detect focus switches and private fields, avoid sending sensitive text to wrong app, show targeted preview on ambiguous actions. If an app blocks global injection, offer clipboard/authorized share fallback. Distinguish transcription from commands (“open file” spoken while dictating should not launch a file without explicit mode/intent).

**VoiceOS:** “open VS Code”, “locate this file”, “rename it”, “organize my desktop”, “change slide” uses shared actual computer-use action engine; scoped approvals, confirmation where appropriate, postcondition and action logs. Controlled by Voice, keyboard/command palette or screen selection; no action falsely reports success because OS adapter returned an optimistic result. Guide/Assist/Act levels. **Gesture mode** can be launched alone by a user who never talks to HEY. Gesture controls function on Android smartboards or attached cameras subject to hardware realities; users can map gestures per app, workspace, device and teacher profile.

## R13. HEY Board — Leaders smartboard-specific details

Distinct teacher smartboard helper/experience, not merely a separate presentation generator. For Android boards with uncertain camera/API support: investigate physical camera, supported Android version, external USB webcam, system microphone, OEM lockdown, accessibility APIs, local network, screen/control integration. Provide a real compatibility diagnostic report. Device management should not assume unsupported device-owner/kiosk provisioning; user previously rejected default kiosk/device-owner mode and teacher proximity confirmation. Enable teacher-created/deletable profiles with own wake word and a safe default/no-profile fallback. Teacher access may use school/S&A-approved codes; proper codes must be revocable and tied to organization policy, not universal backdoor. Principal dashboard/PIN/role only if securely designed. Offline core gesture controls and presentation profiles should remain available where hardware permits; local encrypted profiles, predictable background lifecycle and restart recovery; clear wake/active indicators, noise adaptation, camera/mic controls, per-board keys, health monitor/self-healing with loop prevention and user stop. Real teacher verification, no unapproved student face recognition, and public-display privacy. Substitutes can use safe generic profile when permitted. End-of-Class button/task ends class-relevant temporary permissions, clears sensitive on-screen content, saves/exports teacher work as configured and releases board sessions without deleting teacher artifacts. Do not advertise capability if Android hardware/OS cannot support it.

## R15. HEY Edge: tiny trusted native companion + Device Mesh

Cloud/hosted HEY Brain need not run on user laptop. Edge has minimal idle footprint; real OS adapters for file/window/process/screen/clipboard/shortcuts/notifications, per-app automation, mic/wake, local gesture inference and verified device actions; no fake platform parity. Windows: UI Automation, window/process/filesystem/input APIs; macOS: Accessibility, ScreenCaptureKit, Shortcuts/AppleScript where legitimate; Linux: xdg portals, Wayland/X11, DBus; Android: intents, foreground-service notifications, user-enabled accessibility where appropriate, MediaProjection, camera, share flows; iOS/iPadOS: App Intents/Shortcuts/share extensions/Live Activities, no privileged unrestricted background terminal for ordinary apps; Web/PWA: constrained browser APIs. Enforce signed scoped mandates, device registration/pairing, nonce/replay/expiry and audit, revocation on target change, local policy; immediate stop and least-privilege. Device Mesh can handoff projects/mission state by authorized encrypted channel and choose device based on active capabilities, not invent access to an offline device. Conserve RAM/CPU/battery on older hardware; disable fancy effects as appropriate. No raw screen/audio retention without user's explicit settings.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/09_COMPLETE_PLATFORM_CAPABILITY_MATRIX.md`

# Complete Platform Capability Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Define truthful, strongest-possible behavior for web, PWA, Windows, macOS, Linux, Android and iOS.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Chat, Voice, Live, screen/camera, computer control, background helper, Dynamic Island, notifications, files, gestures, local models, device handoff, install/update.
- Per-platform fallback behavior.

# 2. User experience contract
- UI labels unavailable capabilities honestly.
- Same conceptual feature can have platform-specific implementation.
- User sees the strongest supported fallback rather than a dead button.

# 3. Architecture / runtime contract
- Capability registry includes platform support: native/full, supported-with-limits, guided-only, unavailable.
- Runtime capability detection, not user-agent assumptions alone.
- Native helper interfaces are abstracted behind capability contracts.

# 4. Required state model
- supported
- supported-limited
- permission-required
- unsupported
- temporarily-unavailable
- degraded

# 5. Failure and recovery catalog
- OS API unavailable → fallback.
- Permission denied → guide.
- Browser restrictions → native/PWA suggestion.
- Background suspension → cloud/server durable task fallback.

# 6. Security / privacy / trust requirements
- No fake arbitrary iOS control.
- No security bypass.
- Platform permissions explicit.

# 7. Data model / persistence
- platform_capabilities
- device_capabilities
- capability_health
- permission_grants

# 8. Events / telemetry contracts
- capability.detected
- capability.unavailable
- fallback.selected
- native.helper.connected

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Windows closed-window island.
- PWA install.
- Android assistant integration where supported.
- iOS fallback contracts.
- Linux/macOS background tests.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/10_COMPLETE_PERMISSIONS_RISK_MATRIX.md`

# Complete Permissions, Risk & Confirmation Matrix
## HEY V1 — Full-depth implementation specification

**Mission:** Apply least privilege and proportional confirmation to every HEY action.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Mic, camera, screen, files, browser, computer control, clipboard, terminal, messaging, payments, devices, smart home, memory, integrations.
- Once/session/timed/mission/persistent scopes and risk classes.

# 2. User experience contract
- User sees what permission is needed, why, scope, duration and revoke path.
- Low-risk repeated actions can be streamlined after explicit grant.
- High-impact actions show target/content/consequence before execution.
- Trust Center provides global view and Revoke All.

# 3. Architecture / runtime contract
- Central permission manager is authoritative; agents/tools cannot self-authorize.
- Risk engine combines action class, target sensitivity, reversibility, destination and user policy.
- Grant records include scope/expiry/source.

# 4. Required state model
- not-granted
- prompting
- granted-once
- granted-session
- granted-timed
- granted-mission
- granted-persistent
- expired
- revoked
- blocked

# 5. Failure and recovery catalog
- Permission service unavailable → fail closed.
- Grant expired mid-task → pause and request.
- Target changes after approval → invalidate approval.
- OS permission mismatch → reconcile.

# 6. Security / privacy / trust requirements
- Fail closed.
- No founder bypass.
- Secrets isolated.
- Audit sensitive grants/actions.
- Prompt-injected content cannot approve itself.

# 7. Data model / persistence
- permissions
- permission_grants
- risk_assessments
- approval_requests
- revocations
- audit_events

# 8. Events / telemetry contracts
- permission.requested
- permission.granted
- permission.expired
- action.approval.required
- action.approved
- action.blocked

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Once/session/timed expiry.
- Message-send preview.
- Delete-file confirmation.
- Computer-control target-change invalidates prior confirmation.
- Revoke All halts active sensitive actions.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/11_COMPLETE_BACKGROUND_STATE_MATRIX.md`

# Complete Background / Closed-App Runtime
## HEY V1 — Full-depth implementation specification

**Mission:** Make HEY coherent across foreground, minimized, closed-main-window, lock, termination and offline states.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Native helper, tray/menu bar, Dynamic Island, wake word, reminders, schedules, missions, cloud jobs, file transfers, notifications, device handoff.
- Background privacy and resource budgets.

# 2. User experience contract
- Closing window does not silently terminate HEY unless user chose that behavior.
- Visible indicator for background sensing.
- Camera/screen normally stop on close unless explicit visible background mode.
- Cloud tasks can continue after local window closes.

# 3. Architecture / runtime contract
- Native supervisor owns durable local background capabilities.
- Server scheduler owns durable cloud jobs.
- Main UI reconnects to canonical task state rather than restarting.
- Background tasks have resumable checkpoints where possible.

# 4. Required state model
- F0 foreground
- F1 unfocused
- F2 minimized
- F3 main closed/helper alive
- F4 locked
- F5 terminated
- F6 offline
- F7 remote device

# 5. Failure and recovery catalog
- Helper crash → restart/recover state.
- Network loss → queue/retry.
- OS suspends app → server durable fallback where valid.
- Task cannot run background → explicit pause.

# 6. Security / privacy / trust requirements
- Background sensing requires persistent visible indicator and consent.
- No covert camera/screen.
- Lock-screen notifications redact sensitive data.

# 7. Data model / persistence
- background_preferences
- background_jobs
- task_checkpoints
- helper_sessions
- sensing_sessions

# 8. Events / telemetry contracts
- app.backgrounded
- helper.started
- helper.stopped
- task.resumed
- sensing.paused
- window.reopened

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Close main window during timer/mission.
- Lock device.
- Network drop/resume.
- Helper restart.
- Full quit stops local background surfaces.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `03_INTERACTION_PLATFORM/03_PLATFORM_OUTCOME_PARITY.md`

# Platform Outcome Parity

HEY targets the same **user-level capabilities** across Windows, macOS, Linux, Android, iOS/iPadOS and web/PWA. The internal method can differ because operating systems expose different APIs.

Shared HEY Brain sits above platform Capability Adapters. Each adapter declares what native mechanisms are available, permission state and health. If one device cannot directly perform a step, HEY may compose official OS automation, app intents/shortcuts, accessibility APIs, screen/camera guidance, browser capabilities, a native companion, trusted-device handoff or institution-managed device controls to achieve the same user goal where technically legitimate.

### Examples
Windows: native helper, UI Automation, screen capture, PowerShell/terminal, window/process/filesystem APIs.
macOS: Accessibility API, ScreenCaptureKit, Shortcuts/AppleScript where appropriate, native helper/menu bar.
Linux: Wayland/X11/desktop portals, DBus, shell/native services.
Android: intents, accessibility service when justified/user-enabled, MediaProjection, camera/mic, foreground services, notifications, sideloadable APK before store distribution.
iOS/iPadOS: App Intents, Shortcuts, universal links/URL schemes, ReplayKit/screen broadcast where applicable, camera/mic, Live Activities/Dynamic Island, share extensions, document picker, background tasks within OS limits, and MDM/supervision for eligible institutional deployments.
Web/PWA: manifest/service worker/install, getDisplayMedia/getUserMedia, File System Access where supported, notifications/share/file handlers.

Do not assume an unrestricted iOS terminal exists for ordinary third-party apps. Use the strongest legitimate composition of supported mechanisms instead of building against a false privilege model.

Store publication is not required immediately. Architecture must support PWA, desktop installers and legitimate sideload/institutional distribution paths until App Store/Play Store distribution becomes feasible.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
