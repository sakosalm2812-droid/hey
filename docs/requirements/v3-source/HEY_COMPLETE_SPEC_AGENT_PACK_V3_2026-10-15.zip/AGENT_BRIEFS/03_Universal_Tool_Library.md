# HEY SPECIALIST BRIEF — 03 Universal Tool Library

**Authoritative required attachments:** `00_START_HERE.md`, `01_LATEST_APPROVED_REFINEMENTS.md`, `02_MODEL_FLEET_AND_TRAINING.md`, `03_PRODUCT_INTEGRITY_AND_EXECUTION.md`, full `ARCHIVES/HEY_FINAL_ABSOLUTE_SOURCE_OF_TRUTH_COMBINED.md`, `ARCHIVES/HEY_WORK_MODE_MASTER_BUILD_PROGRAM.md` and indexed applicable `SOURCE_SPLIT/HEY_FINAL/` files.

**Your ownership:** One typed capability registry; semantic search, discovery, install/launch/configure/revoke lifecycle; platform/permission/health/price states, no fake buttons; cross-category entrypoints.

**Mandatory procedure:** Read complete applicable source sections and hashes; record coverage. Inspect actual current HEAD/source; identify original requirements + latest refinements + supersession; derive typed contracts and observable user acceptance paths, implement frontend/backend/provider/db/native adapters as applicable; independently test real end-to-end; report exact branch/commit/entrypoint/expected/actual/negative tests and external blockers. No mocked successes, no unspecified feature invention, no self-issued completion, no duplicate global runtime. Export necessary API contracts for integration. Follow all detailed text in relevant original sections, not merely this overview.

**Proof requirement:** Include at least one real normal-user path, one permission-denied or platform-unsupported case, one interruption/recovery path and one adversarial/regression test; cite exact current requirement IDs. Never expose secrets.


---

# SELF-CONTAINED SOURCE PACKET — scoped full original sections and newest refinements

**Binding:** Below sections are reproduced unabridged from current attached original spec and latest requirements. A specialist must still retrieve applicable larger catalog and visual master sections by targeted search when its work affects that part of the product. DO NOT claim to have read anything not actually received.

**Required golden-journey domains:** Tool Library, Widgets, Forge, Agents. See `../06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `../E2E_ACCEPTANCE_CASES.jsonl` for exact actions and pass/fail clauses.

## Latest approved refinement sections (complete)

## R05. Tools Library + universal discovery + command palette

One canonical capability registry supports installed/available/experimental/platform-constrained entries, per-person/account/organization permissions, costs, dependency health, entitlements and discoverability. Search semantic natural-language requests e.g. “write by speaking everywhere”, “control this slide with my hand”, “edit slide three only”, “run an agent over my code”, “teach chemistry using a quiz” and return actual launchable tools and a truthful support explanation. Each tool provides name/category/description, examples, launch/stop, configure, permissions, status, platform matrix, model/provider dependencies, usage/allowance display, errors/help/version. Provide Favorites, Recently Used, popular/recommended, pin/reorder/add shortcuts, context-aware suggestion and advanced mode. Do not list internal agents as ordinary apps. Tool availability must be evaluated server/runtime side, not only with hidden UI flags.

Tool launch lifecycle: DISCOVERED → PERMISSION_REQUIRED/READY → STARTING → RUNNING → PAUSED/DEGRADED/FAILED → STOPPED, with durable mission linkage when needed. Missing plugin or disconnected provider launches a concrete connection/permissions flow, not fake success.

## R06. Custom Spaces — the user's own operating environment

A Space is a persistently named user- or organization-scoped environment containing selected tools, widgets, project contexts, layouts, shortcuts, saved Living Answers, models, language/theme tweaks and filtered activity. Provide create/rename/duplicate/archive/delete, import/export if safe, default templates, blank canvas, natural-language Space setup with preview, pinned catalog selection, drag/reorder/resize/snap/stack/minimize/dock, multiple view layouts, task/project tabs, undo/redo/snapshots. A Developer may add Teacher tools; a Teacher may add Software Studio and Model Lab. Spaces do not create authorization: access depends on the underlying user/org permission for every item. Organization-managed spaces inherit policy but cannot silently overwrite personal Spaces. Context switch cannot lose draft or active tasks; preserve safe mission continuity. User controls startup Space and workspace defaults. Load only active widgets and refresh them within resource budgets.

Workspace widgets: clock/date/timezone, weather, calendar, task list, routines, notes, project status, music/media, timer, notifications, news, quote, prayer/Quran/Hadith if enabled, HEY/S&A stats where authorized, device battery/health, research, terminal, code, audio, image, video, saved art, agent monitors. Sensitivity is location/time dependent: user controls location and religious widgets; public-display mode conceals private content. Weather/prayer info has source and freshness. Broken widget cannot crash full workspace; stale data explicitly labeled.

## R07. HEY Living Answers — full Generative UI engine

User intent determines output form. A short fact uses concise text; a numerical comparison uses a chart/table; navigating a city uses a real map; editing a file uses an editable artifact; building a calculator can generate a sandboxed working mini-app. Rich component vocabulary includes:

- Editorial: headings, block quotes, inline equations, citations, references and verified source links, collapsible details, comparison tables, badges limited to real statuses.
- Data: sortable/filterable virtual tables, graph/bar/line/pie/scatter/time series, trend lines, uncertainty bands, KPI tiles, export, unit and currency calculations using trusted math code.
- Controls: sliders, switches, segmented selections, radio/checkbox, dates, time ranges, file pickers, editable field/form validation, play/pause, progress, optimistic state with rollback where safe.
- Places: geocoded maps, multi-stop routes, travel time/ETA when backed by actual provider, nearby business data, opening hours with data freshness and verified reservation availability.
- Media: images, before/after, gallery/carousel, 3D/AR previews where supported, audio waveform/player, video/tracks, rich captions/transcripts, camera/screen previews with visible permission states.
- Work: editable doc/spreadsheet/presentation, source-code diff, interactive terminal/test output, calendar event, task board, milestone timeline, agents/delegations, mission logs, approval cards, file/result previews, provenance.
- Learning: flashcards, quizzes, interactive science/simulation diagrams, step-by-step visual math, hint/reveal, progress and teacher feedback.
- Generated app: calculator/planner/dashboard/custom workflow, bounded local state, save/export/reopen, declared data connectors and actions, versioned sandbox.

**Rendering contract:** model outputs a validated, versioned declarative scene/AST describing allowed components, data schema, trust level, source/citation IDs, event handlers by server-known action ID, state persistence scope, permissions and streaming/lifecycle states. Never trust raw model-produced HTML/JS/CSS as privileged app code. The renderer checks schema/size/depth/URL/safe markup, encodes text, enforces resource limits, a11y and content security, and denies unauthorized actions. Rich components using untrusted user-supplied code run in isolated iframe/webview/worker sandboxes (depending on platform) with explicit capability channel and bounded network/file access; clean fallback to static content on unsupported devices. Do not expose keys in component props. All host write actions go through Trust Kernel authorization, actual result receipt and optional undo. Data binds to real scoped services; stale/failed and unavailable states visible, without made-up numbers. A control never advertises a feature it cannot perform.

**Persistence:** Save widget to Space/project/conversation; versions, source data, interaction state and permissions persist only as authorized. On reconnect, restore from safe snapshot; if data source revoked show explanation and enable repair, never silently reuse stale privileged data. External links sourced from actual provider/reference records. User can copy/export where type permits. Voice can narrate widget changes, and screen reader/touch interaction must remain possible. Generated widgets have a resource/cost allowance and suspend when hidden as appropriate.

**Acceptance examples:** user asks for AI-cost calculator → functional sliders recalculate totals (server-backed pricing must show date); saves to Business Space → reload persists; switch account → unauthorized view fails; revoke price data → stale/disabled state; inject malicious model-output component → blocked; keyboard-only interaction passes; small-phone layout works; graph with missing data never invents data; click Deploy requires explicit real mandate and returns actual deployment receipt.

## R09. Product Integrity Engine — requirements that survive agent/context turnover

Every project/change has append-only auditable events (`proposed`, `clarified`, `approved`, `rejected`, `superseded`, `implemented`, `integrated`, `verified`, `released`, `regressed`). Canonical requirement record: stable ID, source conversation/document, exact excerpt/hash, author, created/changed time, privacy scope, approval status, priority, version, semantic summary, acceptance criteria, dependencies, affected systems, owner, implementation links, commits, tests, evidence artifacts, risk, rollout and rollback; sensitive texts ACL-scoped. Distinguish direct user commands vs speculation, quoted data, assistant ideas and tool outputs. Revisions are typed `adds`, `narrows`, `replaces`, `contradicts`, `clarifies`. Superseded versions remain readable to authorized owners. Never infer approval from silence.

On new requested work: retrieve relevant approved state and conflicting history, propose resolved behavior, diff old/new, show what will be preserved, and create/refine acceptance tests. Before claiming feature completion, trace each applicable requirement to UI/backend/db/provider/native tests and independent evidence; flag omissions, unverified claims, broken integrations, unavailable sources and regression to an old design. Avoid just “all requirements read”: verify actual agent got relevant text plus stable source references. Cross-chat personal memory requires user permission; school/org records cannot leak between tenants. Deletion must remove user-governed data according to retention policy without silently compromising legally required audit logs. Reconcile concurrent updates transactionally; conflict UI and rollback. Product Integrity must not hallucinate recovered history.

**Proof scenario:** A→Developer mode; B→Developer includes Teacher tools; C→all Modes customizable Spaces. After context reset, HEY returns final C design and records A/B lineage, identifies an implementation with a hard-coded Developer-only tools list as erroneous, finds code owner, generates failing test, verifies fix in application. Another example: prototype says successfully generated PDF but returned empty object → completion rejected.

## R17. Agents, Intelligence Council, Forge, Evolution, automations and proactivity

Model and agents are separate axes. A 229-specialist historical catalog is neither an engine limit nor 229 always-running expensive models. Agent registry supports families → specialists → temporary specialists, lazy retrieval, typed contracts, scope, permissions, health/cost/timeout/retry/evaluation/retirement. Evidence Board and council select only helpful participants (Architect, Builder, Verifier, Contrarian, Flaw Hunter, Opportunity Hunter, Missing-Requirement Hunter, UX/Business/Teacher etc.); preserve minority evidence and stop debate when marginal gain is low. Deterministic policies, math, schedulers, validators and classifiers should not waste large-model tokens. Forge safely synthesizes tools/workflows/agents/actions if existing tools do not suffice, with source/dependency analysis, sandbox/dry run, Risk Twin + Solution Twin, tests, preview, opt-in save, versioning and revocation. Evolution observes useful advancements and makes evidence-backed proposals; ordinary owners approve new internal product evolution, critical security emergency procedure may permit fast fixes with transparent rollback and notifications. Never let an AI self-approve privileged change.

Automations are durable event/time schedules, with timezone/DST, idempotency, atomic outbox, retry with backoff, poison queue, pause/resume/recovery/revoke, visible next-run and last-run receipts. Morning/Focus/Review modes and proactive nudges use consent and configurable quiet hours; no spam or repetitive suggestions. Real scheduled work must outlive browser tab closure where legitimate and report unavoidable external blocks.

## Original product source sections (complete)

### SOURCE FILE: `00_FOUNDATION/00_READ_ME_FIRST.md`

# HEY — FINAL ABSOLUTE SOURCE OF TRUTH

This folder is the final authoritative product/engineering specification for **HEY** and supersedes every earlier HEY planning document. There is no V1/V2 split in this source: the product is simply HEY.

## Precedence
1. Files in `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION` and `06_PROMPTS` contain the newest decisions and override conflicting older wording.
2. `01_DETAILED_SYSTEM_SPECS` preserves the exhaustive earlier capability, design, answer, motion and subsystem detail so no approved capability is lost. Where it conflicts with newer files, newer files win.
3. No `.txt` deliverables are used.

## Product rule
Do not stop because a subsystem merely works. Preserve what is strong, replace what is weak, integrate missing layers, test failures, independently verify the outcome, and stop only when the subsystem reaches the strongest production implementation justified by the platform and current engineering reality.

## HEY is one intelligence
Users interact with HEY, not with a giant catalog of bots. Internally HEY may use unlimited specialized agents, models, deterministic engines, tools, workflows and providers. Only the relevant subset is retrieved for a mission.

## Completion means end-to-end
A feature is complete only when applicable discovery, UX, backend, persistence, permissions, authorization, security, abuse/cost protection, recovery, verification, performance, accessibility, localization, tests, tutorials/help, observability and production behavior all pass. UI-only, backend-only, mocked, unverified and partially integrated features are not complete.

## Owners
There are exactly three top-level HEY owners. Any one owner can approve ordinary internal evolution. Public third-party extension publication requires all three. Proven critical security fixes may auto-deploy under emergency policy and must immediately notify all three owners with exact changes, evidence and rollback.

## Budget
HEY is no longer free-only. Paid infrastructure/models are allowed when their measurable improvement justifies cost. Architecture remains provider-agnostic and cost-aware.


---



### SOURCE FILE: `00_FOUNDATION/01_COMPLETION_AND_REPLACEMENT_CONTRACT.md`

# Completion & Replacement Contract

For every subsystem the implementation agent must: audit current code → preserve unique strengths → replace weaker architecture when justified → connect every missing layer → remove obsolete duplicates after safe migration → test normal and failure paths → independently verify → benchmark where relevant → leave rollback evidence.

Maturity is `MISSING → DESIGNED → IMPLEMENTING → FUNCTIONAL → INTEGRATED → VERIFIED → PRODUCTION_READY`. Anything below `PRODUCTION_READY` continues to be worked on.

When two implementations overlap, keep the stronger one and transplant any unique useful behavior from the weaker one before removing it. A public rename is allowed when it materially improves the product; all public-facing renames must be reported afterward.

Long tasks must be cancellable. Pause/resume/checkpointing is required where technically useful. Destructive or large edits create restore points. External side effects are verified where possible.

A feature cannot be called complete from a page existing, a backend function existing, tests passing in isolation, or an HTTP 200. The actual user goal must work end-to-end.


---



### SOURCE FILE: `04_SECURITY_GOVERNANCE/02_SECURITY_AUTONOMY_AND_PERMISSIONS.md`

# Security, Autonomy & Permissions

HEY maximizes capability while enforcing least privilege. Security lifecycle: **prevent → minimize → contain → detect → stop → recover → learn**.

Automation/workflow autonomy levels:
- Ask Every Time;
- Smart Approval (routine/reversible steps proceed, meaningful high-risk steps ask);
- Full Execution within the workflow's explicitly granted scope;
- Custom rules by app, destination, action class, budget, time and data scope.

Agents cannot grant themselves permission. Server/runtime authorization remains authoritative. Prompt/page/document content is untrusted data and cannot override user/system policy. High-impact target changes invalidate earlier approval.

Trust Center exposes microphone, camera, screen, background activity, integrations, devices, agent/workflow permissions, Cosmos privacy, local/cloud routing, once/session/timed/mission/persistent grants, Revoke All and Emergency Stop.


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/01_COMPLETE_NAVIGATION_INFORMATION_ARCHITECTURE.md`

# Complete Navigation & Information Architecture
## HEY V1 — Full-depth implementation specification

**Mission:** Make every important HEY capability discoverable without exposing internal complexity.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Conversation Surface (Chat/Voice) is the default signed-in destination.
- Primary global navigation, contextual navigation, Create hierarchy, Explore More, + Add, Universal Search, Command Palette, recent/favorites, mobile bottom nav.
- Information scent, labels, hierarchy, advanced-mode disclosure, role/device/mode adaptations.
- Deep-link routing and return-to-previous-context behavior.

# 2. User experience contract
- Primary normal-user nav: Chat/Voice entry, Live, Projects, Create, Cosmos, Tasks/Missions, Widgets/Workspace, Search, Notifications, Settings.
- Important Create actions visible before Explore More: Image, Video, Presentation, Document, Audio.
- `+ Add` lets users pin additional capabilities without seeing raw agents.
- Advanced tools are discoverable through Advanced Mode, Search, Forge, Developer—not cluttering normal nav.
- Navigation never loses active project/conversation/artifact state.
- Breadcrumbs appear only where hierarchy is genuinely useful.
- Mobile uses bottom nav + More; desktop uses collapsible rail; tablet uses adaptive split shell.

# 3. Architecture / runtime contract
- Central route registry with capability metadata, permissions, feature flags, platform support and discovery rank.
- Navigation state is distinct from task/artifact state.
- Deep links restore intended resource with permission checks.
- Startup route resolver respects newest rule: default Conversation Surface, then explicit user override, then safe resume.
- Explore More reads from capability registry but filters by audience/platform/entitlements.

# 4. Required state model
- anonymous
- authenticating
- signed-in-first-run
- signed-in-returning
- conversation-active
- immersive-live
- embedded-studio
- full-studio
- modal
- offline
- unsupported-platform
- advanced-mode

# 5. Failure and recovery catalog
- Unknown/deprecated route → safe redirect with explanation.
- Feature flag off → remove dead nav and provide fallback if linked.
- Unauthorized deep link → permission/entitlement explanation.
- Stale project/artifact link → recovery and search, not blank page.
- Navigation state corruption → restore last valid route.

# 6. Security / privacy / trust requirements
- Never use client-only nav hiding as authorization.
- Sensitive routes require server/runtime enforcement.
- Do not leak advanced/debug routes to normal users.
- External URLs opened safely and clearly distinguished.

# 7. Data model / persistence
- navigation_preferences
- pinned_capabilities
- recent_capabilities
- startup_destination
- feature_flags
- entitlements
- capability_manifest
- workspace_route_state

# 8. Events / telemetry contracts
- nav.opened
- nav.pinned
- nav.unpinned
- search.opened
- capability.discovered
- capability.launched
- route.failed
- startup.resolved

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Fresh sign-in lands Chat/Voice.
- Returning user resumes safe conversation state.
- Normal user finds Image/Video/Live/Cosmos without Explore More.
- + Add persists pinned tool.
- Deep link to project artifact restores context.
- Advanced Mode reveals developer areas without changing normal nav.

# 12. Non-goals / prohibited shortcuts
- Do not put all 229 agents in navigation.
- Do not make Explore More the only discovery path.
- Do not route sign-in to generic dashboard by default.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/03_COMPLETE_WIDGET_SYSTEM.md`

# Complete Widget Platform
## HEY V1 — Full-depth implementation specification

**Mission:** Turn widgets into a coherent internal app surface with safe extensibility.

This specification is normative for HEY V1. A feature is not complete because a page renders or an API returns. It is complete only when discovery, interaction, state, permissions, failures, recovery, verification, accessibility, observability and end-to-end behavior all work.

# 1. Scope
- Built-in widgets, app/service widgets, custom widgets, Forge-generated widgets, size variants, interaction contracts, refresh, privacy.
- Widget library, customization, drag/drop, stacking, dock, fullscreen.

# 2. User experience contract
- Every widget has compact/standard/expanded behavior when meaningful.
- Widget has clear title, primary information and contextual actions.
- Normal users see product concepts, not provider/internal IDs.
- Widgets can be embedded in Chat/Voice/Workspace where relevant.
- One widget never hijacks the page.

# 3. Architecture / runtime contract
- Widget manifest: id/version/title/category/sizes/data sources/permissions/actions/offline/cache/privacy/render contract.
- Sandbox external/custom widgets where possible.
- Shared lifecycle: mount, load, ready, stale, degraded, error, suspended, unmount.
- Background refresh is budgeted and pauseable.

# 4. Required state model
- loading
- ready
- stale
- refreshing
- degraded
- permission-required
- offline
- error
- suspended
- hidden

# 5. Failure and recovery catalog
- API failure → stale cached state + retry.
- Permission revoked → permission-required state.
- Malformed custom widget → sandbox crash boundary.
- Refresh loop → circuit breaker.

# 6. Security / privacy / trust requirements
- Least privilege per widget.
- No raw secrets in widget code.
- Sensitive widgets can be excluded from screenshots/public modes.
- Third-party content cannot issue HEY commands as authority.

# 7. Data model / persistence
- widget_manifests
- widget_instances
- widget_cache
- widget_permissions
- widget_versions
- widget_health

# 8. Events / telemetry contracts
- widget.loaded
- widget.action
- widget.refresh
- widget.degraded
- widget.crash
- widget.permission.requested

# 9. Platform behavior
- Follow the strongest legitimate behavior available per platform; expose limitations honestly.

# 10. Implementation requirements
- Reuse shared HEY runtime, permissions, audit, verification, Project DNA, Pinpoint, Cosmos and error systems rather than creating isolated local logic.

# 11. Acceptance / regression tests
- Add/remove/reorder survives restart.
- Widget error isolated.
- Offline cached widget shows freshness.
- Custom widget permission revoke works.
- RTL and mobile variants work.

# 12. Non-goals / prohibited shortcuts
- No fake success, no UI-only placeholders, no hidden unsupported behavior, no duplicate parallel subsystem that bypasses the HEY Brain.

# 13. Definition of done
A release candidate passes only when:
- normal users can discover the capability;
- the capability works from its natural HEY entry points;
- it survives supported resume/background states;
- permissions are scoped and revocable;
- errors recover without losing user work;
- meaningful actions are verified;
- analytics/diagnostics can explain failure without exposing secrets;
- keyboard/touch/RTL/reduced-motion behavior is correct where relevant;
- mobile/tablet/desktop adaptations are intentional;
- tests exercise real integration paths, not mocked happy paths only.



---


---



### SOURCE FILE: `01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md`
**FULL original required, 254,934 characters. Read the full file in bounded sections from `SOURCE_SPLIT/HEY_FINAL/01_DETAILED_SYSTEM_SPECS/MASTER_CAPABILITY_ARCHITECTURE_DETAIL.md` before touching related components.** This file is deliberately not abbreviated or silently treated as read.

### SOURCE FILE: `02_INTELLIGENCE_EVOLUTION/04_RUNTIME_CAPABILITY_SYNTHESIS.md`

# Runtime Capability Synthesis

When a user requests an outcome for which HEY has no current capability, HEY should not default to “unavailable.” It should attempt to synthesize the missing capability safely.

## Flow
Request → capability search → gap confirmed → research implementation paths/APIs/libraries/local methods → choose architecture → create smallest capable tool/workflow/agent/adapter/code module → dependency/provenance checks → sandbox → Risk Twin → Solution Twin → adversarial tests → functional tests → execute the original user task → verify outcome.

The synthesized capability is **temporary by default**. The controlling user/owner can choose:
- Save;
- Modify, then Save;
- Delete.

Until saved it is isolated, scoped and disposable. Saved capabilities are versioned, auditable and rollbackable.

## Safety without making the feature weaker
Undo is valuable but cannot reverse exfiltration, an external payment or public disclosure. Therefore generated capabilities use scoped permissions, network/filesystem/tool allowlists, resource budgets, snapshots, sandboxing and action verification before execution. The Solution Twin must find designs that preserve or improve useful capability rather than lazily deleting risky functionality.

## Capability provenance
Record why it was created, models/agents involved, source research, dependencies, permissions, code/config changes, test results, risk findings, mitigations, version, usage and save/delete decision.


---




## Packet receipt and completed work must demonstrate

- List actual source file revisions/hashes, read sections and remaining coverage gaps.
- Name exact UI, API, DB, native/device entrypoints and shared global contracts in current HEAD.
- Connect genuine user journey through real APIs and record tests for both normal and hostile cases.
- Preserve privacy/least privilege; no self-certified completed status.
- Provide commit, independent verification, failure receipts, rollback, actual spend/latency, and specific external blockers.
