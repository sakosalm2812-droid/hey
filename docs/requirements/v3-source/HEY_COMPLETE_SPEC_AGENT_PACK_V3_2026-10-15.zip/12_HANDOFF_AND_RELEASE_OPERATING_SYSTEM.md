# HEY — ENGINEERING OPERATING SYSTEM, NOT ANOTHER AUDIT LOOP

## Stable roles; avoid duplicated tasks

- **Director/coordinator:** Owns immutable current spec pointer, branch integration queue, release gates and source dispatch; never self-certifies product completion.
- **Frontend owner:** Owns shared shell, chat/voice/Spaces/Living Answers design system, responsive accessibility, and real feature integration surfaces; cannot be overwritten by 10 agents without explicit merge control.
- **Domain owners:** Implement vertical feature outcomes with actual integration points, not only helper libraries.
- **Trust/data owner:** Owns auth/RLS/mandates, cross-boundary isolation, migration correctness.
- **Platform/Edge owners:** Real permission-safe OS adapters, smartboards and device verification.
- **Independent QA:** Writes/executes tests without relying on feature author's mocked fixtures; can block release and reopen defects.
- **Release operator:** Maintains staging, CI checks, observability, backup/restore, rollback and artifact integrity; actual deployment needs authorized access.

## 4 canonical queues

1. **SOURCE-UNMAPPED:** requirement unclear, inaccessible or contradicted; continue other work.
2. **IMPLEMENTATION:** design+code+UI+data+OS/provider coupling incomplete.
3. **VERIFICATION:** built but real full-path evidence missing, on-device/service test needed.
4. **RELEASE:** verified journeys combined but operational/environment/legal gate pending.

A requirement cannot move directly from source inventory to production-ready without implementation and independent verification evidence.

## Atomic work order required for every task

```
work_id:
source_revision_hash:
original_source_paths_and_ranges:
latest_amendment_ids:
owner_branch_sha:
user_observable_outcome:
UI_entry_and_native_entry:
existing_code_paths:
service_DB_and_OS_dependencies:
API_contracts_events_and_permission_mandates:
action_failure_cases:
positive_negative_accessibility_tests:
real_integration_environment:
independent_verifier:
artifact_or_receipt_path:
external_blocker_if_any:
next_merge_action:
```

Any blank field is a `NEEDS_RECONCILIATION` or `NOT_APPLICABLE` with reason; don't hide it. Include necessary source text/links retrievable by the executor; SHA and file existence check required. State must be stored in tracked repository files or real durable issue system, not merely an ephemeral assistant message.

## Parallel execution rules

Canonical integration branch based on latest confirmed HEY SHA. Agent branches/worktrees fork from an explicit SHA; no one merges unrelated branch state without CI and conflict reconciliation. Shared schema/permission changes require contract review before downstream feature work. One frontend owner adjudicates UI component conflicts. Independent QA doesn't modify production evidence to make tests pass. Use a merge train: branch → unit/contracts → integration preview → automated E2E → independent review → canonical merge → staging smoke → release candidate.

## Vertical slices that still preserve ultimate scope

Vertical delivery is a **method**, not permission to reduce scope. Complete user task paths in parallel with the full ongoing 47 workstreams. Immediate integration clusters:
1. user registration → Chat/Voice → provider response → Cosmos save/retrieve → organization isolation;
2. onboarding → Tools → custom Space → sync/reload → permission revocation;
3. Edge install/pair → HEY Flow into another application → live feedback/cancel → restart recovery;
4. gestures → teacher presentation next/previous/zoom → false-positive inhibition → camera-revoke;
5. chat artifact creation → embedded Studio → precision edit → export → reopen/version rollback;
6. agent mission → action mandate → execution → independent outcome receipts → recovery;
7. persistent Living Answer mini-app → real calculation/action → safe sandbox → reload/permission change;
8. model selection/Fusion → evidence-backed multi-provider result → spend limit/failure path;
9. protected school org → teacher plans/quiz → export → cross-tenant denial;
10. app install/update, offline/reconnect, observability, staging/rollback and privacy.

No slice is deemed fully production ready while other relevant original/new requirements for that capability remain unmet.

## Defect severity

`BLOCKER`: data leak, authorization bypass, destructive fake success, unsafe payments, integrity loss, app unlaunchable, core journey impossible. `CRITICAL`: major functionality broken/privacy risk/corrupt recovery. `HIGH`: important incomplete functionality or unsupported prominent control. `MEDIUM`: noncritical UX; `LOW`: cosmetic. Source a ticket with exact reproduction, logs and SHA; assign one owner; require independent retest on fix commit.

## Evidence gate

```
IMPLEMENTED ≠ VERIFIED.
unit test pass ≠ E2E pass.
mock result ≠ provider response.
HTTP 200 ≠ user outcome.
UI success animation ≠ actual external action.
model opinion ≠ human/device/tester evidence.
```

Deployment evidence must include URL/build, CI run, timestamp, health endpoint, auth/DB/provider real checks, logs, and rollback operation. For a local device, evidence includes OS version, helper process/version, expected state before/after, device permissions and demonstrable actual result. Avoid embedding personal records/secrets in screenshots.

## Resource/latency governance

Record per-request token costs, estimated and realized vendor spend, job time, queue depth, cache hit, failure retries and abuse controls; hard limits before expensive side effects; legal hosting/merchant eligibility checks; weak-laptop performance tests; approved cloud budget $25–50 per month as starting target, with overage prevention/alerts. Never burn budget just to claim a benchmark. No unattended infinite codex promise without a persistent actual scheduler.

## Definition of final release

Not guaranteed perfect bug-free. Release only after acceptance criteria and security/privacy gate pass on supported target environments, external ownership/merchant/school approvals obtained, rollback tested and remaining limitations explicitly accepted by authorized owners. Continue iteration after release with real user feedback.
