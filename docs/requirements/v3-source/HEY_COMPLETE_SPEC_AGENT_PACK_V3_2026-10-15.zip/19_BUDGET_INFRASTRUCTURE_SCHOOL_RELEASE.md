# $25–50 HEY INFRASTRUCTURE / SMALL LEADERS PILOT — DETAILED OPERATIONS

**Spending is capped by user approval, not by this file.** The $49 illustration below is a *proposed allocation*, not a guarantee of exact vendor invoice or purchase approval. Prices, limits and merchant geography change and must be verified on enrollment.

| Monthly allocation | Target | Enforcement |
|---:|---|---|
| $25 | one managed Supabase production project with Auth/Postgres | avoid extra paid projects/compute upgrades; alerts and isolation; review billable usage |
| $5 | Cloudflare Workers Paid web/API | deploy staged then production; request/CPU, queue/storage traffic monitoring |
| $12 | prepaid real AI inference | $7 public test, $3 teacher pilot, $2 QA; no auto-recharge, app-level atomic reservation |
| $2 | annual domain price amortized | domain actually billed annually; choose registrar and track renewal |
| $5 | contingency buffer, not pre-authorized overage | reserve; spend requires review |
| **$49** | proposed maximum planned allocation | allow provider taxes/overages only after explicit approval; hard stop features as needed |

Object storage and queues use applicable free allowances where eligible; if projected overage arises, stop noncritical media tasks or change approved plan before charges. Actual backups, egress, storage, email volume and operational support must be measured. Dedicated GPU hosting, large model fine-tuning, continuous research sweeps and unrestricted generative video are NOT economically covered here.

**Environment boundaries:** dev local/test accounts, staging synthetic-only Auth/DB/storage, production guarded credentials. Branch CI uses no prod write key; migration rehearsal on staging; promote approved schema to production; service-role keys never to browser/local mobile package. Project/Space/user/organization RLS exercised with adversarial tenant reads/writes. School teacher pilot 5–10 invited users max initially, scoped inference budget and synthetic pupil records, no public student enrollment without explicit agreement. Teacher access codes must be short-lived, revocable and not replace real authentication.

**Backend/queue requirements:** durable DB transaction and outbox for action mandates/scheduled missions; Workers API bounded runtime; Queues/Workflows or equivalent durable worker; idempotent requests/reconciliation; R2-style private object store with signed URLs, expiration and quota enforcement; background tasks never rely on a browser tab remaining open.

**Monitoring:** deployment and health check, provider errors, time-to-first-token and p95 end-user latency, conversion, active mission queue, orphaned job count, budget remaining, storage, login recovery, auth abuses, tenant denial events, media generation charges. Alert S&A before critical spend thresholds; protect secrets/PII in logs. Real backup **restore** exercise required, not just enabled backups.

**School costs:** cloud teacher usage is included in $3 illustrative inference portion, not a promise of unlimited use. Printing, staff time, on-site hardware/cameras, tablets, travel, branded marketing, insurance/contracts and paid school support are outside this cloud $49 allocation. Formal school student data needs written permissions and legal safeguards.

**Payments and ownership:** merchant provider must accept the legitimate operating business's location/age and type; no assumption Stripe/Paddle accounts are available to S&A in Iraq. Authorized adult/business representative may be needed. Build provider-neutral entitlements, invoicing or enabled local processing only upon verified approval; never simulate a working payment checkout.

**Go/no-go gate:** real smoke sign-up, provider-backed chat, history/Space persist, school isolation, one authorized Edge action, undo/recovery, queue restart, backup restore, cost cap, phone/desktop accessibility, privacy/help/terms/support, and independent QA. Launch criteria are evidence, not a promised date.
