# HEY — COMPLETE ABSOLUTE PRODUCT, REFINEMENT, MODEL & ENGINEERING SPECIFICATION

**Edition:** Consolidated 2026-10-15 engineering handoff.  
**Product:** HEY — AI Life Operating System. **Organization:** S&A.  
**Status:** Requirements and engineering instructions, **not** a claim of implemented or verified capabilities.  
**Repository:** `https://github.com/sakosalm2812-droid/hey`.  
**Latest coordinator-reported checkpoint (NOT independently revalidated by this compilation):** branch `codex/resume-emergency-2026-10-14`, SHA `5f09406`, earlier handoff checkpoint `df994cc`; reported automated tests 500/500, Fusion/Edge 73/73, lint and build passing, but NO live DB / deployment / native device / real provider / real browser E2E verified. Treat as historical report to recheck against live HEAD.

## START HERE — binding document rules

This is a **composite source preservation + newest amendment** document. Never use one subsection out of context or confuse its size with an implementation claim. All accessible original source texts are embedded **verbatim** at the end, with file boundaries and hashes. A separate agent-pack ZIP carries split source sections for reliable retrieval.

**Source authority:** (1) the user's express latest approved corrections and this dated user-approved amendment, (2) newest `00_FOUNDATION`, `02_INTELLIGENCE_EVOLUTION`, `03_INTERACTION_PLATFORM`, `04_SECURITY_GOVERNANCE`, `05_EXECUTION`, `06_PROMPTS` materials inside the original combined source, (3) corresponding detailed source sections, (4) historical refined engineering materials and 47 step contracts as supporting implementation specification, (5) older Product Bible for historical features where not superseded. Codebase = actual implemented state, not normative feature intent. If contradictions persist, log and resolve with source citations; do not silently choose convenient interpretations.

**Important provenance:** This compilation covers documents actually available in the conversation runtime and a set of remembered/recently discussed user decisions. It cannot certify that all past private conversations, all branches or the inaccessible historical ledger were searched or recovered. Recover further source records when authorized and amend the ledger; never invent absent content or claim universal completeness. Details labeled **RECOMMENDATION** below are engineering proposals to evaluate, not an assertion that the user already chose them.

**Three distinct statuses:** APPROVED USER REQUIREMENT; SOURCE DOCUMENT CONTRACT; RECOMMENDED IMPLEMENTATION. Maintain the distinction in every agent brief. A requirement is verified only if supported by working UI/backend/service/device evidence, not by this document's existence.

**Never:** turn HEY into 4,210 disconnected UI features; drop later changes; reduce full product to a fictional MVP; call prototypes production; fabricate trained weights/benchmarks/URLs; claim models are owned without licensing/weight artifacts; trust tests alone; process real school data absent proper authorization; expose API keys or old `.env` files; assume an AI agent read a file merely because another agent saw it; grant irreversible or sensitive rights without policy and user authorization.

### Navigation for the combined file

1. `LATEST APPROVED REFINEMENTS` — updated HEY specification with explicit behavior and test journeys.
2. `HEY MODEL FLEET AND TRAINING MANUAL` — model sources, specialist types, fine-tuning and deployment playbooks.
3. `PRODUCT INTEGRITY, RELEASE AND ACCEPTANCE` — decision continuity, requirements indexing, agent handoffs, integration and evidence.
4. `FULL PRESERVED AUTHORITATIVE SOURCE ARCHIVE` — original source documents reproduced unabridged with hashes and precedence annotations.

### Terms

- HEY Brain: single user-facing intelligence and orchestration identity; does not imply one underlying neural net.
- HEY One: branded primary model **program**; initially an adapted licensed open-weight foundation plus tool/runtime integration; not a claim of training a new large model.
- HEY Fusion: adaptive collaboration across independent models and non-LLM tools, not magic merging of inaccessible commercial weights.
- UltraSparse: measured compute-efficiency research, not a validated sub-millisecond whole inference engine.
- HEY Edge: compact local permissioned device runtime, not necessarily a local large LLM.
- Cosmos: governed user/project memory and provenance.
- Forge: governed tool/agent/workflow/capability synthesis.
- Living Answers: structured, genuinely interactive generative UI inside HEY conversation and Spaces.
- Product Integrity Engine: durable requirement/change/implementation evidence graph to avoid lost or contradicted decisions.

---

## Continuation additions — 2026-10-15 revision 2

**Read these in addition to existing instructions:**
- `05_MODEL_ACQUISITION_ADAPTATION_AND_DEPLOYMENT_BLUEPRINT.md`: exact model sources, choices, training, evaluations, serving, cost/security and worked examples.
- `06_E2E_USER_JOURNEYS_AND_ACCEPTANCE_TESTS.md` and `E2E_ACCEPTANCE_CASES.jsonl`: 57 real-user journey contracts; all intentionally marked NOT EXECUTED until a real runner verifies them.
- `07_ALL_75_MODEL_ROLE_IMPLEMENTATION_CARDS.md`: role-by-role implementation contracts; roles are not necessarily independent checkpoints.
- `AGENT_BRIEFS/`: 13 expanded briefs now include complete relevant newer requirements and original source documents where short enough; explicitly references larger source files where needed.
- The older master and archives remain unchanged. Do not claim the update recovered unavailable past conversations or actually trained/deployed a model.

## All 47 original workstream prompts now individually available

Use `08_FULL_47_WORKSTREAM_PROMPT_INDEX.md` and `WORKSTREAMS/ORIGINAL_47_FULL_PROMPTS/` for the full task-by-task historical engineering text. Each task MUST be reconciled with newest refinements and actual HEAD; do not use old assumptions that the HEY repository is unavailable.

## Coordinator activation

`09_SEND_TO_HEY_COORDINATOR.md` is a ready-to-send, source-backed instruction and acceptance gate. Attach the ZIP; sending that instruction without the ZIP does **not** transmit the original source text.
