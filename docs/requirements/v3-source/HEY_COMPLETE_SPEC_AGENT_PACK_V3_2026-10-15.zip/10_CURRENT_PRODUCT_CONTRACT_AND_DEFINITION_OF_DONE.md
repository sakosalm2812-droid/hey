# HEY — CURRENT EFFECTIVE PRODUCT CONTRACT

This chapter states the final unified architecture and critical details that must be carried into **every** subsystem. Source is the user's HEY original specification, the 47 workstream program, and newer approved decisions; where this chapter adds a technical recommendation it is labeled **ENGINEERING RECOMMENDATION**, not retroactively attributed to the user.

## One coherent product; no default dashboard maze

Upon sign-in, navigate to the unified Chat/Voice Conversation Surface. Restore safe conversation/project/active mission state; support user-configured startup location. Home, Tools, Spaces, Activity, Settings are prominent conceptual destinations. Dedicated Create, Projects, Cosmos and Live experiences must be discoverable without forcing a separate bot or mandatory dashboard. A user can run HEY Flow or gesture control without opening a chat. Voice/Chat/Live share the same conversation identity, attachments, user context, files, active artifact, project and permissions; modality changes do not clone sessions.

## Home/Spaces/Tool Library — exact interactions

Initial multi-select prompt: `Why do you want to use HEY?` with AI Assistant; AI Models; Control & Automation; Create & Build; Teaching & Learning; Life & Work; Custom; Skip. Selection affects layout/recommendations, not allowed capabilities. Persist answers with version and timestamp; edit later; treat Skip as non-blocking. User creates named Spaces, optionally from starter templates or instructions; adds/removes/reorders cross-category tools, widgets, shortcuts and project artifacts; saves and reloads layout; duplicates, archives, deletes with confirmation and recovery; keeps per-device/responsive variants. Pinning a tool never conveys school or filesystem permission. Search sees all eligible installed/discoverable tools, supported platform and missing dependencies. Disabled states explain actual reason, with request-permission or alternative flow only if legitimate.

## Conversation and answer system

Allow concise/expanded mode, answer-first when helpful, citations with reliable source metadata, actual file/URL references, truthful uncertainty, live/voice spoken summaries, original supporting detail in transcript. HEY Living Answers dynamically renders validated widgets, charts, maps, pickers, forms, comparisons, media previews, calendars, checklists, editable documents/spreadsheets/presentations, code previews, mini-apps and mission approvals, **only when useful**. Widgets have typed schema, source freshness, loading/error/offline/revoked-permission and accessibility states. Any external action must go through the real action authorization/verification runtime. Generated code must run in a constrained sandbox; no arbitrary renderer-side access to HEY credentials. Save an answer widget to Space and persist safe state/permissions; when reopened on another device, degrade gracefully if native functionality is unavailable.

## HEY Detail Intelligence / Product Integrity

Remember approved requirements/decisions, refinements, rejected suggestions and provenance. Preserve raw source, effective current intention, relations, timestamps, access policies and conflicts. Latest explicit approval wins only in the actual conflicting scope; unchanged compatible behavior survives. Approval status is not inferred merely because the assistant suggested a feature. Before significant answers or completed missions, check: goal fit, unmentioned dependencies, permission/financial/privacy impacts, missed previous constraints, contradictory suggestions, unverified success, status uncertainty. Keep criticism efficient and appropriate to complexity; do not invent facts. Agents operating on user projects use spec retrieval and a Missing Requirement Hunter plus an independent Outcome Judge, but must never claim that model self-review replaces real test evidence.

## HEY Brain / model / agent architecture

One HEY identity orchestrates deterministic rules, classifiers, retrieval, local models, hosted model endpoints, sparse expert routing, context compiler, specialized agents, tool actions, planner/executor/independent-verifier and, when justified, a multi-model Intelligence Council. HEY One names an owned application/model program, not ownership of third-party base weights. Start with economical shared inference and train adapters only after verified improvement on representative tasks. HEY Fusion uses task-sensitive escalation and independent verification, not unconditional parallel paid model calls. HEY UltraSparse explores sparse selection and MoE-like efficient routing; sub-1ms in-process selection is an explicit measurable research objective on specified hardware, **never** a guarantee of full inference latency. Local Edge executes scoped approved device actions, not the whole massive model.

## Interaction modalities

Voice option: deep calm British male; alternative voices and adjustable wake phrase, subject to availability and consent. Chat/Voice/Live synchronize. Include barge-in, speech activity, subtitles, transcript, state machine idle/listening/thinking/speaking/interrupted, visible mic/screen/camera indicators. Wake-word capture local where feasible; respect OS background constraints. HEY Flow writes dictated text into authorized focused apps, supports punctuation, cleanup, correction, clipboard fallback disclosed, custom dictionary, snippets, translation, selected-text rewrite and app profiles. VoiceOS carries out GUI/filesystem/browser commands with Guide/Assist/Act scope, authentic OS adapter, target resolution, high-impact approval, postcondition proof, cancellation/rollback where feasible. Gestures: hand detection, calibration, pinch/click, swipe navigation, palm/fist drag, two-hand scale, pause/stop, accessibility alternatives, per-app mappings, debouncing/conflict detection, false-positive protection; camera local when possible. An Android smartboard without a camera requires supported external camera or paired companion — never fabricate hardware.

## Creation and pinpoint editing

Studios for images, edited images, audio, video, storyboard, motion graphics, presentations, documents, spreadsheets, coding/web apps and knowledge transformations. A creation can start inside Chat/Voice and produce a synchronized embedded Studio, expand to full Studio and collapse without losing state. Pinpoint: scope an edit by object/selection/time/slide/file/region, lock unaffected invariants, version input/output, compute semantic/structural/visual diffs, undo and only report changed elements. For video, preserve character/shot continuity, approved frames, voiceover timing and export constraints. For slides/docs, actual editable artifacts with text structure, citations, theme/layout, live preview and export validation. For coding, compiled/runnable software with real tests and repository safety, not screenshots pretending to be apps. Costly media generation must check quotas before dispatch.

## Cosmos, situations and organizations

Source-aware temporal memory with explicit privacy scope, user correct/delete/export/retain controls, stale/conflict markers, no false claims of permanent retention for unsupported contexts. Project DNA stores approved design/technical/content invariants and connects artifacts/decisions. Context compiler fetches only authorized relevant memory and documents with provenance, avoiding 1:1 dump of entire histories. Teacher Mode includes teacher preferences, curriculum/lessons, editable worksheets, quizzes, activities, presentations, explanations, age-appropriate lesson planning and classroom controls, with synthetic student data until school authorization. School organization authorization enforced on every API/database/file access; teacher tool pinned outside a school Space never grants student-record access.

## Autonomy and operations

Durable missions: requested → planned → awaiting approval → queued → running → waiting/retrying/checkpointed → verifying → verified success/partial/failed/cancelled. Command output or HTTP 200 is insufficient proof. Scheduling and automations must persist with DST-aware timezone, event dedup, idempotent operations, retriable queues, checkpoint recovery, zero blind double side effects, action receipts, and user stop/revoke. External effects that cannot be undone require preflight approval and explicit uncertainty reporting. Long-running work resumes after restart where platform permits; do not promise infinite unattended execution if there is no scheduler/worker deployment.

## Safety, quality and accessibility

Least-privilege mandates, immutable/signed action evidence where supported, revocation, real server-side policy enforcement, RLS/private storage, cloud/local boundary controls, anti-prompt injection from web/doc/screen, org isolation, minors’ safeguards, sensitive display/TV screen privacy, secure extension sandboxes, source provenance, dependency/license checks. RTL Kurdish Sorani/Arabic/English across UI, accessible keyboard/screen-reader controls, reduced-motion, weak-hardware budget, mobile/tablet/desktop adaptation, graceful offline and honest unsupported-platform behavior.

## Definition of DONE (feature)

1. Correct, source-traceable and approved specification, including latest refinements.
2. A real user-accessible entry point in HEY or supported external invocation.
3. Real typed implementation through UI/runtime/DB/provider/OS or explicit alternative.
4. Correct permission, privacy, budget, errors, retry/cancel/recovery and accessible states.
5. Normal and negative paths validated; native/platform features tested on real eligible hardware.
6. Independent observed actual end state (not executor self-report), recorded build SHA/URL/device/provider.
7. No unsupported completion claim; list scope of verified platforms and limitations.

**Feature-complete** must remain different from **production-ready**. A product can contain many implemented features while remaining blocked on school agreements, credentials, native signing, live data or disaster-recovery validation. Neither term may be falsely promoted.
