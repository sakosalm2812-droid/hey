# 07 — COMPLETE MODEL-ROLE IMPLEMENTATION CARDS

This chapter expands all 75 documented logical roles from `MODEL_ROLE_MATRIX.csv`. **Roles do not require 75 independent trained weight sets.** Every card is a design contract, not evidence the implementation exists. Role owners derive richer use cases from the original master source, verify rights and evaluate hardware before selecting weights.

## M-001 — Orchestrator / HEY One General
**Initial execution architecture:** general LLM + tool runtime. **Foundation candidate or implementation starting point:** Qwen3-8B or gpt-oss-20b.
**Training/evaluation input program:** multi-step mission traces, precise final state, correct tool selection.
**Measurable evaluation:** task success, evidence fidelity, cost and latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-002 — Intent and task classifier
**Initial execution architecture:** small typed classifier/rules. **Foundation candidate or implementation starting point:** small encoder or Qwen3-8B as temporary.
**Training/evaluation input program:** user utterances labeled intents and uncertainty.
**Measurable evaluation:** macro-F1, OOD abstention, multilingual.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-003 — MicroDecision router
**Initial execution architecture:** calibrated small classifier. **Foundation candidate or implementation starting point:** linear/GBDT/tiny transformer.
**Training/evaluation input program:** routes labeled by successful provider outcomes.
**Measurable evaluation:** calibration ECE, expected cost, regret.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-004 — Complex reasoning
**Initial execution architecture:** reasoning LLM endpoint/open weights. **Foundation candidate or implementation starting point:** gpt-oss-120b hosted candidate.
**Training/evaluation input program:** challenging constraint reasoning and verified answers.
**Measurable evaluation:** task correctness, tool consistency, spend.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-005 — Researcher
**Initial execution architecture:** general model + web connectors. **Foundation candidate or implementation starting point:** Qwen3-8B or hosted powerful reasoning.
**Training/evaluation input program:** source analysis and citations with freshness.
**Measurable evaluation:** citation precision, source traceability.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-006 — Evidence and citation verifier
**Initial execution architecture:** deterministic URL/source validator + LLM. **Foundation candidate or implementation starting point:** text entailment model + browser fetch.
**Training/evaluation input program:** claim/source entailment adversarial pairs.
**Measurable evaluation:** unsupported-claim catch rate.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-007 — Summarizer
**Initial execution architecture:** general LLM adapter. **Foundation candidate or implementation starting point:** Qwen3-8B or smaller candidate.
**Training/evaluation input program:** faithful summaries of long docs/meetings.
**Measurable evaluation:** fact preservation, omissions.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-008 — Fact-checker / epistemic critic
**Initial execution architecture:** separate model pass + retrieval. **Foundation candidate or implementation starting point:** gpt-oss-20b or separate provider.
**Training/evaluation input program:** contradictions, uncertainty, evidence checking.
**Measurable evaluation:** hallucination detection precision.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-009 — Strategist / business analyst
**Initial execution architecture:** general LLM tools + spreadsheet models. **Foundation candidate or implementation starting point:** Qwen3-8B plus verified numerical tools.
**Training/evaluation input program:** business planning, constraints and assumptions.
**Measurable evaluation:** financial consistency, missing risks.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-010 — Missing-requirement hunter
**Initial execution architecture:** retrieval + change graph + reasoning. **Foundation candidate or implementation starting point:** Qwen3-8B or gpt-oss-20b.
**Training/evaluation input program:** multi-turn specs, supersession and omission labels.
**Measurable evaluation:** recall of omitted approved requirements.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-011 — Decision historian / conflict resolver
**Initial execution architecture:** temporal database + NLI/LLM. **Foundation candidate or implementation starting point:** Qwen3-8B + graph query.
**Training/evaluation input program:** approval/rejection/override labeled conversation cases.
**Measurable evaluation:** false approval rate, lineage accuracy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-012 — Coding architect
**Initial execution architecture:** code specialist + repository tools. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** code architecture and module maps.
**Measurable evaluation:** implementation acceptance, contract compatibility.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-013 — Coder / code generator
**Initial execution architecture:** code-specialized LLM. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** licensed source-to-patch examples and tests.
**Measurable evaluation:** compile/pass real project tests, patch quality.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-014 — Code editor / surgical refactor
**Initial execution architecture:** code LLM with AST/diff validator. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** minimal before/after diffs with locked content.
**Measurable evaluation:** unrequested diff count, unit tests.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-015 — Debugger / repair
**Initial execution architecture:** code model + debugger/test runner. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** failing logs, root causes, verified repair patches.
**Measurable evaluation:** independent reproduced-fix rate.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-016 — Test writer
**Initial execution architecture:** code LLM + test oracle. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** edge/failure/integration test pairs.
**Measurable evaluation:** fault detection mutation score.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-017 — Security code reviewer
**Initial execution architecture:** rule scans + separate reasoning. **Foundation candidate or implementation starting point:** gpt-oss-20b or code model.
**Training/evaluation input program:** CWE and permission-boundary labeled code.
**Measurable evaluation:** true critical findings; false positives.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-018 — Dependency/license auditor
**Initial execution architecture:** deterministic SBOM + policy + reasoning. **Foundation candidate or implementation starting point:** no separate weights required.
**Training/evaluation input program:** package manifests/model cards/licenses.
**Measurable evaluation:** known-vulnerability detection, compliance.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-019 — DevOps / release engineer
**Initial execution architecture:** structured code/infra model. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** CI/deploy/config migration fixtures.
**Measurable evaluation:** deploy/rollback reproducibility.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-020 — SQL/database specialist
**Initial execution architecture:** code/general model + query parser. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** schema migration/RLS/queries + expected plans.
**Measurable evaluation:** query correctness, tenancy policy tests.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-021 — API integration specialist
**Initial execution architecture:** code/general + protocol validators. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** real provider SDK/schema/error specimens.
**Measurable evaluation:** contract compatibility and real calls.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-022 — Frontend UI engineer
**Initial execution architecture:** code model + browser screenshot comparator. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B.
**Training/evaluation input program:** accessible React/layout tasks and references.
**Measurable evaluation:** DOM/interactions/a11y/visual regression.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-023 — UI/UX creative designer
**Initial execution architecture:** multimodal general + design tokens. **Foundation candidate or implementation starting point:** hosted vision-language model plus rules.
**Training/evaluation input program:** premium interface preference labeled designs.
**Measurable evaluation:** human usability, design-system compliance.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-024 — Product/design editor
**Initial execution architecture:** vision+layout constraints / programmatic renderer. **Foundation candidate or implementation starting point:** licensed image/editing model if needed.
**Training/evaluation input program:** before/after exact-region preservation.
**Measurable evaluation:** locked-region pixel/structural changes.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-025 — Image prompt engineer
**Initial execution architecture:** LLM + image model. **Foundation candidate or implementation starting point:** Qwen3-8B → FLUX.1-schnell.
**Training/evaluation input program:** prompt-to-image alignment examples.
**Measurable evaluation:** prompt fidelity, subject preservation.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-026 — Image generator
**Initial execution architecture:** diffusion/flow model. **Foundation candidate or implementation starting point:** FLUX.1-schnell.
**Training/evaluation input program:** licensed image-text pairs; optional LoRA.
**Measurable evaluation:** human preference, artifact issues, cost.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-027 — Image inpainting / masked editor
**Initial execution architecture:** inpainting-licensed model + masks. **Foundation candidate or implementation starting point:** diffusers compatible checkpoint after license review.
**Training/evaluation input program:** mask+reference edits.
**Measurable evaluation:** outside-mask preservation, edit precision.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-028 — Image upscaler/restorer
**Initial execution architecture:** super-resolution model. **Foundation candidate or implementation starting point:** publisher-reviewed ESRGAN-like licensed model.
**Training/evaluation input program:** low/high-resolution pairs.
**Measurable evaluation:** detail fidelity, hallucination artifacts.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-029 — Visual detector / region locator
**Initial execution architecture:** vision model + grounding. **Foundation candidate or implementation starting point:** verified VLM + SAM2.1.
**Training/evaluation input program:** screen/object bounding boxes.
**Measurable evaluation:** mAP, target accuracy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-030 — Image/video segmenter
**Initial execution architecture:** segmentation model. **Foundation candidate or implementation starting point:** facebook/sam2.1-hiera-tiny.
**Training/evaluation input program:** labeled masks/temporal continuity.
**Measurable evaluation:** IoU, boundary stability.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-031 — Camera and screen understanding
**Initial execution architecture:** multimodal LLM + OCR/detection. **Foundation candidate or implementation starting point:** licensed visual-language model evaluated.
**Training/evaluation input program:** screen/frame questions with target IDs.
**Measurable evaluation:** UI ground truth, privacy/prompt injection.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-032 — Document OCR/layout
**Initial execution architecture:** OCR-VL / rules. **Foundation candidate or implementation starting point:** PaddleOCR-VL-1.5.
**Training/evaluation input program:** document lines, tables, formulas and layout.
**Measurable evaluation:** CER/WER, table structure accuracy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-033 — Chart/table interpreter
**Initial execution architecture:** OCR/layout + numerical validators. **Foundation candidate or implementation starting point:** PaddleOCR-VL + deterministic parser.
**Training/evaluation input program:** data chart source/ground-truth values.
**Measurable evaluation:** numerical extraction and provenance.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-034 — Video planner/storyboard
**Initial execution architecture:** LLM + editable timeline schema. **Foundation candidate or implementation starting point:** Qwen3-8B.
**Training/evaluation input program:** scripts → shots, continuity constraints.
**Measurable evaluation:** script-to-storyboard completeness.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-035 — Video generator
**Initial execution architecture:** video diffusion/flow API or licensed weights. **Foundation candidate or implementation starting point:** publisher-verified video provider/model.
**Training/evaluation input program:** text/video aligned short clips and controls.
**Measurable evaluation:** motion coherence, clip defects, dollars/sec.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-036 — Video editor/shot consistency
**Initial execution architecture:** scene graph + video tools + VLM. **Foundation candidate or implementation starting point:** code+vision + ffmpeg.
**Training/evaluation input program:** shot-level edit instructions, locked clip cases.
**Measurable evaluation:** edit locality, audio/video sync.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-037 — Motion graphics generator
**Initial execution architecture:** code/scene renderer + LLM. **Foundation candidate or implementation starting point:** Qwen3-Coder-30B-A3B + renderer.
**Training/evaluation input program:** typographic/vector animation scene graphs.
**Measurable evaluation:** editable output, timing, export fidelity.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-038 — Music/sound generator
**Initial execution architecture:** licensed audio generation. **Foundation candidate or implementation starting point:** publisher-approved audio model/provider.
**Training/evaluation input program:** licensed prompt/audio examples.
**Measurable evaluation:** quality, rights compliance, latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-039 — Automatic speech recognizer
**Initial execution architecture:** ASR model. **Foundation candidate or implementation starting point:** Whisper large-v3-turbo.
**Training/evaluation input program:** consented multilingual/accent/noise speech.
**Measurable evaluation:** WER/CER, Sorani/Arabic tests.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-040 — Wake-word detector
**Initial execution architecture:** compact on-device keyword spotter. **Foundation candidate or implementation starting point:** openWakeWord-like licensed tool.
**Training/evaluation input program:** positive/negative background and accent clips.
**Measurable evaluation:** false activations/hr; detection latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-041 — Voice activity detection
**Initial execution architecture:** small audio classifier. **Foundation candidate or implementation starting point:** Silero VAD candidate after review.
**Training/evaluation input program:** speech/non-speech samples.
**Measurable evaluation:** missed speech, false triggers.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-042 — Voice TTS synthesizer
**Initial execution architecture:** TTS model. **Foundation candidate or implementation starting point:** Kokoro-82M for English candidate.
**Training/evaluation input program:** speaker-consented text/audio pairs.
**Measurable evaluation:** MOS/intelligibility, latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-043 — British voice adaptation
**Initial execution architecture:** consented TTS speaker/style adapter. **Foundation candidate or implementation starting point:** licensed TTS family + authorized voice.
**Training/evaluation input program:** speaker-owned voice recordings.
**Measurable evaluation:** speaker consent, intelligibility/accent.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-044 — Speaker diarization
**Initial execution architecture:** speaker embedding+clustering. **Foundation candidate or implementation starting point:** pyannote Community-1.
**Training/evaluation input program:** consented speaker-labeled audio.
**Measurable evaluation:** DER and privacy retention.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-045 — Audio enhancement/noise suppression
**Initial execution architecture:** DSP/audio denoiser. **Foundation candidate or implementation starting point:** RNNoise-class DSP or vetted open model.
**Training/evaluation input program:** noisy/clean speech pairs.
**Measurable evaluation:** PESQ/STOI proxy, latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-046 — Speech translator/dubber
**Initial execution architecture:** ASR + translation + TTS chain. **Foundation candidate or implementation starting point:** Whisper + approved multilingual LLM + TTS.
**Training/evaluation input program:** consented parallel languages.
**Measurable evaluation:** meaning fidelity, timestamps.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-047 — Sorani Kurdish language assistant
**Initial execution architecture:** multilingual LLM adapter + lexicon. **Foundation candidate or implementation starting point:** Qwen3-8B, benchmark only.
**Training/evaluation input program:** licensed Sorani prompts/transcripts/reviews.
**Measurable evaluation:** native-speaker quality, orthography.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-048 — Kurmanji language assistant
**Initial execution architecture:** multilingual LLM + lexicon. **Foundation candidate or implementation starting point:** Qwen3-8B, benchmark only.
**Training/evaluation input program:** native vetted Kurmanji dialogues.
**Measurable evaluation:** native-speaker adequacy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-049 — Arabic language assistant
**Initial execution architecture:** multilingual LLM. **Foundation candidate or implementation starting point:** Qwen3-8B.
**Training/evaluation input program:** MSA/dialect benchmark/teaching materials.
**Measurable evaluation:** grammar, dialect quality.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-050 — Translator / localization QA
**Initial execution architecture:** translation model + glossary. **Foundation candidate or implementation starting point:** Qwen3-8B or OPUS specialized pair.
**Training/evaluation input program:** parallel corpora, glossary constraints.
**Measurable evaluation:** COMET-like + human preference.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-051 — Teacher lesson planner
**Initial execution architecture:** general LLM + curriculum tools. **Foundation candidate or implementation starting point:** Qwen3-8B education adapter.
**Training/evaluation input program:** teacher-authored approved curriculum lessons.
**Measurable evaluation:** curriculum alignment and teacher ratings.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-052 — Quiz and worksheet writer
**Initial execution architecture:** general LLM + validators. **Foundation candidate or implementation starting point:** Qwen3-8B teacher adapter.
**Training/evaluation input program:** difficulty/rubric aligned question-answer pairs.
**Measurable evaluation:** correct answer rate, diversity, editability.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-053 — Tutor / misconception detector
**Initial execution architecture:** general LLM + retrieval. **Foundation candidate or implementation starting point:** Qwen3-8B + curriculum documents.
**Training/evaluation input program:** age-appropriate misconception/hint dialogs.
**Measurable evaluation:** pedagogical quality, correctness.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-054 — Rubric/assessment assistant
**Initial execution architecture:** typed rubric engine + LLM. **Foundation candidate or implementation starting point:** Qwen3-8B.
**Training/evaluation input program:** rubric-scored synthetic/sample answers.
**Measurable evaluation:** fairness, agreement, rationale.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-055 — Math solver / verifier
**Initial execution architecture:** symbolic tools + LLM. **Foundation candidate or implementation starting point:** SymPy + general reasoner.
**Training/evaluation input program:** equations and numeric proofs.
**Measurable evaluation:** exact result consistency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-056 — Science reasoning assistant
**Initial execution architecture:** general LLM + sourced knowledge. **Foundation candidate or implementation starting point:** Qwen3-8B with retrieval.
**Training/evaluation input program:** labeled physics/chemistry/biology QA.
**Measurable evaluation:** verified scientific correctness.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-057 — Memory embedding indexer
**Initial execution architecture:** embedding encoder. **Foundation candidate or implementation starting point:** Qwen3-Embedding-0.6B or bge-m3.
**Training/evaluation input program:** consented semantic search pairs.
**Measurable evaluation:** Recall@k, leakage prevention.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-058 — Reranker
**Initial execution architecture:** cross encoder / lexical re-ranker. **Foundation candidate or implementation starting point:** publisher-verified reranker.
**Training/evaluation input program:** query-relevant passage pairs.
**Measurable evaluation:** nDCG@k, retrieval latency.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-059 — Knowledge extraction/entity linker
**Initial execution architecture:** NER + temporal graph + LLM. **Foundation candidate or implementation starting point:** compact encoder / Qwen3-8B.
**Training/evaluation input program:** typed fact/relationship/temporal annotations.
**Measurable evaluation:** entity precision, privacy scope.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-060 — Intent for computer use
**Initial execution architecture:** typed parser / general model. **Foundation candidate or implementation starting point:** Qwen3-8B structured output.
**Training/evaluation input program:** UI task plans constrained by capabilities.
**Measurable evaluation:** action proposal validity.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-061 — GUI element locator
**Initial execution architecture:** vision/OCR/geometry model. **Foundation candidate or implementation starting point:** PaddleOCR-VL + image grounding.
**Training/evaluation input program:** screenshots and element coordinates.
**Measurable evaluation:** exact target click accuracy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-062 — Gesture recognizer
**Initial execution architecture:** MediaPipe landmark tracker + tiny temporal classifier. **Foundation candidate or implementation starting point:** MediaPipe + trained custom gesture head.
**Training/evaluation input program:** consented hand landmarks, gesture labels.
**Measurable evaluation:** per-gesture F1, false trigger/hour.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-063 — Device resource scheduler
**Initial execution architecture:** deterministic control + prediction. **Foundation candidate or implementation starting point:** small regression/GBDT.
**Training/evaluation input program:** device load, memory/battery forecasts.
**Measurable evaluation:** p95 lag, energy, fairness.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-064 — Anomaly and fraud monitor
**Initial execution architecture:** rules + calibrated model. **Foundation candidate or implementation starting point:** small classifier/GBDT.
**Training/evaluation input program:** abuse/billing anomaly labels.
**Measurable evaluation:** recall at low false-positive.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-065 — Safety / prompt-injection detector
**Initial execution architecture:** policy rules + separate text classifier. **Foundation candidate or implementation starting point:** small encoder + validator.
**Training/evaluation input program:** prompt injection/test attacks.
**Measurable evaluation:** attack catch rate, false refusals.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-066 — Compliance/privacy assistant
**Initial execution architecture:** rules and retrieval-first LLM. **Foundation candidate or implementation starting point:** Qwen3-8B plus policy library.
**Training/evaluation input program:** policy/age/data examples.
**Measurable evaluation:** policy adherence, no unsupported legal claims.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-067 — Cost/latency forecaster
**Initial execution architecture:** statistical model / rules. **Foundation candidate or implementation starting point:** gradient boosting / regression.
**Training/evaluation input program:** real per-provider usage logs.
**Measurable evaluation:** forecast error p95, spend overshoot.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-068 — Agent selector / council builder
**Initial execution architecture:** small classifier + graph. **Foundation candidate or implementation starting point:** MicroDecision Fabric.
**Training/evaluation input program:** task to agents + measured outcome cases.
**Measurable evaluation:** useful agent selection, marginal benefit.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-069 — Risk Twin
**Initial execution architecture:** separate critical reasoning + scanners. **Foundation candidate or implementation starting point:** gpt-oss-20b / independent provider.
**Training/evaluation input program:** adversarial failure patterns.
**Measurable evaluation:** severity-weighted true positives.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-070 — Solution Twin
**Initial execution architecture:** code/architecture reasoner. **Foundation candidate or implementation starting point:** Qwen3-Coder + gpt-oss-20b.
**Training/evaluation input program:** mitigations preserving capabilities.
**Measurable evaluation:** risk reduction without function loss.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-071 — Product Integrity reviewer
**Initial execution architecture:** requirements graph retrieval + model. **Foundation candidate or implementation starting point:** Qwen3-8B + deterministic diff.
**Training/evaluation input program:** conflict/omission/source provenance examples.
**Measurable evaluation:** omission catch, false authority claims.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-072 — Living Answer component selector
**Initial execution architecture:** small UI schema classifier / LLM. **Foundation candidate or implementation starting point:** Qwen3-8B + allowlisted renderer.
**Training/evaluation input program:** tasks → typed components, no unsafe markup.
**Measurable evaluation:** widget usefulness, schema validity.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-073 — Sandbox mini-app builder
**Initial execution architecture:** code model + isolated runtime. **Foundation candidate or implementation starting point:** Qwen3-Coder + secure app sandbox.
**Training/evaluation input program:** bounded app specs + tests.
**Measurable evaluation:** functional controls, sandbox escapes=0.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-074 — Customer support/help
**Initial execution architecture:** small general + knowledge retrieval. **Foundation candidate or implementation starting point:** Qwen3-8B.
**Training/evaluation input program:** documentation/support case with verified resolution.
**Measurable evaluation:** resolution, escalation accuracy.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.

## M-075 — Agent evaluator/independent outcome judge
**Initial execution architecture:** deterministic checks + external model. **Foundation candidate or implementation starting point:** independent provider or exact state tests.
**Training/evaluation input program:** task outcome truth labels and receipts.
**Measurable evaluation:** false success rate, independence.
**Completion evidence:** a frozen model/tool revision, typed output and permission scope, representative held-out dataset, independent measured improvement (or documented decision not to train), actual service result, failure-path result, cost/latency and rollback. **Forbidden:** fictitious training, invented metrics, provider API called owned weights.
