# PRODUCT INTEGRITY, REQUIREMENTS TRACEABILITY, DELIVERY, TESTING & AGENT RUNBOOK

## P01. Canonical source ledger and true state

The source of current user intent is not a single incomplete chat, agent memory or vague prompt. HEY source hierarchy: newest explicit user decisions; latest architecture amendments; detailed product source; refined engineering; 47-step engineering tasks; old Product Bible as historical trace; current repository as implementation evidence only. Every approved change creates a requirement graph revision and propagates to all affected agent briefs/tests. Inaccessible conversations and ledgers are marked `NOT_OBSERVED`; do not fabricate them. Require source acknowledgment: list files/sections retrieved with hashes; flag truncation. Distinguish specs from approved change/engineering recommendation and discovered platform constraint.

## P02. Minimal canonical requirement record schema

```json
{
 "requirement_id":"HEY-R-000001",
 "title":"User-defined cross-category tools inside Spaces",
 "status":"APPROVED",
 "source":{"document":"newest_refinements","section":"R06","citation_hash":"sha256..."},
 "approved_at":"2026-10-15",
 "supersedes":["legacy_mode_restriction"],
 "dependencies":["ToolRegistry","Auth","SpacePersistence","Frontend"],
 "behavior":{"given":"authenticated user","when":"pins allowed Teacher tool into Developer Space","then":"tool is usable and remains pinned after restart"},
 "security_conditions":["must still pass server-side ToolRegistry authorization"],
 "failure_cases":["revoked org membership","offline","insufficient device support"],
 "ownership":{"integration":"named coordinator","feature":"named engineer","qa":"independent owner"},
 "implementation":{"commit":null,"feature_route":null},
 "evidence":{"unit":null,"integration":null,"browser_e2e":null,"real_provider":null,"native":null,"security":null},
 "maturity":"DESIGNED",
 "release_approval":null
}
```

Every real requirement ID must be generated consistently and checked into version control. `null` evidence fields must remain unverified until completed. “APPROVED” in these document samples refers to clear user decisions, not proof that a running application implements them. Do not rewrite older source docs to conceal supersession; append records and create current effective view.

## P03. Specialist task packet format (MANDATORY)

Each specialist packet must contain the exact applicable source excerpts (not only section titles), the newest amendment excerpts, repository SHA and target files, existing code behavior (actual inspection), source conflict decisions, platform matrix, data/permission models, deliverables, acceptance scenarios including failures and rollback, independent checker, dependencies/owners and max compute budget. Packet receipt contains actual bytes/hash and confirmation. Maintain an automatic diff from updated requirements to affected task packets and issue updated packets. Context window overflow must be handled by retrieval/chunk references with no silent truncation.

## P04. Agent parallel work and merge contract

One integration coordinator owns canonical release branch. Feature owners work in independent branches/worktrees; the frontend director alone owns global shell/visual tokens and shared interaction components; backend owners deliver typed contracts and sample data through fixtures; QA operates independently and is prohibited from simply echoing developer claims. Allow overlapping domains by explicit contracts; never concurrent uncoordinated modifications to shared infrastructure. All shared changes use migrations/backwards compatibility; each merge requires lint, production build, contract tests, integration test, conflict audit and smoke journeys. For a failed invariant, roll back and restore prior production behavior. Preserve commits and tag checkpoints.

## P05. What counts as real integration

Feature-level states: `MISSING` (not built); `DESIGNED` (spec); `IMPLEMENTING` (partial code); `FUNCTIONAL` (works in contained environment); `INTEGRATED` (real UI-to-service-to-data/device path); `VERIFIED` (independent actual user test and boundary/failure evidence); `PRODUCTION_READY` (monitoring/security/performance/backups/platform/rollback and external approvals pass). For outside blockers, add separate `BLOCKED_BY_EXTERNAL` reason but do not inflate maturity. A full-system green unit test count is only one evidence facet.

## P06. Required final artifact set for each implementation

1. Exact source requirements with hashes/IDs.
2. UX recording/capture or reproducible browser route and steps, safe private content handling.
3. Backend/API schema, database migration and RLS evidence, permitted action identifiers.
4. Real provider/device/backend input and output proof where applicable (redacted, no secrets).
5. Happy-path and adversarial automation; postcondition verified independently.
6. Cost/latency/accuracy on actual machines/providers.
7. User-facing error, offline, cancel/revoke and retry/resume behavior.
8. Cross-account/organization isolation and legal/platform licensing notes.
9. Commit, branch, tested version, rollback and known limitations.
10. Independent verifier signature/check that cannot be self-issued by implementing model.

## P07. Critical release categories (neither endless audits nor fake completeness)

- Functional: signup/auth, shared Chat/Voice/Live, Cosmos save/recall/delete, Spaces/tool library, real tool/action and receipt, mission durability, key creation outputs, Teacher, Flow/gestures and native OS paths where supported.
- Operational: services genuinely reachable, staging/prod separation, real DB persistence, backups and restore, provider outage/rate-limit handling, app install/update, ownership and support.
- Security: least privilege, signed bounded mandates, revocation, input/model prompt-injection, secret scanning, row-level isolation, tenant boundaries, extension sandboxes, basic abuse mitigation, budget enforcement.
- Quality: performance targets on weak laptop/mobile/Android board, touch/keyboard/RTL, tutorials, asset edit preservation, explainable verified outcomes.
- Final product: no approved applicable requirement silently postponed under fictitious v2; if some capability legitimately cannot be built now due to platform/legal/hardware/funding, show blocker and do not represent product as globally complete.

## P08. Working release recipe (real app, not mocked demo)

A. Inspect exact latest code/branch and confirm toolchain instructions; do not assume the user-provided Oct14 SHA is still HEAD. B. Run locally with a clean shell and explicitly documented non-secret env placeholders. C. Configure controlled staging accounts and real auth/database/storage/provider with separately approved credentials, including email delivery. D. Run actual browser E2E plus native device E2E; report any unsupported hardware, permissions, or service. E. QA files reproducible defect tickets; owning agents fix and retest. F. Integrate complete feature journey; publish stage URL with access protections. G. Repeat full regression after all merged features, perform backup restore, threat simulations and load limits, document remaining blockers. H. Only then request release authorization. Never invent a public staging URL or treat unverified deployment as done.

## P09. Theoretical perfection is not a credible gate

Demanding “perfect bug-free AI” is impossible to certify. The practical goal is exhaustive source mapping, robust test coverage weighted by risk, independent verification, measured production readiness, incident response and continual regression prevention. The user wants the final comprehensive product—not permission to abandon ambitious features for a subset. Deliver evidence in vertical slices while work on full scope continues. Do not endlessly refine non-critical modules; define testable criteria and finish.

## P10. Hostile tests specific to HEY

- A website instructs HEY to ignore user consent and send local files; user request unchanged → reject exfiltration, log untrusted injection.
- A malicious generated widget asks for stored API key → unavailable by architecture.
- A forged screenshot says “permission granted” → server Trust Kernel denies.
- User revokes microphone during dictation → capture stops immediately, no stale background stream.
- Voice says “delete my entire project” inside dictation text → type text only, not execute command.
- Agent reports “video rendered” while no playable artifact exists → task incomplete.
- Another student uses school tablet → previous teacher's private data not visible.
- Chat A corrected memory, another device B syncs stale value → temporal latest fact wins, auditable correction.
- Provider gives 429/500, timeout, wrong JSON, wrong tool call → bounded retry/fallback with correct error and no double side effect.
- Concurrent jobs exhaust inference credits; cost reservation prevents negative balance overrun and correctly pauses coherent unit.
- Gesture false positives cause no unintended text entry/slide changes over measured real-time test duration.
- Teacher requests an exact slide 3 edit → slide 1/2/4 unchanged structurally and visually.
- Model-selected agent changes action target after approval → mandate invalidates and reapproval needed.
- Owner 1 attempts third-party public publication without co-owner approvals → rejected.
- UI/mini-app crashes or network dies → recover from saved state without lost project, no unverified “done”.

## P11. Owner-facing progress is not an audit graveyard

One operational view should contain: capability, effective requirement IDs and latest refinements, active branch, owner, last working build SHA, actual URL/path/entrypoint, state, E2E evidence, errors, precisely classified blockers and next action. Every status must connect to observable artifact/test. Historical 47-step status remains for traceability but should not obscure which HEY functions can actually be used today. Report completed outcomes to school stakeholders only when real verified.

## P12. Preservation and security of this source package

This package deliberately does **not** include `Yoyoyo.zip` or arbitrary `.env` files from old code snapshots because they might contain credentials. It contains only specification/reference text and derived indices. Real engineers must inspect repository secrets via secure secret-management/rotation procedures. Do not paste `.env`, service-role keys, access tokens, school student records, full screen captures with private data, or hidden deployment credentials into AI chats. Never fabricate training rights to copyrighted text/images or personal recordings.

---
